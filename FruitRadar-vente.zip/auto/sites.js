// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
// FruitRadar — automatisation : comment reconnaître les éléments de chaque site piloté.
// Chaque liste est essayée dans l'ordre. Quand un site change son interface, c'est ICI qu'on corrige
// (ou sans toucher au code : Réglages → Automatisation → Corrections de sélecteurs).
const SEND = ['button[aria-label*="Send" i]', 'button[aria-label*="Envoyer" i]', 'button[aria-label*="Submit" i]', 'button[aria-label*="Soumettre" i]', 'button[type="submit"]'];
const STOP = ['button[aria-label*="Stop" i]', 'button[aria-label*="Arrêter" i]', 'button[aria-label*="Interrompre" i]'];

export const SITES = {
  claude: {
    name: 'Claude', match: /(^|\.)claude\.ai$/,
    composer: ['div.ProseMirror[contenteditable="true"]', '[contenteditable="true"][role="textbox"]', '[contenteditable="true"]', 'textarea'],
    fileInput: ['input[type="file"]'],
    send: ['button[aria-label*="Send message" i]', 'button[aria-label*="Envoyer le message" i]', ...SEND],
    stop: ['button[aria-label*="Stop response" i]', ...STOP],
    streaming: ['[data-is-streaming="true"]'],
    answer: ['[data-is-streaming]', '.font-claude-response', '.font-claude-message'],
    userTurn: ['[data-testid="user-message"]'],
    loginText: '^(log in|se connecter|continue with google|continuer avec google)$',
    endMark: '@@\\s*(FINI|SUITE|CHOIX)\\s*@@', // dernière ligne d'une réponse complète (voir auto/protocol.js)
    pasteMayAttach: true
  },
  chatgpt: {
    name: 'ChatGPT', match: /(^|\.)chatgpt\.com$/,
    // repères relevés sur le vrai chatgpt.com (novembre 2026), puis les anciens en secours
    composer: ['form .ProseMirror[contenteditable="true"]', '#prompt-textarea', 'div.ProseMirror[contenteditable="true"]', '[contenteditable="true"]', 'textarea'],
    fileInput: ['form input[type="file"]', 'input[type="file"]'],
    send: ['form button[aria-label="Envoyer"]', 'form button[aria-label^="Send" i]', '[data-testid="send-button"]', '#composer-submit-button', ...SEND],
    stop: ['[data-testid="stop-button"]', ...STOP],
    answer: ['[data-message-author-role="assistant"]', 'article[data-turn="assistant"]'],
    userTurn: ['[data-user-message-bubble]', '[data-message-author-role="user"]', 'article[data-turn="user"]'],
    turn: '[data-turn-key]', // un échange (ton message + la réponse)
    turnBox: ['[data-user-message-bubble]', 'article', '[data-testid^="conversation-turn"]', '[data-turn]'],
    turnState: 'data-talvt-turn-state', // « complete » quand la réponse est finie
    genImg: '[data-testid="generated-image-gallery"] img, [data-testid="generated-image-preview"] img', // les images générées (adresses blob:)
    genAlt: '(image générée|generated image)',
    imgDone: '(modifier|partager|copier|t[ée]l[ée]charger|edit|share|copy|download)[^|]{0,24}image', // boutons qui n'apparaissent qu'une fois l'image finie
    loginText: '^(log in|se connecter|connexion)$',
    minImg: 500,
    convPattern: '/c/[\\w-]{8,}' // adresse d'une conversation : on y revient toujours pour la même vidéo
  },
  grok: {
    name: 'Grok', match: /(^|\.)grok\.com$/,
    // repères relevés sur le vrai grok.com/imagine (novembre 2026) : la boîte est celle du formulaire de la page Imagine,
    // ses réglages sont des boutons à aria-label (« Durée de la vidéo », « Résolution vidéo », « Proportions », « Vidéo », « Valider »).
    composer: ['form [role="textbox"][contenteditable="true"]', 'form .ProseMirror[contenteditable="true"]', '[role="textbox"][contenteditable="true"]', 'form textarea', '[contenteditable="true"]', 'textarea'],
    resultVideo: '#hd-video, #sd-video', // la vidéo sur la page /imagine/post/…
    // le cadre de saisie d'Imagine contient la barre de réglages : 1080p · 10s · 9:16
    cardMarker: '^\\s*(\\d{3,4}\\s*p|\\d{1,2}\\s*s|\\d{1,2}\\s*:\\s*\\d{1,2})\\s*$',
    qTrig: '^\\s*(240|360|480|540|720|1080|1440|2160)\\s*p\\s*$',
    dTrig: '^\\s*\\d{1,2}\\s*(s|sec)\\s*$',
    rTrig: '^\\s*\\d{1,2}\\s*:\\s*\\d{1,2}\\s*$',
    imaginePath: '/imagine',
    fileInput: ['form input[type="file"][name="files"]', 'form input[type="file"]', 'input[type="file"]'],
    // L'envoi ne se fait QUE par la flèche du formulaire d'Imagine (voir grokFire dans auto/page.js) : aucun autre bouton « Créer », « Générer »…
    // n'est accepté, pour ne jamais relancer une génération depuis la page d'un clip ni écrire dans une conversation.
    send: ['form button[aria-label="Valider"]', 'form button[type="submit"]'],
    sendNoSubmit: true, noEnterFallback: true, changeOnly: true,
    stop: STOP,
    answer: [], userTurn: [], scope: ['main', 'body'],
    loginText: '^(sign in|log in|se connecter|connexion)$',
    // options de génération : motifs de texte des boutons
    duration: { option: (s) => `^\\s*${s}\\s*(s|sec|secondes?)\\b`, trigger: '(^\\s*\\d+\\s*s\\s*$|durée|duration)' },
    ratio: { option: '^\\s*9\\s*[:/]\\s*16\\b', trigger: '(^\\s*\\d+\\s*[:/]\\s*\\d+\\s*$|format|ratio|aspect)' },
    quality: { option: (q) => `^\\s*${q}\\s*p?\\b`, trigger: '(^\\s*(480|720|1080)\\s*p\\s*$|résolution|resolution|qualité|quality)' },
    // la page Imagine s'ouvre en mode image : on passe d'abord sur l'onglet Vidéo, AVANT de joindre l'image de départ
    videoMode: '^\\s*(vidéos?|videos?)\\s*$',
    labels: { quality: '(résolution vidéo|video resolution)', duration: '(durée de la vidéo|video duration)', ratio: '(proportions|aspect ratio)' }, // aria-label des trois réglages
    busyText: '(generating|génération en cours|\\b\\d{1,2}\\s?%)'
  },
  capcut: {
    name: 'CapCut', match: /(^|\.)capcut\.com$/,
    fileInput: ['[class*="top-part-container"] input[type="file"]', '[class*="bottom-part-container"] input[type="file"]', 'input[type="file"]'],
    dismiss: ['.lv-modal-close-icon', '[class*="modal"] [class*="close-icon"]'], // fenêtres de pub à fermer avant d'agir
    uploadText: '^(importer|upload|téléverser|charger|import)$',
    mediaCard: ['[class*="material" i]', '[class*="media-item" i]', '[class*="card" i]', 'li'],
    addButton: ['[class*="add" i]', '[aria-label*="add" i]', '[aria-label*="ajouter" i]', '[class*="plus" i]'],
    timeline: ['[class*="timeline" i]', '[class*="track" i]'],
    segment: ['[class*="segment" i]', '[class*="clip" i]'],
    transitionsTab: '^\\s*transitions?\\s*$',
    transitionText: '(fondu (au|en|vers le)? ?noir|fondu noir|dip to black|fade to black|black fade|^\\s*noir\\s*$|^\\s*black\\s*$)',
    applyAll: '(appliquer à tou|appliquer partout|tout appliquer|apply to all)',
    loginText: '^(log in|se connecter|sign in|connexion)$'
  },
  tiktok: {
    name: 'TikTok Studio', match: /(^|\.)tiktok\.com$/,
    composer: ['.public-DraftEditor-content[contenteditable="true"]', '[data-contents="true"]', 'div[contenteditable="true"]'], // description
    fileInput: ['input[type="file"][accept*="video"]', 'input[type="file"]'],
    loginText: '^(log in|se connecter|sign in|connexion)$'
  },
  /* VideoTranscriber (videotranscriber.ai) — relevé sur le vrai site le 17 novembre 2026 : on dépose le fichier, on clique « Transcribe »,
     puis l'état et le texte se lisent dans les données du site (pas de copier-coller). Compte gratuit : 10 transcriptions par jour. */
  vt: {
    name: 'VideoTranscriber', match: /(^|\.)videotranscriber\.ai$/,
    fileInput: ['input[type="file"]'],
    submit: '^(transcribe|transcrire)$',
    popup: '(desktop app|download for windows|download for mac|application de bureau)'
  },
  turbo: {
    name: 'TurboScribe', match: /(^|\.)turboscribe\.ai$/,
    fileInput: ['input[type="file"]'],
    openUpload: '(transcrire des fichiers|transcribe files)',
    submit: '^(transcrire|transcribe)$',
    busyRow: '(traitement|processing|en attente|pending|queued|file d.attente|transcription en cours|\\d{1,3}\\s?%)',
    limitText: '(limite|limit|quota|upgrade|passer à|mettre à niveau)',
    transcript: ['[class*="transcript" i]', 'article', 'main'],
    loginText: '^(log in|se connecter|sign in|connexion)$'
  }
};

/* Config finale d'un site = valeurs par défaut + corrections de l'utilisateur (listes placées en tête) */
export function siteConfig(key, overrides = {}) {
  const base = SITES[key];
  const o = (overrides && overrides[key]) || {};
  const out = { ...base, match: undefined };
  for (const [k, v] of Object.entries(o)) {
    if (Array.isArray(v) && Array.isArray(base[k])) out[k] = [...v, ...base[k]];
    else if (v !== undefined && v !== '') out[k] = v;
  }
  if (key === 'grok') { // fonctions non transmissibles à la page : on les met à plat
    out.durationOption = { 6: base.duration.option(6), 10: base.duration.option(10), 15: base.duration.option(15) };
    out.durationTrigger = (o.durationTrigger) || base.duration.trigger;
    out.ratioOption = base.ratio.option; out.ratioTrigger = base.ratio.trigger;
    out.qualityOption = { '1080p': base.quality.option(1080), '720p': base.quality.option(720) }; out.qualityTrigger = base.quality.trigger;
    delete out.duration; delete out.ratio; delete out.quality;
  }
  return JSON.parse(JSON.stringify(out));
}

export const START_URL = (key, auto) => ({ claude: auto.claudeUrl, chatgpt: auto.chatgptUrl, grok: auto.grokUrl, capcut: auto.capcutUrl, turbo: auto.turboUrl, vt: auto.vtUrl || 'https://videotranscriber.ai/', tiktok: auto.tiktokUrl }[key]);
