// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
/* Un seul téléchargement par export CapCut.
   À la fin d'un export, CapCut télécharge la vidéo tout seul. Quand l'export a été relancé (bloqué sur un pourcentage), ou quand son
   téléchargement automatique arrive en plus du bouton « Télécharger », la même vidéo arrive deux fois dans les Téléchargements.
   Ce garde laisse passer le premier téléchargement venu de CapCut et arrête les suivants dès qu'ils démarrent (rien n'est effacé du disque :
   un téléchargement arrêté en route ne laisse pas de fichier). Les téléchargements qui ne viennent pas de CapCut ne sont jamais touchés. */
export function dupGuard(host, onCut = () => {}) {
  let kept = null;
  const cut = [];
  const fromCapcut = (d) => { const s = `${d.finalUrl || ''} ${d.url || ''} ${d.referrer || ''}`; return /capcut/i.test(s) || (!!host && s.includes(host)); };
  const on = (d) => {
    if (!d || d.byExtensionId === chrome.runtime.id || !fromCapcut(d)) return false;
    if (kept === null) { kept = d.id; return false; }
    if (d.id === kept || cut.includes(d.id)) return false;
    cut.push(d.id);
    Promise.resolve(chrome.downloads.cancel(d.id)).then(() => chrome.downloads.erase({ id: d.id })).catch(() => null);
    try { onCut(d); } catch (e) { /* le journal n'est plus là : tant pis */ }
    return true;
  };
  return { on, keep: (id) => { if (kept === null && id !== undefined && id !== null) kept = id; }, kept: () => kept, cut };
}
