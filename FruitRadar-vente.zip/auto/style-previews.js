/* Images d'aperçu fournies avec les styles (dossier auto/styles), dans les deux éditions. */
export const STYLE_PREVIEWS = ["bubbletea", "cafe", "cafe_verre", "diamant", "fruits", "fruits_humains", "fruits_porcelaine", "givres", "liquide", "lumineux", "marbre", "metal", "nacres", "smartphone", "the"];
