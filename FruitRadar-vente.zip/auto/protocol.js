// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
// FruitRadar — automatisation : ce qu'on demande au rédacteur (Claude) et comment on relit sa réponse.
// Le métaprompt reste la référence pour le FOND. L'annexe ci-dessous ne change que la FORME de la réponse,
// pour qu'un programme puisse retrouver chaque prompt sans se tromper.

export const DURATIONS = [6, 10, 15];

export const ANNEX = `# ANNEXE AUTOMATISATION — FRUITRADAR (prioritaire sur les règles de mise en forme du métaprompt)

Tu es appelé par un programme, pas par un humain. Personne ne lit ta réponse : elle est découpée automatiquement puis envoyée à ChatGPT (images) et à Grok (vidéos). Toutes les lois et règles du métaprompt joint s'appliquent au CONTENU. Seule la FORME de la réponse change, comme suit.

## 1. Pas de question, pas d'attente
- La PHASE 0 est sautée : l'option choisie est donnée dans le message.
- Tu ne poses aucune question et tu n'attends aucun choix. Quand le métaprompt prévoit un choix de l'utilisateur (3 angles, version, ouverture), tu choisis toi-même la meilleure option et tu continues.
- Avant d'écrire, tu imagines 3 ouvertures différentes pour la scène 1 (première image, première réplique exacte, ce qui change avant la 5e seconde) et tu gardes la plus accrocheuse : un geste précis qui change quelque chose, une image et une réplique qui se complètent, une question précise, une réaction entre 2 et 5 secondes. Tu ne les affiches pas.
- Le tableau de script, le test du petit cousin et la proposition finale de l'autre version sont faits mentalement et ne sont PAS écrits.

## 2. Une seule forme de sortie
- Toute ta réponse tient dans UN SEUL bloc de code (ouvert par trois accents graves suivis de text). Rien avant, rien après, aucun artefact, aucun fichier. Cette règle remplace la règle « texte brut, jamais de bloc code ».
- Tu réponds directement dans le chat. Tu ne crées ni artefact, ni page, ni document, ni fichier, et tu n'utilises aucun outil (pas de recherche, pas de mémoire à consulter), même si mes préférences enregistrées ou ta mémoire disent que j'aime recevoir mes packages sous forme de page : ici, c'est un programme qui lit.
- Dans ce bloc, uniquement les blocs balisés ci-dessous. Chaque balise est seule sur sa ligne. Les valeurs sont entre guillemets droits. Chaque bloc se ferme par @@FIN@@.
- Si la réponse risque d'être coupée par la limite de longueur : termine le bloc en cours, écris @@SUITE@@ seul sur la dernière ligne, et arrête-toi. Quand tu reçois le message SUITE, tu reprends au bloc suivant, au même format, sans rien répéter.
- Quand tout est livré, la dernière ligne est @@FINI@@.

## 3. Les blocs, dans cet ordre

@@META@@
titre: [titre complet de l'histoire]
serie: [titre court de la série pour la miniature, 3 à 5 mots, ex. Le Secret des Grenadines]
partie: [numéro de la partie, donné dans le message]
accroche: [le gros titre de la miniature, 5 mots maximum, en capitales, une question ou une promesse qui donne envie de cliquer, sans révéler la fin]
duree: [somme des durées en secondes]
moteur: [moteur de conflit]
univers: [univers]
@@FIN@@

@@BIBLE@@
[Mémoire de la série, pour écrire la partie suivante plus tard, 250 mots maximum : résumé de cette partie scène par scène en une ligne chacune ; pour chaque personnage : nom, espèce, rôle, étiquette Grok, verrou de voix complet ; la question laissée ouverte.]
@@FIN@@

@@PLANCHE nom="[nom unique de la planche]"@@
[prompt complet de la planche de référence, tel que le métaprompt le définit, Directive de Style Planche comprise]
@@FIN@@
(une par personnage et par état de tenue ou de coiffure ; si un personnage a deux états, deux planches avec deux noms différents, ex. nom="Grenadina" et nom="Grenadina mariée")

@@SCENE n="1" duree="6" refs="[noms exacts des planches visibles, séparés par |]" titre="[titre court]" version="normale"@@
@@IMAGE@@
[prompt image complet de la scène, VERROU DE CADRAGE et Directive de Style de Scène compris]
@@VIDEO@@
[prompt vidéo complet, version recommandée uniquement, commençant par la phrase d'ouverture commune]
@@MONTAGE@@
fin: [le mouvement de caméra ou le geste qui termine ce clip]
suivant: [la première image du clip suivant]
montage: [ce qu'on fait au montage entre les deux : coupe franche sur le mouvement, balayage 0,2 s dans le même sens, etc.]
@@FIN@@
(une par scène, numérotées 1, 2, 3… sans saut ; duree vaut 6, 10 ou 15 ; refs reprend lettre pour lettre les noms des planches)

@@MINIATURE refs="[noms exacts des planches à charger, séparés par |]"@@
[prompt image complet de la miniature, voir point 5]
@@FIN@@

@@DESCRIPTION@@
[description TikTok, voir point 6]
@@FIN@@

@@FINI@@

## 4. Rythme et transitions (prioritaire : c'est ce qui fait qu'on regarde jusqu'au bout)
- La vidéo doit être claire, dynamique et agréable à regarder. L'histoire reste simple ; le dynamisme vient de la mise en scène : décors variés (jamais le même cadre deux scènes de suite), caméra qui bouge, gestes nets, répliques courtes qui s'enchaînent.
- Chaque scène ouvre une question nouvelle dans la tête du spectateur (qui ? pourquoi ? et lui ? et maintenant ?), jamais un rappel.
- Chaque clip SE TERMINE par un mouvement de caméra ou un geste qui appelle le plan suivant (whip-pan, push-in sur un objet, tilt vers le ciel, regard vers une porte, objet lancé). Ce mouvement final est écrit dans le prompt vidéo, comme dernier temps de l'action, et repris dans le bloc MONTAGE.
- La première image du clip suivant répond à ce mouvement (raccord de direction, de lumière, d'objet ou de regard). Au montage, une coupe franche pile sur le mouvement suffit presque partout ; les effets sont rares et très courts (0,1 à 0,2 s).
- La dernière scène coupe juste avant la réponse : le spectateur doit vouloir la partie suivante.

## 4 bis. Zéro texte à l'image
- Aucun texte lisible dans les images de scène ni dans les clips : pas de panneau, d'enseigne, de pancarte, d'affiche, d'écran, de lettre, d'étiquette ou de vêtement portant des mots, des lettres ou des chiffres. N'en demande jamais dans un prompt image ou vidéo, et ne nomme aucun lieu par un panneau.
- Si l'histoire a besoin d'un écrit (lettre, pancarte, message sur un téléphone, nom d'un lieu), on ne le lit pas : il est vu de dos, flou, hors champ, ou remplacé par un dessin ou un symbole, et c'est une réplique qui dit ce qu'il contient.
- Aucun sous-titre : les répliques s'entendent, elles ne s'écrivent jamais. Seule exception possible : la rubrique « mot fort à l'écran », si elle figure dans la demande.

## 4 ter. Qui parle (prioritaire : Grok fait parler le mauvais personnage dès que c'est flou)
- Chaque réplique est dite par UN seul personnage, et tient sur UNE ligne du prompt vidéo, à ce format exact : RÉPLIQUE n — NOM (sa place dans l'image : à gauche, à droite, au centre, au premier plan ou au fond ; son espèce ; un signe distinctif bien visible) : "texte". La place écrite est celle du personnage dans l'image de la scène.
- Jamais deux personnages qui parlent en même temps : les répliques se suivent, dans l'ordre écrit. Dans une scène à une seule réplique, un seul personnage ouvre la bouche.
- Deux personnages qui se ressemblent (même espèce, même couleur) ne sont jamais ensemble dans une scène où l'un d'eux parle, sauf si un signe distinctif net les sépare (vêtement, couleur, accessoire), repris dans la ligne de la réplique.
- Les personnages présents qui n'ont pas de réplique sont nommés dans le prompt vidéo comme silencieux : bouche fermée du début à la fin, ils réagissent avec le regard et le corps.
- Celui qui parle est bien visible, de face ou de trois quarts, pendant sa réplique ; un personnage de dos ou hors champ ne parle pas (sauf voix off voulue par l'histoire, alors écrite comme telle : RÉPLIQUE n — NARRATEUR (voix off) : "texte").

## 5. La miniature
Format vertical 9:16, même rendu 3D que les scènes. Le bloc MINIATURE décrit UNIQUEMENT l'image, jamais le texte :
- L'image la plus forte de l'épisode, sans la révéler entièrement : les deux personnages principaux au premier plan dans un moment d'émotion lisible en un quart de seconde, et le personnage rival ou témoin au second plan, plus petit, qui les regarde, visage net. Lumière et couleurs fortes, décor de l'histoire, cadrage d'affiche.
- Les visages et l'action tiennent dans les deux tiers inférieurs de l'image ; le tiers supérieur reste calme (ciel, mur, décor flou) pour recevoir le titre.
- N'écris AUCUNE consigne de texte, de titre, de lettrage, de badge ni de couleur de lettres : le programme ajoute lui-même le texte de la miniature (l'accroche et le numéro de partie) dans le style choisi par l'utilisateur.
- La matière des personnages (celle de leurs planches) partout, jamais de peau humaine, aucun visage coupé par le cadre.

## 6. La description TikTok
{{REGLE_DESCRIPTION}}
`;

/* ---------- Messages envoyés au rédacteur ---------- */
const fmtT = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(Math.round(s % 60)).padStart(2, '0')}`;

export function sourceBlock(prod) {
  const L = [];
  const s = prod.source || {};
  if (s.url) L.push(`Vidéo d'origine : ${s.url}`);
  if (s.author) L.push(`Compte : @${s.author}${s.stats ? ` — ${s.stats}` : ''}`);
  if (s.duration) L.push(`Durée : ${Math.round(s.duration)} s`);
  if (s.desc) L.push(`Description : « ${s.desc} »`);
  if (prod.sheets && prod.sheets.length) {
    L.push('', `LA VIDÉO : regarde-la en entier avant d'écrire quoi que ce soit. Les planches jointes « lecture-01.jpg » à « lecture-${String(prod.sheets.length).padStart(2, '0')}.jpg » sont toute la vidéo, dans l'ordre, ${String(prod.sheetsRate || 2).replace('.', ',')} images par seconde, 12 images par planche, à lire de gauche à droite puis de haut en bas ; le temps est écrit en jaune sur chaque image (${prod.sheets.map((x, i) => `lecture-${String(i + 1).padStart(2, '0')} = ${fmtT(x.from)} à ${fmtT(x.to)}`).join(', ')}).`,
      'Sers-t\'en pour comprendre exactement ce qui se passe : qui est qui, les actions, les gestes, les cadrages, les changements de plan, les décors, le rythme et le moment de chaque retournement. La transcription ci-dessous donne ce qui est dit (tu n\'as pas le son).');
    if (prod.videoSent) L.push('La vidéo d\'origine est aussi jointe (« video-source.mp4 ») : si tu peux l\'ouvrir avec ton outil d\'analyse, fais-le pour compléter les planches.');
    L.push('');
  }
  if (prod.frames && prod.frames.length) L.push(`Captures jointes, dans l'ordre : ${prod.frames.map((f, i) => `capture-${String(i + 1).padStart(2, '0')} = ${fmtT(f.t)}`).join(', ')}.`);
  const tr = prod.transcript || [];
  if (tr.length) {
    L.push('', `Transcription (${prod.transcriptFrom || 'source inconnue'}) :`);
    tr.forEach((c) => L.push(c.start !== null && c.start !== undefined ? `[${fmtT(c.start)}] ${c.text}` : c.text));
  } else L.push('', 'Pas de transcription disponible : appuie-toi sur les planches de lecture, les captures et la description.');
  return L.join('\n');
}

/* La règle de la description dépend de la chaîne : son nom est cité et repris en hashtag (s'il y en a un) */
export function descriptionRule(brand = '') {
  const b = String(brand || '').trim(), tag = b.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9]+/g, '');
  return `Courte, mystérieuse, sans emoji, une ou deux phrases qui donnent envie sans révéler la fin${b ? `, avec la mention ${b}` : ''}, puis exactement cinq hashtags dont #partie[numéro] #RealCreator ${tag ? `#${tag} ` : ''}#HistoireDeFruit.`;
}
export const annexFor = (brand) => ANNEX.replace('{{REGLE_DESCRIPTION}}', descriptionRule(brand));

export function firstMessage(prod, { extra = '', knownPlanches = [], prevBible = '', metaAttached = true, brand = '', audience = '', hook = false, prevVideo = false, prevScript = false, cast = [], castImages = false } = {}) {
  const L = [];
  L.push(metaAttached
    ? 'Le fichier joint « metaprompt.txt » est ton métaprompt : applique-le en entier. L\'annexe ci-dessous fixe la forme de ta réponse.'
    : 'Applique le métaprompt de ce projet en entier. L\'annexe ci-dessous fixe la forme de ta réponse.');
  const sb = styleBlock(prod, openingFor(OPENING_DEFAULT, prod));
  if (sb) L.push('', sb);
  L.push('', annexFor(brand), '', '# LA DEMANDE', '', `Audience : ${String(audience || '').trim() || 'France (adultes de 24 à 35 ans)'}.`, `Partie : ${prod.part || 1}.`);
  if (prod.mode === 'remake') {
    L.push('', 'OPTION 3 — refaire cette vidéo virale. Même histoire avec MES fruits : garde les mêmes moments forts, le même rythme, les mêmes retournements et la même fin qui donne envie de la suite, mais avec mes personnages, mes dialogues en français et ma direction artistique. Ne copie pas plan pour plan. Regarde d\'abord toute la vidéo (planches de lecture), fais le déroulé scène par scène mentalement, puis livre le package complet au format de l\'annexe.', '', sourceBlock(prod));
  } else if (prod.mode === 'idee') {
    L.push('', 'OPTION 2 — voici mon idée. Choisis toi-même le meilleur angle, puis livre le package complet au format de l\'annexe.', '', `Mon idée : ${prod.idea || ''}`);
  } else if (prod.mode === 'idees') {
    L.push('', 'OPTION 1 — propose 10 scénarios. Pour CETTE réponse uniquement, le format est :', '', IDEA_FORMAT(1), '',
      'Les dix idées restent dans un même style qui marche (histoires humaines simples, gros enjeu, hook visuel fort), pas dix univers éparpillés.',
      'Écris pour quelqu\'un qui choisit en 5 secondes : des phrases courtes, claires, sans jargon, sans répéter le titre dans l\'histoire.',
      prod.idea ? `Ce que je veux : ${prod.idea}` : '');
  } else if (prod.mode === 'suite') {
    L.push('', `SUITE — écris la PARTIE ${prod.part} de cette histoire, cohérente avec les parties précédentes (mêmes personnages, mêmes voix, même règle du monde, aucune nouvelle magie). Elle démarre sur la réponse au cliffhanger précédent et se termine sur un nouveau cliffhanger.`,
      prod.idea ? `Ce que je veux dans cette partie : ${prod.idea}` : '', '', 'Mémoire de la série :', prevBible || '(aucune mémoire enregistrée : appuie-toi sur le titre et invente la suite la plus logique)');
    if (prevScript) L.push('', 'LA MÉMOIRE COMPLÈTE DE LA SÉRIE EST JOINTE (« histoire-precedente.txt ») : le résumé de chaque partie déjà publiée, puis le SCRIPT EXACT de la dernière, scène par scène, avec toutes ses répliques jusqu\'à la fin. Lis-la en entier AVANT d\'écrire. Elle fait foi pour les noms, les voix et les dialogues : une transcription peut mal entendre un nom, pas ce fichier. Ta partie démarre juste après sa dernière réplique.');
    if (prevVideo) L.push('', 'LA PARTIE PRÉCÉDENTE EST JOINTE EN IMAGES : ses planches de lecture « lecture-NN.jpg » montrent TOUTE la vidéo dans l\'ordre, avec le minutage incrusté ; ses captures « capture-NN.jpg » et sa transcription sont jointes quand elles existent (et le fichier « partie-precedente.mp4 » quand le site l\'accepte). Regarde-les en entier AVANT d\'écrire. Ce n\'est PAS une vidéo à refaire : c\'est l\'épisode d\'avant. Reprends exactement ses personnages (apparence, tenue, voix, façon de parler), son décor, son ton et son rythme, et pars de la question laissée ouverte à sa dernière scène.');
  }
  if (hook && prod.mode === 'remake') L.push('', 'UNE ANALYSE DE CETTE VIDÉO PAR GEMINI EST JOINTE (« analyse-hook.txt ») : le hook des 3 premières secondes, la question qui fait rester, ce qui retient les gens. Sers-t\'en pour écrire un hook au moins aussi fort et garder ce qui fait marcher la vidéo. Si elle contredit ce que tu vois dans la vidéo, c\'est la vidéo qui a raison.');
  if (cast.length && prod.mode !== 'suite') {
    L.push('', `PERSONNAGES IMPOSÉS (choisis par l'utilisateur dans sa bibliothèque) : l'histoire se joue avec eux. Ils existent déjà : garde leur nom exact, leur apparence et leur tenue. Leur rôle, leur caractère et leur voix dans CETTE histoire, c'est toi qui les fixes. Ajoute d'autres personnages seulement si l'histoire en a besoin.${castImages ? ' Leurs planches sont jointes (« planche-nom.jpg ») : regarde-les avant d\'écrire.' : ''}`,
      ...cast.map((c) => `- "${c.name}"${c.desc ? ` : ${c.desc}` : ''}`));
  }
  if (knownPlanches.length) {
    L.push('', `Planches déjà en stock (images existantes) : ${knownPlanches.map((n) => `"${n}"`).join(', ')}.`,
      'Pour un personnage de cette liste qui garde exactement la même apparence, n\'écris PAS de bloc PLANCHE : cite simplement son nom exact dans refs. Écris une PLANCHE seulement pour un personnage nouveau ou un nouvel état (avec un nouveau nom).');
  }
  if (prod.keyText) L.push('', '# MOT FORT À L\'ÉCRAN (option choisie par l\'utilisateur)', '',
    'But : un mot-choc qui accroche le regard dès le hook, comme un beau titre en volume posé dans l\'image. Ce n\'est jamais un sous-titre.',
    'OÙ DANS LA VIDÉO — 2 scènes AU MAXIMUM : la scène 1 (le hook) et, au plus, un autre moment vraiment décisif de l\'histoire (révélation, chiffre, retournement). Toutes les autres scènes restent sans aucun texte à l\'écran.',
    'QUEL MOT — celui qui résume le choc de la scène : un mot, deux au grand maximum, jamais une phrase ni un morceau de réplique. Pistes : un lien ou un prénom (« SŒUR »), une couleur dont on parle (« BLEUS »), un verdict (« TRAHIE », « MENTEUR »), un secret (« ENCEINTE »). Si c\'est un chiffre, écris-le en chiffres avec son unité, exactement comme il doit se lire (« 50 000 € », « 3 ANS », « 7 MOIS »), jamais en toutes lettres. Écris le mot tel qu\'il doit apparaître, majuscules conseillées, orthographe et accents vérifiés : il sera recopié caractère pour caractère.',
    'QUAND — pendant un temps SANS PAROLE de la scène, jamais pendant une réplique : les légendes de TikTok s\'affichent dès que quelqu\'un parle, il ne faut pas de texte sur du texte. Deux bons moments : le silence de réaction juste après la réplique-choc, ou le temps mort qui ouvre le clip avant la première parole. Prévois ce silence dans la scène (environ 2 secondes), quitte à raccourcir une réplique, et écris-le dans la description de l\'action (ex. : silence de 2 secondes après la réplique, elle se fige, personne ne parle, le mot apparaît).',
    'COULEUR — c\'est toi qui la choisis, et elle vient de l\'histoire : la couleur d\'un élément visible lié au mot. Pistes : la sœur a les cheveux bleus → le mot est de ce bleu ; une robe rouge → ce rouge ; un citron → jaune citron ; de l\'argent → vert billet ; un secret → violet nuit ; un danger → rouge sombre. Nomme la teinte précisément (deep cobalt blue, pas seulement blue) et dis à quoi elle correspond. Il n\'y a pas de couleur par défaut : pas de jaune ni de doré sauf si l\'histoire le demande, et deux mots de la même vidéo n\'ont la même couleur que si l\'histoire le justifie. La teinte doit se détacher du décor de la scène.',
    'RENDU — de belles lettres en volume, pas une écriture plate. Pistes selon le ton de la scène : lettres 3D brillantes à bords biseautés, chrome teinté, verre coloré, glace, braise, velours, ballon gonflé, or massif (seulement si l\'histoire parle de richesse). La lumière de la scène se reflète dessus. Pour un chiffre : des chiffres larges et épais, très lisibles, avec le symbole de l\'unité à la même taille.',
    'PLACEMENT — dans une zone calme du décor, dans la moitié haute de l\'image ou à côté du personnage ou de l\'objet concerné, bien lisible (entre un tiers et la moitié de la largeur de l\'image). Jamais sur un visage, jamais dans le tiers bas de l\'image (réservé aux légendes TikTok), jamais en bandeau.',
    'COMMENT L\'ÉCRIRE — dans le prompt vidéo de ces scènes-là, ajoute une ligne à part, exactement sous cette forme, les quatre rubriques rédigées en anglais :',
    'MOT FORT À L\'ÉCRAN : « LE MOT » — COLOR: … ; LOOK: … ; PLACE: … ; WHEN: …',
    'Exemple : MOT FORT À L\'ÉCRAN : « BLEUS » — COLOR: deep cobalt blue, the exact blue of her sister\'s hair ; LOOK: glossy 3D letters with beveled edges, soft reflections of the kitchen light ; PLACE: upper third of the frame, floating just above the photo frame she holds ; WHEN: silent 2-second beat right after her line, she freezes and nobody speaks',
    'Les images de scène ne contiennent jamais de texte.');
  if (extra && extra.trim()) L.push('', 'Consignes en plus :', extra.trim());
  return L.filter((x) => x !== undefined).join('\n');
}

/* La phrase tapée dans Claude : tout le reste est dans les fichiers joints */
export function shortMessage(prod, metaAttached = true) {
  const what = { remake: 'OPTION 3, refaire une vidéo virale', idee: 'OPTION 2, mon idée', idees: 'OPTION 1, dix idées', suite: `SUITE, partie ${prod.part}` }[prod.mode];
  return `Demande FruitRadar (${what}). ${metaAttached ? 'Lis d\'abord metaprompt.txt en entier, puis demande.txt' : 'Applique le métaprompt de ce projet, puis lis demande.txt'} : ce fichier contient l'annexe de mise en forme et la demande. Réponds exactement au format que demande.txt impose, dans un seul bloc de code, sans artefact et sans autre texte.`;
}

/* Format d'une idée : des champs nommés, pour l'afficher proprement en carte */
const IDEA_FORMAT = (from) => [
  `@@IDEE n="${from}"@@`,
  'TITRE : [le titre de la vidéo, accrocheur, qui se comprend tout seul]',
  'ACCROCHE : [ce qu\'on voit ou entend dans les 2 premières secondes, qui scotche]',
  'HISTOIRE : [3 ou 4 phrases simples : qui sont les personnages, ce qui se passe, le retournement, la fin qui donne envie de la suite]',
  'PERSONNAGES : [Nom (fruit ou légume, rôle) ; Nom (…, rôle)]',
  'POURQUOI ÇA PEUT PERCER : [une phrase]',
  'PARTIES : [nombre de parties possibles, un chiffre]',
  '@@FIN@@', `(dix blocs IDEE numérotés de ${from} à ${from + 9}, puis la ligne @@CHOIX@@ et rien d'autre)`
].join('\n');
export const chooseMessage = (n, note = '') => `Je choisis l'idée ${n}.${note && note.trim() ? ` Précisions pour cette histoire : ${note.trim()}` : ''} Livre maintenant le package complet de cette histoire au format de l'annexe (META, BIBLE, PLANCHE, SCENE, MINIATURE, DESCRIPTION, puis @@FINI@@).`;
export const moreIdeasMessage = (from, note = '', titles = []) => [
  `Propose 10 NOUVELLES idées, numérotées de ${from} à ${from + 9}, toutes différentes de celles déjà proposées${titles.length ? ` (${titles.slice(-30).map((t) => `« ${t} »`).join(', ')})` : ''}.`,
  note && note.trim() ? `Ce que je veux cette fois : ${note.trim()}` : 'Garde le même style qui marche, avec des histoires et des retournements nouveaux.',
  'Même format exact qu\'avant :', '', IDEA_FORMAT(from)
].join('\n');
export const continueMessage = (missing) => (missing && missing.length
  ? `SUITE. Il manque encore : ${missing.join(' ; ')}. Livre uniquement ces blocs, au même format, dans un seul bloc de code, puis @@FINI@@.`
  : 'SUITE');

/* ---------- Lecture de la réponse ---------- */
const MARK = /^\s*@@\s*([A-ZÉÈ_]+)\b(.*?)@@\s*$/;
const ATTR = /([a-z_]+)\s*=\s*(?:"([^"]*)"|“([^”]*)”|([^\s"]+))/g;
export const normName = (s) => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const splitRefs = (s) => String(s || '').split('|').map((x) => x.trim()).filter(Boolean);

export function emptyPackage() {
  return { meta: {}, bible: '', planches: [], scenes: [], miniature: null, description: '', ideas: [], done: false, more: false, choice: false };
}

const IDEA_KEYS = [['titre', /^titre$/], ['accroche', /^(accroche|hook)$/], ['histoire', /^(histoire|resume|pitch|synopsis)$/], ['personnages', /^(personnages?|casting)$/], ['pourquoi', /^pourquoi/], ['parties', /^(parties|nombre de parties)$/]];
function parseIdea(n, attrs, lines) {
  const out = { n, titre: (attrs.titre || '').trim(), accroche: '', histoire: '', personnages: '', pourquoi: '', parties: '' };
  let key = null; const rest = [];
  for (const raw of lines) {
    const m = raw.match(/^\s*[-*•]?\s*\**([A-Za-zÀ-ÿ' ]{3,32}?)\**\s*:\s*(.*)$/);
    const k = m && IDEA_KEYS.find(([, re]) => re.test(normName(m[1])));
    if (k) { key = k[0]; out[key] = m[2].trim(); continue; }
    if (key && raw.trim()) out[key] += (out[key] ? ' ' : '') + raw.trim();
    else if (raw.trim()) rest.push(raw.trim());
  }
  if (!out.histoire && rest.length) out.histoire = rest.join(' ');
  out.titre = out.titre.replace(/^["«\s]+|["»\s]+$/g, '') || `Idée ${n}`;
  out.parties = (String(out.parties).match(/\d+/) || [''])[0];
  out.pitch = out.histoire; // ancien nom
  return out;
}
export function parsePackage(text) {
  const pkg = emptyPackage();
  const lines = String(text || '').replace(/\r/g, '').split('\n');
  let cur = null, field = null;
  const push = (line) => { if (cur && field) cur.buf[field].push(line); };
  const close = () => {
    if (!cur) return;
    const get = (k) => (cur.buf[k] || []).join('\n').trim();
    const a = cur.attrs;
    if (cur.type === 'META') {
      for (const l of cur.buf.body) { const m = l.match(/^\s*([a-zé_]+)\s*:\s*(.+)$/i); if (m) pkg.meta[normName(m[1]).replace(/ /g, '_')] = m[2].trim(); }
    } else if (cur.type === 'BIBLE') pkg.bible = get('body');
    else if (cur.type === 'PLANCHE') { if (a.nom && get('body')) pkg.planches.push({ name: a.nom.trim(), prompt: get('body') }); }
    else if (cur.type === 'SCENE') {
      const n = parseInt(a.n, 10), image = get('IMAGE'), video = get('VIDEO');
      if (Number.isFinite(n) && image && video) {
        const mt = {};
        for (const l of cur.buf.MONTAGE || []) { const m = l.match(/^\s*(fin|suivant|montage)\s*:\s*(.+)$/i); if (m) mt[m[1].toLowerCase()] = m[2].trim(); }
        pkg.scenes.push({ n, duree: parseInt(a.duree, 10) || 6, refs: splitRefs(a.refs), titre: a.titre || '', version: a.version || '', image, video, montage: mt });
      }
    } else if (cur.type === 'MINIATURE') { if (get('body')) pkg.miniature = { refs: splitRefs(a.refs), prompt: get('body') }; }
    else if (cur.type === 'DESCRIPTION') pkg.description = get('body');
    else if (cur.type === 'IDEE') { const n = parseInt(a.n, 10); if (Number.isFinite(n)) pkg.ideas.push(parseIdea(n, a, cur.buf.body)); }
    cur = null; field = null;
  };
  for (const raw of lines) {
    const m = raw.match(MARK);
    if (!m) { push(raw); continue; }
    const type = m[1];
    if (type === 'FIN') { close(); continue; }
    if (type === 'FINI') { cur = null; pkg.done = true; continue; }
    if (type === 'SUITE') { cur = null; pkg.more = true; continue; }
    if (type === 'CHOIX') { cur = null; pkg.choice = true; continue; }
    if (cur && cur.type === 'SCENE' && (type === 'IMAGE' || type === 'VIDEO' || type === 'MONTAGE')) { field = type; cur.buf[type] = []; continue; }
    if (['META', 'BIBLE', 'PLANCHE', 'SCENE', 'MINIATURE', 'DESCRIPTION', 'IDEE'].includes(type)) {
      // un bloc ouvert sans @@FIN@@ avant le suivant : coupé, on l'ignore (il sera redemandé)
      const attrs = {};
      for (const am of m[2].matchAll(ATTR)) attrs[am[1]] = am[2] ?? am[3] ?? am[4] ?? '';
      cur = { type, attrs, buf: { body: [] } };
      field = type === 'SCENE' ? null : 'body';
    }
  }
  return pkg;
}

/* Fusionne une réponse dans le package en cours (la version la plus récente d'un bloc gagne) */
export function mergePackage(base, add) {
  const out = base ? JSON.parse(JSON.stringify(base)) : emptyPackage();
  Object.assign(out.meta, add.meta);
  if (add.bible) out.bible = add.bible;
  for (const p of add.planches) { const i = out.planches.findIndex((x) => normName(x.name) === normName(p.name)); if (i >= 0) out.planches[i] = { ...out.planches[i], ...p }; else out.planches.push(p); }
  for (const s of add.scenes) { const i = out.scenes.findIndex((x) => x.n === s.n); if (i >= 0) out.scenes[i] = { ...out.scenes[i], ...s }; else out.scenes.push(s); }
  out.scenes.sort((a, b) => a.n - b.n);
  if (add.miniature) out.miniature = { ...(out.miniature || {}), ...add.miniature };
  if (add.description) out.description = add.description;
  if (add.ideas.length) out.ideas = add.ideas;
  out.done = out.done || add.done; out.more = add.more; out.choice = out.choice || add.choice;
  return out;
}

/* Ce qui manque pour lancer la production. known = noms des planches déjà en stock. */
export function missingParts(pkg, known = []) {
  const miss = [];
  if (!pkg.meta.titre) miss.push('le bloc META');
  if (!pkg.scenes.length) { miss.push('toutes les scènes'); return miss; }
  const max = Math.max(...pkg.scenes.map((s) => s.n));
  const holes = [];
  for (let i = 1; i <= max; i++) if (!pkg.scenes.some((s) => s.n === i)) holes.push(i);
  if (holes.length) miss.push(`les scènes ${holes.join(', ')}`);
  if (!pkg.done && !holes.length) miss.push(`les scènes après la ${max} s'il en reste`);
  const have = new Set([...pkg.planches.map((p) => normName(p.name)), ...known.map(normName)]);
  const lost = new Set();
  for (const s of pkg.scenes) for (const r of s.refs) if (!have.has(normName(r))) lost.add(r);
  if (pkg.miniature) for (const r of pkg.miniature.refs) if (!have.has(normName(r))) lost.add(r);
  if (lost.size) miss.push(`les planches ${[...lost].map((x) => `"${x}"`).join(', ')}`);
  const bad = pkg.scenes.filter((s) => !DURATIONS.includes(s.duree)).map((s) => s.n);
  if (bad.length) miss.push(`une durée de 6, 10 ou 15 s pour les scènes ${bad.join(', ')} (renvoie ces scènes en entier)`);
  if (!pkg.miniature) miss.push('le bloc MINIATURE');
  if (!pkg.description) miss.push('le bloc DESCRIPTION');
  if (!pkg.bible) miss.push('le bloc BIBLE');
  return miss;
}

export const totalDuration = (pkg) => pkg.scenes.reduce((a, s) => a + (s.duree || 0), 0);

export const slug = (s) => normName(s).replace(/ /g, '-').slice(0, 48) || 'video';

/* Texte lisible du package (export, copie) */
export function packageToText(pkg) {
  const L = [`# ${pkg.meta.titre || 'Sans titre'} — partie ${pkg.meta.partie || '?'}`, ''];
  for (const p of pkg.planches) L.push(`## PLANCHE — ${p.name}`, '', p.prompt, '');
  for (const s of pkg.scenes) {
    L.push(`## SCÈNE ${s.n} — ${s.titre} — ${s.duree} s`, `Références : ${s.refs.join(', ') || '—'}`, '', '### Prompt image', '', s.image, '', `### Prompt vidéo (${s.duree} s)`, '', s.video, '');
    if (s.montage && (s.montage.fin || s.montage.montage)) L.push(`Montage : ${[s.montage.fin, s.montage.suivant, s.montage.montage].filter(Boolean).join(' → ')}`, '');
  }
  if (pkg.miniature) L.push('## MINIATURE', '', pkg.miniature.prompt, '');
  if (pkg.description) L.push('## DESCRIPTION TIKTOK', '', pkg.description, '');
  return L.join('\n');
}

/* Refus de ChatGPT / Grok (modération) : on adoucit le prompt sans changer l'histoire.
   Niveau 1 : mots qui déclenchent les filtres remplacés + consigne « tout public ».
   Niveau 2 : en plus, les gestes brusques deviennent des émotions jouées par les expressions. */
const SOFT1 = [
  [/\b(sang|sanglant(e|s|es)?|ensanglant\w*)\b/gi, 'jus rouge'], [/\bsaign\w*/gi, 'coule du jus'],
  [/\b(poignard\w*|couteau\w*|lame\w*|machette\w*|hache\w*)\b/gi, 'ustensile'], [/\b(pistolet\w*|fusil\w*|revolver\w*|arme\w*)\b/gi, 'objet'],
  [/\b(tu(e|es|er|é|ée|ent)|assassin\w*|meurtr\w*)\b/gi, 'trahit'], [/\b(mort(e|s|es)?|cadavre\w*|décéd\w*)\b/gi, 'évanoui'],
  [/\b(bless(é|ée|és|ure|ures|er)|plaie\w*)\b/gi, 'égratigné'], [/\b(gifl\w*|frapp\w*|cogn\w*|tabass\w*|coup de poing|coups de poing)\b/gi, 'bouscule'],
  [/\b(étrangl\w*|égorg\w*|décapit\w*|écras\w*)\b/gi, 'menace'], [/\b(drogu\w*|cocaïne|héroïne)\b/gi, 'potion'], [/\b(alcool\w*|ivre|bourré\w*)\b/gi, 'jus pétillant'],
  [/\b(cigarette\w*|clope\w*)\b/gi, 'paille'], [/\b(nu|nue|nus|nues|déshabill\w*|sexy|sensuel\w*)\b/gi, 'élégant'], [/\b(viol|viols|viol(é|ée|és|ées|er)|abus\w*)\b/gi, 'trahison'],
  [/\b(suicid\w*)\b/gi, 'désespoir'], [/\b(enfant|bébé|petit(e)? fille|petit garçon)s?\b/gi, 'petit fruit']
];
const SOFT2 = [
  [/\b(hurl\w*|cri(e|ent|er|ant))\b/gi, 'parle fort'], [/\b(violent(e|s|es)?|violemment|brutal\w*)\b/gi, 'intense'], [/\b(pousse|poussé|bouscule)\b/gi, 'tire doucement'],
  [/\b(détrui\w*|cass\w*|explos\w*)\b/gi, 'renverse'], [/\b(peur panique|terroris\w*|horreur)\b/gi, 'inquiétude'], [/\b(larmes de sang)\b/gi, 'grosses larmes']
];
// \b ne connaît pas les accents : on refait les frontières de mots avec les lettres Unicode
const fix = (list) => list.map(([re, by]) => { const src = re.source; const parts = src.split('\\b'); return [new RegExp(parts.map((x, i) => i === 0 ? x : (i === parts.length - 1 && x === '' ? '(?![\\p{L}\\d])' : (i % 2 ? '(?<![\\p{L}\\d])' : '(?![\\p{L}\\d])') + x)).join(''), 'giu'), by]; });
const S1 = fix(SOFT1), S2 = fix(SOFT2);
export function soften(text, level = 1, kind = 'image') {
  let t = String(text || '');
  for (const [re, by] of S1) t = t.replace(re, by);
  if (level >= 2) for (const [re, by] of S2) t = t.replace(re, by);
  const head = kind === 'video'
    ? 'Animation 3D tout public, style film d\'animation familial. Aucune violence, aucun contact brutal : les émotions passent par les expressions du visage, les gestes et la voix.'
    : 'Illustration 3D tout public, style film d\'animation familial. Aucune violence ni blessure visible : les émotions passent par les expressions et les postures.';
  return `${head}${level >= 2 ? ' Scène sobre et bienveillante, sans rien de choquant.' : ''}\n\n${t}`;
}

/* ---------- Contrôle du métaprompt V6 sur les prompts vidéo ----------
   On ne se fie pas à Claude : chaque prompt vidéo est relu avec les règles VERROUILLÉES du métaprompt qu'on peut vérifier à coup sûr.
   Si une règle n'est pas respectée, on redemande ces scènes-là à Claude (puis on corrige à la main ce qui est mécanique). */
/* Styles de personnages proposés au lancement. « opening » remplace le type de personnages dans la phrase d'ouverture V6 des prompts vidéo. */
export const STYLES = {
  fruits: { label: 'Fruits', short: 'Fruits et légumes humanoïdes réalistes', opening: 'semi-realistic textured fruit-and-vegetable characters',
    brief: 'Fruits et légumes humanoïdes réalistes et texturés (le style habituel du métaprompt).' },
  porcelaine: { label: 'Fruits cristal', short: 'Cristal vivant très brillant, façon pierre précieuse', opening: 'luminous translucent living-crystal gemstone fruit-and-vegetable characters, glossy like blown glass with a soft inner glow',
    look: 'RENDU MATIÈRE OBLIGATOIRE (haut de gamme) : chaque personnage est fait d\'une matière de cristal vivant, translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours. Rendu très lumineux, net et premium, digne d\'une affiche de film d\'animation ; jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque ; matière parfaitement intacte. Les vêtements restent en vrais tissus opaques.',
    brief: 'Fruits et légumes humanoïdes en CRISTAL VIVANT, rendu haut de gamme : le corps entier de chaque personnage (visage, torse, bras, mains, jambes) est fait d\'une matière translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours. Le fruit ou le légume forme la chevelure, en fibres ou en facettes de cristal scintillantes. Chaque personnage a SA pierre précieuse, écrite dans sa planche et dans chaque prompt image (saphir, rubis, émeraude, améthyste, citrine, tourmaline rose, quartz rose, ambre, jade, topaze, aigue-marine…) ; deux personnages d\'une même scène n\'ont jamais la même. La matière reste souple, lisse et vivante sur le visage, parfaitement intacte, sans fissure. Grands yeux lumineux avec catchlights, visages très beaux qu\'on aime au premier regard, vêtements en vrais tissus opaques. Jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque. Écris cette matière en toutes lettres pour chaque personnage dans chaque planche et chaque prompt image.' },
  bubbletea: { label: 'Bubble tea', cast: 'des gobelets de bubble tea humanoïdes', short: 'Gobelets de bubble tea fruités, avec le liquide', opening: 'semi-realistic fruity bubble-tea cup characters with visible liquid and tapioca pearls inside',
    brief: 'Personnages BUBBLE TEA : chaque personnage est un gobelet de bubble tea humanoïde au parfum d\'un fruit (couleur, motifs et morceaux du fruit), corps transparent rempli de thé au lait ou de jus coloré qui bouge avec eux, perles de tapioca visibles à l\'intérieur, couvercle bombé et paille comme coiffure, bras et jambes, visage expressif sur le gobelet. Le nom de chaque personnage vient de son fruit.' },
  bubbletea_porcelaine: { label: 'Bubble tea cristal', cast: 'des gobelets de bubble tea humanoïdes', short: 'Bubble tea en cristal vivant très brillant', opening: 'luminous translucent living-crystal bubble-tea cup characters, glossy like blown glass, with visible liquid and tapioca pearls inside',
    look: 'RENDU MATIÈRE OBLIGATOIRE (haut de gamme) : chaque personnage est fait d\'une matière de cristal vivant, translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours. Rendu très lumineux, net et premium, digne d\'une affiche de film d\'animation ; jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque ; matière parfaitement intacte. Les vêtements restent en vrais tissus opaques.',
    brief: 'Personnages BUBBLE TEA en CRISTAL VIVANT, rendu haut de gamme : gobelets de bubble tea humanoïdes au parfum d\'un fruit, dont le gobelet, le couvercle et la paille sont faits d\'une matière translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours, avec le thé ou le jus coloré et les perles de tapioca visibles à l\'intérieur. Visage expressif, bras et jambes. Chaque personnage a SA pierre précieuse, écrite dans sa planche et dans chaque prompt image (saphir, rubis, émeraude, améthyste, citrine, tourmaline rose, quartz rose, ambre, jade, topaze, aigue-marine…) ; deux personnages d\'une même scène n\'ont jamais la même. La matière reste souple, lisse et vivante sur le visage, parfaitement intacte, sans fissure. Grands yeux lumineux avec catchlights, visages très beaux qu\'on aime au premier regard, vêtements en vrais tissus opaques. Jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque. Écris cette matière en toutes lettres pour chaque personnage dans chaque planche et chaque prompt image.' },
  oiseaux: { label: 'Oiseaux', cast: 'des oiseaux humanoïdes', short: 'Autruche, pigeon, oie… avec un bec et des dents', opening: 'semi-realistic textured humanoid bird characters with beaks full of human-like teeth',
    brief: 'OISEAUX humanoïdes réalistes à la place des fruits : autruche, pigeon, oie, canard, poule, dinde, mouette, flamant, perroquet… Plumes texturées, habillés comme des humains, BEC avec des DENTS humaines bien visibles quand ils parlent ou crient. Le nom de chaque personnage vient de son espèce. Toutes les autres règles du métaprompt s\'appliquent comme pour les fruits.' },
  oiseaux_porcelaine: { label: 'Oiseaux cristal', cast: 'des oiseaux humanoïdes', short: 'Oiseaux en cristal vivant, bec et dents', opening: 'luminous translucent living-crystal humanoid bird characters, glossy like blown glass, with beaks full of human-like teeth',
    look: 'RENDU MATIÈRE OBLIGATOIRE (haut de gamme) : chaque personnage est fait d\'une matière de cristal vivant, translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours. Rendu très lumineux, net et premium, digne d\'une affiche de film d\'animation ; jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque ; matière parfaitement intacte. Les vêtements restent en vrais tissus opaques.',
    brief: 'OISEAUX humanoïdes en CRISTAL VIVANT, rendu haut de gamme, à la place des fruits : autruche, pigeon, oie, canard, poule, flamant… Plumes sculptées dans une matière translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours, habillés comme des humains, BEC avec des DENTS humaines bien visibles quand ils parlent. Chaque personnage a SA pierre précieuse, écrite dans sa planche et dans chaque prompt image (saphir, rubis, émeraude, améthyste, citrine, tourmaline rose, quartz rose, ambre, jade, topaze, aigue-marine…) ; deux personnages d\'une même scène n\'ont jamais la même. La matière reste souple, lisse et vivante sur le visage, parfaitement intacte, sans fissure. Grands yeux lumineux avec catchlights, visages très beaux qu\'on aime au premier regard, vêtements en vrais tissus opaques. Jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque. Écris cette matière en toutes lettres pour chaque personnage dans chaque planche et chaque prompt image. Toutes les autres règles du métaprompt s\'appliquent comme pour les fruits.' },
  fruits_humains: { label: 'Fruits très humains', short: 'Anatomie humaine marquée, zéro effet mascotte', opening: 'semi-realistic textured fruit-and-vegetable characters with strongly human anatomy, defined faces and proportions', v6: true,
    matiere: 'anatomie humaine renforcée : tête bien proportionnée, cou visible, nez, pommettes et mâchoire dessinés, membres humains, expressions nuancées ; les couleurs, textures et contours du fruit restent lisibles sur la tête et la peau ; jamais d\'aspect mascotte.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : anatomie humaine renforcée : tête bien proportionnée, cou visible, nez, pommettes et mâchoire dessinés, membres humains, expressions nuancées ; les couleurs, textures et contours du fruit restent lisibles sur la tête et la peau ; jamais d\'aspect mascotte.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : anatomie humaine renforcée : tête bien proportionnée, cou visible, nez, pommettes et mâchoire dessinés, membres humains, expressions nuancées ; les couleurs, textures et contours du fruit restent lisibles sur la tête et la peau ; jamais d\'aspect mascotte.' },
  diamant: { label: 'Fruits diamant', short: 'Peau en diamant coloré taillé, à facettes', opening: 'semi-realistic fruit-and-vegetable characters whose skin is faceted colored diamond with crisp edges and inner refraction', v6: true,
    matiere: 'toute la peau visible (visage, cou, mains, jambes) est un diamant coloré taillé : facettes géométriques translucides, arêtes nettes, profondeur cristalline, réfractions internes et éclats de lumière ; facettes plus fines autour des yeux et de la bouche pour garder toute l\'expressivité ; la couleur est celle du fruit de chaque personnage ; les vêtements restent en tissu.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : toute la peau visible (visage, cou, mains, jambes) est un diamant coloré taillé : facettes géométriques translucides, arêtes nettes, profondeur cristalline, réfractions internes et éclats de lumière ; facettes plus fines autour des yeux et de la bouche pour garder toute l\'expressivité ; la couleur est celle du fruit de chaque personnage ; les vêtements restent en tissu.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : toute la peau visible (visage, cou, mains, jambes) est un diamant coloré taillé : facettes géométriques translucides, arêtes nettes, profondeur cristalline, réfractions internes et éclats de lumière ; facettes plus fines autour des yeux et de la bouche pour garder toute l\'expressivité ; la couleur est celle du fruit de chaque personnage ; les vêtements restent en tissu.' },
  liquide: { label: 'Fruits à cœur liquide', short: 'Enveloppe transparente remplie de jus coloré', opening: 'semi-realistic fruit-and-vegetable characters made of a thin transparent shell filled with colored juice, bubbles and floating seeds', v6: true,
    matiere: 'la tête et toute la peau visible sont une fine enveloppe transparente remplie de jus à la couleur du fruit : niveau de liquide lisible, poche d\'air, petites bulles et quelques graines en suspension ; le visage est modelé dans la paroi ; réfractions crédibles, lumière qui traverse le liquide ; cou, mains et membres visibles sont dans la même matière.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la tête et toute la peau visible sont une fine enveloppe transparente remplie de jus à la couleur du fruit : niveau de liquide lisible, poche d\'air, petites bulles et quelques graines en suspension ; le visage est modelé dans la paroi ; réfractions crédibles, lumière qui traverse le liquide ; cou, mains et membres visibles sont dans la même matière.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la tête et toute la peau visible sont une fine enveloppe transparente remplie de jus à la couleur du fruit : niveau de liquide lisible, poche d\'air, petites bulles et quelques graines en suspension ; le visage est modelé dans la paroi ; réfractions crédibles, lumière qui traverse le liquide ; cou, mains et membres visibles sont dans la même matière.' },
  givres: { label: 'Fruits givrés', short: 'Voile de givre et petits cristaux de glace', opening: 'semi-realistic fruit-and-vegetable characters with a frosted skin, a thin veil of frost and tiny ice crystals', v6: true,
    matiere: 'la matière du fruit est givrée : surface fraîche légèrement translucide, fin voile de givre et petits cristaux de glace sur la peau, les contours et les feuilles ; reflets froids, couleur du fruit toujours reconnaissable ; le givre ne cache ni les yeux ni les expressions. C\'est une matière, pas un décor d\'hiver : l\'histoire et les tenues restent libres.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la matière du fruit est givrée : surface fraîche légèrement translucide, fin voile de givre et petits cristaux de glace sur la peau, les contours et les feuilles ; reflets froids, couleur du fruit toujours reconnaissable ; le givre ne cache ni les yeux ni les expressions. C\'est une matière, pas un décor d\'hiver : l\'histoire et les tenues restent libres.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la matière du fruit est givrée : surface fraîche légèrement translucide, fin voile de givre et petits cristaux de glace sur la peau, les contours et les feuilles ; reflets froids, couleur du fruit toujours reconnaissable ; le givre ne cache ni les yeux ni les expressions. C\'est une matière, pas un décor d\'hiver : l\'histoire et les tenues restent libres.' },
  nacres: { label: 'Fruits nacrés', short: 'Fini perlé, irisations douces', opening: 'semi-realistic fruit-and-vegetable characters with a smooth pearlescent mother-of-pearl skin and soft iridescence', v6: true,
    matiere: 'la peau du fruit a un fini de nacre, lisse et lumineux : couches perlées, irisations subtiles qui changent avec l\'angle, reflets doux ; la couleur de chaque fruit reste perceptible sous la nacre ; ni facettes de diamant, ni métal miroir.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la peau du fruit a un fini de nacre, lisse et lumineux : couches perlées, irisations subtiles qui changent avec l\'angle, reflets doux ; la couleur de chaque fruit reste perceptible sous la nacre ; ni facettes de diamant, ni métal miroir.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la peau du fruit a un fini de nacre, lisse et lumineux : couches perlées, irisations subtiles qui changent avec l\'angle, reflets doux ; la couleur de chaque fruit reste perceptible sous la nacre ; ni facettes de diamant, ni métal miroir.' },
  fruits_porcelaine: { label: 'Fruits en porcelaine', short: 'Porcelaine émaillée, motifs peints', opening: 'semi-realistic fruit-and-vegetable characters with glazed porcelain skin and delicate painted botanical patterns', v6: true,
    matiere: 'la peau du fruit est en porcelaine émaillée : reliefs du visage finement moulés, reflets de glaçure et délicats motifs botaniques peints, propres à l\'espèce de chaque personnage ; formes de fruits reconnaissables, couleurs harmonieuses, détails de céramique crédibles.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la peau du fruit est en porcelaine émaillée : reliefs du visage finement moulés, reflets de glaçure et délicats motifs botaniques peints, propres à l\'espèce de chaque personnage ; formes de fruits reconnaissables, couleurs harmonieuses, détails de céramique crédibles.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la peau du fruit est en porcelaine émaillée : reliefs du visage finement moulés, reflets de glaçure et délicats motifs botaniques peints, propres à l\'espèce de chaque personnage ; formes de fruits reconnaissables, couleurs harmonieuses, détails de céramique crédibles.' },
  metal: { label: 'Fruits métalliques', short: 'Métal coloré poli ou brossé', opening: 'semi-realistic fruit-and-vegetable characters with colored polished or brushed metal skin, never robotic', v6: true,
    matiere: 'la peau du fruit est en métal coloré, à la couleur de l\'espèce : surfaces polies ou brossées, reflets physiquement justes, nuances riches ; visage expressif sculpté dans le métal, tige et feuilles reconnaissables ; vêtements en vrais tissus ; le corps reste humanoïde et vivant, jamais un robot mécanique.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la peau du fruit est en métal coloré, à la couleur de l\'espèce : surfaces polies ou brossées, reflets physiquement justes, nuances riches ; visage expressif sculpté dans le métal, tige et feuilles reconnaissables ; vêtements en vrais tissus ; le corps reste humanoïde et vivant, jamais un robot mécanique.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la peau du fruit est en métal coloré, à la couleur de l\'espèce : surfaces polies ou brossées, reflets physiquement justes, nuances riches ; visage expressif sculpté dans le métal, tige et feuilles reconnaissables ; vêtements en vrais tissus ; le corps reste humanoïde et vivant, jamais un robot mécanique.' },
  lumineux: { label: 'Fruits lumineux', short: 'Graines et veines qui brillent doucement', opening: 'semi-realistic fruit-and-vegetable characters with softly glowing seeds and fine bioluminescent veins in their skin', v6: true,
    matiere: 'la peau du fruit porte des graines lumineuses et de très fines veines bioluminescentes : lueur douce, intégrée à la matière et accordée à la couleur de l\'espèce, qui ne cache pas la texture fraîche du fruit et ne surexpose jamais les expressions.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la peau du fruit porte des graines lumineuses et de très fines veines bioluminescentes : lueur douce, intégrée à la matière et accordée à la couleur de l\'espèce, qui ne cache pas la texture fraîche du fruit et ne surexpose jamais les expressions.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la peau du fruit porte des graines lumineuses et de très fines veines bioluminescentes : lueur douce, intégrée à la matière et accordée à la couleur de l\'espèce, qui ne cache pas la texture fraîche du fruit et ne surexpose jamais les expressions.' },
  marbre: { label: 'Fruits en marbre', short: 'Marbre poli coloré, fines veines', opening: 'semi-realistic fruit-and-vegetable characters with colored polished marble skin and fine mineral veins', v6: true,
    matiere: 'la peau du fruit est en marbre poli coloré : fines veines minérales, profondeur naturelle, reflets satinés ; silhouettes de fruits reconnaissables, visages expressifs finement sculptés ; les vêtements restent en tissu.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la peau du fruit est en marbre poli coloré : fines veines minérales, profondeur naturelle, reflets satinés ; silhouettes de fruits reconnaissables, visages expressifs finement sculptés ; les vêtements restent en tissu.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la peau du fruit est en marbre poli coloré : fines veines minérales, profondeur naturelle, reflets satinés ; silhouettes de fruits reconnaissables, visages expressifs finement sculptés ; les vêtements restent en tissu.' },
  cafe: { label: 'Tasses de café', short: 'Tête en tasse de café, café visible', opening: 'semi-realistic humanoid characters with a ceramic coffee-cup head, visible coffee and foam on top', v6: true, espece: 'une tasse de café',
    matiere: 'céramique de tasse, avec son anse, et le café visible au sommet (mousse, crème, motif) ; visage expressif sculpté dans la céramique ; cou, mains et peau visible assortis à la tasse ; formes de tasses, cafés, mousses et couleurs différents d\'un personnage à l\'autre.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus : les personnages ne sont pas des fruits ni des légumes ; la tête de chacun est une tasse de café. Matière : céramique de tasse, avec son anse, et le café visible au sommet (mousse, crème, motif) ; visage expressif sculpté dans la céramique ; cou, mains et peau visible assortis à la tasse ; formes de tasses, cafés, mousses et couleurs différents d\'un personnage à l\'autre.',
    brief: 'ESPÈCE DU STYLE : à la place des fruits et légumes, chaque personnage est un humanoïde dont la tête est une tasse de café. Matière : céramique de tasse, avec son anse, et le café visible au sommet (mousse, crème, motif) ; visage expressif sculpté dans la céramique ; cou, mains et peau visible assortis à la tasse ; formes de tasses, cafés, mousses et couleurs différents d\'un personnage à l\'autre. Tout le reste est celui du métaprompt : rendu 3D semi-réaliste haut de gamme, corps humain habillé, proportions selon l\'âge, yeux et expressions réalistes.' },
  cafe_verre: { label: 'Cafés en verre', short: 'Tasse en verre, couches de café et de lait', opening: 'semi-realistic humanoid characters with a glass coffee-cup head showing layered coffee, milk and foam', v6: true, espece: 'une tasse en verre remplie de café',
    matiere: 'tasse en verre remplie de café : liquide, couches de lait, mousse ou glaçons visibles avec des réfractions crédibles ; visage expressif intégré au verre ; cou et mains translucides eux aussi ; tasses et boissons différentes d\'un personnage à l\'autre.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus : les personnages ne sont pas des fruits ni des légumes ; la tête de chacun est une tasse en verre remplie de café. Matière : tasse en verre remplie de café : liquide, couches de lait, mousse ou glaçons visibles avec des réfractions crédibles ; visage expressif intégré au verre ; cou et mains translucides eux aussi ; tasses et boissons différentes d\'un personnage à l\'autre.',
    brief: 'ESPÈCE DU STYLE : à la place des fruits et légumes, chaque personnage est un humanoïde dont la tête est une tasse en verre remplie de café. Matière : tasse en verre remplie de café : liquide, couches de lait, mousse ou glaçons visibles avec des réfractions crédibles ; visage expressif intégré au verre ; cou et mains translucides eux aussi ; tasses et boissons différentes d\'un personnage à l\'autre. Tout le reste est celui du métaprompt : rendu 3D semi-réaliste haut de gamme, corps humain habillé, proportions selon l\'âge, yeux et expressions réalistes.' },
  the: { label: 'Thés et matcha', short: 'Tête en tasse ou bol de thé, vapeur légère', opening: 'semi-realistic humanoid characters with a teacup or tea-bowl head, visible tea and light steam', v6: true, espece: 'une tasse ou un bol de thé',
    matiere: 'tasse ou bol de thé en céramique ou en verre détaillés, boisson visible, parfois une légère vapeur ; visage expressif intégré à la matière ; cou, mains et peau visible assortis ; variétés de thé, contenants, couleurs et détails botaniques différents d\'un personnage à l\'autre.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus : les personnages ne sont pas des fruits ni des légumes ; la tête de chacun est une tasse ou un bol de thé. Matière : tasse ou bol de thé en céramique ou en verre détaillés, boisson visible, parfois une légère vapeur ; visage expressif intégré à la matière ; cou, mains et peau visible assortis ; variétés de thé, contenants, couleurs et détails botaniques différents d\'un personnage à l\'autre.',
    brief: 'ESPÈCE DU STYLE : à la place des fruits et légumes, chaque personnage est un humanoïde dont la tête est une tasse ou un bol de thé. Matière : tasse ou bol de thé en céramique ou en verre détaillés, boisson visible, parfois une légère vapeur ; visage expressif intégré à la matière ; cou, mains et peau visible assortis ; variétés de thé, contenants, couleurs et détails botaniques différents d\'un personnage à l\'autre. Tout le reste est celui du métaprompt : rendu 3D semi-réaliste haut de gamme, corps humain habillé, proportions selon l\'âge, yeux et expressions réalistes.' },
  smartphone: { label: 'Smartphones premium', short: 'Tête en smartphone, visage sur l\'écran', opening: 'semi-realistic humanoid characters with a premium smartphone head and an expressive face on the screen', v6: true, espece: 'un smartphone',
    matiere: 'smartphone haut de gamme : cadre métallique, verre et boutons crédibles, visage expressif affiché sur l\'écran ; cou et mains assortis à l\'appareil ; formes, couleurs et finitions inventées, sans copier un modèle ni une marque existants.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus : les personnages ne sont pas des fruits ni des légumes ; la tête de chacun est un smartphone. Matière : smartphone haut de gamme : cadre métallique, verre et boutons crédibles, visage expressif affiché sur l\'écran ; cou et mains assortis à l\'appareil ; formes, couleurs et finitions inventées, sans copier un modèle ni une marque existants.',
    brief: 'ESPÈCE DU STYLE : à la place des fruits et légumes, chaque personnage est un humanoïde dont la tête est un smartphone. Matière : smartphone haut de gamme : cadre métallique, verre et boutons crédibles, visage expressif affiché sur l\'écran ; cou et mains assortis à l\'appareil ; formes, couleurs et finitions inventées, sans copier un modèle ni une marque existants. Tout le reste est celui du métaprompt : rendu 3D semi-réaliste haut de gamme, corps humain habillé, proportions selon l\'âge, yeux et expressions réalistes.' },
  // Style repris de la vidéo jointe (vidéo à reproduire, ou partie précédente donnée en fichier) : c'est Claude qui le lit dans les images
  video: { label: 'Style de la vidéo', short: 'Le même que les personnages de la vidéo', opening: 'semi-realistic textured stylized humanoid characters', brief: '', fromVideo: true },
  autre: { label: 'Nouveau style', short: 'Tu le décris, tu peux l\'enregistrer', opening: 'semi-realistic textured stylized humanoid characters', brief: '' }
};
const FRUIT_PHRASE = 'semi-realistic textured fruit-and-vegetable characters';
export const styleOf = (prod) => STYLES[(prod && prod.style) || 'fruits'] || STYLES.fruits;
/* Phrase d'ouverture V6 adaptée au style choisi (le reste de la phrase ne change pas) */
export function openingFor(opening, prod) {
  const st = styleOf(prod);
  return st === STYLES.fruits || !opening.includes(FRUIT_PHRASE) ? opening : opening.replace(FRUIT_PHRASE, st.opening);
}
/* Bloc ajouté à la demande quand le style n'est pas celui par défaut */
export function styleBlock(prod, opening) {
  const st = styleOf(prod);
  if (st === STYLES.fruits) return '';
  if (st.fromVideo) {
    return ['# STYLE DES PERSONNAGES : CELUI DE LA VIDÉO JOINTE (choisi par l\'utilisateur, prioritaire sur le métaprompt)', '',
      'Regarde les captures (« capture-NN.jpg ») et les planches de lecture (« lecture-NN.jpg ») de la vidéo. Avant d\'écrire, identifie le STYLE D\'APPARENCE de ses personnages : leur espèce ou leur nature (fruits, légumes, oiseaux, gobelets, objets…), leur matière et sa finition (texturée, brillante, cristal, verre, porcelaine, métal…), le niveau de réalisme, les proportions du corps, la façon dont ils sont habillés.',
      prod.mode === 'suite'
        ? 'Les personnages qui reviennent gardent EXACTEMENT leur apparence de la vidéo (espèce, couleurs, visage, tenue) ; les nouveaux personnages sont faits dans le même style.'
        : 'Tes personnages sont faits dans CE style-là : même espèce ou même famille, même matière, même rendu, mêmes proportions. Tu reprends le style, pas les personnages : chacun reste nouveau (autre variété, autre nom, autre visage, autre tenue).',
      'Écris ce style en une ou deux phrases précises, et reprends ces mêmes phrases, mot pour mot, dans chaque planche, chaque image de scène et la miniature.', '',
      'Comment l\'appliquer — le métaprompt reste la base, le style n\'y ajoute que son espèce et sa matière :',
      '- Planches : le FORMAT DE PLANCHE du métaprompt, point par point (ouverture, nom, proportions, description unique, quatre vues, trois gros plans, interdictions). La matière du style s\'écrit dans la « Description unique » (texture du matériau, couleur exacte).',
      '- Chaque planche se termine par la Directive de Style Planche, et chaque image de scène par la Directive de Style de Scène, recopiées intégralement. Juste AVANT la directive, ajoute cette phrase : « Précisions de style, qui priment sur la directive de style qui suit : [le style de la vidéo, en une ou deux phrases]. »',
      '- Si les personnages de la vidéo ne sont pas des fruits ou des légumes, recopie les directives en remplaçant seulement les mots « fruit ou légume » par leur espèce : le rendu, les proportions, les yeux et les expressions ne changent pas.',
      '- Même style partout : planches, images de scène, miniature, prompts vidéo. Toutes les autres règles du métaprompt s\'appliquent (structure, durées, répliques, voix, hook).',
      `Dans les prompts vidéo, la phrase d'ouverture commune devient, mot pour mot : « ${opening} »`].join('\n');
  }
  const custom = prod.style === 'autre';
  const brief = custom ? String(prod.styleText || '').trim() : st.brief;
  if (!brief) return '';
  const L = ['# STYLE DES PERSONNAGES (choisi par l\'utilisateur, prioritaire sur le métaprompt)', '', brief, ''];
  if (st.v6 || custom) L.push( // styles bâtis sur le métaprompt : il reste la base, le style n'ajoute que sa matière (ou son espèce)
    'Comment l\'appliquer — le métaprompt reste la base, le style n\'y ajoute que sa matière :',
    '- Planches : le FORMAT DE PLANCHE du métaprompt, point par point (ouverture, nom, proportions, description unique, quatre vues, trois gros plans, interdictions). La matière du style s\'écrit dans la « Description unique » (texture du matériau, couleur exacte).',
    '- Chaque planche se termine par la Directive de Style Planche, et chaque image de scène par la Directive de Style de Scène, recopiées intégralement. Juste AVANT la directive, ajoute cette phrase : « Précisions de style, qui priment sur la directive de style qui suit : [la matière du style, en une ou deux phrases]. »',
    '- Si le style remplace les fruits et légumes par une autre espèce (tasse, gobelet, smartphone, oiseau…), recopie les directives en remplaçant seulement les mots « fruit ou légume » par cette espèce : le rendu, les proportions, les yeux et les expressions ne changent pas.',
    '- Même matière partout : planches, images de scène, miniature, prompts vidéo. Toutes les autres règles du métaprompt s\'appliquent (structure, durées, répliques, voix, hook).');
  else L.push('Applique ce style à TOUT : personnages, planches de personnages, images de scène, miniature, prompts vidéo. Garde toutes les autres règles du métaprompt (structure, durées, répliques, voix, hook).');
  L.push(`Dans les prompts vidéo, la phrase d'ouverture commune devient, mot pour mot : « ${opening} »`);
  return L.join('\n');
}
/* ---------- Le métaprompt comme base des images de style ----------
   La Directive de Style Planche est lue dans le métaprompt lui-même (si tu l'as modifié, c'est ta version qui compte). */
export const PLANCHE_DIRECTIVE_DEFAULT = 'Style d\'animation 3D haut de gamme dans la lignée de Pixar et DreamWorks, poussé vers un rendu semi-réaliste mature et texturé, avec un niveau de détail matière élevé et une diffusion sous-surfacique sur la matière du fruit ou du légume. Éclairage de studio doux, neutre et uniforme sur un fond blanc pur, couleurs fidèles et saturées, légère ombre douce au sol. Le corps entier — visage, torse, bras, mains, jambes, pieds — est fait intégralement de la matière de son fruit ou légume, sans aucune peau chair humaine nulle part. Corps entièrement humanoïde, grand et élancé, environ cinq têtes et demie de haut pour un adulte, longues jambes, cou visible, jamais chibi. Yeux réalistes et expressifs, expressions réalistes et nuancées.';
export function plancheDirectiveOf(metaText) {
  const t = String(metaText || ''), at = t.search(/DIRECTIVE DE STYLE PLANCHE\*\*/);
  if (at < 0) return PLANCHE_DIRECTIVE_DEFAULT;
  const m = /```\s*\n([\s\S]*?)\n```/.exec(t.slice(at));
  return m && m[1].trim().length > 200 ? m[1].trim() : PLANCHE_DIRECTIVE_DEFAULT;
}
/* Image d'aperçu d'un style (bouton du lanceur) : cinq personnages côte à côte, dans le rendu exact des planches du métaprompt.
   Même logique que pour une vraie planche : la directive de style du métaprompt, précédée des précisions du style. */
export function stylePreviewPrompt(style, metaText) {
  const st = style || {}, dir = plancheDirectiveOf(metaText).replace(/,?\s*composition verticale 9:16/i, '').replace(/\s*Rendu net, propre et parfaitement identique dans chaque vue\.?/i, '').trim();
  const esp = st.cast || (st.espece ? `des humanoïdes dont la tête est ${st.espece}` : st.custom ? 'dans le style décrit plus bas' : 'des fruits et légumes humanoïdes');
  // précisions du style : son rendu matière s'il en a un, sinon sa description (styles d'origine et styles enregistrés)
  const precis = st.look || (st.matiere ? `PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessous : ${st.matiere}` : (st.brief && st.key !== 'fruits' ? `PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessous : ${String(st.brief).trim()}` : ''));
  return ['Une image de présentation de style, au format paysage 16:9, sur un fond blanc pur et uniforme, sans décor, sans cadre et sans aucun texte.',
    `Cinq personnages adultes différents, ${esp}, debout, en pied, côte à côte et bien espacés : hommes et femmes, chacun d'une espèce ou d'une variété différente, chacun dans une tenue élégante différente et complète, poses naturelles et variées, regards dirigés de côté, jamais vers la caméra, légère ombre douce au sol. Chaque corps est entier, du sommet de la tête jusqu'aux pieds, jamais coupé.`,
    'Chaque personnage a un CORPS D\'ADULTE COMPLET, GRAND ET ÉLANCÉ, d\'environ cinq têtes et demie de haut, avec de longues jambes, un cou visible et des épaules d\'adulte ; visage semi-réaliste aux expressions nuancées, jamais de peau humaine.',
    precis.replace('ci-dessus', 'ci-dessous'), dir].filter(Boolean).join('\n\n');
}
/* Style repris de la vidéo : des captures de la vidéo partent avec chaque planche */
export const VIDEO_REF_NOTE = 'Les images jointes sont des captures d\'une vidéo : ce sont des RÉFÉRENCES DE STYLE uniquement. Reprends leur rendu (espèce ou nature des personnages, matière, niveau de réalisme, finition, lumière, proportions des corps), mais ne reproduis aucun de leurs personnages, ni leurs visages, ni leurs tenues, ni le décor : le personnage à dessiner est celui décrit ci-dessous.\n\n';
export const VIDEO_REF_NOTE_SUITE = 'Les images jointes sont des captures de la partie précédente de cette histoire. Si le personnage décrit ci-dessous y apparaît, dessine-le IDENTIQUE (même espèce, mêmes couleurs, même visage, même tenue). Sinon, reprends seulement leur rendu (matière, niveau de réalisme, finition, proportions). N\'ajoute ni décor ni autre personnage.\n\n';
/* Résumé court d'un personnage de la bibliothèque, tiré du prompt de sa planche */
export function charBrief(prompt, max = 420) {
  const t = String(prompt || '').replace(/\s+/g, ' ').trim();
  if (t.length <= max) return t;
  const cut = t.slice(0, max), dot = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf(' ; '));
  return (dot > max * 0.5 ? cut.slice(0, dot + 1) : cut.replace(/\s+\S*$/, '')) + ' […]';
}
/* Note jointe à une planche quand l'image du style part avec elle : c'est une référence de rendu, pas un modèle de personnage */
export const STYLE_REF_NOTE = 'L\'image jointe est une RÉFÉRENCE DE STYLE uniquement : reprends son rendu (matière, niveau de réalisme, finition, lumière, proportions des corps), mais ne reproduis aucun de ses personnages, ni leurs visages, ni leurs tenues, ni leurs poses, et ne reprends pas sa mise en page. Génère la planche du personnage décrit ci-dessous. ';
/* ---------- Miniature : le texte et son style sont ajoutés ICI, au moment d'envoyer à ChatGPT ----------
   Claude décrit l'image ; l'utilisateur choisit le style du texte (au lancement, ou en refaisant la miniature).
   Le style peut donc changer sans réécrire le package, et chaque « Refaire » demande une version vraiment différente. */
export const MINI_STYLES = {
  libre: { label: 'Carte blanche', short: 'ChatGPT invente le lettrage et la mise en page, différents à chaque histoire',
    rule: 'carte blanche. Tu es le directeur artistique : invente un lettrage sur mesure pour CETTE histoire (forme, matière, couleurs et effets des lettres inspirés du décor, de l\'objet clé ou de l\'émotion de la scène), comme le titre d\'une affiche qu\'on n\'a encore jamais vue. Le gros titre est très grand, spectaculaire et parfaitement lisible ; le repère de partie est intégré dans le même esprit (étiquette, ruban, tampon, autocollant… à toi de choisir). Typographie, couleurs et disposition libres, tant que c\'est beau, net et lisible.' },
  cartoon: { label: 'Gros titre cartoon', short: 'Très grosses lettres rondes et rebondies, façon dessin animé',
    rule: 'gros titre de dessin animé. Très grosses lettres rondes, épaisses et rebondies, en 3D brillante, un peu penchées et de tailles inégales comme un logo de cartoon, avec un épais contour sombre, une ombre portée et des reflets ; couleurs vives et joyeuses tirées de la scène ; un ou deux mots clés encore plus gros que les autres. Le repère de partie tient dans une petite bulle ou un autocollant assorti.' },
  cinema: { label: 'Affiche de cinéma', short: 'Titre 3D sculpté, lumière dramatique, composition d\'affiche',
    rule: 'affiche de film d\'animation. Titre en grandes lettres 3D sculptées dans une matière liée à l\'histoire (or, glace, bois, verre, bonbon, pierre…), reliefs et reflets soignés, éclairage dramatique, composition d\'affiche de cinéma. Le repère de partie est écrit en petites capitales élégantes, comme le numéro d\'un épisode.' },
  bd: { label: 'Bande dessinée', short: 'Éclat de BD, lettres épaisses inclinées, trame de points',
    rule: 'bande dessinée. Le gros titre jaillit d\'un grand éclat ou d\'une bulle de BD : lettres épaisses et inclinées à contour noir, trame de points, traits de vitesse, deux ou trois couleurs franches. Le repère de partie est dans un petit cartouche de BD.' },
  neon: { label: 'Néon lumineux', short: 'Lettres lumineuses qui éclairent la scène',
    rule: 'néon lumineux. Titre en tubes de néon ou en lettres lumineuses qui éclairent vraiment la scène (reflets colorés sur les personnages et le décor), une ou deux couleurs de lumière accordées à l\'histoire, fond un peu plus sombre derrière les lettres pour qu\'elles ressortent. Le repère de partie est un petit néon assorti.' },
  classique: { label: 'Classique', short: 'Titre de la série, badge bleu « PARTIE », accroche jaune (l\'ancien style)',
    rule: 'trois niveaux bien séparés, de haut en bas : (1) le titre de la série en lettres cursives élégantes blanc crème avec un fin contour sombre ; (2) un badge arrondi bleu roi à bordure dorée contenant le repère de partie en capitales blanches épaisses ; (3) le gros titre en très grosses capitales jaune vif à épais contour rouge sombre, légèrement inclinées, sur une ou deux lignes.' }
};
export const MINI_DEFAULT = 'libre';
export const miniStyleKey = (prod, fallback) => (prod && MINI_STYLES[prod.miniStyle] ? prod.miniStyle : MINI_STYLES[fallback] ? fallback : MINI_DEFAULT);
/* pistes données à ChatGPT quand on refait une miniature « carte blanche » : une direction différente à chaque essai */
const MINI_TWISTS = ['lettres faites de la matière de l\'objet clé de l\'histoire', 'lettres gonflées et brillantes comme des ballons', 'titre peint à grands coups de pinceau, avec des éclaboussures de couleur',
  'lettres découpées façon autocollants, à gros contour blanc', 'lettres dorées en relief, façon écrin de luxe', 'lettres de lumière, qui éclairent les personnages'];
export function miniPrompt(pkg, prod, fallback) {
  const m = (pkg && pkg.miniature) || {}, meta = (pkg && pkg.meta) || {};
  const base = String(m.prompt || '').trim();
  const hook = String(meta.accroche || '').replace(/\s+/g, ' ').replace(/^["«“]\s*|\s*["»”]$/g, '').trim().toUpperCase();
  if (!base || !hook) return base; // pas d'accroche (package ancien ou collé à la main) : le prompt part tel quel
  const key = miniStyleKey(prod, fallback), st = MINI_STYLES[key], v = Number(m.variant) || 0;
  const part = `PARTIE ${String(meta.partie || (prod && prod.part) || 1).replace(/^partie\s*/i, '').trim()}`;
  const serie = String(meta.serie || '').replace(/\s+/g, ' ').trim();
  const L = ['', '', 'TEXTE DE LA MINIATURE — consigne prioritaire : elle remplace toute autre indication de texte, de titre, de police, de badge ou de couleur de lettres donnée ailleurs dans ce message.',
    'Texte à écrire, exactement ces mots, lettre pour lettre, sans guillemets, sans faute, et rien d\'autre :'];
  if (key === 'classique' && serie) L.push(`- Titre de la série : ${serie}`);
  L.push(`- Gros titre : ${hook}`, `- Repère de partie : ${part}`,
    `Style du texte : ${st.rule}`,
    'Placement : tout le texte tient dans la moitié haute de l\'image, à plus de 8 % des bords, sans jamais couvrir un visage ; il se lit d\'un coup d\'œil sur un écran de téléphone. Aucun autre texte, aucun logo, aucun filigrane.');
  if (v > 0) L.push(`NOUVELLE VERSION (n° ${v + 1}) : fais une miniature nettement différente de la précédente (autre disposition du texte, autres couleurs de lettres, autre cadrage des personnages), avec le même texte.${key === 'libre' ? ` Piste pour cette version : ${MINI_TWISTS[(v - 1) % MINI_TWISTS.length]}.` : ''}`);
  return base + L.join('\n');
}

/* Aucun texte à l'image : ajouté à chaque prompt vidéo envoyé à Grok et à chaque image de scène */
export const NO_TEXT_VIDEO = 'NO TEXT ON SCREEN: no subtitles, no captions, no titles, no speech bubbles, no letters, words or numbers anywhere in the video, no logos, no watermark.';
export const NO_TEXT_IMAGE = 'AUCUN TEXTE dans l\'image : pas de sous-titre, pas de bulle, pas de titre, pas de lettre, de mot ou de chiffre, pas de logo, pas de filigrane. Un panneau, une enseigne, une pancarte, une affiche ou un écran présent dans la scène reste vierge, flou ou vu de dos : rien n\'y est écrit.';
/* Rendu matière ajouté à chaque prompt image quand le style choisi est un style cristal */
export const lookOf = (prod) => {
  const st = styleOf(prod);
  if (prod && prod.style === 'autre') { const t = String(prod.styleText || '').replace(/\s+/g, ' ').trim(); return t && t.length <= 700 ? `PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus : ${t}` : ''; }
  return (st && st.look) || '';
};
/* Suite : on garde le TEXTE de la miniature précédente (mêmes mots, même lettrage, mêmes effets, même place) avec le nouveau numéro de partie.
   L'image, elle, est nouvelle : c'est la scène de cette partie, décrite par Claude. */
export function miniKeepTextPrompt(pkg, prod, prevPart) {
  const m = (pkg && pkg.miniature) || {}, base = String(m.prompt || '').trim(), v = Number(m.variant) || 0;
  const part = `PARTIE ${String((prod && prod.part) || 1).replace(/^partie\s*/i, '').trim()}`;
  const L = [
    'L\'image jointe nommée « miniature-precedente » est la miniature de la partie précédente de cette série. Elle sert de MODÈLE POUR LE TEXTE, et seulement pour le texte : ce n\'est pas une planche de personnage.',
    `TEXTE — consigne prioritaire, elle remplace toute autre indication de texte, de titre, de police, de badge ou de couleur de lettres donnée plus bas : recopie le titre de cette miniature mot pour mot, sans faute, avec exactement le même lettrage (même police, mêmes couleurs, mêmes contours, mêmes ombres, mêmes reflets et effets, même inclinaison, même taille) et au même endroit dans l'image. UN SEUL changement dans le texte : le repère de partie devient « ${part} »${prevPart ? ` (à la place de « PARTIE ${prevPart} »)` : ''}, écrit au même endroit et dans le même style que l'ancien. Aucun autre texte, aucun logo, aucun filigrane.`,
    'IMAGE — elle est NOUVELLE : ne reprends ni la scène, ni les poses, ni le décor, ni le cadrage de la miniature jointe. Dessine la scène décrite ci-dessous, celle de cette nouvelle partie, sans jamais couvrir un visage avec le texte.'
  ];
  if (v > 0) L.push(`NOUVELLE VERSION (n° ${v + 1}) : change nettement l'image (autre cadrage, autre moment de la scène), en gardant exactement le même texte et le même lettrage.`);
  L.push('Format portrait vertical 9:16. Ne réponds que par l\'image.');
  return `${L.join('\n')}\n\n${base}`;
}
/* Suite : la miniature de la partie précédente refaite à l'identique, seul le numéro de partie change (ancienne façon, gardée pour les productions déjà lancées) */
export function miniReusePrompt(part, prevPart) {
  return `L'image jointe est la miniature de la partie précédente. Refais EXACTEMENT cette image, à l'identique : mêmes personnages, mêmes poses, même décor, même cadrage, mêmes couleurs, même titre, mêmes lettres, même mise en page. UN SEUL changement : le repère de partie devient « PARTIE ${part} »${prevPart ? ` (à la place de « PARTIE ${prevPart} »)` : ''}, écrit au même endroit, dans le même style et la même couleur. Ne change rien d'autre, n'ajoute rien. Format portrait vertical 9:16. Ne réponds que par l'image.`;
}
/* Analyse Gemini (lib/analysis.js, format du Radar) → note en texte clair jointe à la demande de Claude */
export function hookNote(a) {
  a = a || {}; const h = a.hook || {}, q = a.question || {}, L = ['ANALYSE DE LA VIDÉO D\'ORIGINE PAR GEMINI (aide pour écrire le hook)', ''];
  const line = (k, v) => { if (v) L.push(`- ${k} : ${v}`); };
  L.push(`LE HOOK (${h.temps || '00:00-00:03'})`); line('Ce qu\'on voit', h.visuel); line('Ce qu\'on entend ou lit', h.texte_ou_voix); line('Type de hook', h.type); line('Pourquoi ça empêche de scroller', h.pourquoi);
  if (q.question) { L.push('', 'LA QUESTION QUI FAIT RESTER'); line('Question', q.question); line('Posée à', q.posee_a); line('Réponse', q.reponse); line('Donnée à', q.repondue_a); }
  if (a.resume) L.push('', 'EN BREF', a.resume);
  const list = (title, arr) => { if (arr && arr.length) { L.push('', title); arr.forEach((x) => L.push(`- ${x}`)); } };
  list('CE QUI RETIENT LES GENS', a.retention); list('POURQUOI ÇA MARCHE', a.pourquoi_ca_marche);
  if (a.retournement && a.retournement.description) L.push('', `LE RETOURNEMENT (${a.retournement.moment || '?'}) : ${a.retournement.description}`);
  if (a.fin) L.push('', `LA FIN : ${a.fin}`);
  return L.join('\n');
}
/* Catégorie proposée pour une planche, d'après sa description (modifiable ensuite dans Personnages) */
export function charCat(p) {
  const t = ` ${String((p && (p.prompt || '')) || '')} ${String((p && p.name) || '')} `.toLowerCase();
  const n = (words) => (t.match(new RegExp(`(?<![\\p{L}])(${words})(?![\\p{L}])`, 'gu')) || []).length;
  // L'espèce (oiseau, fruit…) est le STYLE ; la catégorie dit d'abord si c'est un enfant, une femme ou un homme, et « Animaux » seulement à défaut
  if (n('enfant|bébé|bebe|fillette|garçonnet|child|kid|baby|toddler|little girl|little boy')) return 'Enfants';
  const f = n('femme|woman|female|fille|girl|mère|mother|épouse|wife|madame|lady|she|her|feminine|féminine');
  const h = n('homme|man|male|garçon|boy|père|father|mari|husband|monsieur|gentleman|he|his|him|masculine|masculin');
  if (f !== h) return f > h ? 'Femmes' : 'Hommes';
  return n('chien|chat|cheval|animal|dog|cat|horse|puppy|kitten|pet') ? 'Animaux' : '';
}
/* Verrou des voix : Grok fait parfois dire la réplique d'un personnage par un autre, ou fait parler un personnage qui n'a pas de réplique.
   À partir des répliques du prompt lui-même (« RÉPLIQUE n — QUI (position, espèce, marqueur) : "texte" »), on ajoute :
   - EN TÊTE du prompt (ce que Grok lit en premier) : combien de personnages parlent, lesquels, où ils sont dans l'image, dans quel ordre,
     et que tous les autres personnages visibles n'ont AUCUNE réplique ;
   - À LA FIN : la liste « qui dit quoi », réplique par réplique, avec la place du personnage dans l'image. */
const SPEAKER_POS = [[/\b(gauche|left)\b/i, 'on the LEFT of the frame'], [/\b(droite|right)\b/i, 'on the RIGHT of the frame'], [/\b(centre|milieu|center|middle)\b/i, 'in the CENTER of the frame'],
  [/\b(premier plan|devant|foreground|front)\b/i, 'in the FOREGROUND'], [/\b(arrière-plan|arriere-plan|au fond|fond|background)\b/i, 'in the BACKGROUND']];
export function speakerLines(video) {
  return String(video || '').split('\n').map((l) => l.trim().match(/^R[ÉE]PLIQUE\s*(\d+)\s*[—–-]\s*(.+?)\s*:\s*["«“]\s*(.+?)\s*["»”]?\s*$/i)).filter(Boolean).map((m) => {
    const who = m[2].trim(), inside = (who.match(/\(([^)]*)\)/) || [])[1] || '';
    return { who, off: /narrat|voix[- ]?off|voice[- ]?over|hors[- ]?champ|off[- ]?screen/i.test(who), label: who.replace(/\s*\([^)]*\)\s*/g, ' ').replace(/\s+/g, ' ').trim(), pos: SPEAKER_POS.filter(([re]) => re.test(inside)).map(([, en]) => en).join(' and '),
      text: m[3].replace(/\s*\([^)]*\)\s*/g, ' ').replace(/\s+/g, ' ').trim().replace(/["»”]+$/, '').trim() };
  });
}
export function withSpeakerLock(video) {
  const t = String(video || '').replace(/\s+$/, '');
  if (/SPEAKER LOCK/i.test(t)) return t;
  const lines = speakerLines(t);
  if (!lines.length) return t;
  const full = (x) => (x.off ? `${x.who} — an OFF-SCREEN voice, no mouth on screen moves for this line` : `${x.who}${x.pos ? ` — the character ${x.pos}` : ''}`);
  const anyOff = lines.some((x) => x.off);
  const speakers = [...new Map(lines.map((x) => [x.label.toLowerCase(), x])).values()];
  const one = speakers.length === 1;
  const head = `WHO SPEAKS — READ THIS FIRST: in this clip exactly ${speakers.length} ${anyOff ? 'voice' : 'character'}${one ? '' : 's'} speak${one ? 's' : ''}: ${speakers.map(full).join(' ; ')}. `
    + `Order of the ${lines.length} spoken line${lines.length > 1 ? 's' : ''}: ${lines.map((x, i) => `${i + 1}) ${x.label}`).join(', then ')}. `
    + 'Every OTHER character visible in the image has NO line at all: lips sealed and completely silent from the first frame to the last, reacting only with eyes, face and body. '
    + (anyOff ? 'A line is never spoken by a character other than its owner.' : 'A line is never spoken by a character other than its owner, and never by an off-screen voice or a narrator.');
  const list = lines.map((x, i) => `${i + 1}) ${full(x)} — and nobody else — says: "${x.text}"`).join('\n');
  const tail = `SPEAKER LOCK — NON NEGOTIABLE: this clip has exactly ${lines.length} spoken line${lines.length > 1 ? 's' : ''}, in this exact order, each one by ONE character only.\n${list}\n`
    + 'While a line is spoken, ONLY its owner\'s mouth moves (lip-sync on that character alone) and that character is clearly on screen; every other character keeps the mouth fully closed and stays silent. '
    + (anyOff ? 'During an off-screen line, NO mouth on screen moves at all. ' : '')
    + `A character never says a line assigned to another character. Voices are never swapped${one ? '' : `: the ${speakers.length} speakers have clearly different voices, and each keeps the same single voice for the whole clip`}. `
    + 'Characters without a line never speak, never whisper, never mouth words. No other words are spoken by anyone.';
  const nl = t.indexOf('\n');
  const body = nl < 0 ? `${t}\n\n${head}` : `${t.slice(0, nl)}\n\n${head}\n${t.slice(nl)}`;
  return `${body}\n\n${tail}`;
}
/* Mot fort : ligne écrite par Claude dans le prompt vidéo de 1 ou 2 scènes, quand l'option est cochée.
   Forme attendue : MOT FORT À L'ÉCRAN : « BLEUS » — COLOR: deep cobalt blue… ; LOOK: glossy 3D letters… ; PLACE: upper third… ; WHEN: silent beat…
   (anciens packages : un style libre après le tiret, sans rubriques — il sert alors de rendu). */
const KEYWORD_LINE = /^.*MOT FORT (?:À|A) L['’][ÉE]CRAN\s*:\s*(.+)$/im;
const KW_LABELS = { color: 'COLOU?R|COULEUR', look: 'LOOK|STYLE|RENDU', place: 'PLACE(?:MENT)?|ENDROIT', when: 'WHEN|MOMENT|QUAND' };
export function keywordOf(video) {
  const m = String(video || '').match(KEYWORD_LINE); if (!m) return null;
  const rest = m[1].trim(), q = rest.match(/^[«"“]\s*(.+?)\s*[»"”]\s*(?:[—–\-:,;]\s*)?(.*)$/);
  let word = '', style = '';
  if (q) { word = q[1]; style = q[2]; } else { const parts = rest.split(/\s+[—–-]\s+/); word = parts[0]; style = parts.slice(1).join(', '); }
  word = word.replace(/[.«»"“”\s]+$/g, '').replace(/\s+/g, ' ').trim();
  if (!word || word.split(' ').length > 3) return null; // une phrase n'est pas un mot fort : la scène reste sans texte
  const all = Object.values(KW_LABELS).join('|'), out = { word: word.slice(0, 40) }; // le mot garde sa casse, ses chiffres et ses symboles : il s'affiche tel que Claude l'a écrit
  for (const [k, re] of Object.entries(KW_LABELS)) {
    const x = style.match(new RegExp(`(?:^|[;.,]\\s*|\\s)(?:${re})\\s*:\\s*([\\s\\S]*?)(?=\\s*[;.,]?\\s*(?:${all})\\s*:|$)`, 'i'));
    out[k] = x ? x[1].trim().replace(/[;.,\s]+$/, '').slice(0, 260) : '';
  }
  out.style = out.color || out.look || out.place || out.when ? '' : style.trim().replace(/[.\s]+$/, '').slice(0, 260);
  return out;
}
const NO_TEXT_HEAD = 'NOTHING IS WRITTEN ON SCREEN in this video: no subtitles, no captions, no titles, no written dialogue, no sign, label or screen with readable letters, words or numbers. Every dialogue line below is SPOKEN AUDIO ONLY and is never displayed as text.';
export function withNoText(video, allowKeyword = false) {
  let t = String(video || '').replace(/\s+$/, '');
  const kw = allowKeyword ? keywordOf(t) : null;
  t = t.replace(new RegExp(KEYWORD_LINE.source, 'gim'), '').replace(/\n{3,}/g, '\n\n').trim(); // la ligne « mot fort » ne part jamais telle quelle
  if (kw) {
    // Le mot est annoncé juste après la phrase d'ouverture (ce que Grok lit d'abord), puis décrit en détail à la fin :
    // quand (un temps sans parole), couleur (celle que Claude a tirée de l'histoire), rendu (lettres en volume), placement (hors visage, hors zone des légendes).
    const head = `ONLY ONE WRITTEN WORD in this whole video: "${kw.word}". It is a designed 3D title word inside the scene, not a subtitle. No sentence, no other word of the dialogue and no caption is ever written: every dialogue line below is SPOKEN AUDIO ONLY.`;
    t = t.replace(/\bno on-screen text\b/gi, `no on-screen text except the single written word "${kw.word}"`).replace(/\b(no\s+)?text overlays?\b/gi, `no text overlay except the single written word "${kw.word}"`);
    const nl = t.indexOf('\n');
    t = nl >= 40 ? `${t.slice(0, nl)}\n${head}${t.slice(nl)}` : `${head}\n\n${t}`;
    const look = kw.look || kw.style || 'bold glossy 3D letters with real depth, beveled edges and soft reflections of the scene light';
    return `${t}\n\nTHE WRITTEN WORD — "${kw.word}", and nothing else. A beautiful 3D title word that belongs to the scene, never a subtitle.
- WHEN: ${kw.when || 'during a silent beat of about 2 seconds, right after the key line'}. Nobody speaks while the word is visible: no voice, no moving lips. It pops in with one quick, punchy 3D pop, holds still, then disappears before anyone speaks again.
- COLOR: ${kw.color || 'the main color of the character or object this scene is about, clearly standing out from the background'}. The letters are entirely this color: this color is mandatory.
- LOOK: ${look}. Clean, sharp and premium, with a subtle contact shadow so it sits in the scene.
- PLACE: ${kw.place || 'in the upper half of the frame, over a calm area of the background, next to the character concerned'}. Never on a face, never in the lower third of the frame, never as a banner across the top or bottom. Clearly readable: between one third and one half of the frame width.
Spelled exactly "${kw.word}", character for character${/\d/.test(kw.word) ? ' (digits, spaces and symbols exactly as written, thick and wide numerals)' : ''}. The rest of the dialogue is NEVER written. No subtitles, no captions, no other letters, words or numbers anywhere, no logos, no watermark.`;
  }
  // la consigne est dite deux fois : juste après la phrase d'ouverture (qui fixe le style et reste en tête), et à la fin
  if (!/NOTHING IS WRITTEN ON SCREEN/i.test(t)) {
    const nl = t.indexOf('\n');
    t = nl >= 40 ? `${t.slice(0, nl)}\n${NO_TEXT_HEAD}${t.slice(nl)}` : `${NO_TEXT_HEAD}\n\n${t}`;
  }
  return /NO TEXT ON SCREEN:/i.test(t) ? t : `${t}\n\n${NO_TEXT_VIDEO}`;
}

export const OPENING_DEFAULT = 'Vertical 9:16 cinematic 3D animation, semi-realistic textured fruit-and-vegetable characters, animate the attached image (@image1) while keeping its exact setting, lighting, characters, outfits and props unchanged.';
/* la phrase d'ouverture commune est lue dans le métaprompt lui-même (si tu l'as modifié, c'est ta version qui compte) */
export function openingOf(metaText) {
  const m = /^Vertical 9:16 cinematic 3D animation[^\n]*$/m.exec(metaText || '');
  return m ? m[0].trim() : OPENING_DEFAULT;
}
export function videoProblems(s, opening = OPENING_DEFAULT) {
  const t = String(s.video || '').replace(/\r/g, '');
  const out = [];
  if (!t.trim()) return ['prompt vidéo vide'];
  if (/```/.test(t)) out.push('le prompt est dans un bloc code (texte brut obligatoire)');
  const first = t.split('\n').find((l) => l.trim()) || '';
  if (first.trim() !== opening) out.push('la première ligne doit être la phrase d\'ouverture commune, mot pour mot');
  const dyn = /CHARACTERS AND VOICES/.test(t);
  if (/ANIMATION BRIEF/i.test(t)) out.push('en-tête interdit (« ANIMATION BRIEF »)');
  if (dyn) {
    for (const k of ['ACTION', 'CAMERA', 'DIALOGUE', 'CRITICAL RULE', 'AUDIO:', 'NEGATIVE:']) if (!t.includes(k)) out.push(`bloc « ${k.replace(':', '')} » absent de la version dynamique`);
  } else {
    if (!/Characters in shot:/.test(t)) out.push('« Characters in shot: » absent (gabarit version normale)');
    for (const k of ['Voices:', 'Dialogue:', 'ANIMATION RULES', 'EYELINE', 'AUDIO:', 'OUTPUT:']) if (!t.includes(k)) out.push(`« ${k.replace(':', '')} » absent de la version normale`);
  }
  if (/@image[2-9]/i.test(t)) out.push('seule @image1 existe (pas de @image2, @image3…)');
  if (!/RÉPLIQUE 1/.test(t)) out.push('répliques numérotées absentes (RÉPLIQUE 1 — …)');
  { const numbered = t.split('\n').filter((l) => /^\s*R[ÉE]PLIQUE\s*\d+/i.test(l)).length;
    if (numbered && speakerLines(t).length < numbered) out.push('chaque réplique tient sur UNE ligne, avec le personnage qui la dit puis le texte entre guillemets : RÉPLIQUE n — NOM (place dans l\'image, espèce, signe distinctif) : "texte"'); }
  if (s.duree && !new RegExp(`\\b${s.duree}\\s*(secondes|seconds|s)\\b`, 'i').test(t.slice(t.search(/Dialogue|DIALOGUE/) >= 0 ? t.search(/Dialogue|DIALOGUE/) : 0))) out.push(`le bloc Dialogue doit annoncer ${s.duree} secondes (durée de la scène)`);
  if (!/exactement la même voix que d'habitude/i.test(t)) out.push('verrou de voix incomplet (« exactement la même voix que d\'habitude, cette fois… » absent)');
  if (!dyn && /(bruitage|sound effects?)/i.test(t.replace(/NO (background music, NO soundtrack, NO )?sound effects/gi, ''))) out.push('pas de bruitages dans la version normale');
  return out;
}
export function v6Problems(pkg, opening = OPENING_DEFAULT) {
  const res = [];
  for (const s of pkg.scenes) { const list = videoProblems(s, opening); if (s.n === 1 && s.duree > 10) list.push('la scène 1 dure 6 secondes par défaut, 10 au maximum'); if (list.length) res.push({ n: s.n, list }); }
  return res;
}
export function fixMessage(problems) {
  return `CONTRÔLE MÉTAPROMPT V6 : un programme a relu tes prompts vidéo et trouvé des règles VERROUILLÉES non respectées.\n\n${problems.map((p) => `Scène ${p.n} :\n${p.list.map((x) => `- ${x}`).join('\n')}`).join('\n\n')}\n\nRéécris UNIQUEMENT ces scènes ${problems.map((p) => p.n).join(', ')}, en entier (blocs @@SCENE …@@ avec @@IMAGE@@, @@VIDEO@@ et @@MONTAGE@@, chacun fermé par @@FIN@@), en suivant à la lettre le gabarit du métaprompt (phrase d'ouverture commune en première ligne, gabarit version normale ou dynamique complet, verrou de voix recopié, dialogue annonçant la bonne durée). Garde l'histoire, les répliques et les planches. Même forme de sortie qu'avant, puis @@FINI@@.`;
}
/* Corrections mécaniques, quand Claude n'a pas corrigé après relance : retire les accents graves, remet la phrase d'ouverture */
export function patchVideo(s, opening = OPENING_DEFAULT) {
  let t = String(s.video || '').replace(/\r/g, '').replace(/```[a-z]*\n?/gi, '').trim();
  const lines = t.split('\n'); const i = lines.findIndex((l) => l.trim());
  if (i >= 0 && lines[i].trim() !== opening) {
    if (/^Vertical 9:16 cinematic 3D animation/i.test(lines[i].trim())) lines[i] = opening; else lines.splice(i, 0, opening, '');
    t = lines.join('\n');
  }
  return t;
}
