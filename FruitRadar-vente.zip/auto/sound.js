// Les sons de l'automatisation, fabriqués ici (aucun fichier audio) et joués par un document hors écran.
//   done  : arpège qui monte, quand la vidéo est prête
//   alert : deux « ding-dong » doux, quand l'automatisation a besoin de toi (pause)
//   info  : une petite note, pour un essai raté ou une attente longue
const RATE = 44100;
const SOUNDS = {
  // [fréquence, départ (s), durée (s), niveau]
  done: { seq: [[587.33, 0, 0.9, 1], [739.99, 0.11, 0.9, 0.9], [880, 0.22, 0.9, 0.9], [1174.66, 0.33, 1.5, 1], [880, 0.64, 1.3, 0.4], [1479.98, 0.64, 1.5, 0.5]], dur: 2.4, decay: 3.2, echo: [0.19, 0.28] },
  alert: { seq: [[880, 0, 0.55, 1], [659.25, 0.2, 0.8, 1], [880, 0.66, 0.55, 0.85], [659.25, 0.86, 1.0, 0.85]], dur: 2.1, decay: 4.4, echo: [0.14, 0.18] },
  info: { seq: [[783.99, 0, 0.5, 0.8], [1046.5, 0.09, 0.7, 0.6]], dur: 1.1, decay: 5, echo: [0.12, 0.15] }
};
// Timbre de carillon : la note, puis des harmoniques plus faibles qui s'éteignent plus vite
const PARTIALS = [[1, 1, 1], [2, 0.42, 1.8], [3.01, 0.16, 2.6], [4.1, 0.06, 3.4]];

function wav(kind) {
  const S = SOUNDS[kind] || SOUNDS.done;
  const n = Math.floor(RATE * S.dur), f = new Float32Array(n);
  for (const [hz, t0, len, amp] of S.seq) {
    const a = Math.floor(t0 * RATE), m = Math.floor(len * RATE);
    for (let i = 0; i < m && a + i < n; i++) {
      const t = i / RATE;
      let s = 0;
      for (const [ratio, level, speed] of PARTIALS) s += level * Math.sin(2 * Math.PI * hz * ratio * t) * Math.exp((-S.decay * speed * t) / len);
      f[a + i] += s * Math.min(1, i / 180) * amp;
    }
  }
  const d = Math.floor(S.echo[0] * RATE);
  for (let i = d; i < n; i++) f[i] += f[i - d] * S.echo[1]; // un peu d'espace
  let peak = 0;
  for (let i = 0; i < n; i++) peak = Math.max(peak, Math.abs(f[i]));
  const gain = 0.72 / (peak || 1), fade = Math.floor(0.08 * RATE);
  const buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVEfmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, RATE, true); v.setUint32(28, RATE * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
  for (let i = 0; i < n; i++) v.setInt16(44 + i * 2, Math.round(f[i] * gain * Math.min(1, (n - i) / fade) * 32767), true);
  return new Blob([buf], { type: 'audio/wav' });
}

const cache = {};
function play(kind) {
  const k = SOUNDS[kind] ? kind : 'done';
  cache[k] = cache[k] || URL.createObjectURL(wav(k));
  const audio = new Audio(cache[k]);
  audio.volume = 0.9;
  return audio.play();
}
if (globalThis.chrome && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((msg) => { if (msg && msg.type === 'autoChime') play(msg.kind).catch(() => {}); });
  play(new URLSearchParams(location.search).get('k')).catch(() => {});
}
