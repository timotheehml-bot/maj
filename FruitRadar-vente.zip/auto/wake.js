/* FruitRadar — réveiller la lecture vidéo d'une page d'extension cachée.
   Chrome ne charge aucune vidéo dans un onglet qui n'a jamais été affiché ; dès que la page a joué une vidéo en étant visible,
   il la laisse en lire d'autres même cachée (vérifié le 16 novembre 2026). La fenêtre pilote s'ouvre en arrière-plan : on joue donc
   une vidéo muette d'une demi-seconde dès que possible, et, en dernier recours, on affiche l'onglet une seconde pour le faire. */
let primed = false; // vrai dès que cette page a joué une vidéo en étant affichée : Chrome la laisse ensuite lire des vidéos même cachée
export function playPrime() {
  return new Promise((res) => {
    try {
      const v0 = document.createElement('video'); v0.muted = true; v0.playsInline = true; v0.src = chrome.runtime.getURL('auto/prime.mp4');
      v0.style.cssText = 'position:fixed;left:0;top:0;width:1px;height:1px;opacity:0;pointer-events:none';
      let done = false;
      const fin = () => { if (done) return; done = true; try { v0.remove(); } catch (e) { /* déjà retirée */ } res(primed); };
      v0.onplaying = () => { primed = true; }; v0.onended = fin; v0.onerror = fin; setTimeout(fin, 3000);
      (document.body || document.documentElement).appendChild(v0);
      const pl = v0.play(); if (pl && pl.catch) pl.catch(() => {});
    } catch (e) { res(false); }
  });
}
export const isPrimed = () => primed;
export function initWake() {
  playPrime();
  document.addEventListener('visibilitychange', () => { if (!primed && document.visibilityState === 'visible') playPrime(); });
}
/* Dernier recours avant de lire une vidéo avec le lecteur de la page : si cette page n'a jamais été affichée, on affiche son onglet
   une seconde (le temps de jouer la vidéo d'amorce), puis on revient à l'onglet d'avant. */
export async function wakeVideo() {
  if (primed) return true;
  if (document.visibilityState === 'visible') return playPrime();
  let me = null, prev = null;
  try {
    me = await chrome.tabs.getCurrent(); if (!me) return false;
    [prev] = await chrome.tabs.query({ active: true, windowId: me.windowId });
    await chrome.tabs.update(me.id, { active: true });
  } catch (e) { return false; }
  if (document.visibilityState !== 'visible') await new Promise((res) => { const t = setTimeout(res, 3000); document.addEventListener('visibilitychange', () => { clearTimeout(t); res(); }, { once: true }); });
  const ok = document.visibilityState === 'visible' ? await playPrime() : false;
  try { if (prev && prev.id !== me.id) await chrome.tabs.update(prev.id, { active: true }); } catch (e) { /* l'onglet d'avant a été fermé */ }
  return ok;
}

