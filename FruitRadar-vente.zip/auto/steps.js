// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
// FruitRadar — la chaîne de fabrication, dessinée pareil dans le dashboard et dans la fenêtre pilote.
const svg = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;

export const STEPS = [
  { key: 'source', label: 'Source', by: 'TikTok, TurboScribe', icon: '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>' },
  { key: 'package', label: 'Package', by: 'Claude', icon: '<path d="M4 20l4-1L19 8l-3-3L5 16l-1 4z"/><path d="M14 7l3 3"/>' },
  { key: 'images', label: 'Images', by: 'ChatGPT', icon: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M4 18l5-5 4 4 3-3 4 4"/>' },
  { key: 'videos', label: 'Clips', by: 'Grok', icon: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10.5 9.5v5l4.5-2.5-4.5-2.5z"/>' },
  { key: 'capcut', label: 'Montage', by: 'CapCut', icon: '<circle cx="6" cy="7" r="2.6"/><circle cx="6" cy="17" r="2.6"/><path d="M8.2 8.4L20 17M8.2 15.6L20 7"/>' },
  { key: 'valider', label: 'Validation', by: 'toi', icon: '<circle cx="12" cy="12" r="3"/><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/>' },
  { key: 'tiktok', label: 'TikTok', by: 'Studio', icon: '<path d="M14 4v10.5a3.5 3.5 0 1 1-3.5-3.5"/><path d="M14 4c.3 2.6 2 4.2 4.5 4.4"/>' },
  { key: 'done', label: 'Prête', by: 'à publier', icon: '<path d="M5 12.5l4.5 4.5L19 7.5"/>' }
];
export const STATUS = { queued: 'En file d\'attente', running: 'En cours', paused: 'En pause', waiting: 'Attend ton accord', done: 'Prête', stopped: 'Mise de côté' };

/* p : la production, ou null pour montrer la chaîne au repos */
export function railHtml(p) {
  const steps = STEPS.filter((s) => (s.key !== 'source' || !p || p.mode === 'remake') && (!['valider', 'tiktok'].includes(s.key) || !p || p.tiktokFlow !== false));
  const idx = p ? steps.findIndex((s) => s.key === p.step) : -1;
  const stuck = p && ['paused', 'stopped'].includes(p.status);
  return `<ol class="rail">${steps.map((s, i) => {
    const cls = !p ? '' : p.status === 'done' || i < idx ? 'done' : i === idx ? (stuck ? 'on warn' : 'on') : '';
    return `<li class="${cls}"><span class="node">${svg(cls === 'done' ? STEPS[STEPS.length - 1].icon : s.icon)}</span><b>${s.label}</b><small>${s.by}</small></li>`;
  }).join('')}</ol>`;
}

/* Avancement d'une production : éléments générés sur le total (planches, images, clips, miniature) */
export function progressOf(p) {
  const k = p && p.pkg; if (!k) return { done: 0, total: 0, pct: 0 };
  const items = [...k.planches.map((x) => x.status), ...k.scenes.map((s) => s.imgStatus), ...k.scenes.map((s) => s.vidStatus), k.miniature ? k.miniature.status : 'done'];
  const done = items.filter((x) => x === 'done').length;
  return { done, total: items.length, pct: items.length ? Math.round((done / items.length) * 100) : 0 };
}
