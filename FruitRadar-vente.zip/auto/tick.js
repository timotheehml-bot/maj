// Minuterie hors de la page : Chrome ralentit les minuteries des onglets cachés, pas celles des workers.
onmessage = (e) => setTimeout(() => postMessage(e.data.id), e.data.ms);
