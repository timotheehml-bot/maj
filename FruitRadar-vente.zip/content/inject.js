/* FruitRadar — tourne dans la page TikTok (monde MAIN).
   Lit les réponses que TikTok charge déjà (fetch / XHR + JSON embarqué)
   et transmet les vidéos trouvées au script "bridge". */
(function () {
  if (window.__fruitradarInjected) return;
  Object.defineProperty(window, '__fruitradarInjected', { value: true });
  const lib = globalThis.__FRLib;
  if (!lib) return;

  const API_RE = /\/api\/(search|challenge|post|recommend|item|related|explore|music|preload|repost|favorite|user)/;

  const send = (items, origin) => {
    if (!items || !items.length) return;
    window.postMessage({ __fruitradar: true, kind: 'items', origin, items }, window.location.origin);
  };

  const handleJson = (json, origin) => {
    try { send(lib.extractItems(json), origin); } catch (e) { /* silencieux */ }
  };

  // --- fetch ---
  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = function (input, init) {
      const p = origFetch.apply(this, arguments);
      try {
        const url = typeof input === 'string' ? input : (input && input.url) || '';
        if (API_RE.test(url)) {
          p.then((res) => {
            try {
              const ct = res.headers.get('content-type') || '';
              if (!ct.includes('json') && !ct.includes('text')) return;
              res.clone().text().then((t) => {
                if (t && (t[0] === '{' || t[0] === '[')) {
                  try { handleJson(JSON.parse(t), 'fetch'); } catch (e) {}
                }
              }).catch(() => {});
            } catch (e) {}
          }).catch(() => {});
        }
      } catch (e) {}
      return p;
    };
  }

  // --- XHR ---
  const XO = XMLHttpRequest.prototype.open;
  const XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    try { this.__frUrl = String(url || ''); } catch (e) {}
    return XO.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function () {
    try {
      if (this.__frUrl && API_RE.test(this.__frUrl)) {
        this.addEventListener('load', () => {
          try {
            let data = null;
            if (this.responseType === '' || this.responseType === 'text') {
              const t = this.responseText;
              if (t && (t[0] === '{' || t[0] === '[')) data = JSON.parse(t);
            } else if (this.responseType === 'json') {
              data = this.response;
            }
            if (data) handleJson(data, 'xhr');
          } catch (e) {}
        });
      }
    } catch (e) {}
    return XS.apply(this, arguments);
  };

  // --- Compte TikTok connecté dans ce navigateur (pour prévenir si c'est ton compte principal) ---
  const readSession = (json) => {
    try {
      const scope = json && (json.__DEFAULT_SCOPE__ || json);
      const ctx = scope && (scope['webapp.app-context'] || (json.AppContext && json.AppContext.appContext));
      if (!ctx || typeof ctx !== 'object') return;          // structure inconnue : on ne dit rien
      const u = ctx.user;
      window.postMessage({
        __fruitradar: true, kind: 'session',
        uniqueId: (u && u.uniqueId) || null,
        nickname: (u && (u.nickName || u.nickname)) || null
      }, window.location.origin);
    } catch (e) {}
  };

  // --- JSON embarqué au chargement de la page ---
  const readEmbedded = () => {
    ['__UNIVERSAL_DATA_FOR_REHYDRATION__', 'SIGI_STATE', '__NEXT_DATA__'].forEach((id) => {
      const el = document.getElementById(id);
      if (el && el.textContent && !el.__frRead) {
        el.__frRead = true;
        try {
          const json = JSON.parse(el.textContent);
          handleJson(json, 'embedded');
          readSession(json);
        } catch (e) {}
      }
    });
  };
  document.addEventListener('DOMContentLoaded', readEmbedded);
  window.addEventListener('load', readEmbedded);
})();
