// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
// FruitRadar — service worker : réception des vidéos, scans programmés (avec découverte), actualisation des stats,
// et ouverture de la fenêtre pilote de l'automatisation (auto/runner.html fait le travail).
import './lib/normalize.js';
import * as DB from './lib/db.js';
import { getSettings, planFor, CODE_REV } from './lib/settings.js';
import * as LIC from './lib/license.js';
import { rankAll, fmtNum, fmtRate } from './lib/metrics.js';
import { relevance, normAccount, isNicheTag } from './lib/relevance.js';
import { scanReady } from './lib/risk.js';

// Firefox expose `browser` (promesses), Chrome expose `chrome`
const chrome = globalThis.browser ?? globalThis.chrome;
const IS_FIREFOX = chrome.runtime.getURL('').startsWith('moz-extension:');
const EXT_HOST = new URL(chrome.runtime.getURL('')).hostname;

const FR = globalThis.__FRLib;
const H = 3600 * 1000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const jitter = (a, b) => a + Math.random() * (b - a);
// hashtags trop génériques pour être explorés
const TAG_STOP = new Set(['fyp', 'foryou', 'foryoupage', 'pourtoi', 'pourtoii', 'viral', 'viralvideo', 'xyzbca', 'fy', 'fypage', 'trending',
  'tiktok', 'parati', 'capcut', 'foru', 'fypp', 'viraltiktok', 'ia', 'ai', 'drama', 'story', 'histoire', 'love', 'humour', 'funny', 'realcreator']);

const scanTabs = new Map(); // tabId -> requête en cours
let scanning = false;
const scanCtl = { stop: false, pause: false, win: null }; // commandes du bandeau de scan : arrêter, mettre en pause, reprendre
/* Entre deux pages : attend pendant une pause. Rend false si le scan doit s'arrêter. */
async function scanGate() {
  if (scanCtl.pause && !scanCtl.stop) {
    await setState({ paused: true });
    while (scanCtl.pause && !scanCtl.stop) { await sleep(700); await chrome.storage.local.get('scanState'); } // cet appel garde le service de fond éveillé pendant la pause
    await setState({ paused: false, pauseAsked: false });
  }
  return !scanCtl.stop;
}

/* ---------------- Utilitaires ---------------- */

const blockedSet = (settings) => new Set((settings.blockedAccounts || []).map(normAccount));

/* Toute la base, classée (même calcul que le dashboard) */
async function rankedBase(settings) {
  const blocked = blockedSet(settings);
  const entries = (await DB.getAll())
    .filter((v) => !v.isAd && !v.hidden && !blocked.has(normAccount(v.author && v.author.uniqueId)))
    .map((v) => ({ v, rel: relevance(v, settings) }));
  rankAll(entries, { isRef: (e) => e.rel.niche && e.v.type !== 'photo' });
  return entries;
}

function queryUrl(q) {
  q = q.trim();
  if (q.startsWith('#')) return 'https://www.tiktok.com/tag/' + encodeURIComponent(q.slice(1));
  if (q.startsWith('@')) return 'https://www.tiktok.com/@' + encodeURIComponent(q.slice(1));
  return 'https://www.tiktok.com/search/video?q=' + encodeURIComponent(q);
}

async function setState(patch) {
  const { scanState } = await chrome.storage.local.get('scanState');
  await chrome.storage.local.set({ scanState: { ...(scanState || {}), ...patch, updatedAt: Date.now() } });
}

async function saveItems(items, { source, fromScan }) {
  const settings = await getSettings();
  const blocked = blockedSet(settings);
  const kept = items.filter((it) => !it.isAd && !blocked.has(normAccount(it.author && it.author.uniqueId)));
  return DB.upsertItems(kept, {
    source,
    // scans : on garde tout (le tri fruits IA se fait à l'affichage) ; navigation : seulement les fruits IA
    accept: (it) => fromScan || (settings.passiveCapture && relevance(it, settings).niche)
  });
}

/* ---------------- Referer TikTok pour les miniatures, vidéos et sous-titres ---------------- */

async function installHeaderRules() {
  const action = { type: 'modifyHeaders', requestHeaders: [{ header: 'Referer', operation: 'set', value: 'https://www.tiktok.com/' }] };
  const requestDomains = ['tiktok.com', 'tiktokcdn.com', 'tiktokcdn-us.com', 'tiktokcdn-eu.com', 'tiktokv.com', 'tiktokv.eu', 'byteoversea.com', 'ibytedtos.com', 'muscdn.com'];
  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [1, 2],
      addRules: [
        // requêtes du service worker (et des téléchargements)
        { id: 1, priority: 1, action, condition: { requestDomains, resourceTypes: ['xmlhttprequest', 'media', 'other'], tabIds: [chrome.tabs.TAB_ID_NONE] } },
        // requêtes faites depuis le dashboard (miniatures comprises)
        { id: 2, priority: 1, action, condition: { requestDomains, resourceTypes: ['xmlhttprequest', 'media', 'image', 'other'], initiatorDomains: [EXT_HOST] } }
      ]
    });
  } catch (e) { console.warn('[FruitRadar] règles réseau', e); }
}

/* ---------------- Récupération d'une page vidéo ---------------- */

async function fetchVideoPage(url) {
  const res = await fetch(url, { credentials: 'include', headers: { 'Accept': 'text/html' } });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  return FR.extractFromHtml(await res.text());
}

async function refreshOne(video) {
  const items = await fetchVideoPage(video.url);
  const it = items.find((x) => x.id === video.id) || null;
  if (it) await saveItems([it], { source: null, fromScan: true });
  return it;
}

/* ---------------- Scan ---------------- */

async function waitTabComplete(tabId, timeout = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    try {
      const t = await chrome.tabs.get(tabId);
      if (t.status === 'complete') return true;
    } catch (e) { return false; }
    await sleep(500);
  }
  return false;
}

async function openScanWindow(settings) {
  const opts = { url: 'about:blank' };
  if (settings.windowMode === 'normal') Object.assign(opts, { width: 480, height: 860 });
  else opts.state = 'minimized';
  if (!IS_FIREFOX) opts.focused = false; // Firefox refuse cette option
  return chrome.windows.create(opts);
}

/* Charge une page TikTok (recherche, hashtag ou compte), la fait défiler, et compte les nouvelles vidéos */
async function visit(tabId, it, plan, report) {
  const entry = { q: it.q, kind: it.kind, added: 0, block: null };
  scanTabs.set(tabId, it.q);
  const before = await DB.count();
  try {
    await chrome.tabs.update(tabId, { url: queryUrl(it.q) });
    await sleep(1500);
    await waitTabComplete(tabId);
    await sleep(jitter(3000, 4500));
    let res = null;
    try {
      res = await chrome.tabs.sendMessage(tabId, { type: 'autoscroll', steps: plan.scroll, delay: 1400, keepalive: true });
    } catch (e) { /* le script n'a pas répondu : on garde ce qui a été capté */ }
    await sleep(1500);
    if (res && res.block) {
      entry.block = res.block;
      report.captcha = true;
      report.warnings.push(`« ${it.q} » : TikTok a demandé une vérification (captcha). Scan arrêté.`);
    }
  } catch (e) {
    if (!scanCtl.stop) report.warnings.push(`« ${it.q} » : ${e.message}`); // arrêt demandé : la fenêtre a été fermée exprès
  }
  entry.added = Math.max(0, (await DB.count()) - before);
  report.added += entry.added;
  report.perQuery.push(entry);
  scanTabs.delete(tabId);
  return entry;
}

/* Découverte : hashtags de la niche et comptes qui cartonnent, pas explorés récemment */
async function pickDiscovery(settings, plan, seen) {
  if (!plan.tags && !plan.accounts) return [];
  const { exploreLog = {} } = await chrome.storage.local.get('exploreLog');
  const now = Date.now();
  const fresh = (key, days) => !exploreLog[key] || now - exploreLog[key] > days * 24 * H;
  const niche = (await rankedBase(settings)).filter((e) => e.rel.niche && e.v.type !== 'photo');

  const tagMap = new Map();
  for (const e of niche) for (const t of new Set(e.v.hashtags || [])) {
    if (TAG_STOP.has(t) || !isNicheTag(t, settings)) continue;
    const s = tagMap.get(t) || { n: 0, views: 0 };
    s.n++; s.views += e.m.views; tagMap.set(t, s);
  }
  const tags = [...tagMap.entries()]
    .filter(([t, s]) => s.n >= 3 && !seen.has('#' + t) && fresh('#' + t, 3))
    .sort((a, b) => b[1].views - a[1].views)
    .slice(0, plan.tags)
    .map(([t]) => ({ q: '#' + t, kind: 'hashtag découvert' }));

  const accMap = new Map();
  for (const e of niche) {
    if (e.rel.mine) continue;
    const u = normAccount(e.v.author && e.v.author.uniqueId);
    if (!u) continue;
    const s = accMap.get(u) || { n: 0, views: 0 };
    s.n++; s.views += e.m.views; accMap.set(u, s);
  }
  const accounts = [...accMap.entries()]
    .filter(([u]) => !seen.has('@' + u) && fresh('@' + u, 2))
    .sort((a, b) => b[1].views - a[1].views)
    .slice(0, plan.accounts)
    .map(([u]) => ({ q: '@' + u, kind: 'compte découvert' }));
  return [...tags, ...accounts];
}

/* opts.only : liste de requêtes (mini-scan, ex. ton compte) · opts.breadth : étendue choisie pour ce scan */
async function runScan(trigger = 'manuel', opts = {}) {
  if (scanning) return { ok: false, reason: 'already' };
  scanning = true;
  const settings = await getSettings();
  const plan = planFor(settings, opts.breadth);
  const startedAt = Date.now();
  const mini = Array.isArray(opts.only);
  const list = mini
    ? opts.only.map((q) => ({ q, kind: 'ton compte' }))
    : [...plan.queries.map((q) => ({ q, kind: 'recherche' })), ...plan.mine.map((q) => ({ q, kind: 'ton compte' }))];
  const report = { trigger, breadth: plan.key, startedAt, perQuery: [], refreshed: 0, refreshFailed: 0, added: 0, warnings: [], captcha: false, blocked: false };
  let total = list.length + (mini ? 0 : plan.tags + plan.accounts);
  Object.assign(scanCtl, { stop: false, pause: false, win: null });
  await setState({ running: true, phase: 'recherche', done: 0, total, current: '', startedAt, trigger, paused: false, pauseAsked: false, stopping: false });

  let win = null;
  try {
    win = await openScanWindow(settings);
    scanCtl.win = win.id;
    const tabId = win.tabs[0].id;
    let done = 0;
    const visitAll = async (items) => {
      for (const it of items) {
        if (report.captcha) break; // inutile d'insister
        if (!(await scanGate())) break; // arrêté depuis le bandeau (ou reprise après une pause)
        await setState({ phase: 'recherche', done, total, current: it.q });
        await visit(tabId, it, plan, report);
        done++;
        await sleep(jitter(1500, 3000));
      }
    };

    // 1) Recherches, hashtags et ton compte
    await visitAll(list);

    // 2) Découverte : nouveaux hashtags et comptes de la niche
    if (!mini && !report.captcha && !scanCtl.stop) {
      const seen = new Set(list.map((i) => i.q.toLowerCase()));
      const disc = await pickDiscovery(settings, plan, seen);
      total = list.length + disc.length;
      await visitAll(disc);
      const { exploreLog = {} } = await chrome.storage.local.get('exploreLog');
      const now = Date.now();
      for (const d of disc) exploreLog[d.q.toLowerCase()] = now;
      for (const k of Object.keys(exploreLog)) if (now - exploreLog[k] > 30 * 24 * H) delete exploreLog[k];
      await chrome.storage.local.set({ exploreLog });
    }

    // 3) Nouveau relevé des vidéos fruits IA qui ne sont pas réapparues.
    //    Priorité : suivies 📌, puis meilleur score, les plus récentes et celles relevées il y a longtemps.
    if (!mini && opts.refresh !== false && !report.captcha && !scanCtl.stop && plan.refresh > 0) {
      const ranked = await rankedBase(settings);
      const maxAge = (settings.refreshMaxAgeDays || 10) * 86400;
      const nowMs = Date.now();
      const candidates = ranked
        .filter((e) => e.rel.niche && e.v.lastSeen < startedAt && (e.v.pinned || (nowMs / 1000 - (e.v.createTime || 0)) < maxAge))
        .map((e) => ({
          v: e.v,
          prio: (e.v.pinned ? 1000 : 0) + e.m.score
            + 30 * Math.min(1, (nowMs - (e.v.lastSeen || 0)) / (24 * H))
            + (e.m.ageH !== null && e.m.ageH < 72 ? 15 : 0)
        }))
        .sort((a, b) => b.prio - a.prio)
        .slice(0, plan.refresh);

      await setState({ phase: 'actualisation', done: 0, total: candidates.length, current: '' });
      let consecutiveFail = 0;
      for (let i = 0; i < candidates.length; i++) {
        if (!(await scanGate())) break;
        const { v } = candidates[i];
        await setState({ done: i, current: '@' + (v.author.uniqueId || '') });
        try {
          const it = await refreshOne(v);
          if (it) { report.refreshed++; consecutiveFail = 0; } else { report.refreshFailed++; consecutiveFail++; }
        } catch (e) { report.refreshFailed++; consecutiveFail++; }
        if (consecutiveFail >= 6) {
          report.blocked = true;
          report.warnings.push('Actualisation stoppée : TikTok bloque les requêtes pour le moment.');
          break;
        }
        await sleep(jitter(1200, 2600));
      }
    }
  } catch (e) {
    report.warnings.push('Erreur : ' + e.message);
  } finally {
    if (win) { try { await chrome.windows.remove(win.id); } catch (e) {} }
    scanTabs.clear();
    scanning = false;
    report.endedAt = Date.now();
    report.stopped = scanCtl.stop;
    if (report.stopped) report.warnings.push('Scan arrêté par toi : ce qui a été trouvé avant est gardé.');
    scanCtl.win = null;
    const { scanHistory = [] } = await chrome.storage.local.get('scanHistory');
    scanHistory.push({ t: startedAt, end: report.endedAt, trigger, pages: report.perQuery.length, refreshed: report.refreshed, captcha: report.captcha, blocked: report.blocked });
    const patch = { scanHistory: scanHistory.slice(-40) };
    if (mini) patch.lastMineScanAt = startedAt;
    else Object.assign(patch, { lastScanAt: startedAt, lastScanReport: report });
    if (report.captcha || report.blocked) {
      patch.pauseUntil = Date.now() + 24 * H;
      patch.pauseReason = report.captcha ? 'TikTok a demandé une vérification (captcha)' : 'TikTok a bloqué l\'actualisation des vidéos';
      report.warnings.push('Scans automatiques mis en pause 24 h par sécurité.');
    }
    await chrome.storage.local.set(patch);
    await setState({ running: false, phase: report.stopped ? 'arrêté' : 'fini', current: '', trigger, paused: false, pauseAsked: false, stopping: false });
  }

  if (settings.notify && !mini && !report.stopped) notifyReport(report).catch(() => {});
  return { ok: true, report };
}

async function notifyReport(report) {
  const settings = await getSettings();
  const ranked = await rankedBase(settings);
  const recent = ranked.filter((e) => e.rel.niche && e.v.type !== 'photo' && e.m.ageH !== null && e.m.ageH <= 7 * 24);
  const top = [...recent].sort((a, b) => b.m.score - a.m.score)[0];
  const hot = recent.filter((e) => e.m.hot).length;
  const lines = [`${report.added} nouvelle(s) vidéo(s), ${report.refreshed} actualisée(s).`];
  if (top) lines.push(`Top 7 j : @${top.v.author.uniqueId} — score ${top.m.score}, ${fmtNum(top.m.views)} vues, ${fmtRate(top.m)}`);
  if (hot) lines.push(`🔥 ${hot} vidéo(s) accélèrent en ce moment`);
  if (report.warnings.length) lines.push('⚠ ' + report.warnings[0]);
  chrome.notifications.create('fr-scan-' + report.startedAt, {
    type: 'basic', iconUrl: 'icons/icon128.png', title: 'FruitRadar — scan terminé', message: lines.join('\n'), priority: 0
  });
}

/* ---------------- Planification matin / soir ---------------- */

function lastSlotBefore(now, times) {
  let best = null;
  for (const d of [0, -1]) {
    for (const t of times) {
      const [h, m] = String(t).split(':').map(Number);
      if (!Number.isFinite(h)) continue;
      const dt = new Date(now);
      dt.setDate(dt.getDate() + d);
      dt.setHours(h, m || 0, 0, 0);
      const ts = dt.getTime();
      if (ts <= now && (!best || ts > best)) best = ts;
    }
  }
  return best;
}

async function checkDue() {
  const settings = await getSettings();
  const { scanState, lastScanAt, pauseUntil } = await chrome.storage.local.get(['scanState', 'lastScanAt', 'pauseUntil']);
  // verrou fantôme (navigateur fermé pendant un scan)
  if (scanState && scanState.running && !scanning) await setState({ running: false, phase: 'interrompu' });
  if (!settings.autoScan || scanning) return;
  if (LIC.required() && !LIC.access(await LIC.getState()).allowed) return; // version vendue sans clé valable (absente, refusée, en pause, retirée) : pas de scan automatique
  const now = Date.now();
  if (pauseUntil && pauseUntil > now) return; // pause de sécurité après un captcha
  const slot = lastSlotBefore(now, settings.scanTimes || []);
  if (!slot) return;
  if ((lastScanAt || 0) < slot && now - slot < 6 * H) {
    // pas de scan automatique avant que la personne ait vu une fois la fenêtre d'avant scan (choix du compte, risques)
    if (!scanReady(settings, await chrome.storage.local.get(['scanAck', 'scanHistory']))) return;
    // un compte de scan est déclaré et ce Chrome est connecté à un autre compte (celui de publication, souvent) : pas de scan automatique
    const want = normAccount(settings.scanAccount || '');
    if (want) {
      const { tiktokSession, scanSkip } = await chrome.storage.local.get(['tiktokSession', 'scanSkip']);
      const uid = tiktokSession && tiktokSession.uniqueId ? normAccount(tiktokSession.uniqueId) : '';
      if (uid && uid !== want) {
        if (!scanSkip || scanSkip.slot !== slot) {
          await chrome.storage.local.set({ scanSkip: { slot, at: now, uid, want } });
          try { chrome.notifications.create('fr-scan-skip-' + slot, { type: 'basic', iconUrl: 'icons/icon128.png', title: 'FruitRadar — scan automatique sauté', message: `Ce Chrome est connecté à @${uid}, pas à ton compte de scan @${want}. Passe sur @${want} dans TikTok, puis lance un scan.`, priority: 0 }); } catch (e) { /* notification refusée */ }
        }
        return;
      }
    }
    await chrome.storage.local.remove('scanSkip').catch(() => {});
    runScan('auto');
  }
}

chrome.runtime.onInstalled.addListener(async (details) => {
  await chrome.alarms.create('tick', { periodInMinutes: 10 });
  await installHeaderRules();
  try { const u = (await chrome.storage.local.get('fr_update')).fr_update; if (u && u.busy) await chrome.storage.local.set({ fr_update: { ...u, busy: 0 } }); } catch (e) { /* rien à lever */ } // FruitRadar vient de redémarrer : la mise à jour est finie, les vidéos peuvent repartir
  if (details.reason === 'install') {
    // pas de scan surprise juste après l'installation
    await chrome.storage.local.set({ lastScanAt: Date.now() });
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html?welcome=1') });
  }
});

chrome.runtime.onStartup.addListener(async () => {
  await chrome.alarms.create('tick', { periodInMinutes: 10 });
  await installHeaderRules();
  checkDue();
});

chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'tick') { checkDue(); if (LIC.required()) LIC.ensure().catch(() => null); } }); // la clé est revérifiée en tâche de fond (toutes les 6 h ; une clé refusée, toutes les 30 min)

chrome.notifications.onClicked.addListener((id) => {
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html' + (String(id).startsWith('fr-auto-') ? '#auto' : '')) });
});

/* ---------------- Messages ---------------- */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // « top » demandé par une page pilotée dont les minuteries sont bridées (fenêtre cachée)
  if (msg && msg.type === 'frTick') { setTimeout(() => { try { sendResponse(true); } catch (e) {} }, Math.min(60000, Math.max(0, Number(msg.ms) || 0))); return true; }
  // messages destinés à la fenêtre pilote ou au document sonore : ce n'est pas à l'arrière-plan de répondre
  if (msg && (msg.type === 'autoCmd' || msg.type === 'autoChime')) return false;
  (async () => {
    switch (msg && msg.type) {
      case 'items': {
        const tabId = sender.tab && sender.tab.id;
        const q = tabId !== undefined ? scanTabs.get(tabId) : undefined;
        const r = await saveItems(msg.items || [], { source: q || 'navigation', fromScan: q !== undefined });
        if (r.added && q === undefined && tabId !== undefined) {
          // petit compteur sur l'icône quand la capture passive trouve des vidéos
          const { passiveToday = 0 } = await chrome.storage.session.get('passiveToday');
          const n = passiveToday + r.added;
          await chrome.storage.session.set({ passiveToday: n });
          chrome.action.setBadgeBackgroundColor({ color: '#FFB21E' });
          chrome.action.setBadgeText({ text: n > 99 ? '99+' : String(n) });
        }
        return r;
      }
      case 'session':
        await chrome.storage.local.set({ tiktokSession: { uniqueId: msg.uniqueId || null, nickname: msg.nickname || null, at: Date.now() } });
        return { ok: true };
      case 'hello':
        return { ok: true, rev: CODE_REV, version: chrome.runtime.getManifest().version };
      case 'keepalive':
        return { ok: true, scanning };
      case 'scanNow':
        runScan('manuel', { breadth: msg.breadth });
        return { ok: true };
      case 'scanMine': {
        const settings = await getSettings();
        const only = (settings.myAccounts || []).map((a) => '@' + normAccount(a)).filter((q) => q.length > 1);
        if (!only.length) return { ok: false, error: 'Ajoute ton compte dans Réglages → Mon compte.' };
        if (scanning) return { ok: false, error: 'Un scan est déjà en cours.' };
        runScan('ton compte', { only, refresh: false });
        return { ok: true };
      }
      case 'scanPause':
      case 'scanResume':
      case 'scanStop': { // bandeau « Scan en cours »
        if (!scanning) { await setState({ running: false, phase: 'interrompu', paused: false, pauseAsked: false, stopping: false }); return { ok: false, gone: true }; } // plus de scan (service redémarré) : le bandeau disparaît
        if (msg.type === 'scanPause') { scanCtl.pause = true; await setState({ pauseAsked: true }); return { ok: true }; }
        if (msg.type === 'scanResume') { scanCtl.pause = false; await setState({ pauseAsked: false }); return { ok: true }; }
        scanCtl.stop = true; await setState({ stopping: true });
        if (scanCtl.win) chrome.windows.remove(scanCtl.win).catch(() => {}); // la page TikTok en cours est abandonnée tout de suite
        return { ok: true };
      }
      case 'resumeScans':
        await chrome.storage.local.set({ pauseUntil: 0, pauseReason: '' });
        return { ok: true };
      case 'resolvePlay': {
        // URL fraîche de la vidéo (les liens TikTok expirent) + sous-titres + stats à jour au passage
        await installHeaderRules();
        const items = await fetchVideoPage(msg.url);
        const it = items.find((x) => x.id === String(msg.id));
        if (!it) return { ok: false, error: 'Vidéo introuvable dans la page (TikTok a peut-être demandé une vérification).' };
        await saveItems([it], { source: null, fromScan: true });
        return { ok: true, playUrl: it.playUrl, cover: it.cover, subtitles: it.subtitles || [], duration: it.duration };
      }
      case 'refreshOne': {
        const v = await DB.get(msg.id);
        if (!v) return { ok: false };
        const it = await refreshOne(v);
        return { ok: !!it };
      }
      case 'tiktokMe': { // quel compte TikTok est connecté dans ce Chrome ? (lu dans la page d'accueil de tiktok.com)
        await installHeaderRules();
        const res = await fetch('https://www.tiktok.com/', { credentials: 'include', headers: { 'Accept': 'text/html' } });
        if (!res.ok) return { ok: false, error: 'TikTok n\'a pas répondu (HTTP ' + res.status + ').' };
        const html = await res.text();
        let user = null;
        try {
          const m = /<script[^>]+id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>([\s\S]*?)<\/script>/.exec(html);
          const scope = m ? (JSON.parse(m[1]).__DEFAULT_SCOPE__ || {}) : {};
          user = (scope['webapp.app-context'] || {}).user || null;
        } catch (e) { user = null; }
        if (!user || !user.uniqueId) return { ok: false, error: 'Aucun compte connecté trouvé sur tiktok.com : connecte-toi dans ce Chrome, ou tape ton @.' };
        return { ok: true, uniqueId: String(user.uniqueId), nickname: String(user.nickName || user.nickname || '') };
      }
      /* ----- automatisation ----- */
      case 'autoOpen': { // ouvre (ou réutilise) la fenêtre pilote pour une production
        if (msg.cmd !== 'stop') { // arrêter reste toujours possible ; le reste demande une clé valable (l'édition de l'auteur répond toujours oui)
          const launch = !msg.cmd || msg.cmd === 'load' || msg.cmd === 'resume'; // lancer ou reprendre une vidéo : la clé est revérifiée auprès du serveur (pause ou retrait décidés par l'auteur)
          const lic = await LIC.ensure(launch).catch(() => ({ allowed: true }));
          if (!lic.allowed) return { ok: false, license: true, error: lic.message || 'Clé de licence à saisir : ouvre FruitRadar.' };
          const ca = LIC.canAuto(await LIC.getState()); if (!ca.allowed && ca.why === 'trial') return { ok: false, license: true, trial: true, error: ca.message }; // clé d'essai : Radar seulement
        }
        { const u = (await chrome.storage.local.get('fr_update')).fr_update; if (msg.cmd !== 'stop' && u && u.busy && Date.now() - u.busy < 3 * 60e3) return { ok: false, error: 'Une mise à jour de FruitRadar s\'installe : relance dans quelques secondes, après le redémarrage.' }; } // pas de vidéo lancée pendant que les fichiers changent
        const base = chrome.runtime.getURL('auto/runner.html');
        const open = (await chrome.tabs.query({})).filter((t) => (t.url || '').startsWith(base));
        if (open.length) {
          let r = null;
          for (let i = 0; i < 4 && !r; i++) { // une fenêtre pilote occupée peut répondre lentement : on insiste avant de la croire figée
            try { r = await chrome.runtime.sendMessage({ type: 'autoCmd', cmd: msg.cmd || 'load', id: msg.id, n: msg.n, text: msg.text, kind: msg.kind, key: msg.key }); } catch (e) { r = null; }
            if (!r) await new Promise((ok) => setTimeout(ok, 1500));
          }
          if (!r) { // Chrome met en veille un onglet resté longtemps en arrière-plan : on l'affiche pour le réveiller, puis on redemande
            try { await chrome.tabs.update(open[0].id, { active: true }); await chrome.windows.update(open[0].windowId, { focused: true }); } catch (e) { /* onglet disparu */ }
            for (let i = 0; i < 6 && !r; i++) {
              await new Promise((ok) => setTimeout(ok, 1500));
              try { r = await chrome.runtime.sendMessage({ type: 'autoCmd', cmd: msg.cmd || 'load', id: msg.id, n: msg.n, text: msg.text, kind: msg.kind, key: msg.key }); } catch (e) { r = null; }
            }
            if (r && sender && sender.tab && msg.cmd && msg.cmd !== 'load') { try { await chrome.tabs.update(sender.tab.id, { active: true }); await chrome.windows.update(sender.tab.windowId, { focused: true }); } catch (e) { /* rien */ } }
          }
          if (r) { if (r.ok && (msg.cmd || 'load') === 'load') { try { await chrome.windows.update(open[0].windowId, { focused: true }); } catch (e) {} } return r; }
          // toujours muette : pour un simple ordre (publier, valider, importer…), on ne ferme RIEN : fermer la fenêtre pilote relançait l'étape en cours et faisait perdre l'onglet TikTok prêt à publier
          if (msg.cmd && msg.cmd !== 'load' && msg.cmd !== 'resume') return { ok: false, error: 'L\'automatisation ne répond pas. Clique sur son onglet « FruitRadar — automatisation » pour la réveiller, puis réessaie. Rien n\'a été fermé.' };
          try { await chrome.tabs.remove(open.map((t) => t.id)); } catch (e) {} // fenêtre pilote figée : on la remplace
        }
        if (msg.cmd && msg.cmd !== 'load' && msg.cmd !== 'resume') return { ok: false, error: 'La fenêtre d\'automatisation est fermée. Rouvre la production et clique sur « Relancer » : l\'onglet TikTok déjà prêt sera repris tel quel.' };
        // par défaut, l'automatisation s'ouvre dans la fenêtre Chrome d'où elle est lancée (onglets rangés dans un groupe « FruitRadar ») ;
        // option « fenêtre à part » dans les réglages
        let same = false; try { same = ((await getSettings()).auto || {}).sameWindow === true; } catch (e) { /* réglages illisibles : fenêtre à part */ }
        const from = sender && sender.tab;
        if (same && from && from.windowId != null) await chrome.tabs.create({ windowId: from.windowId, index: from.index + 1, url: base + '?id=' + encodeURIComponent(msg.id), active: false });
        else await chrome.windows.create({ url: base + '?id=' + encodeURIComponent(msg.id), type: 'normal', width: 1320, height: 920, focused: true });
        return { ok: true, opened: true };
      }
      case 'autoPing': { // la fenêtre pilote est-elle ouverte, et sur quelle production ?
        const base = chrome.runtime.getURL('auto/runner.html');
        const open = (await chrome.tabs.query({})).filter((t) => (t.url || '').startsWith(base));
        if (!open.length) return { ok: false };
        try { return (await chrome.runtime.sendMessage({ type: 'autoCmd', cmd: 'ping' })) || { ok: false }; } catch (e) { return { ok: false }; }
      }
      case 'autoSound': {
        try {
          const kind = ['done', 'alert', 'info'].includes(msg.kind) ? msg.kind : 'done';
          if (await chrome.offscreen.hasDocument()) chrome.runtime.sendMessage({ type: 'autoChime', kind }).catch(() => {});
          else await chrome.offscreen.createDocument({ url: 'auto/sound.html?k=' + kind, reasons: ['AUDIO_PLAYBACK'], justification: 'Signal sonore quand l\'automatisation a fini ou a besoin de toi.' });
        } catch (e) { console.warn('[FruitRadar] son', e); }
        return { ok: true };
      }
      case 'openDashboard': {
        const url = chrome.runtime.getURL('dashboard/dashboard.html');
        const tabs = (await chrome.tabs.query({})).filter((t) => (t.url || '').startsWith(url));
        if (tabs.length) { await chrome.tabs.update(tabs[0].id, { active: true, url: url + (msg.hash ? '#' + msg.hash : '') }); try { await chrome.windows.update(tabs[0].windowId, { focused: true }); } catch (e) {} } else chrome.tabs.create({ url: url + (msg.hash ? '#' + msg.hash : '') });
        return { ok: true };
      }
      case 'clearBadge':
        await chrome.storage.session.set({ passiveToday: 0 });
        chrome.action.setBadgeText({ text: '' });
        return { ok: true };
      default:
        return null;
    }
  })().then(sendResponse).catch((e) => sendResponse({ ok: false, error: e.message }));
  return true;
});

// filet de sécurité au réveil du service worker
installHeaderRules();

// Rechargement demandé depuis le dashboard (fin de mise à jour) : on rouvre le dashboard
chrome.storage.local.get('reopenDashboard').then(({ reopenDashboard }) => {
  if (!reopenDashboard) return;
  chrome.storage.local.remove('reopenDashboard');
  if (typeof reopenDashboard !== 'number' || Date.now() - reopenDashboard > 30 * 60 * 1000) return;
  const url = chrome.runtime.getURL('dashboard/dashboard.html');
  return chrome.tabs.query({}).then((tabs) => {
    if (!tabs.some((t) => (t.url || '').startsWith(url))) chrome.tabs.create({ url });
  });
}).catch(() => {});
