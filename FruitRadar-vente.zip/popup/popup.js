// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
import * as DB from '../lib/db.js';
import { getSettings, saveSettings, CODE_REV } from '../lib/settings.js';
import { rankAll, fmtNum, fmtAge, fmtRate } from '../lib/metrics.js';
import { relevance, normAccount } from '../lib/relevance.js';

// Firefox expose `browser` (promesses), Chrome expose `chrome`
const chrome = globalThis.browser ?? globalThis.chrome;

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const dash = (q = '') => { chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html' + q) }); window.close(); };

(async () => {
  const settings = await getSettings();
  $('#passive').checked = settings.passiveCapture;
  $('#passive').onchange = (e) => saveSettings({ passiveCapture: e.target.checked });

  // même classement que le dashboard
  const blocked = new Set((settings.blockedAccounts || []).map(normAccount));
  const entries = (await DB.getAll())
    .filter((v) => !v.isAd && !v.hidden && !blocked.has(normAccount(v.author && v.author.uniqueId)))
    .map((v) => ({ v, rel: relevance(v, settings) }));
  rankAll(entries, { isRef: (e) => e.rel.niche && e.v.type !== 'photo' });
  const list = entries.filter((e) => e.rel.niche && e.v.type !== 'photo');
  $('#nTotal').textContent = fmtNum(list.length);
  $('#nNew').textContent = fmtNum(list.filter((x) => x.m.ageH !== null && x.m.ageH <= 24).length);

  const top = list.filter((x) => x.m.ageH !== null && x.m.ageH <= 7 * 24).sort((a, b) => (b.m.score - a.m.score) || (b.m.views - a.m.views)).slice(0, 5);
  $('#top').innerHTML = top.length
    ? '<h2>Score viral, 7 derniers jours</h2>' + top.map(({ v, m }) =>
      `<div title="${esc(fmtRate(m))}"><span><span class="sc">${m.score}</span>@${esc(v.author.uniqueId)}, ${fmtAge(m.ageH)}</span><b class="v">${fmtNum(m.views)}</b></div>`).join('')
    : '<span class="m">Rien encore : lance un scan ou scrolle TikTok.</span>';

  const { scanState, lastScanReport, pauseUntil } = await chrome.storage.local.get(['scanState', 'lastScanReport', 'pauseUntil']);
  if (scanState && scanState.running) {
    $('#state').textContent = scanState.paused ? 'Scan en pause' : 'Scan en cours…';
    $('#scan').disabled = true;
  } else {
    $('#state').textContent = lastScanReport ? 'Dernier scan : ' + new Date(lastScanReport.endedAt || lastScanReport.startedAt).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'Aucun scan encore';
  }
  if (pauseUntil && pauseUntil > Date.now()) {
    $('#pause').hidden = false;
    $('#pause').textContent = 'Scans auto en pause après un blocage TikTok. Détails dans le dashboard.';
  }

  let hello = null;
  try { hello = await chrome.runtime.sendMessage({ type: 'hello' }); } catch (e) {}
  if (!hello || hello.rev !== CODE_REV) {
    $('#pause').hidden = false;
    $('#pause').textContent = 'Mise à jour pas terminée : ouvre le dashboard et suis le bandeau en haut.';
  }

  $('#open').onclick = () => dash();
  // un scan manuel passe toujours par la fenêtre qui explique les risques
  $('#scan').onclick = () => dash('?scan=1');
})();
