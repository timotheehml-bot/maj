# FruitRadar

Repère les vidéos TikTok de fruits IA qui percent, puis fabrique les tiennes : écriture, images, clips, montage et préparation de la publication.

Créé par Timothée Hamel. © 2026 Timothée Hamel, tous droits réservés (voir LICENCE.txt).

## Installer
1. Décompresse le dossier quelque part où il restera (pas dans Téléchargements si tu le vides souvent).
2. Dans Chrome, ouvre `chrome://extensions`, active le « Mode développeur » en haut à droite.
3. Clique sur « Charger l'extension non empaquetée » et choisis le dossier décompressé.
4. Clique sur l'icône FruitRadar : le dashboard s'ouvre et te demande ta clé, puis te propose de créer ton compte.

## Ta clé
- Elle s'affiche à la fin de ton inscription, et tu la retrouves dans ton espace client. Colle-la dans l'écran « Entre ta clé FruitRadar ».
- Pas encore inscrit ? Le bouton « Commencer l'essai gratuit » de cet écran ouvre la page d'inscription.
- Pendant l'essai, le nombre de jours restants est affiché en bas du menu. Si tu arrêtes avant la fin, rien n'est prélevé.
- La clé est revérifiée toute seule. Sans internet, FruitRadar marche encore 3 jours.
- Changer d'ordinateur : onglet Support, « Ma licence », « Retirer la clé de cet ordinateur », puis colle-la sur le nouveau.
- Arrêter l'abonnement ou changer de carte : onglet Support, « Gérer mon abonnement ».

## Mises à jour
- Quand une nouvelle version existe, un bouton « Mise à jour » apparaît en bas du menu. Clique dessus, puis sur « Mettre à jour ».
- La première fois, Chrome te demande le dossier de FruitRadar : c'est celui que tu as dézippé à l'installation. Ne le déplace pas ensuite, sinon tu perds tes vidéos et tes réglages.
- FruitRadar se ferme pour redémarrer : rouvre-le avec son icône.

## Un bug, un avis
- Onglet Support : « Signaler un bug » ou « Donner mon avis ». Le message arrive directement au créateur de FruitRadar.
- Rien ne part tant que tu ne cliques pas sur « Envoyer », et tu peux voir avant ce qui sera envoyé.

## Ton compte
- Il est créé à la première ouverture : un prénom, ton compte TikTok, le nom de ta chaîne. Pas de mot de passe.
- Il reste dans ton Chrome, sur ton ordinateur : il n'est envoyé nulle part. Seule ta clé part vers la boutique pour être vérifiée, et tes messages de l'onglet Support quand tu cliques sur « Envoyer ».
- Pour le retrouver sur un autre ordinateur : Réglages, « Mon compte », « Sauvegarder mon compte », puis « Importer une sauvegarde » sur l'autre machine.

## Avant ta première vidéo
- Connecte-toi dans ce Chrome à : Claude, ChatGPT, Grok, CapCut, VideoTranscriber et TikTok.
- Page Automatisation, « Connexions aux sites », bouton « Tout tester » : chaque site doit passer au vert.
- Le guide complet est dans le menu de gauche, bouton « Guide ».

## À savoir
- FruitRadar pilote ces sites avec tes propres comptes, dans ton navigateur. Leurs conditions d'utilisation peuvent limiter l'usage d'outils automatiques : un compte peut être ralenti ou limité.
- Rien n'est publié sur TikTok sans ton clic.
- Tes fichiers (clips, vidéo finale, images) sont copiés dans Téléchargements/FruitRadar/Productions.
