# FruitRadar

Repère les vidéos TikTok de fruits IA qui percent, puis fabrique les tiennes : écriture, images, clips, montage et préparation de la publication.

Créé par Timothée Hamel. © 2026 Timothée Hamel, tous droits réservés (voir LICENCE.txt).

## Installer
1. Décompresse le dossier quelque part où il restera (pas dans Téléchargements si tu le vides souvent).
2. Dans Chrome, ouvre `chrome://extensions`, active le « Mode développeur » en haut à droite.
3. Clique sur « Charger l'extension non empaquetée » et choisis le dossier décompressé.
4. Clique sur l'icône FruitRadar : le dashboard s'ouvre et te demande ta clé, puis te propose de créer ton compte.

## Ta clé
- Elle s'affiche à la fin de ton inscription, et tu la retrouves dans ton espace client. Colle-la dans l'écran « Entre ta clé FruitRadar ».
- Pas encore de clé ? Sur cet écran, « Essayer le Radar » donne une clé d'essai gratuite (3 jours, sans carte) et « S'abonner » donne la clé d'abonné.
- La clé d'essai ouvre le Radar. Lancer des vidéos demande la clé d'abonné. À la fin de l'essai, rien n'est prélevé : la clé s'éteint toute seule.
- Une clé fonctionne sur un ordinateur à la fois.
- La clé est revérifiée toute seule par le serveur FruitRadar. Sans internet, FruitRadar marche encore 3 jours.
- Changer d'ordinateur : onglet Support, « Ma licence », « Retirer la clé de cet ordinateur », puis colle-la sur le nouveau. Si l'ancien ordinateur n'est plus là, la clé passe sur le nouveau quand l'ancien ne s'en est pas servi pendant 3 jours (ou écris au support).
- Arrêter l'abonnement ou changer de carte : onglet Support, « Gérer mon abonnement ».

## Mises à jour
- Quand une nouvelle version existe, un bouton « Mise à jour » apparaît en bas du menu. Clique dessus, puis sur « Mettre à jour ».
- La première fois, Chrome te demande le dossier de FruitRadar : c'est celui que tu as dézippé à l'installation. Ne le déplace pas ensuite, sinon tu perds tes vidéos et tes réglages.
- FruitRadar se ferme pour redémarrer : rouvre-le avec son icône.

## Un bug, un avis
- Onglet Support : « Signaler un bug » ou « Donner mon avis ». Le message arrive directement au créateur de FruitRadar.
- Rien ne part tant que tu ne cliques pas sur « Envoyer », et tu peux voir avant ce qui sera envoyé.

## Ton compte
- Il est créé à la première ouverture : un prénom, ton compte TikTok, le nom de ta chaîne. Pas de mot de passe.
- Il reste dans ton Chrome, sur ton ordinateur. Pour vérifier ta clé, le serveur FruitRadar reçoit la clé, un numéro tiré au hasard qui désigne ton ordinateur, ton système, tes versions de Chrome et de FruitRadar, ton prénom et ton @TikTok. Tes messages de l'onglet Support partent seulement quand tu cliques sur « Envoyer ».
- Le détail est sur https://fruitradar.fr/confidentialite.html
- Pour le retrouver sur un autre ordinateur : Réglages, « Mon compte », « Sauvegarder mon compte », puis « Importer une sauvegarde » sur l'autre machine.

## Avant ta première vidéo
- Connecte-toi dans ce Chrome à : Claude, ChatGPT, Grok, CapCut, VideoTranscriber et TikTok.
- Page Automatisation, « Connexions aux sites », bouton « Tout tester » : chaque site doit passer au vert.
- Le guide complet est dans le menu de gauche, bouton « Guide ».

## À savoir
- FruitRadar pilote ces sites avec tes propres comptes, dans ton navigateur. Leurs conditions d'utilisation peuvent limiter l'usage d'outils automatiques : un compte peut être ralenti ou limité.
- Rien n'est publié sur TikTok sans ton clic.
- Tes fichiers (clips, vidéo finale, images) sont copiés dans Téléchargements/FruitRadar/Productions.
