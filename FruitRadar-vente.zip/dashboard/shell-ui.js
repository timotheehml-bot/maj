// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
// Coque du dashboard : accueil, compte (création à la première ouverture), réglages « Mon compte » et « À propos », dictée vocale.
import * as DB from '../lib/db.js';
import { BUILD, IS_ADMIN, COPYRIGHT } from '../lib/build.js';
import { getAccount, saveAccount, exportAccount, importAccount, wipeEverything, cleanHandle } from '../lib/account.js';
import { SITES } from '../auto/sites.js';
import { STATUS, progressOf } from '../auto/steps.js';

const chrome = globalThis.browser ?? globalThis.chrome;
let H = null;
let account = null;
const VERSION = chrome.runtime.getManifest().version;
const SITE_KEYS = ['claude', 'chatgpt', 'grok', 'capcut', 'vt', 'turbo', 'tiktok'];
const MODES = { remake: 'Reproduction', idee: 'Mon idée', idees: '10 idées', suite: 'Suite' };

export async function init(helpers) {
  H = helpers;
  H.voiceActive = () => !!rec;
  account = await getAccount();
  paintChrome();
  bind();
  if (!account) openWelcome();
  return account;
}
export const currentAccount = () => account;

const firstName = () => String((account && account.name) || '').trim().split(/\s+/)[0] || '';
const initial = () => (firstName()[0] || '?').toUpperCase();

/* ---------- ce qui est toujours à l'écran : compte dans le menu, crédits ---------- */
function paintChrome() {
  const $ = H.$;
  const n = $('#navAccount');
  if (n) n.innerHTML = account
    ? `<span class="avatar" aria-hidden="true">${H.esc(initial())}</span><span class="acct-txt"><b>${H.esc(account.name)}</b><small>${IS_ADMIN ? 'Administrateur' : account.tiktok ? '@' + H.esc(account.tiktok) : 'Mon compte'}</small></span>`
    : '<span class="avatar" aria-hidden="true">?</span><span class="acct-txt"><b>Créer mon compte</b></span>';
  const c = $('#navCredit'); if (c) c.textContent = `Créé par ${BUILD.author}`;
  const sc = $('#setCredit'); if (sc) sc.textContent = `FruitRadar ${VERSION} · ${COPYRIGHT}`;
  const wc = $('#welcomeCredit'); if (wc) wc.textContent = `FruitRadar, créé par ${BUILD.author} · ${COPYRIGHT}`;
  H.$$('[data-admin]').forEach((el) => { el.hidden = !IS_ADMIN; });
  H.$$('.mic:empty').forEach((b) => { b.innerHTML = H.icon('mic'); b.title = 'Dicter à la voix'; });
}

/* ---------- première ouverture ---------- */
function openWelcome() {
  const w = H.$('#welcome'); if (!w) return;
  w.hidden = false; document.body.classList.add('locked');
  setTimeout(() => { const el = H.$('#wName'); if (el) el.focus(); }, 60);
}
async function detectTiktok(inputSel, statusSel) {
  const st = H.$(statusSel), inp = H.$(inputSel);
  st.textContent = 'Je regarde quel compte est connecté sur tiktok.com…'; st.className = 'status-line';
  let r = null;
  try { r = await chrome.runtime.sendMessage({ type: 'tiktokMe' }); } catch (e) { r = null; }
  if (r && r.ok && r.uniqueId) { inp.value = r.uniqueId; inp.dispatchEvent(new Event('input', { bubbles: true })); st.textContent = `Compte connecté trouvé : @${r.uniqueId}${r.nickname ? ` (${r.nickname})` : ''}.`; st.className = 'status-line ok'; }
  else { st.textContent = (r && r.error) || 'Je n\'ai pas trouvé : connecte-toi à tiktok.com dans ce Chrome, ou tape ton @ ici.'; st.className = 'status-line no'; }
}
async function readJsonFile(file) { return JSON.parse(await file.text()); }
async function doImport(file) {
  try {
    const out = await importAccount(await readJsonFile(file));
    account = await getAccount();
    paintChrome();
    H.toast(`Sauvegarde importée : ${out.videos} vidéos, ${out.productions} productions, ${out.characters} planches`, 5000);
    await H.reload();
    return true;
  } catch (e) { H.toast(e.message && /sauvegarde/.test(e.message) ? e.message : 'Fichier invalide : choisis une sauvegarde FruitRadar (.json)', 5000); return false; }
}

/* ---------- accueil ---------- */
export async function renderHome() {
  const box = H.$('#viewHome'); if (!box || box.hidden) return;
  const [prods, chars, st] = await Promise.all([DB.allProds(), DB.allChars(), chrome.storage.local.get(['autoState', 'siteChecks', 'lastScanAt', 'lastScanReport'])]);
  const state = st.autoState, checks = st.siteChecks || {};
  const live = state && ['running', 'paused', 'waiting', 'queued'].includes(state.status) ? prods.find((p) => p.id === state.id) : null;
  const hot = H.hot(4);
  const done = prods.filter((p) => p.status === 'done').length;
  const parked = prods.filter((p) => ['stopped', 'paused'].includes(p.status) && (!live || p.id !== live.id));
  const lastScan = (st.lastScanReport && st.lastScanReport.endedAt) || st.lastScanAt;
  const hello = new Date().getHours() < 18 ? 'Bonjour' : 'Bonsoir';

  const liveHtml = live ? (() => {
    const pr = progressOf(live);
    return `<button class="home-live ${live.status}" type="button" data-go="auto">
        <span class="home-live-st">${H.esc(STATUS[live.status] || live.status)}</span>
        <b>${H.esc(live.title || 'Nouvelle vidéo')}</b>
        <span class="home-live-msg">${H.esc(live.status === 'paused' ? ((live.pause && live.pause.reason) || 'En pause') : (state.msg || ''))}</span>
        <i class="meter${pr.total ? '' : ' wait'}"><span style="width:${pr.total ? Math.max(3, pr.pct) : 100}%"></span></i>
        <span class="home-live-go">${pr.total ? `${pr.done}/${pr.total} · ` : ''}Ouvrir${H.icon('ext')}</span>
      </button>`;
  })() : '';

  const tiles = [
    ['radar', 'radar', 'Voir ce qui perce', `${H.fmtNum(H.radarCount())} vidéos fruits IA au radar${lastScan ? `, scan ${H.relTime(lastScan)}` : ''}.`, 'data-go="radar"'],
    ['repeat', 'remake', 'Reproduire une vidéo', 'Une vidéo virale refaite avec tes personnages, de l\'écriture au montage.', 'data-action="newVideo"'],
    ['bolt', 'ideas', 'Demander 10 idées', 'Claude propose dix histoires, tu orientes et tu choisis.', 'data-action="ideas"'],
    ['film', 'prods', 'Mes productions', `${prods.length ? `${done} terminée${done > 1 ? 's' : ''}${parked.length ? `, ${parked.length} mise${parked.length > 1 ? 's' : ''} de côté` : ''}` : 'Aucune pour l\'instant'}, ${chars.length} planche${chars.length > 1 ? 's' : ''} de personnage.`, 'data-go="prods"']
  ].map(([ic, cls, title, sub, attr]) => `<button class="home-tile ${cls}" type="button" ${attr}>${H.icon(ic)}<b>${title}</b><span>${sub}</span></button>`).join('');

  const hotHtml = hot.length ? `<section class="panel"><div class="panel-head"><h3>Ça perce cette semaine</h3><button class="btn small ghost" type="button" data-go="radar">Tout le radar</button></div>
      <div class="home-hot">${hot.map((x, i) => `<article class="hotcard">
        <button class="hot-thumb" type="button" data-open="${H.esc(x.v.id)}" aria-label="Ouvrir la fiche de la vidéo de @${H.esc(x.v.author.uniqueId)}">${H.coverOk(x.v) ? `<img src="${H.esc(x.v.cover)}" alt="" loading="lazy">` : `<span class="nothumb">${H.icon('play')}</span>`}<span class="hot-rank">${i + 1}</span><span class="hot-score">${x.m.score}/100</span></button>
        <div class="hot-body"><b>@${H.esc(x.v.author.uniqueId)}</b><span class="muted">${H.fmtNum(x.m.views)} vues · ${H.fmtAge(x.m.ageH)}</span>
          <p>${H.esc(x.v.desc || 'Sans description')}</p>
          <button class="btn small primary" type="button" data-repro="${H.esc(x.v.id)}">${H.icon('repeat')}Reproduire</button></div></article>`).join('')}</div></section>`
    : `<section class="panel"><h3>Ça perce cette semaine</h3><p class="hint">Le radar est encore vide. Lance un premier scan : FruitRadar va chercher les vidéos de fruits IA qui décollent.</p><div class="row"><button class="btn primary" type="button" data-action="scan">${H.icon('radar')}Lancer un scan</button></div></section>`;

  const recent = prods.slice(0, 3);
  const recentHtml = `<section class="panel"><div class="panel-head"><h3>Dernières productions</h3>${prods.length ? '<button class="btn small ghost" type="button" data-go="prods">Tout voir</button>' : ''}</div>
      ${recent.length ? `<ul class="home-list">${recent.map((p) => `<li><button type="button" data-auto="open" data-id="${H.esc(p.id)}"><span class="st ${p.status}">${H.esc(STATUS[p.status] || p.status)}</span><b>${H.esc(p.title || MODES[p.mode] || 'Vidéo')}</b><small>${MODES[p.mode] || ''}, partie ${p.part || 1}</small></button></li>`).join('')}</ul>`
    : '<p class="hint">Tes vidéos apparaîtront ici dès la première lancée.</p>'}</section>`;

  const dots = SITE_KEYS.map((k) => { const c = checks[k]; return `<li class="${c ? (c.ok ? 'ok' : 'no') : ''}"><i class="sdot${c ? (c.ok ? ' ok' : ' no') : ''}"></i>${H.esc(SITES[k].name)}</li>`; }).join('');
  const tested = SITE_KEYS.filter((k) => checks[k]).length, bad = SITE_KEYS.filter((k) => checks[k] && !checks[k].ok).length;
  const sitesHtml = `<section class="panel"><div class="panel-head"><h3>Connexions</h3><button class="btn small ghost" type="button" data-go="auto" data-auto="conn">Vérifier</button></div>
      <ul class="home-sites">${dots}</ul>
      <p class="hint">${!tested ? 'Pas encore vérifiées : il faut être connecté à chaque site dans ce Chrome.' : bad ? `${bad} site${bad > 1 ? 's' : ''} à reconnecter avant de lancer une vidéo.` : 'Tout est connecté.'}</p></section>`;

  box.innerHTML = `
    <header class="home-head">
      <div><h2>${hello}${firstName() ? ` ${H.esc(firstName())}` : ''}</h2><p>Repère ce qui perce, puis laisse FruitRadar fabriquer la vidéo.</p></div>
      <button class="btn primary big" type="button" data-action="newVideo">${H.icon('sparkle')}Nouvelle vidéo</button>
    </header>
    ${liveHtml}
    <div class="home-tiles">${tiles}</div>
    ${hotHtml}
    <div class="home-cols">${recentHtml}${sitesHtml}</div>
    <footer class="home-foot"><span>FruitRadar ${H.esc(VERSION)}</span><button class="linkbtn" type="button" data-action="openAbout">Créé par ${H.esc(BUILD.author)}</button><span>${H.esc(COPYRIGHT)}</span></footer>`;
  H.$$('.hot-thumb img', box).forEach((img) => img.addEventListener('error', () => { img.outerHTML = `<span class="nothumb">${H.icon('play')}</span>`; }, { once: true }));
}

/* ---------- réglages : Mon compte, À propos ---------- */
export async function fillSettings(settings) {
  const $ = H.$;
  account = await getAccount();
  const acc = account || { name: '', tiktok: '', brand: '' };
  $('#acName').value = acc.name || '';
  $('#acTiktok').value = acc.tiktok || '';
  $('#acBrand').value = acc.brand || settings.auto.brand || '';
  $('#acScan').value = acc.scan || settings.scanAccount || ''; $('#acScanSame').checked = !!(acc.scanSame || settings.scanSame); $('#acScan').disabled = $('#acScanSame').checked; $('#acScanStatus').textContent = '';
  $('#sMine').value = (settings.myAccounts || []).filter((a) => cleanHandle(a) !== cleanHandle(acc.tiktok)).join(', ');
  $('#sTiktokAccount').value = acc.tiktok || '';
  $('#sTiktokAccountShow').textContent = acc.tiktok ? '@' + acc.tiktok : 'aucun (pas de vérification du compte)';
  $('#acDetectStatus').textContent = '';
  const [prods, chars, vids] = await Promise.all([DB.allProds(), DB.allChars(), DB.count().catch(() => 0)]);
  $('#acctCard').innerHTML = `<span class="avatar big" aria-hidden="true">${H.esc(initial())}</span>
    <div><b>${H.esc(acc.name || 'Compte sans nom')}</b><span class="role ${IS_ADMIN ? 'admin' : ''}">${IS_ADMIN ? 'Administrateur' : 'Membre'}</span>
      <p>${acc.tiktok ? `TikTok : @${H.esc(acc.tiktok)} · ` : ''}${acc.createdAt ? `compte créé le ${new Date(acc.createdAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}` : ''}</p>
      <p class="muted">${H.fmtNum(vids)} vidéos au radar · ${prods.length} production${prods.length > 1 ? 's' : ''} · ${chars.length} planche${chars.length > 1 ? 's' : ''}</p></div>`;
  $('#sEditionInfo').textContent = `Édition ${BUILD.edition} · version ${VERSION}. L'onglet « Avancé » n'existe que dans l'édition de l'auteur.`;
  $('#aboutBox').innerHTML = `
    <div class="about-hero ink">
      <img src="../icons/icon128.png" alt="" width="72" height="72">
      <div><p class="about-app">FruitRadar ${H.esc(VERSION)}</p><h3>Imaginé, conçu et dirigé par ${H.esc(BUILD.author)}</h3></div>
    </div>
    <div class="about-text">${BUILD.about.map((p) => `<p>${H.esc(p)}</p>`).join('')}</div>
    <dl class="about-facts">
      <dt>Conception et direction</dt><dd>${H.esc(BUILD.author)}</dd>
      <dt>Méthode d'écriture</dt><dd>Métaprompt V6, par ${H.esc(BUILD.author)}</dd>
      <dt>Version</dt><dd>${H.esc(VERSION)}</dd>
      <dt>Polices</dt><dd>Lexend et Bricolage Grotesque, sous licence libre OFL</dd>
    </dl>
    <p class="about-legal">${H.esc(COPYRIGHT)}. Tous droits réservés. FruitRadar, son code, son interface et sa méthode d'écriture ne peuvent pas être copiés, revendus ou redistribués sans l'accord écrit de l'auteur.</p>`;
}
export async function saveSettings() {
  const $ = H.$;
  const name = $('#acName').value.trim();
  account = await saveAccount({ name: name || (account && account.name) || 'Moi', tiktok: $('#acTiktok').value, brand: $('#acBrand').value, scan: $('#acScanSame').checked ? '' : $('#acScan').value, scanSame: $('#acScanSame').checked });
  paintChrome();
}

/* ---------- dictée vocale ---------- */
let rec = null, recFor = null;
function stopVoice() {
  const r = rec; rec = null;
  if (r) { r.onend = null; r.onerror = null; r.onresult = null; try { r.stop(); } catch (e) { /* déjà arrêtée */ } }
  H.$$('.mic.on').forEach((b) => { b.classList.remove('on'); b.setAttribute('aria-pressed', 'false'); });
  recFor = null;
}
function toggleVoice(btn) {
  const id = btn.dataset.voice;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return H.toast('La dictée vocale n\'existe pas dans ce navigateur : utilise Chrome.', 4500);
  if (rec) { const same = recFor === id; stopVoice(); if (same) return; }
  const field = H.$('#' + id); if (!field) return;
  const base = field.value.replace(/\s+$/, '');
  let finalText = '';
  rec = new SR(); recFor = id;
  rec.lang = 'fr-FR'; rec.continuous = true; rec.interimResults = true;
  rec.onresult = (e) => {
    let interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) { const t = e.results[i][0].transcript; if (e.results[i].isFinal) finalText += t; else interim += t; }
    const f = H.$('#' + id); if (!f) return stopVoice();
    const said = (finalText + interim).replace(/\s+/g, ' ').trim();
    f.value = base && said ? `${base} ${said}` : base || said;
    f.dispatchEvent(new Event('input', { bubbles: true }));
  };
  rec.onerror = (e) => {
    const why = { 'not-allowed': 'Micro refusé : autorise-le pour FruitRadar (icône à gauche de la barre d\'adresse).', 'service-not-allowed': 'Micro refusé par Chrome.', 'audio-capture': 'Aucun micro détecté.', network: 'La dictée a besoin d\'Internet.', 'no-speech': 'Je n\'ai rien entendu.' }[e.error];
    if (why) H.toast(why, 5000);
    stopVoice();
  };
  rec.onend = () => stopVoice();
  try { rec.start(); } catch (e) { stopVoice(); return H.toast('Impossible de démarrer la dictée.', 4000); }
  btn.classList.add('on'); btn.setAttribute('aria-pressed', 'true');
  H.toast('Je t\'écoute. Reclique sur le micro pour arrêter.', 2600);
}

/* ---------- événements ---------- */
function bind() {
  const $ = H.$;
  document.addEventListener('click', (e) => {
    const mic = e.target.closest('[data-voice]');
    if (mic) { e.preventDefault(); return toggleVoice(mic); }
    const chipB = e.target.closest('[data-chip-for]');
    if (chipB) { // raccourci d'orientation : ajoute le mot au champ visé
      const f = $('#' + chipB.dataset.chipFor); if (!f) return;
      const word = chipB.dataset.chip, has = f.value.toLowerCase().includes(word.toLowerCase());
      if (!has) { f.value = f.value.trim() ? `${f.value.trim().replace(/[,;.]$/, '')}, ${word}` : word; f.dispatchEvent(new Event('input', { bubbles: true })); }
      f.focus();
    }
  });
  document.addEventListener('input', (e) => { if (e.target.id === 'acTiktok') { const v = cleanHandle(e.target.value); $('#sTiktokAccount').value = v; $('#sTiktokAccountShow').textContent = v ? '@' + v : 'aucun (pas de vérification du compte)'; } });
  $('#settingsDlg').addEventListener('close', stopVoice);
  let homeT = null;
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && (ch.autoState || ch.siteChecks)) { clearTimeout(homeT); homeT = setTimeout(renderHome, 700); } });

  $('#acDetect').onclick = () => detectTiktok('#acTiktok', '#acDetectStatus');
  $('#wDetect').onclick = () => detectTiktok('#wTiktok', '#wDetectStatus');
  $('#acScanDetect').onclick = () => detectTiktok('#acScan', '#acScanStatus');
  for (const [box, inp] of [['#wScanSame', '#wScan'], ['#acScanSame', '#acScan']]) $(box).addEventListener('change', () => { $(inp).disabled = $(box).checked; if ($(box).checked) $(inp).value = ''; }); // même compte : la case du 2e compte ne sert plus
  $('#welcomeForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = $('#wName').value.trim(); if (!name) return $('#wName').focus();
    account = await saveAccount({ name, tiktok: $('#wTiktok').value, brand: $('#wBrand').value, scan: $('#wScanSame').checked ? '' : $('#wScan').value, scanSame: $('#wScanSame').checked, createdAt: Date.now() });
    $('#welcome').hidden = true; document.body.classList.remove('locked');
    paintChrome(); await H.reload(); renderHome();
    H.toast(`Bienvenue ${firstName()} : ton compte est créé`, 3500);
  });
  $('#wImport').onchange = async (e) => { const f = e.target.files[0]; if (!f) return; if (await doImport(f) && account) { $('#welcome').hidden = true; document.body.classList.remove('locked'); renderHome(); } e.target.value = ''; };
  $('#acImport').onchange = async (e) => { const f = e.target.files[0]; if (!f) return; if (await doImport(f)) { $('#settingsDlg').close(); H.showView('home'); } e.target.value = ''; };
  $('#acExport').onclick = async () => {
    const data = await exportAccount();
    const url = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
    const who = (account && account.name ? account.name : 'compte').normalize('NFD').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '').toLowerCase() || 'compte';
    chrome.downloads.download({ url, filename: `FruitRadar/compte-${who}_${new Date().toISOString().slice(0, 10)}.json`, saveAs: true });
    setTimeout(() => URL.revokeObjectURL(url), 120000);
  };
  $('#btnWipeAll').onclick = async () => {
    if (!(await H.ask('Tout effacer ?', { text: 'Compte, réglages, radar, productions et personnages de ce Chrome. Impossible à annuler. Pense à « Sauvegarder mon compte » avant.', ok: 'Tout effacer', danger: true }))) return;
    if (!(await H.ask('Dernière confirmation : tout effacer maintenant ?', { ok: 'Oui, tout effacer', danger: true }))) return;
    await wipeEverything();
    location.href = location.pathname;
  };
}
