// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
// Licence, support et retours. Version vendue : l'écran « Entre ta clé », l'étiquette d'essai, l'onglet Support.
// Édition de l'auteur : l'onglet Retours, qui lit la feuille Google où arrivent les messages.
// Ce fichier ne touche à rien de l'automatisation.
import * as DB from '../lib/db.js';
import * as LIC from '../lib/license.js';
import * as FB from '../lib/feedback.js';
import * as UPD from '../lib/update.js';
import { BUILD, IS_ADMIN } from '../lib/build.js';
import { getAccount } from '../lib/account.js';
import { STATUS } from '../auto/steps.js';

let H = null;
const C = LIC.config();
const VERSION = chrome.runtime.getManifest().version;
const RET = 'fr_retours';
let state = null;        // la licence enregistrée
let prods = [];          // dernières productions (pour joindre un journal)
let retours = null;      // { rows, error, mode, at }
let retFilter = 'todo';
let retStore = { url: '', done: [], seen: [] };
let pseudo = '';          // le nom donné à la création du compte FruitRadar : il accompagne chaque retour
let licNote = null;
let gateMode = '';        // ce que montre l'écran de clé quand il est ouvert ('upgrade' : proposé à une clé d'essai encore valable)
let upd = null;           // dernière réponse du fichier de version (mise à jour en un clic)      // dernier message du panneau « Ma licence »

const day = (t) => new Date(t).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
const hour = (t) => new Date(t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }).replace(':', ' h ');
const until = (t) => `${day(t)} à ${hour(t)}`;
const left = (tr) => `Il reste ${LIC.remaining(tr.ms)}`; // « Il reste 2 j 5 h », puis « 5 h 12 min », puis « 42 min »
const price = () => String(C.price || '').trim();
const voice = (id, rows, ph) => `<span class="voicewrap"><textarea id="${id}" rows="${rows}" placeholder="${H.esc(ph)}"></textarea><button class="mic" type="button" data-voice="${id}" aria-label="Dicter à la voix" title="Dicter à la voix">${H.icon('mic')}</button></span>`;
const link = (url) => { try { const u = new URL(String(url || '').trim()); return u.protocol === 'https:' ? u.href : ''; } catch (e) { return ''; } };
const env = () => {
  let chromeV = '', os = '';
  try { chromeV = (navigator.userAgent.match(/Chrome\/(\d+)/) || [])[1] || ''; const p = (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || ''; os = /win/i.test(p) ? 'Windows' : /mac/i.test(p) ? 'Mac' : /cros/i.test(p) ? 'ChromeOS' : /linux/i.test(p) ? 'Linux' : ''; } catch (e) { /* inconnu */ }
  return `FruitRadar ${VERSION} ${BUILD.edition}${chromeV ? ` · Chrome ${chromeV}` : ''}${os ? ` · ${os}` : ''}`;
};
const keyTail = () => { const k = (state && (state.displayKey || state.key)) || ''; return k ? k.replace(/[^A-Za-z0-9]/g, '').slice(-4).toUpperCase() : ''; };

/* ====================== écran « Entre ta clé » ====================== */
function gateHtml() {
  const buy = link(C.checkoutUrl), days = Number(C.trialDays) || 0;
  const tryUrl = LIC.hasTrialPlan() ? link(C.trialUrl) : '';
  const offer = tryUrl
    ? `<div class="licnew" id="licNew"><div><b>Pas encore de clé ?</b><p>Essaie le Radar gratuitement pendant ${days || 3} jours, sans carte. Ou abonne-toi pour tout débloquer : ${H.esc(price())}.</p></div><span class="licbtns"><a class="btn" href="${H.esc(tryUrl)}" target="_blank" rel="noopener">Essayer le Radar</a><a class="btn primary" href="${H.esc(buy)}" target="_blank" rel="noopener">S'abonner</a></span></div>`
    : `<div class="licnew" id="licNew"><div><b>Pas encore de clé ?</b><p>${days ? `${days} jours gratuits, puis ` : ''}${H.esc(price())}. Tu arrêtes quand tu veux.</p></div><a class="btn" href="${H.esc(buy)}" target="_blank" rel="noopener">${days ? 'Commencer l\'essai gratuit' : 'S\'abonner'}</a></div>`;
  return `<div class="licbox">
    <img src="../icons/icon128.png" width="64" height="64" alt="">
    <h2 id="licTitle">Entre ta clé FruitRadar</h2>
    <p class="licsub" id="licSub">Elle s'affiche juste après ton paiement, ou quand tu demandes l'essai gratuit.</p>
    <p class="licwarn" id="licWarn" role="alert" hidden></p>
    <form id="licForm" novalidate>
      <label for="licKey">Ta clé</label>
      <input id="licKey" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="FRUITRADAR-XXXXXXXX-… ou FR-XXXX-XXXX-XXXX-XXXX">
      <div class="licrow"><button class="btn primary big" type="submit" id="licGo">Activer FruitRadar</button><button class="btn big" type="button" id="licRetry" data-lic="recheck" hidden>Revérifier ma clé</button></div>
      <p class="status-line" id="licStatus" role="status"></p>
    </form>
    ${buy ? `${offer}
    <div class="licnew" id="licUp" hidden><div><b>Passe à l'abonnement</b><p>Le Radar et l'automatisation pour ${H.esc(price())}. Tu reçois une clé d'abonné à coller ici.</p></div><a class="btn primary" href="${H.esc(buy)}" target="_blank" rel="noopener">S'abonner</a></div>
    <div class="licnew" id="licBack" hidden><div><b>Abonnement arrêté ?</b><p>Reprends-le pour ${H.esc(price())} : tu recevras une nouvelle clé à coller ici.</p></div><a class="btn" href="${H.esc(buy)}" target="_blank" rel="noopener">Me réabonner</a></div>` : ''}
    <button class="linkbtn" type="button" id="licLater" data-lic="gateLater" hidden>Plus tard, je reste sur le Radar</button>
    <div class="lichelp">
      <button class="linkbtn" type="button" data-lic="gateHelp" aria-expanded="false" aria-controls="licHelp">Un souci avec ta clé ? Écris-moi</button>
      <form id="licHelp" hidden novalidate>
        <label for="licHelpText">Ton message</label>
        <textarea id="licHelpText" rows="3" placeholder="Ex. : je me suis inscrit mais je ne trouve pas ma clé"></textarea>
        <label for="licHelpContact">Ton mail, pour que je puisse te répondre</label>
        <input id="licHelpContact" type="text" autocomplete="off">
        <p class="hint">Ne sont envoyés que ce message, ce mail et la version de FruitRadar.</p>
        ${C.supportEmail ? `<p class="hint">Ou écris directement à <a href="mailto:${H.esc(C.supportEmail)}">${H.esc(C.supportEmail)}</a>.</p>` : ''}
        <div class="licrow"><button class="btn" type="submit">Envoyer</button><span class="status-line" id="licHelpStatus" role="status"></span></div>
      </form>
    </div>
    ${C.sandbox ? '<p class="lictest">Version de test : boutique d\'essai, aucun vrai paiement. Utilise la carte de test de la boutique.</p>' : ''}
    <p class="liccredit">FruitRadar, créé par ${H.esc(BUILD.author)}</p>
  </div>`;
}

function showGate(a) {
  const g = H.$('#licGate'); if (!g) return;
  const had = !!(state && state.key);
  const up = a.why === 'upgrade', over = a.why === 'refused' && LIC.plan(state) === 'essai'; // clé d'essai : on propose l'abonnement (au lancement d'une vidéo, ou à la fin de l'essai)
  const code = a.code || (state && state.code) || '';
  H.$('#licTitle').textContent = up ? 'Passe à l\'abonnement' : code === 'changements' ? 'Ta clé a trop changé d\'ordinateur' : code === 'essai_appareil' ? 'Essai déjà utilisé sur cet ordinateur' : over ? 'Ton essai gratuit est terminé' : a.why === 'none' ? 'Entre ta clé FruitRadar' : a.why === 'stale' ? 'Ta clé doit être revérifiée'
    : code === 'attente' ? 'Ta clé est en pause' : code === 'retiree' ? 'Ta clé a été retirée' : code === 'deplacee' ? 'Ta clé est sur un autre ordinateur' : code === 'deconnectee' ? 'Saisis à nouveau ta clé' : 'Ta clé n\'est plus acceptée';
  H.$('#licSub').hidden = a.why !== 'none';
  const w = H.$('#licWarn'); w.hidden = a.why === 'none'; w.textContent = a.why === 'none' ? '' : (a.message || '');
  H.$('#licRetry').hidden = !had || up || over;
  H.$('#licGo').textContent = up || over ? 'Utiliser ma clé d\'abonné' : had ? 'Utiliser une autre clé' : 'Activer FruitRadar';
  const held = ['attente', 'retiree', 'deplacee', 'appareil', 'deconnectee', 'changements'].includes(code); // pause, retrait, autre ordinateur : se réabonner ne changerait rien
  if (H.$('#licNew')) { H.$('#licNew').hidden = a.why === 'refused' || up; H.$('#licBack').hidden = a.why !== 'refused' || over || held; H.$('#licUp').hidden = !(up || over); }
  H.$('#licLater').hidden = !up;
  gateMode = up ? 'upgrade' : a.why;
  if (!g.open) { const st = H.$('#licStatus'); st.textContent = ''; st.className = 'status-line'; }
  document.documentElement.classList.add('liclock'); // la page derrière ne défile pas
  if (!g.open) { try { g.showModal(); } catch (e) { g.setAttribute('open', ''); } setTimeout(() => { const k = H.$('#licKey'); if (k) k.focus(); }, 60); }
}
function hideGate() { gateMode = ''; const g = H.$('#licGate'); if (g && g.open) g.close(); document.documentElement.classList.remove('liclock'); }

async function onActivate(e) {
  e.preventDefault();
  const st = H.$('#licStatus'), go = H.$('#licGo'), key = H.$('#licKey').value;
  if (!key.trim()) { st.textContent = LIC.MSG.empty; st.className = 'status-line no'; return H.$('#licKey').focus(); }
  go.disabled = true; st.textContent = 'Vérification de la clé…'; st.className = 'status-line';
  const r = await LIC.activate(key);
  go.disabled = false;
  if (!r.ok) { st.textContent = r.error; st.className = 'status-line no'; return; }
  st.textContent = ''; H.$('#licKey').value = '';
  await refresh();
  const t = LIC.trial(state);
  H.toast(t && t.open ? 'Clé activée. Le Radar est à toi.' : t && t.radar ? `Clé d'essai activée. Le Radar est à toi jusqu'au ${until(t.end)}.` : 'Clé activée. Bienvenue dans FruitRadar !', 5000);
}

async function onRecheck(btn) {
  const inGate = !!(btn && btn.closest('#licGate'));
  if (btn) btn.disabled = true;
  if (inGate) { const st = H.$('#licStatus'); st.textContent = 'Vérification de la clé…'; st.className = 'status-line'; }
  else { licNote = { text: 'Vérification de la clé…', cls: '' }; if (H.$('#supLic')) H.$('#supLic').innerHTML = licPanel(); }
  const a = await LIC.check();
  licNote = inGate ? null : { text: a.allowed ? 'Clé vérifiée, tout est en ordre.' : (a.message || ''), cls: a.allowed ? 'ok' : 'no' };
  await refresh();
  if (btn && btn.isConnected) btn.disabled = false;
  if (inGate) { const st = H.$('#licStatus'); st.textContent = !a.allowed && a.why === 'stale' ? LIC.MSG.offline : ''; st.className = 'status-line' + (a.allowed ? '' : ' no'); }
}

async function onGateHelp(e) {
  e.preventDefault();
  const st = H.$('#licHelpStatus'), text = H.$('#licHelpText').value.trim();
  if (!text) { st.textContent = 'Écris ton message.'; st.className = 'status-line no'; return; }
  st.textContent = 'Envoi…'; st.className = 'status-line';
  const r = await FB.send({ type: 'bug', message: `[Écran de la clé] ${text}`, note: '', version: env(), cle: keyTail(), contact: H.$('#licHelpContact').value.trim(), journal: '' });
  if (r.ok) { st.textContent = 'Envoyé. Je te réponds au plus vite.'; st.className = 'status-line ok'; H.$('#licHelpText').value = ''; }
  else { st.textContent = r.error === 'off' ? 'L\'envoi n\'est pas encore branché sur cette version.' : 'Pas envoyé : vérifie ta connexion et réessaie.'; st.className = 'status-line no'; }
}

/* ====================== étiquette dans le menu ====================== */
function paintTag() {
  const t = H.$('#licTag'); if (!t) return;
  const a = LIC.access(state), tr = a.why === 'ok' ? LIC.trial(state) : null;
  let html = '';
  if (a.why === 'open') html = '<b>Version de test</b><span>Licence non reliée</span>';
  else if (tr && tr.open) html = '<b>Accès au Radar</b><span>Sans date de fin</span><small>Automatisation : avec l\'abonnement</small>';
  else if (tr && tr.radar) html = `<b>Essai gratuit du Radar</b><span>${left(tr)}</span><small>Automatisation : avec l'abonnement</small>`;
  else if (tr && C.sandbox) html = `<b>Essai gratuit (test)</b><span>${left(tr)}</span><small>boutique d'essai, aucun vrai paiement</small>`;
  else if (a.why === 'ok' && C.sandbox && !(state.checkedAt - state.okAt > 3600e3)) html = '<b>Version de test</b><span>Boutique d\'essai</span>';
  else if (tr) html = `<b>Essai gratuit</b><span>${left(tr)}</span>${price() ? `<small>puis ${H.esc(price())}</small>` : ''}`;
  else if (a.why === 'ok' && state.checkedAt - state.okAt > 3600e3) html = `<b>Clé à revérifier</b><span>Accès gardé jusqu'au ${new Date(state.okAt + LIC.GRACE_H * 3600e3).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</span>`;
  if (t.innerHTML !== html) { t.hidden = !html; t.innerHTML = html; }
  t.classList.toggle('trial', !!tr);
}

/* État de la licence → écran de clé, étiquette, panneau « Ma licence » */
async function refresh() {
  state = await LIC.getState();
  if (IS_ADMIN) return;
  const a = LIC.access(state);
  if (!a.allowed) showGate(a);
  else if (!(gateMode === 'upgrade' && LIC.plan(state) === 'essai')) hideGate(); // la proposition d'abonnement faite à une clé d'essai reste affichée tant qu'il n'a pas choisi
  paintTag();
  if (H.$('#supLic')) H.$('#supLic').innerHTML = licPanel();
}
async function recheckIfDue() {
  if (!LIC.required()) return;
  const before = LIC.access(state);
  const due = before.why === 'stale' || before.why === 'refused' || (before.why === 'ok' && Date.now() - (state.checkedAt || 0) > LIC.OPEN_RECHECK_MS);
  if (!due) return;
  await LIC.check();
  await refresh();
}

/* ====================== onglet Support (version vendue) ====================== */
function journalOf(p) {
  if (!p) return '';
  const head = `Vidéo : ${p.title || 'sans titre'} · ${p.mode || ''} · partie ${p.part || 1} · ${STATUS[p.status] || p.status || ''}${p.step ? ` · étape ${p.step}` : ''}`;
  const lines = (p.log || []).map((l) => `${new Date(l.t).toLocaleTimeString('fr-FR')}${l.level && l.level !== 'info' ? ` [${l.level}]` : ''} ${l.msg}`).join('\n');
  const body = lines.length > FB.JOURNAL_MAX ? '… (début coupé)\n' + lines.slice(-FB.JOURNAL_MAX) : lines;
  return `${head}\n${body}`;
}
function bugPayload() {
  const id = (H.$('#supProd') || {}).value || '', p = prods.find((x) => x.id === id);
  const join = !!(H.$('#supJournal') || {}).checked && !!p;
  const le = upd && upd.lastError && upd.lastError.message ? ` · mise à jour vers ${upd.lastError.to || '?'} : ${upd.lastError.message}` : '';
  return { type: 'bug', message: (H.$('#supBugText') || {}).value.trim(), note: '', version: env() + le, cle: keyTail(), contact: [pseudo, (H.$('#supBugContact') || {}).value.trim()].filter(Boolean).join(' · '), journal: join ? journalOf(p) : '' };
}
function avisPayload() {
  const n = (document.querySelector('input[name="supNote"]:checked') || {}).value || '';
  return { type: 'avis', message: (H.$('#supAvisText') || {}).value.trim(), note: n, version: env(), cle: keyTail(), contact: pseudo, journal: '' };
}
const LABELS = { type: 'Type', message: 'Message', note: 'Note', version: 'Version', cle: 'Fin de ta clé', contact: 'Pseudo et contact', journal: 'Journal' };
const preview = (d) => FB.FIELDS.filter((f) => d[f] !== '').map((f) => `${LABELS[f]} : ${f === 'journal' ? '\n' : ''}${d[f]}`).join('\n');
function paintPreview() {
  const a = H.$('#supBugSee'); if (a) a.textContent = preview(bugPayload());
  const j = H.$('#supJournal'), sel = H.$('#supProd');
  if (j && sel) { j.disabled = !sel.value; j.closest('.chk').classList.toggle('off', !sel.value); }
}

function licPanel() {
  const a = LIC.access(state);
  const ver = UPD.enabled() ? `<p class="hint licver">FruitRadar ${H.esc(VERSION)}${upd && upd.available ? ` · <button class="linkbtn" type="button" data-lic="updOpen">mise à jour ${H.esc(upd.version)} disponible</button>` : ' · <button class="linkbtn" type="button" data-lic="updCheck">vérifier les mises à jour</button>'}</p>` : '';
  if (a.why === 'open') return `<h3>Ma licence</h3><p class="hint">Cette version n'est pas reliée à la boutique : aucune clé n'est demandée.</p>${ver}`;
  if (!state || !state.key) return `<h3>Ma licence</h3><p class="hint">Aucune clé enregistrée.</p>${ver}`;
  const tr = LIC.trial(state), portal = state.source === 'stripe'; // abonnement payé en ligne : il se gère dans l'espace abonné
  const auto = `L'automatisation demande l'abonnement${price() ? ` (${H.esc(price())})` : ''}`;
  const etat = tr && tr.open ? `Accès au Radar. ${auto}` : tr && tr.radar ? `Essai gratuit du Radar jusqu'au ${until(tr.end)} (${left(tr).toLowerCase()}). ${auto}` : state.expiresAt ? `Abonné jusqu'au ${day(state.expiresAt)}` : 'Abonnement actif';
  return `<h3>Ma licence</h3>
    <dl class="licfacts">
      <dt>Clé</dt><dd><code>${H.esc(state.displayKey || '••••' + keyTail())}</code></dd>
      <dt>État</dt><dd>${etat}</dd>
      <dt>Dernière vérification</dt><dd>${H.esc(H.relTime(state.okAt))}</dd>
      <dt>Ordinateur</dt><dd>Celui-ci. Une clé marche sur un seul ordinateur à la fois.</dd>
    </dl>
    <div class="row">
      ${tr && tr.radar ? '<button class="btn small primary" type="button" data-lic="upgrade">Passer à l\'abonnement</button>' : ''}
      <button class="btn small" type="button" data-lic="recheck">${H.icon('refresh')}Revérifier</button>
      ${portal ? `<button class="btn small" type="button" data-lic="portal">${H.icon('ext')}Gérer mon abonnement</button>` : ''}
      <button class="btn small ghost danger" type="button" data-lic="release">Retirer la clé de cet ordinateur</button>
    </div>
    <p class="hint">${portal ? 'Pour arrêter l\'abonnement ou changer de carte, passe par « Gérer mon abonnement ». ' : ''}Pour changer d'ordinateur, retire d'abord la clé ici.</p>
    ${ver}
    <p class="status-line ${licNote ? licNote.cls : ''}" id="supLicStatus" role="status"${licNote && licNote.text ? '' : ' hidden'}>${licNote ? H.esc(licNote.text) : ''}</p>`;
}

async function renderSupport() {
  const box = H.$('#viewSupport'); if (!box) return;
  pseudo = String(((await getAccount().catch(() => null)) || {}).name || '').trim().slice(0, 60);
  prods = (await DB.allProds().catch(() => [])).sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0)).slice(0, 8);
  const off = !FB.canSend();
  box.innerHTML = `<div class="pagehead"><div><h2>Support</h2><p>Un bug, une idée, un avis : ton message arrive directement à ${H.esc(BUILD.author)}, qui a créé FruitRadar.${C.supportEmail ? ` Tu peux aussi écrire à <a href="mailto:${H.esc(C.supportEmail)}">${H.esc(C.supportEmail)}</a>.` : ''}</p></div></div>
    <p class="sendnote">${H.icon('check')}<span><b>Rien ne part tant que tu ne cliques pas sur « Envoyer ».</b> Ce qui est envoyé : ton message, ton pseudo FruitRadar${pseudo ? ` (« ${H.esc(pseudo)} »)` : ''}, la version de FruitRadar et de Chrome, les 4 derniers caractères de ta clé et, si tu laisses la case cochée, le journal de la vidéo choisie. Jamais tes mots de passe, ni tes comptes.</span></p>
    ${off ? '<p class="sendnote warn"><span>L\'envoi n\'est pas encore branché sur cette version : « Envoyer » copiera ton message, à coller dans un mail.</span></p>' : ''}
    <div class="supgrid">
      <section class="panel" aria-labelledby="supBugH">
        <h3 id="supBugH">Signaler un bug</h3>
        <label class="block" for="supBugText"><span>Qu'est-ce qui s'est passé ? <small>Ce que tu faisais, ce que tu attendais, ce que tu as vu. Tu peux dicter.</small></span></label>
        ${voice('supBugText', 4, 'Ex. : au clip 3, Grok a fini la vidéo mais FruitRadar est resté en attente')}
        <label class="block" for="supProd"><span>Vidéo concernée</span></label>
        <select id="supProd"><option value="">Aucune en particulier</option>${prods.map((p, i) => `<option value="${H.esc(p.id)}"${i === 0 ? ' selected' : ''}>${H.esc((p.title || 'Sans titre').slice(0, 60))} · ${H.esc(STATUS[p.status] || p.status || '')}</option>`).join('')}</select>
        <label class="chk supchk"><input type="checkbox" id="supJournal" checked><span>Joindre le journal de cette vidéo</span><small>Les lignes de la fenêtre d'automatisation, avec le titre de la vidéo. C'est ce qui aide le plus à trouver le bug.</small></label>
        <label class="block" for="supBugContact"><span>Ton mail <small>Facultatif, si tu veux une réponse. Ton pseudo${pseudo ? ` « ${H.esc(pseudo)} »` : ''} est déjà joint.</small></span></label>
        <input id="supBugContact" type="text" autocomplete="off">
        <details class="supsee"><summary>Voir exactement ce qui sera envoyé</summary><pre id="supBugSee"></pre></details>
        <div class="row"><button class="btn primary" type="button" data-lic="sendBug">Envoyer le signalement</button><span class="status-line" id="supBugStatus" role="status"></span></div>
      </section>
      <div class="supcol">
        <section class="panel" aria-labelledby="supAvisH">
          <h3 id="supAvisH">Donner mon avis</h3>
          <div class="stars" role="radiogroup" aria-label="Ta note sur 5"><span class="starslab">Ta note</span>${[1, 2, 3, 4, 5].map((n) => `<label><input type="radio" name="supNote" value="${n}" aria-label="${n} sur 5"><span aria-hidden="true">${n}</span></label>`).join('')}<small>1 = déçu · 5 = top</small></div>
          <label class="block" for="supAvisText"><span>Ton avis <small>Ce qui te plaît, ce qui manque, ce qui t'a gêné.</small></span></label>
          ${voice('supAvisText', 3, 'Ex. : le montage est super, mais j\'aimerais choisir la musique')}
          <div class="row"><button class="btn primary" type="button" data-lic="sendAvis">Envoyer mon avis</button><span class="status-line" id="supAvisStatus" role="status"></span></div>
        </section>
        <section class="panel" id="supLic" aria-label="Ma licence">${licPanel()}</section>
      </div>
    </div>`;
  paintPreview();
}

async function sendFrom(kind, btn) {
  const bug = kind === 'bug', st = H.$(bug ? '#supBugStatus' : '#supAvisStatus'), d = bug ? bugPayload() : avisPayload();
  const say = (t, c = '') => { st.textContent = t; st.className = 'status-line ' + c; };
  if (bug && !d.message) { say('Décris ce qui s\'est passé.', 'no'); return H.$('#supBugText').focus(); }
  if (!bug && !d.message && !d.note) { say('Mets une note ou écris ton avis.', 'no'); return; }
  btn.disabled = true; say('Envoi…');
  const r = await FB.send(d);
  btn.disabled = false;
  if (r.ok) {
    say(bug ? 'Envoyé. Merci, je regarde ça.' : 'Envoyé. Merci pour ton avis !', 'ok');
    H.$(bug ? '#supBugText' : '#supAvisText').value = '';
    if (!bug) { const c = document.querySelector('input[name="supNote"]:checked'); if (c) c.checked = false; }
    paintPreview();
  }
  else if (r.error === 'off') {
    let copied = false;
    try { await navigator.clipboard.writeText(preview(d)); copied = true; } catch (e) { /* presse-papiers refusé */ }
    say(copied ? 'Envoi pas encore branché : ton message est copié, colle-le dans un mail.' : 'Envoi pas encore branché sur cette version.', 'no');
  }
  else say('Pas envoyé : vérifie ta connexion et réessaie. Ton texte est toujours là.', 'no');
}

async function onRelease(btn) {
  if (!(await H.ask('Retirer la clé de cet ordinateur ?', { text: 'FruitRadar redemandera une clé ici. Ton abonnement continue : tu peux la saisir sur un autre ordinateur.', ok: 'Retirer la clé', danger: true }))) return;
  btn.disabled = true;
  const r = await LIC.release();
  btn.disabled = false;
  licNote = r.ok ? null : { text: r.error, cls: 'no' };
  await refresh();
}

/* ====================== onglet Retours (édition de l'auteur) ====================== */
async function loadRetStore() { try { retStore = { url: '', done: [], seen: [], ...((await chrome.storage.local.get(RET))[RET] || {}) }; } catch (e) { /* valeurs par défaut */ } if (!retStore.url && BUILD.owner && BUILD.owner.sheet) retStore.url = BUILD.owner.sheet; } // la feuille de l'auteur est déjà renseignée dans son édition
const saveRetStore = () => chrome.storage.local.set({ [RET]: retStore });
async function loadRetours() {
  if (!retStore.url) { retours = null; return; }
  const r = await FB.fetchRetours(retStore.url);
  retours = r.ok ? { rows: r.rows, mode: r.mode, at: Date.now() } : { rows: (retours && retours.rows) || [], error: r.error, at: Date.now() };
  paintBadge();
}
function paintBadge() {
  const b = H.$('#navRetours'); if (!b) return;
  const done = new Set(retStore.done), seen = new Set(retStore.seen);
  const n = retours && retours.rows ? retours.rows.filter((x) => !seen.has(x.id) && !done.has(x.id)).length : 0; // nouveaux = pas encore affichés (on ne se fie pas à l'heure de la feuille)
  b.hidden = !n; b.textContent = n > 99 ? '99+' : String(n);
}
/* « Maxime · son@mail » : le pseudo du compte FruitRadar d'abord, puis ce que la personne a ajouté */
const who = (x) => { const [name, ...rest] = String(x.contact || '').split(' · '); return { name: name.trim(), more: rest.join(' · ').trim() }; };
const stars = (n) => (n ? `<span class="retstars" aria-label="${n} sur 5">${'★'.repeat(n)}<i>${'★'.repeat(5 - n)}</i></span>` : '');

async function renderRetours() {
  const box = H.$('#viewRetours'); if (!box) return;
  const done = new Set(retStore.done), rows = (retours && retours.rows) || [];
  const groups = { todo: rows.filter((x) => !done.has(x.id)), bug: rows.filter((x) => x.type === 'bug'), avis: rows.filter((x) => x.type === 'avis'), all: rows };
  if (!groups[retFilter]) retFilter = 'todo';
  const notes = groups.avis.filter((x) => x.note).map((x) => x.note), avg = notes.length ? (notes.reduce((a, b) => a + b, 0) / notes.length) : 0;
  const setup = `<section class="panel retsetup">
      <h3>Feuille Google des réponses</h3>
      <label class="block" for="retUrl"><span>Lien de la feuille <small>Ouvre la feuille liée à ton formulaire et copie l'adresse de la page. Elle reste privée : FruitRadar la lit avec ta session Google de ce Chrome.</small></span></label>
      <div class="inline"><input id="retUrl" type="url" value="${H.esc(retStore.url)}" placeholder="https://docs.google.com/spreadsheets/d/…"><button class="btn primary" type="button" data-lic="retSave">Enregistrer</button></div>
      <p class="hint">Colonnes attendues, dans l'ordre : Horodateur, Type, Message, Note, Version, Clé, Contact, Journal. Le pas-à-pas est dans le fichier LISEZMOI.</p>
    </section>`;
  const card = (x) => `<article class="retcard ${x.type}${done.has(x.id) ? ' done' : ''}">
      <header><b class="retwho">${H.esc(who(x).name || 'Sans pseudo')}</b><span class="rettype">${x.type === 'bug' ? 'Bug' : 'Avis'}</span>${stars(x.note)}<time>${x.at ? H.esc(new Date(x.at).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })) : H.esc(x.atText)}</time>${x.version ? `<span>${H.esc(x.version)}</span>` : ''}${x.cle ? `<span>clé …${H.esc(x.cle)}</span>` : ''}${who(x).more ? `<span>${H.esc(who(x).more)}</span>` : ''}</header>
      ${x.message ? `<p class="retmsg">${H.esc(x.message)}</p>` : ''}
      ${x.journal ? `<details><summary>Journal joint (${x.journal.split('\n').length} lignes)</summary><pre>${H.esc(x.journal)}</pre></details>` : ''}
      <div class="row"><button class="btn small${done.has(x.id) ? ' ghost' : ''}" type="button" data-lic="retDone" data-id="${H.esc(x.id)}">${done.has(x.id) ? 'Remettre à traiter' : `${H.icon('check')}Traité`}</button><button class="btn small ghost" type="button" data-lic="retCopy" data-id="${H.esc(x.id)}">${H.icon('copy')}Copier</button></div>
    </article>`;
  const list = groups[retFilter];
  box.innerHTML = `<div class="pagehead"><div><h2>Retours</h2><p>Les signalements et les avis envoyés depuis l'onglet Support de la version vendue.${retours && retours.at && !retours.error ? ` Lu ${H.esc(H.relTime(retours.at))}.` : ''}</p></div>
      ${retStore.url ? `<div class="row"><button class="btn" type="button" data-lic="retRefresh">${H.icon('refresh')}Actualiser</button></div>` : ''}</div>
    ${retours && retours.error ? `<p class="sendnote warn" role="alert"><span>${H.esc(retours.error)}</span></p>` : ''}
    ${!retStore.url ? setup : `
      <div class="retstats"><div><b>${groups.todo.length}</b><span>à traiter</span></div><div><b>${groups.bug.length}</b><span>bugs signalés</span></div><div><b>${groups.avis.length}</b><span>avis</span></div><div><b>${avg ? avg.toFixed(1).replace('.', ',') : '—'}</b><span>note moyenne sur 5</span></div></div>
      <div class="ptabs" role="group" aria-label="Filtrer les retours">${[['todo', 'À traiter'], ['bug', 'Bugs'], ['avis', 'Avis'], ['all', 'Tout']].map(([k, l]) => `<button type="button" aria-pressed="${retFilter === k}" class="${retFilter === k ? 'on' : ''}" data-lic="retFilter" data-f="${k}">${l}<small>${groups[k].length}</small></button>`).join('')}</div>
      ${list.length ? `<div class="retlist">${list.map(card).join('')}</div>` : `<div class="empty"><h3>${rows.length ? 'Rien dans cette liste' : 'Aucun retour pour l\'instant'}</h3><p>${rows.length ? 'Tout est traité ici.' : 'Dès qu\'un testeur envoie un message depuis l\'onglet Support, il apparaît ici.'}</p></div>`}
      <details class="retmore"><summary>Changer de feuille</summary>${setup}</details>`}`;
  if (rows.length && rows.some((x) => !retStore.seen.includes(x.id))) { retStore.seen = rows.map((x) => x.id).slice(0, 3000); saveRetStore(); paintBadge(); }
}

/* ====================== mise à jour en un clic (version vendue) ====================== */
function paintUpd() {
  const t = H.$('#updTag'); if (!t) return;
  const on = !!(upd && upd.available);
  t.hidden = !on;
  if (on) t.innerHTML = `<b>Mise à jour ${H.esc(upd.version)}</b><span>Installer maintenant</span>`;
  const su = H.$('#setUpd'); if (su) { su.hidden = !on; if (on) su.innerHTML = `${H.icon('download')}Mise à jour ${H.esc(upd.version)} · Installer`; }
  if (H.$('#supLic')) H.$('#supLic').innerHTML = licPanel();
}
async function checkUpd(force = false) {
  if (!UPD.enabled()) return null;
  upd = await UPD.check(force).catch(() => upd);
  paintUpd();
  return upd;
}
/* Le panneau de mise à jour : posé en bas à droite, il ne bloque rien (on continue à utiliser FruitRadar pendant ce temps).
   Étapes : intro → (la première fois) dossier → prêt → installation → redémarrage. */
let updStep = 'intro', updDir = null, updMsg = { text: '', cls: '' };
const updSay = (text, cls = '') => { updMsg = { text, cls }; const st = H.$('#updStatus'); if (st) { st.textContent = text; st.className = 'status-line ' + cls; } };
/* Une vidéo est-elle vraiment en cours ? L'état gardé en mémoire ne suffit pas : si la fenêtre d'automatisation a été fermée d'un coup, il reste sur
   « en cours » et bloquerait la mise à jour pour toujours. On vérifie donc aussi que la fenêtre d'automatisation est ouverte. Rend le titre, ou ''. */
async function prodActive() {
  const { autoState } = await UPD.within(chrome.storage.local.get('autoState'), 3000, {});
  if (!(autoState && ['running', 'waiting', 'queued'].includes(autoState.status))) return '';
  // la fenêtre d'automatisation est-elle encore ouverte ? (on regarde l'onglet lui-même : une fenêtre endormie par Chrome ne répond pas aux messages, mais sa vidéo est bien en cours)
  const base = chrome.runtime.getURL('auto/runner.html');
  const open = await UPD.within(chrome.tabs.query({}).then((ts) => ts.some((t) => (t.url || '').startsWith(base))).catch(() => true), 3000, true);
  if (!open) return ''; // plus de fenêtre d'automatisation : rien ne tourne, la mise à jour peut se faire
  return autoState.title || 'une vidéo';
}
const prodMsg = (title) => `Une vidéo est en cours (${title === 'une vidéo' ? 'automatisation lancée' : `« ${title} »`}). La mise à jour redémarre FruitRadar : elle la couperait. Mets la vidéo de côté (Automatisation, bouton « Mettre de côté »), puis reclique sur « Mettre à jour ».`;
/* Le fil de la mise à jour, étape par étape : affiché dans « Ça ne marche pas ? » et copiable, pour savoir où ça s'arrête et pourquoi */
let updTrace = [], updWorking = false;
const trace = (t) => { updTrace.push(`${new Date().toLocaleTimeString('fr-FR')}  ${t}`); updTrace = updTrace.slice(-40); const el = H.$('#updTrace'); if (el) el.textContent = updTrace.join('\n'); };
function paintUpdDlg() {
  const d = H.$('#updDlg'); if (!d || !upd) return;
  const head = (t) => `<div class="dlg-head"><h2 id="updTitle">${t}</h2><button class="close" type="button" data-lic="updClose" aria-label="Fermer">${H.icon('close')}</button></div>`;
  const status = `<p class="status-line ${updMsg.cls}" id="updStatus" role="status">${H.esc(updMsg.text)}</p>`;
  const pg = UPD.page();
  const manual = `<details class="updalt" id="updAlt"${updMsg.cls === 'no' ? ' open' : ''}><summary>Ça ne marche pas ? Mise à jour à la main (2 minutes)</summary>
      <ol><li>${pg ? `<button class="btn small" type="button" data-lic="updPage">${H.icon('download')}Ouvrir la page de téléchargement</button> puis, sur la page, clique sur « Télécharger FruitRadar ».` : `<button class="btn small" type="button" data-lic="updDl">${H.icon('download')}Télécharger le zip</button>`}</li>
      <li>Ouvre ton dossier FruitRadar, celui chargé dans Chrome à l'installation. <button class="linkbtn" type="button" data-lic="updWhere">Où est-il ?</button></li>
      <li>Dézippe le zip dans ce même dossier et accepte de remplacer les fichiers. Même dossier qu'avant, sinon tu perds tes vidéos.</li>
      <li><button class="btn small" type="button" data-lic="updReload">${H.icon('refresh')}Recharger FruitRadar</button>, puis rouvre-le avec son icône.</li></ol>
      <p class="hint">${pg ? `<button class="linkbtn" type="button" data-lic="updDl">Télécharger le zip directement</button> · ` : ''}<button class="linkbtn" type="button" data-lic="updRepick">Désigner à nouveau le dossier</button></p>
      ${updTrace.length ? `<p class="hint">Ce qui s'est passé au dernier essai : <button class="linkbtn" type="button" data-lic="updCopy">Copier</button></p><pre class="updtrace" id="updTrace">${H.esc(updTrace.join('\n'))}</pre>` : ''}</details>`;
  let body = '';
  if (updStep === 'folder') body = `${head('Étape 1 sur 2 · Le dossier de FruitRadar')}
    <p>Montre une fois à Chrome <b>le dossier de FruitRadar</b> : celui que tu as chargé à l'installation (le dossier, pas le zip).</p>
    <ol class="updsteps"><li>Clique sur « Choisir le dossier » : la fenêtre s'ouvre dans tes Téléchargements.</li><li>Clique une fois sur le dossier FruitRadar, puis sur « Sélectionner un dossier ».</li><li>Chrome demande s'il peut modifier les fichiers : accepte.</li></ol>
    <p class="hint">Chrome interdit à une extension de trouver son dossier toute seule. Si tu désignes le dossier juste au-dessus, FruitRadar le retrouve dedans. <button class="linkbtn" type="button" data-lic="updWhere">Où est mon dossier ?</button></p>
    <div class="dlg-actions"><button class="btn primary big" type="button" data-lic="updPick">Choisir le dossier</button><button class="btn" type="button" data-lic="updCancel">Annuler</button></div>${status}`;
  else if (updStep === 'ready') body = `${head('Étape 2 sur 2 · Prêt')}
    <p class="sendnote">${H.icon('check')}<span>Dossier trouvé : <b>« ${H.esc((updDir && updDir.name) || 'FruitRadar')} »</b>. C'est bien celui que Chrome utilise, il est retenu pour les prochaines fois.</span></p>
    <p>La mise à jour ${H.esc(upd.version)} prend quelques secondes, puis FruitRadar redémarre. Tes vidéos, tes réglages et ta clé ne bougent pas.</p>
    <div class="dlg-actions"><button class="btn primary big" type="button" data-lic="updGo">Mettre à jour</button><button class="btn" type="button" data-lic="updCancel">Annuler</button></div>${status}`;
  else if (updStep === 'busy') body = `${head(`Mise à jour ${H.esc(upd.version)}`)}
    <p>Tu peux continuer à utiliser FruitRadar. Seul le lancement d'une vidéo attend la fin (quelques secondes).</p>${status}`;
  else body = `${head(`Mise à jour ${H.esc(upd.version)}`)}
    ${upd.notes ? `<p class="updnotes">${H.esc(upd.notes)}</p>` : ''}
    <p>Tu as la version ${H.esc(VERSION)}. Tes vidéos, tes réglages et ta clé ne bougent pas. Cette fenêtre ne bloque rien : tu peux continuer à utiliser FruitRadar.</p>
    ${upd.lastError && upd.lastError.message && updMsg.cls !== 'no' ? `<p class="sendnote warn" id="updLast"><span>Dernier essai (${H.esc(H.relTime(upd.lastError.at))}) : ${H.esc(upd.lastError.message)}</span></p>` : ''}
    <div class="dlg-actions"><button class="btn primary big" type="button" data-lic="updGo">Mettre à jour</button><button class="btn" type="button" data-lic="updCancel">Plus tard</button></div>${status}${manual}`;
  d.innerHTML = `<div class="dlg">${body}</div>`;
}
function openUpd() {
  const d = H.$('#updDlg'); if (!d || !upd || !upd.available) return;
  // Une fenêtre ouverte par-dessus (Réglages, Guide…) fige tout ce qui est derrière, panneau de mise à jour compris : on la referme d'abord.
  // Sans ça, le clic « ne faisait rien » (signalé le 18 novembre 2026). L'écran de clé, lui, ne se referme jamais comme ça.
  H.$$('dialog[open]:not(#licGate):not(#updDlg)').forEach((x) => { try { if (x.matches(':modal')) x.close(); } catch (e) { /* navigateur sans :modal */ } });
  if (updStep !== 'busy' && !d.open) { updStep = 'intro'; updMsg = { text: '', cls: '' }; }
  paintUpdDlg();
  if (!d.open) d.show(); // pas « showModal » : le reste de FruitRadar reste utilisable
}
function closeUpd(reset = false) { const d = H.$('#updDlg'); if (d && d.open) d.close(); if (reset && updStep !== 'busy') { updStep = 'intro'; updMsg = { text: '', cls: '' }; } }
function updFail(e) {
  trace(`Échec : ${e.message}`);
  if (updStep === 'busy') updStep = 'intro';
  const blocked = /security policy|safe browsing/i.test(e.message || ''); // Chrome fait analyser chaque fichier écrit : l'antivirus a dit non
  updMsg = { text: blocked && !e.broken
    ? 'Ton antivirus (ou la protection de Windows) a bloqué l\'écriture d\'un fichier. L\'ancienne version est remise en place, rien n\'est cassé. Fais la mise à jour à la main, juste en dessous : deux minutes.'
    : `Mise à jour impossible : ${e.message}.${updStep === 'intro' ? ' Réessaie, ou fais-la à la main ci-dessous.' : ''}`, cls: 'no' };
  UPD.noteError(e.message, upd && upd.version).catch(() => null); upd = { ...upd, lastError: { at: Date.now(), message: e.message } }; // reste lisible si la fenêtre est refermée
  paintUpdDlg(); const d = H.$('#updDlg'); if (d && !d.open) d.show();
}
/* « Mettre à jour ». Le clic se voit tout de suite (bouton « Vérification… »), chaque étape a un délai, et tout arrêt dit pourquoi :
   vidéo en cours → refus expliqué ; dossier jamais désigné → étape du dossier ; autorisation de Chrome sans réponse, dossier déplacé ou antivirus
   qui retient les fichiers → la raison s'affiche, avec la suite à donner. Avant, une attente sans fin laissait le bouton sans aucun effet. */
async function runUpd(btn) {
  if (updStep === 'busy' || updWorking) return;
  updWorking = true; updTrace = [];
  const say = (t, cls = '') => { trace(t); updSay(t, cls); };
  const busyBtn = (on) => { const b = H.$('#updDlg [data-lic=updGo]'); if (!b) return; b.disabled = on; b.textContent = on ? 'Vérification…' : 'Mettre à jour'; };
  try {
    busyBtn(true); say('Je vérifie qu\'aucune vidéo n\'est en cours…');
    const title = await prodActive();
    if (title) { say(prodMsg(title), 'no'); return; }
    let dir = updStep === 'ready' ? updDir : null;
    if (!dir) {
      say('Je retrouve le dossier de FruitRadar…');
      const r = await UPD.reopen(true, () => say('Chrome pose une question en haut de la fenêtre (« … modifier les fichiers ? ») : accepte-la pour continuer.'));
      if (r.dir) dir = r.dir;
      else {
        trace(r.none ? 'Dossier de FruitRadar : jamais désigné sur ce Chrome.' : `Dossier de FruitRadar : ${r.why}.`);
        if (r.blocked) { updMsg = { text: `${r.why.charAt(0).toUpperCase()}${r.why.slice(1)}. Fais la mise à jour à la main, juste en dessous : deux minutes.`, cls: 'no' }; UPD.noteError(r.why, upd && upd.version).catch(() => null); return paintUpdDlg(); }
        updStep = 'folder'; updMsg = r.none ? { text: '', cls: '' } : { text: `${r.why.charAt(0).toUpperCase()}${r.why.slice(1)}. Désigne à nouveau le dossier de FruitRadar avec « Choisir le dossier ».`, cls: 'no' };
        return paintUpdDlg();
      }
    }
    trace(`Dossier de FruitRadar : « ${dir.name || 'FruitRadar'} », prêt.`);
    updWorking = false;
    return await installUpd(dir);
  } catch (e) { trace(`Arrêt : ${e.message}`); updFail(e); } finally { updWorking = false; busyBtn(false); }
}
async function pickUpd() {
  let dir = null;
  try { dir = await UPD.pick(); } catch (e) { trace(`Choix du dossier : ${e.message}`); return updSay(`${e.message.charAt(0).toUpperCase()}${e.message.slice(1)}. Réessaie avec « Choisir le dossier ».`, 'no'); } // en premier : Chrome n'ouvre sa fenêtre que juste après un clic
  updDir = dir; updStep = 'ready'; updMsg = { text: '', cls: '' }; paintUpdDlg();
}
async function installUpd(dir) {
  updStep = 'busy'; updMsg = { text: 'Téléchargement de la mise à jour…', cls: '' }; paintUpdDlg();
  try {
    await UPD.setBusy(true);
    if (await prodActive()) throw new Error('une vidéo vient de démarrer : mets-la de côté, puis reclique sur « Mettre à jour »');
    trace('Téléchargement de la mise à jour…');
    let up = null;
    try { up = await UPD.fetchUpdate(upd); } catch (e) {
      const again = await UPD.check(true).catch(() => null); // une version plus récente a pu être publiée entre-temps : on relit le fichier de version
      if (!again || !again.available || again.sha256 === upd.sha256) throw e;
      upd = again; updSay(`Téléchargement de la version ${upd.version}…`);
      up = await UPD.fetchUpdate(upd);
    }
    trace(`Téléchargement terminé (${up.files.length} fichiers). Installation…`); updSay('Installation…');
    await UPD.install(dir, up.files, (i, n) => updSay(`Installation… ${i} fichier${i > 1 ? 's' : ''} sur ${n}`));
    trace('Installation terminée.'); await UPD.noteError('');
    await UPD.markDone(VERSION, up.version);
    let test = false; try { test = !!localStorage.__majdir; } catch (e) { /* stockage fermé */ }
    updSay(`Version ${up.version} installée. FruitRadar se ferme pour redémarrer : rouvre-le avec son icône.`, 'ok');
    const d = H.$('#updDlg'); if (d && !d.open) d.show();
    if (!test) setTimeout(() => chrome.runtime.reload(), 1800); else { await UPD.setBusy(false); updStep = 'intro'; }
  } catch (e) {
    await UPD.setBusy(false).catch(() => null);
    updFail(e);
  }
}

/* ====================== branchement ====================== */
export async function render(name) {
  if (name === 'support') return renderSupport();
  if (name === 'retours') { await renderRetours(); if (retStore.url) { await loadRetours(); if (!H.$('#viewRetours').hidden) await renderRetours(); } }
}

async function onClick(e) {
  const b = e.target.closest('[data-lic]'); if (!b) return;
  const a = b.dataset.lic;
  if (a === 'recheck') return onRecheck(b);
  if (a === 'upgrade') return showGate({ allowed: true, why: 'upgrade', message: LIC.MSG.trialAuto });
  if (a === 'gateLater') return hideGate();
  if (a === 'updOpen') return openUpd();
  if (a === 'updPage') { const u = UPD.page(); try { await chrome.tabs.create({ url: u }); } catch (e) { window.open(u, '_blank', 'noopener'); } return; }
  if (a === 'updPick') return pickUpd(); // rien avant : Chrome n'ouvre le choix du dossier que juste après le clic
  if (a === 'updClose') return closeUpd(false);
  if (a === 'updCancel') return closeUpd(true);
  if (a === 'updGo') return runUpd(b);
  if (a === 'updCopy') { try { await navigator.clipboard.writeText(`FruitRadar ${VERSION} → ${upd ? upd.version : '?'}\n${updTrace.join('\n')}`); H.toast('Copié : colle-le dans ton message', 3500); } catch (e) { H.toast('Copie impossible : sélectionne le texte à la main', 4000); } return; }
  if (a === 'updRepick') { await UPD.forgetDir(); updDir = null; updStep = 'folder'; updMsg = { text: '', cls: '' }; return paintUpdDlg(); }
  if (a === 'updWhere') { try { await chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` }); } catch (e) { H.toast('Ouvre chrome://extensions, puis « Détails » sur FruitRadar.', 6000); } return; }
  if (a === 'updCheck') { b.disabled = true; const u = await checkUpd(true); if (!(u && u.available)) H.toast(u && u.error ? `Vérification impossible (${u.error}).` : `FruitRadar ${VERSION} est à jour.`, 4000); return; }
  if (a === 'updDl') { try { await chrome.downloads.download({ url: upd.zipUrl, filename: `FruitRadar-${upd.version}.zip`, saveAs: false }); H.toast('Le zip est dans tes Téléchargements.', 4000); } catch (e) { H.toast('Téléchargement impossible.', 4000); } return; }
  if (a === 'updReload') return chrome.runtime.reload();
  if (a === 'gateHelp') { const f = H.$('#licHelp'); f.hidden = !f.hidden; b.setAttribute('aria-expanded', String(!f.hidden)); if (!f.hidden) H.$('#licHelpText').focus(); return; }
  if (a === 'sendBug') return sendFrom('bug', b);
  if (a === 'sendAvis') return sendFrom('avis', b);
  if (a === 'release') return onRelease(b);
  if (a === 'portal') {
    b.disabled = true;
    const r = await LIC.portal();
    b.disabled = false;
    if (!r.ok) { licNote = { text: r.error, cls: 'no' }; if (H.$('#supLic')) H.$('#supLic').innerHTML = licPanel(); return; }
    try { await chrome.tabs.create({ url: r.url }); } catch (e) { window.open(r.url, '_blank', 'noopener'); }
    return;
  }
  if (a === 'retFilter') { retFilter = b.dataset.f; return renderRetours(); }
  if (a === 'retRefresh') { b.disabled = true; await loadRetours(); return renderRetours(); }
  if (a === 'retSave') {
    const v = H.$('#retUrl').value.trim();
    if (v && !FB.sheetSource(v)) return H.toast('Ce lien n\'est pas celui d\'une feuille Google Sheets.', 4500);
    retStore.url = v; retours = null; await saveRetStore();
    await renderRetours();
    if (v) { await loadRetours(); await renderRetours(); }
    return;
  }
  if (a === 'retDone') { const id = b.dataset.id, i = retStore.done.indexOf(id); if (i >= 0) retStore.done.splice(i, 1); else retStore.done.push(id); retStore.done = retStore.done.slice(-2000); await saveRetStore(); paintBadge(); return renderRetours(); }
  if (a === 'retCopy') {
    const x = ((retours && retours.rows) || []).find((r) => r.id === b.dataset.id); if (!x) return;
    try { await navigator.clipboard.writeText([`${x.contact ? `${x.contact} — ` : ''}${x.type === 'bug' ? 'Bug' : 'Avis'}${x.note ? ` ${x.note}/5` : ''} · ${x.atText} · ${x.version} · clé …${x.cle}`, x.message, x.journal].filter(Boolean).join('\n\n')); H.toast('Copié.'); } catch (err) { H.toast('Copie impossible.'); }
  }
}

export async function init(helpers) {
  H = helpers;
  H.$$('[data-vente]').forEach((el) => { el.hidden = IS_ADMIN; });
  document.addEventListener('click', onClick);
  if (IS_ADMIN) { // l'auteur : pas de clé, seulement les retours
    await loadRetStore();
    if (retStore.url) loadRetours().catch(() => 0);
    return;
  }
  const g = document.createElement('dialog');
  g.id = 'licGate'; g.className = 'licgate'; g.setAttribute('aria-labelledby', 'licTitle');
  g.innerHTML = gateHtml();
  document.body.appendChild(g);
  g.addEventListener('cancel', (e) => e.preventDefault()); // Échap ne ferme pas l'écran de clé
  g.addEventListener('close', () => { const acc = LIC.access(state); if (!acc.allowed) setTimeout(() => showGate(acc), 0); }); // refermé par autre chose alors que la clé manque : il revient
  H.$('#licForm').addEventListener('submit', onActivate);
  window.addEventListener('fr-upgrade', () => showGate({ allowed: true, why: 'upgrade', message: LIC.MSG.trialAuto })); // une clé d'essai a voulu lancer une vidéo
  H.$('#licHelp').addEventListener('submit', onGateHelp);
  const foot = H.$('#sidenav .navfoot');
  if (foot) { const t = document.createElement('button'); t.type = 'button'; t.id = 'licTag'; t.className = 'lictag'; t.dataset.go = 'support'; t.hidden = true; t.title = 'Ma licence'; foot.parentNode.insertBefore(t, foot); }
  if (UPD.enabled()) {
    const u = document.createElement('button'); u.type = 'button'; u.id = 'updTag'; u.className = 'updtag'; u.dataset.lic = 'updOpen'; u.hidden = true;
    const before = H.$('#licTag') || foot; if (before) before.parentNode.insertBefore(u, before);
    const dlg = document.createElement('dialog'); dlg.id = 'updDlg'; dlg.className = 'upddlg'; dlg.setAttribute('aria-labelledby', 'updTitle'); document.body.appendChild(dlg);
    UPD.getInfo().then(async (i) => { if (i.done && !i.seen && i.done.to === VERSION) { H.toast(`FruitRadar est à jour : version ${VERSION}.`, 6000); await UPD.markSeen(); } });
    checkUpd().catch(() => 0);
    setInterval(() => { checkUpd().catch(() => 0); }, 60 * 60 * 1000);
  }
  document.addEventListener('input', (e) => { if (e.target.closest && e.target.closest('#viewSupport')) paintPreview(); });
  document.addEventListener('change', (e) => { if (e.target.closest && e.target.closest('#viewSupport')) paintPreview(); });
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.fr_license) refresh(); });
  await refresh();
  recheckIfDue().catch(() => 0);
  setInterval(() => { recheckIfDue().catch(() => 0); paintTag(); }, 30 * 60 * 1000);
  let wasOpen = LIC.access(state).allowed;
  setInterval(() => { // essai : le temps qui reste se met à jour tout seul, et l'écran de fin s'affiche dès que l'essai se termine
    if (!state || LIC.plan(state) !== 'essai') return;
    const open = LIC.access(state).allowed;
    if (wasOpen && !open) refresh().then(() => recheckIfDue()).catch(() => 0);
    else paintTag();
    wasOpen = open;
  }, 15e3);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) recheckIfDue().catch(() => 0); });
}
