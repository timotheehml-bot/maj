/* FruitRadar — script "pont" (monde isolé de l'extension).
   Relaie les vidéos vers le service worker et exécute le défilement auto
   quand l'onglet est un onglet de scan. */
(function () {
  const chrome = globalThis.browser ?? globalThis.chrome;
  let buffer = [];
  let timer = null;

  const flush = () => {
    timer = null;
    if (!buffer.length) return;
    const items = buffer;
    buffer = [];
    try {
      chrome.runtime.sendMessage({ type: 'items', items, pageUrl: location.href }).catch(() => {});
    } catch (e) { /* extension rechargée : on ignore */ }
  };

  window.addEventListener('message', (ev) => {
    if (ev.origin !== location.origin || !ev.data || !ev.data.__fruitradar) return;
    if (ev.data.kind === 'items' && Array.isArray(ev.data.items)) {
      buffer.push(...ev.data.items);
      if (!timer) timer = setTimeout(flush, 600);
    }
    if (ev.data.kind === 'session') {
      try {
        chrome.runtime.sendMessage({ type: 'session', uniqueId: ev.data.uniqueId || null, nickname: ev.data.nickname || null }).catch(() => {});
      } catch (e) {}
    }
  });

  let keepTimer = null;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /* La fenêtre « Vérification » de TikTok (puzzle à glisser) : par son cadre, ou par le texte d'une fenêtre par-dessus la page.
     Seulement le texte des fenêtres : un titre de vidéo « compte vérifié » ne doit pas arrêter le scan. Vu le 24 novembre 2026 :
     la fenêtre peut même échouer à charger son puzzle (« networkErrorText [5101] [500] ») : c'est toujours une vérification. */
  const detectBlock = () => {
    if (document.querySelector('[id*="captcha"], [class*="captcha"], [class*="Captcha"], #tiktok-verify-ele, iframe[src*="verify"], iframe[src*="captcha"]')) return 'captcha';
    const boxes = [...document.querySelectorAll('[role="dialog"], [class*="Modal"], [class*="modal"], [class*="verify"]')].filter((el) => el.offsetParent !== null || el.getClientRects().length);
    for (const el of boxes) if (/v[ée]rification|verify to continue|faites glisser|drag the slider|networkerrortext|puzzle/i.test((el.innerText || '').slice(0, 600))) return 'captcha';
    return null;
  };

  /* S'arrête net dès que TikTok demande une vérification : continuer à défiler pendant qu'elle est affichée aggrave les choses. */
  async function autoScroll(steps, delay) {
    for (let i = 0; i < steps; i++) {
      if (detectBlock()) break;
      const cards = document.querySelectorAll('[data-e2e="search_video-item"], [data-e2e="challenge-item"], [data-e2e="user-post-item"], [class*="DivItemContainer"]');
      const last = cards[cards.length - 1];
      if (last && last.scrollIntoView) last.scrollIntoView({ block: 'end' });
      window.scrollBy(0, Math.max(window.innerHeight, 900));
      window.dispatchEvent(new Event('scroll'));
      await sleep(delay + Math.random() * 600);
      // bouton "Charger plus" sur la recherche
      const more = document.querySelector('[data-e2e="search-load-more"], button[class*="LoadMore"]');
      if (more) { try { more.click(); } catch (e) {} await sleep(delay); }
    }
    flush();
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg && msg.type === 'autoscroll') {
      // Onglet de scan : on "réveille" régulièrement l'arrière-plan pour qu'il ne soit pas mis en veille (Firefox)
      if (msg.keepalive && !keepTimer) {
        keepTimer = setInterval(() => {
          try { chrome.runtime.sendMessage({ type: 'keepalive' }).catch(() => {}); } catch (e) { clearInterval(keepTimer); }
        }, 10000);
      }
      autoScroll(msg.steps || 5, msg.delay || 1400).then(() => sendResponse({ ok: true, block: detectBlock() }));
      return true;
    }
    if (msg && msg.type === 'ping') {
      sendResponse({ ok: true, block: detectBlock() });
    }
    return false;
  });
})();
