// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
import * as DB from '../lib/db.js';
import { getSettings, saveSettings, DEFAULTS, BREADTH, planFor, CODE_REV } from '../lib/settings.js';
import { rankAll, WEIGHTS, WEIGHT_LABELS, fmtNum, fmtAge, fmtDur, fmtPct, fmtMult, fmtRate, median } from '../lib/metrics.js';
import { relevance, normAccount } from '../lib/relevance.js';
import { scanRisk, scanReady } from '../lib/risk.js';
import { getAccount, saveAccount } from '../lib/account.js';
import * as AN from '../lib/analysis.js';
import * as AUTO from './auto-ui.js';
import * as SHELL from './shell-ui.js';
import * as LICUI from './license-ui.js';
let KEYS = null; // onglet « Clés » (édition de l'auteur), chargé au démarrage seulement dans cette édition
let STATS = null; // onglet « Stats » (édition de l'auteur) : fréquentation de fruitradar.fr, essais et abonnements
let PROMO = null; // rubrique « Promo » de Gestion (édition de l'auteur) : réduction sur le 1er mois, appliquée sur la page de paiement
let SITE = null; // vitrine de fruitradar.fr (édition de l'auteur) : chiffres TikTok envoyés au site après « Mettre à jour »
import { IS_ADMIN } from '../lib/build.js';

// Firefox expose `browser` (promesses), Chrome expose `chrome`
const chrome = globalThis.browser ?? globalThis.chrome;

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const H = 3600 * 1000;
const PAGE = 60;
const TAG_STOP = new Set(['fyp', 'foryou', 'foryoupage', 'pourtoi', 'pourtoii', 'viral', 'viralvideo', 'xyzbca', 'fypシ', 'fy', 'fypage', 'trending', 'tiktok', 'parati', 'fypシ゚viral', 'capcut', 'foru', 'fypp', 'viraltiktok']);

/* ---------------- icônes ---------------- */
const HEART = '<path d="M12 20.5s-7.5-4.4-9.4-9C1.3 8.3 3.4 4.8 6.9 4.8c2 0 3.5 1.1 5.1 3 1.6-1.9 3.1-3 5.1-3 3.5 0 5.6 3.5 4.3 6.7-1.9 4.6-9.4 9-9.4 9z"/>';
const ICONS = {
  pen: '<path d="M4 20h4L18.6 9.4a2.1 2.1 0 0 0-3-3L5 17v3z"/><path d="M13.6 7.4l3 3"/>',
  trophy: '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4z"/><path d="M17 6h3v2a3 3 0 0 1-3 3M7 6H4v2a3 3 0 0 0 3 3"/>',
  bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z"/>',
  eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  heart: HEART,
  rocket: '<path d="M5 15c-1.5 1.5-2 5-2 5s3.5-.5 5-2"/><path d="M9 11.5 12.5 15"/><path d="M14.5 4.5C17 2 21 3 21 3s1 4-1.5 6.5L13 16l-5-5 6.5-6.5z"/><circle cx="16" cy="8" r="1.4"/>',
  sprout: '<path d="M12 21v-8"/><path d="M12 13c0-4-3-6-8-6 0 4 3 6 8 6z"/><path d="M12 11c0-4 3-7 8-7 0 5-3 7-8 7z"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.6 9.2a2.5 2.5 0 1 1 3.4 2.4c-.6.3-1 .9-1 1.5v.6"/><path d="M12 17h.01"/>',
  radar: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5"/><path d="M12 12l6.2-6.2"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  play: '<path d="M7 4.5v15l12.5-7.5L7 4.5z"/>',
  download: '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
  alert: '<path d="M10.3 3.9 2.4 18a2 2 0 0 0 1.7 3h15.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
  share: '<path d="M14 5l7 7-7 7"/><path d="M21 12H10a7 7 0 0 0-7 7"/>',
  bookmark: '<path d="M6 3h12v18l-6-4-6 4V3z"/>',
  comment: '<path d="M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-6.2A8 8 0 1 1 21 12z"/>',
  sparkle: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  scale: '<path d="M12 3v18M7 21h10M5 7h14"/><path d="M5 7l-3 7a3 3 0 0 0 6 0L5 7zM19 7l-3 7a3 3 0 0 0 6 0l-3-7z"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.3-4.9L4 8"/><path d="M4 4v4h4"/><path d="M4 13a8 8 0 0 0 14.3 4.9L20 16"/><path d="M20 20v-4h-4"/>',
  pin: '<path d="M12 17v5"/><path d="M8 3h8l-1 6 4 4H5l4-4-1-6z"/>',
  eyeOff: '<path d="M3 3l18 18"/><path d="M10.6 5.1A10 10 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.6 6.6C3.9 8.4 2 12 2 12s3.6 7 10 7a9.7 9.7 0 0 0 4.4-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  ext: '<path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  ban: '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>',
  film: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><circle cx="17.5" cy="9" r="2.5"/><path d="M17 14.5a5 5 0 0 1 4.5 5"/>',
  home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9a1 1 0 0 0 1 1H10v-5h4v5h3.5a1 1 0 0 0 1-1v-9"/>',
  bell: '<path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15L6 16z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0"/><path d="M12 17.5V21M9 21h6"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  trash: '<path d="M4 7h16M10 7V4h4v3M6.5 7l1 13h9l1-13"/><path d="M10 11v6M14 11v6"/>',
  check: '<path d="M4.5 12.5 10 18 19.5 6.5"/>',
  plug: '<path d="M9 3v5M15 3v5"/><path d="M6.5 8h11v3.5a5.5 5.5 0 0 1-11 0V8z"/><path d="M12 17v4"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
  book: '<path d="M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5v-15z"/><path d="M5 19.5A1.5 1.5 0 0 0 6.5 21H19"/>',
  repeat: '<path d="M17 2l4 4-4 4"/><path d="M3 11V9a3 3 0 0 1 3-3h15"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 0 1-3 3H3"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M10.8 12.2 20 3M16 7l3 3M14 9l2 2"/>',
  chart: '<path d="M4 20h16"/><path d="M7 16v-4M12 16V6M17 16V9"/>'
};
function icon(name) {
  if (name === 'heartFill') return `<span class="ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="currentColor">${HEART}</svg></span>`;
  const d = ICONS[name];
  return d ? `<span class="ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg></span>` : '';
}
function hydrateIcons(root = document) { $$('[data-icon]', root).forEach((el) => { el.outerHTML = icon(el.dataset.icon); }); }

/* ---------------- état ---------------- */
let all = [];             // [{ v, rel, m }]
let byId = new Map();
let refCount = 0;
let settings = DEFAULTS;
let mode = 'viral';
let view = 'grid';
let shown = PAGE;
let activeTags = new Set();
let accountFilter = null;
let tableSort = null;     // clic sur une colonne du tableau
let analyzed = new Set(); // vidéos déjà analysées
let drawerId = null;
let drawerTab = 'stats';
let job = null;           // analyse en cours

/* ---------------- les classements ---------------- */
const MODES = {
  viral: {
    icon: 'trophy', label: 'Score viral', sort: 'score', guide: 'g-score',
    sticker: (m) => `${m.score}/100`,
    info: () => `Note sur 100 : vues (${w('size')} pts), vues pour son âge (${w('age')}), vitesse actuelle (${w('speed')}), surperformance du compte (${w('outlier')}) et engagement (${w('engagement')}), comparés aux ${fmtNum(refCount)} vidéos fruits IA de ta base.`
  },
  now: {
    icon: 'bolt', label: 'Explose maintenant', sort: 'speed', guide: 'g-badges',
    sticker: (m) => fmtRate(m),
    info: () => 'Les vidéos qui prennent le plus de vues par heure en ce moment. « ≈ » veut dire estimé : la vidéo n\'a été vue qu\'une fois.'
  },
  views: { icon: 'eye', label: 'Top vues', sort: 'views', guide: 'g-modes', sticker: () => 'en vues', info: () => 'Les vidéos les plus vues sur la période choisie avec le filtre « Posté ».' },
  likes: { icon: 'heart', label: 'Top likes', sort: 'likes', guide: 'g-modes', sticker: () => 'en likes', info: () => 'Les vidéos les plus likées sur la période choisie avec le filtre « Posté ».' },
  outlier: {
    icon: 'rocket', label: 'Surperformance', sort: 'outlier', guide: 'g-badges',
    sticker: (m) => `${fmtMult(m.outlier)} compte`,
    info: () => 'Les vidéos qui ont fait beaucoup plus que d\'habitude pour leur compte : c\'est le concept qui a marché, pas la taille du compte. Minimum 20 k vues.'
  },
  fresh: {
    icon: 'sprout', label: 'Pépites < 48 h', sort: 'perfAge', guide: 'g-modes',
    sticker: (m) => `${fmtMult(m.perfAge)} l'âge`,
    info: () => 'Postées il y a moins de 48 h, classées par vues comparées à une vidéo fruits IA normale du même âge. Les futures virales sont là.'
  }
};
const w = (k) => Math.round(WEIGHTS[k] * 100);

const ELIGIBLE = {
  viral: () => true,
  now: (x) => x.m.rateNow !== null && ((x.m.rateKind === 'mesuré' && x.m.fresh) || (x.m.rateKind === 'estimé' && x.m.ageSnapH <= 48 && x.m.sinceLastH <= 24)),
  views: () => true,
  likes: () => true,
  outlier: (x) => x.m.outlier !== null && x.m.views >= 20000 && x.m.likes >= 1000,
  fresh: (x) => x.m.ageH !== null && x.m.ageH <= 48 && x.m.perfAge !== null
};

const SORTERS = {
  score: (x) => x.m.score,
  speed: (x) => x.m.rateNow ?? -1,
  rateAvg: (x) => x.m.rateAvg ?? -1,
  gain24: (x) => x.m.gain24 ?? -1,
  views: (x) => x.m.views,
  likes: (x) => x.m.likes,
  comments: (x) => x.m.comments,
  shares: (x) => x.m.shares,
  saves: (x) => x.m.saves,
  engagement: (x) => x.m.engagement,
  outlier: (x) => x.m.outlier ?? -1,
  perfAge: (x) => x.m.perfAge ?? -1,
  followers: (x) => x.m.followers ?? -1,
  duration: (x) => x.v.duration ?? -1,
  recent: (x) => x.v.createTime || 0,
  author: (x) => (x.v.author.uniqueId || '').toLowerCase()
};

function sortList(list) {
  const custom = view === 'table' && tableSort;
  const key = custom ? tableSort.key : MODES[mode].sort;
  const dir = custom ? tableSort.dir : -1;
  const f = SORTERS[key] || SORTERS.score;
  return [...list].sort((a, b) => {
    const A = f(a), B = f(b);
    if (A !== B) return (A > B ? 1 : -1) * dir;
    return b.m.views - a.m.views;
  });
}

/* ---------------- thème ---------------- */
function applyTheme(t) {
  if (t === 'dark' || t === 'light') document.documentElement.dataset.theme = t;
  else delete document.documentElement.dataset.theme;
  const dark = t ? t === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches;
  $('#btnTheme').innerHTML = icon(dark ? 'sun' : 'moon') + (dark ? 'Thème clair' : 'Thème sombre');
  $('#btnTheme').setAttribute('aria-label', dark ? 'Passer en thème clair' : 'Passer en thème sombre');
}
function currentTheme() { try { return localStorage.getItem('fr-theme') || ''; } catch (e) { return ''; } }

/* ---------------- filtres mémorisés ---------------- */
const FILTER_IDS = ['fText', 'fAge', 'fDur', 'fMin', 'fLang', 'fMine', 'fNiche', 'fAccel', 'fPinned', 'fPhotos', 'fHidden'];
const STORE_KEY = 'fr-filters-v2';
function saveFilters() {
  const o = {};
  FILTER_IDS.forEach((id) => { const el = $('#' + id); o[id] = el.type === 'checkbox' ? el.checked : el.value; });
  o.view = view; o.mode = mode; o.tags = [...activeTags];
  try { localStorage.setItem(STORE_KEY, JSON.stringify(o)); } catch (e) {}
}
function loadFilters() {
  let o = null;
  try { o = JSON.parse(localStorage.getItem(STORE_KEY) || 'null'); } catch (e) {}
  if (!o) return;
  FILTER_IDS.forEach((id) => {
    const el = $('#' + id);
    if (!(id in o) || !el) return;
    if (el.type === 'checkbox') el.checked = !!o[id]; else if (id !== 'fLang') el.value = o[id];
  });
  if (o.view) view = o.view;
  if (o.mode && MODES[o.mode]) mode = o.mode;
  if (Array.isArray(o.tags)) activeTags = new Set(o.tags);
  window.__savedLang = o.fLang || '';
}

/* ---------------- données ---------------- */
async function loadData() {
  const [raw, ids] = await Promise.all([DB.getAll(), DB.analysisIds().catch(() => [])]);
  analyzed = new Set(ids.map(String));
  const blocked = new Set((settings.blockedAccounts || []).map(normAccount));
  all = raw
    .filter((v) => !v.isAd && !blocked.has(normAccount(v.author && v.author.uniqueId)))
    .map((v) => ({ v, rel: relevance(v, settings) }));
  const r = rankAll(all, { now: Date.now(), isRef: (x) => x.rel.niche && !x.v.hidden && x.v.type !== 'photo' });
  refCount = r.refCount;
  byId = new Map(all.map((x) => [x.v.id, x]));
  fillLangs();
  render();
  renderStatus();
  if (drawerId && $('#drawer').classList.contains('open') && byId.has(drawerId)) renderDrawer();
}

function fillLangs() {
  const sel = $('#fLang');
  const cur = sel.value || window.__savedLang || '';
  const counts = {};
  all.forEach(({ v }) => { if (v.lang) counts[v.lang] = (counts[v.lang] || 0) + 1; });
  const langs = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  sel.innerHTML = '<option value="">Toutes</option>' + langs.map(([l, n]) => `<option value="${esc(l)}">${esc(l.toUpperCase())} (${n})</option>`).join('');
  if ([...sel.options].some((o) => o.value === cur)) sel.value = cur;
}

function baseFiltered() {
  const q = $('#fText').value.trim().toLowerCase();
  const maxAge = mode === 'fresh' ? 48 : Number($('#fAge').value);
  const dur = $('#fDur').value;
  const minV = Number($('#fMin').value);
  const lang = $('#fLang').value;
  const mineF = $('#fMine').value;
  const nicheOnly = $('#fNiche').checked;
  const accel = $('#fAccel').checked;
  const pinned = $('#fPinned').checked;
  const photos = $('#fPhotos').checked;
  const hidden = $('#fHidden').checked;
  const [dmin, dmax] = dur ? dur.split('-').map(Number) : [null, null];
  return all.filter(({ v, m, rel }) => {
    if (hidden ? !v.hidden : v.hidden) return false;
    if (pinned && !v.pinned) return false;
    if (nicheOnly && !rel.niche) return false;
    if (!photos && v.type === 'photo') return false;
    if (maxAge && (m.ageH === null || m.ageH > maxAge)) return false;
    if (dur && (v.duration === null || v.duration === undefined || v.duration < dmin || v.duration > dmax)) return false;
    if (minV && m.views < minV) return false;
    if (lang && v.lang !== lang) return false;
    if (mineF === 'mine' && !rel.mine) return false;
    if (mineF === 'others' && rel.mine) return false;
    if (accel && !m.hot) return false;
    if (accountFilter && v.author.uniqueId !== accountFilter) return false;
    if (activeTags.size && ![...activeTags].every((t) => (v.hashtags || []).includes(t))) return false;
    if (q) {
      const hay = (v.desc + ' @' + v.author.uniqueId + ' ' + v.author.nickname + ' ' + (v.hashtags || []).map((h) => '#' + h).join(' ') + ' ' + (v.music ? v.music.title : '')).toLowerCase();
      if (!q.split(/\s+/).every((wd) => hay.includes(wd))) return false;
    }
    return true;
  });
}

/* ---------------- rendu de la liste ---------------- */
function renderModes() {
  $('#modes').innerHTML = Object.entries(MODES).map(([k, d]) =>
    `<button type="button" class="mode${k === mode ? ' on' : ''}" data-mode="${k}" aria-pressed="${k === mode}">${icon(d.icon)}${d.label}</button>`).join('');
  $('#fAge').disabled = mode === 'fresh';
  $('#fAgeWrap').title = mode === 'fresh' ? 'Les pépites sont toujours les vidéos de moins de 48 h' : '';
}

function render() {
  saveFilters();
  renderModes();
  const base = baseFiltered();
  const list = sortList(base.filter(ELIGIBLE[mode]));
  renderResultsBar(base, list);
  renderActiveTags();
  renderSide(base);
  const box = $('#list');
  if (!list.length) {
    $('#btnMore').hidden = true;
    if (!all.length) {
      box.innerHTML = `<div class="empty"><h3>Ton radar est vide</h3>
        <p>Lance un premier scan : FruitRadar va chercher les vidéos de fruits IA sur TikTok. Juste avant, il te demande avec quel compte scanner.</p>
        <div class="row"><button class="btn primary" type="button" data-action="scan">${icon('radar')}Lancer le premier scan</button><button class="btn" type="button" data-guide="g-start">${icon('help')}Lire le guide (2 min)</button></div></div>`;
    } else if (mode === 'now' && base.length) {
      box.innerHTML = '<div class="empty"><h3>Pas encore de vitesse mesurée</h3><p>Il faut deux relevés de la même vidéo. Le prochain scan (matin ou soir) les mesurera.</p></div>';
    } else {
      box.innerHTML = '<div class="empty"><h3>Aucune vidéo avec ces filtres</h3><p>Essaie « Posté : depuis toujours », ou enlève un filtre.</p></div>';
    }
    return;
  }
  const page = list.slice(0, shown);
  box.innerHTML = view === 'grid' ? gridHtml(page) : tableHtml(page);
  $('#btnMore').hidden = list.length <= shown;
  $('#btnMore').textContent = `Afficher plus (${list.length - shown} restantes)`;
  wireCovers(box);
  wireAvatars(box);
}

function renderResultsBar(base, list) {
  const missing = base.length - list.length;
  let extra = '';
  if (mode === 'now' && missing > 0) extra = `<p class="rnote">${fmtNum(missing)} autre${missing > 1 ? 's attendent' : ' attend'} un 2<sup>e</sup> relevé pour mesurer leur vitesse : le prochain scan s'en occupe.</p>`;
  if (mode === 'outlier' && missing > 0) extra = `<p class="rnote">${fmtNum(missing)} vidéo${missing > 1 ? 's' : ''} sans assez d'infos sur leur compte, ou sous 20 k vues.</p>`;
  const d = MODES[mode];
  $('#resultsbar').innerHTML = `
    <div class="rhead"><h2>${d.label}</h2><span class="rcount">${fmtNum(list.length)} vidéo${list.length > 1 ? 's' : ''}${view === 'table' && tableSort ? ', tri personnalisé du tableau' : ''}</span>
    <button class="helpbtn" type="button" data-guide="${d.guide}">${icon('help')}Comprendre</button></div>
    <p class="rinfo">${d.info()}</p>${extra}`;
}

function coverHtml(v) {
  if (v.cover && !coverExpired(v.cover)) return `<img src="${esc(v.cover)}" alt="" loading="lazy" decoding="async">`;
  return `<div class="nothumb">${icon('play')}<small>Chargement de l'aperçu…</small></div>`;
}

function cardChips(x) {
  const { m, v } = x;
  const chips = [];
  if (mode !== 'viral') chips.push(`<span class="chip" title="Score viral sur 100">Score ${m.score}</span>`);
  if (mode !== 'now' && m.rateNow !== null) chips.push(`<span class="chip" title="Vues par heure en ce moment">${icon('bolt')}${esc(fmtRate(m))}</span>`);
  if (mode !== 'fresh' && m.perfAge !== null && m.perfAge >= 2) chips.push(`<span class="chip" title="Vues comparées à une vidéo fruits IA normale du même âge">${fmtMult(m.perfAge)} pour son âge</span>`);
  if (mode !== 'outlier' && m.outlier !== null && m.outlier >= 3) chips.push(`<span class="chip" title="Par rapport aux autres vidéos du compte">${fmtMult(m.outlier)} vs compte</span>`);
  if (analyzed.has(v.id)) chips.push(`<span class="chip ai" title="Analyse disponible dans la fiche">${icon('sparkle')}Analysée</span>`);
  return chips.slice(0, 3).join('');
}

function gridHtml(page) {
  const d = MODES[mode];
  return '<div class="grid">' + page.map((x, i) => {
    const { v, m, rel } = x;
    return `<article class="card${rel.mine ? ' mine' : ''}${rel.niche ? '' : ' offniche'}" data-id="${esc(v.id)}" tabindex="0" aria-label="Vidéo de @${esc(v.author.uniqueId)}, ${fmtNum(m.views)} vues">
      <div class="thumb" data-vid="${esc(v.id)}">
        ${coverHtml(v)}
        <div class="sticker"><b>#${i + 1}</b><small>${esc(d.sticker(m))}</small></div>
        <div class="flags">
          ${m.hot ? `<span class="flag hot" title="Va ${fmtMult(m.accel)} plus vite que la normale pour son âge">Accélère</span>` : ''}
          ${rel.mine ? '<span class="flag mine">Toi</span>' : ''}
          ${v.pinned ? '<span class="flag">Suivie</span>' : ''}
          ${rel.niche ? '' : '<span class="flag" title="Pas reconnue comme fruit IA">Hors niche</span>'}
        </div>
        <span class="dur">${v.type === 'photo' ? 'Photos' : fmtDur(v.duration)}</span>
        <div class="ov">
          <div class="v"><b>${fmtNum(m.views)}</b><span>vues</span></div>
          <div class="l" title="Likes">${icon('heartFill')}<b>${fmtNum(m.likes)}</b></div>
        </div>
      </div>
      <div class="cbody">
        <div class="who"><span class="acct">@${esc(v.author.uniqueId)}</span><span class="age">${fmtAge(m.ageH)}</span></div>
        <p class="desc">${esc(v.desc) || '<span class="muted">Sans description</span>'}</p>
        <div class="chips">${cardChips(x)}</div>
        ${rel.mine || v.type === 'photo' ? '' : `<button class="btn small repro" type="button" data-repro="${esc(v.id)}" title="Refaire cette histoire avec tes personnages, dans l'automatisation">${icon('repeat')}Reproduire</button>`}
      </div>
    </article>`;
  }).join('') + '</div>';
}

const COLS = [
  ['#', null], ['', null], ['Compte', 'author', 'l'], ['Description', null, 'l'],
  ['Score', 'score'], ['Vues', 'views'], ['Likes', 'likes'], ['Vitesse', 'speed'], ['Moy. /h', 'rateAvg'], ['+24 h', 'gain24'],
  ['Pour son âge', 'perfAge'], ['Vs compte', 'outlier'], ['Comm.', 'comments'], ['Partages', 'shares'], ['Enreg.', 'saves'], ['Engag.', 'engagement'],
  ['Abonnés', 'followers'], ['Durée', 'duration'], ['Posté', 'recent']
];
function tableHtml(page) {
  const sk = view === 'table' && tableSort ? tableSort.key : MODES[mode].sort;
  const asc = view === 'table' && tableSort && tableSort.dir === 1;
  const head = COLS.map(([label, key, al]) => `<th class="${al || ''}${key && key === sk ? ' on' : ''}"${key ? ` data-sort="${key}" title="Trier"` : ''} scope="col">${label}${key && key === sk ? (asc ? ' ↑' : ' ↓') : ''}</th>`).join('');
  const rows = page.map(({ v, m, rel }, i) => `<tr data-id="${esc(v.id)}"${rel.niche ? '' : ' class="offniche"'}>
    <td><span class="rk">${i + 1}</span></td><td>${v.cover && !coverExpired(v.cover) ? `<img src="${esc(v.cover)}" alt="" loading="lazy">` : ''}</td>
    <td class="l">@${esc(v.author.uniqueId)}${rel.mine ? ' <span class="flag mine">Toi</span>' : ''}</td>
    <td class="l"><span class="tdesc" title="${esc(v.desc)}">${esc(v.desc)}</span></td>
    <td><b>${m.score}</b></td><td><b>${fmtNum(m.views)}</b></td><td>${fmtNum(m.likes)}</td>
    <td>${esc(fmtRate(m))}${m.hot ? ' 🔥' : ''}</td><td>${fmtNum(m.rateAvg)}</td><td>${m.gain24 !== null ? '+' + fmtNum(m.gain24) : '—'}</td>
    <td>${fmtMult(m.perfAge)}</td><td>${fmtMult(m.outlier)}</td>
    <td>${fmtNum(m.comments)}</td><td>${fmtNum(m.shares)}</td><td>${fmtNum(m.saves)}</td><td>${fmtPct(m.engagement)}</td>
    <td>${fmtNum(m.followers)}</td><td>${v.type === 'photo' ? 'Photos' : fmtDur(v.duration)}</td><td>${fmtAge(m.ageH)}</td>
  </tr>`).join('');
  return `<div class="tablewrap"><table><thead><tr>${head}</tr></thead><tbody>${rows}</tbody></table></div>`;
}

function renderActiveTags() {
  const chips = [...activeTags].map((t) => `<button class="tag on" data-untag="${esc(t)}" type="button">#${esc(t)} ✕</button>`);
  if (accountFilter) chips.push(`<button class="tag on" data-unaccount="1" type="button">@${esc(accountFilter)} ✕</button>`);
  $('#activeTags').innerHTML = chips.join('');
}

/* ---------------- miniatures ---------------- */
// Les aperçus TikTok expirent : on les recharge via l'oEmbed officiel de TikTok, seulement pour les cartes visibles.
const cov = { queue: [], active: 0, tried: new Set(), budget: 200, observer: null };
function coverExpired(url) {
  const mm = /[?&]x-expires=(\d+)/.exec(url || '');
  return mm ? Number(mm[1]) * 1000 < Date.now() + 5 * 60 * 1000 : false;
}
function wireCovers(root) {
  if (cov.observer) cov.observer.disconnect();
  $$('.thumb[data-vid]', root).forEach((th) => {
    const img = th.querySelector(':scope > img');
    if (img) img.addEventListener('error', () => { img.replaceWith(noThumbNode('Chargement de l\'aperçu…')); watchCover(th); }, { once: true });
    else watchCover(th);
  });
  $$('td img', root).forEach((img) => img.addEventListener('error', () => img.remove(), { once: true }));
}
function wireAvatars(root) { $$('img[data-avatar]', root).forEach((img) => img.addEventListener('error', () => img.replaceWith(Object.assign(document.createElement('span'), { className: 'avatar-fallback' })), { once: true })); }
function noThumbNode(text) {
  const d = document.createElement('div');
  d.className = 'nothumb';
  d.innerHTML = `${icon('play')}<small>${esc(text)}</small>`;
  return d;
}
function watchCover(th) {
  if (!cov.observer) {
    cov.observer = new IntersectionObserver((ents) => ents.forEach((en) => {
      if (en.isIntersecting) { cov.observer.unobserve(en.target); queueCover(en.target.dataset.vid); }
    }), { rootMargin: '300px' });
  }
  cov.observer.observe(th);
}
function queueCover(id) {
  if (cov.tried.has(id) || cov.budget <= 0) { markNoThumb(id); return; }
  cov.tried.add(id); cov.budget--;
  cov.queue.push(id);
  pumpCovers();
}
function pumpCovers() {
  while (cov.active < 3 && cov.queue.length) {
    const id = cov.queue.shift();
    cov.active++;
    fetchCover(id).catch(() => markNoThumb(id)).finally(() => { cov.active--; setTimeout(pumpCovers, 350); });
  }
}
async function fetchCover(id) {
  const x = byId.get(id);
  if (!x) return;
  const res = await fetch('https://www.tiktok.com/oembed?url=' + encodeURIComponent(x.v.url), { credentials: 'omit' });
  if (!res.ok) throw new Error('oembed ' + res.status);
  const j = await res.json();
  if (!j.thumbnail_url) throw new Error('pas de miniature');
  x.v.cover = j.thumbnail_url;
  await DB.patch(id, { cover: j.thumbnail_url, coverAt: Date.now() });
  $$(`.thumb[data-vid="${id}"]`).forEach((th) => {
    const img = new Image();
    img.alt = ''; img.decoding = 'async'; img.src = j.thumbnail_url;
    img.addEventListener('error', () => img.replaceWith(noThumbNode('Aperçu indisponible')), { once: true });
    const old = th.querySelector(':scope > img, :scope > .nothumb');
    if (old) old.replaceWith(img); else th.prepend(img);
  });
}
function markNoThumb(id) { $$(`.thumb[data-vid="${id}"] .nothumb small`).forEach((s) => { s.textContent = 'Aperçu indisponible'; }); }

/* ---------------- panneaux de droite ---------------- */
function medianOf(arr) { return median(arr) ?? 0; }

function mineEntries() { return all.filter((x) => x.rel.mine && !x.v.hidden && x.v.type !== 'photo' && x.m.views > 0); }

function renderMinePanel() {
  const accts = (settings.myAccounts || []).map(normAccount).filter(Boolean);
  const box = $('#minePanel');
  if (!accts.length) {
    box.innerHTML = `<h3>Ton compte</h3><p class="hint">Ajoute ton compte TikTok pour comparer les vidéos du radar avec les tiennes.</p><button class="btn small" type="button" data-action="settings">${icon('gear')}Ajouter mon compte</button>`;
    return;
  }
  const mine = mineEntries();
  if (!mine.length) {
    box.innerHTML = `<h3>Ton compte</h3><p class="hint">@${esc(accts[0])} : aucune de tes vidéos dans le radar pour l'instant.</p>
      <button class="btn small primary" type="button" data-action="scanMine">${icon('download')}Récupérer mes vidéos</button>`;
    if (SITE) SITE.decorate(box);
    return;
  }
  const best = [...mine].sort((a, b) => b.m.views - a.m.views)[0];
  const bestRank = Math.min(...mine.map((x) => x.m.rank.viral || Infinity));
  box.innerHTML = `<h3>Ton compte</h3><p class="hint">@${esc(accts.join(', @'))}, ${mine.length} vidéo${mine.length > 1 ? 's' : ''} dans le radar.</p>
    <div class="mine-stats">
      <div><b>${fmtNum(medianOf(mine.map((x) => x.m.views)))}</b><span>vues médianes</span></div>
      <div><b>${fmtNum(best.m.views)}</b><span>ta meilleure</span></div>
      <div><b>${fmtNum(medianOf(mine.map((x) => x.m.score)))}</b><span>score médian</span></div>
      <div><b>${Number.isFinite(bestRank) ? '#' + bestRank : '—'}</b><span>ta meilleure place</span></div>
    </div>
    <div class="row" style="display:flex;gap:6px;flex-wrap:wrap">
      <button class="btn small" type="button" data-action="showMine">Voir mes vidéos</button>
      <button class="btn small ghost" type="button" data-action="scanMine">${icon('refresh')}Mettre à jour</button>
    </div>`;
  if (SITE) SITE.decorate(box);
}

function renderSide(list) {
  renderMinePanel();
  const tags = new Map();
  list.forEach(({ v, m }) => new Set(v.hashtags || []).forEach((t) => {
    if (TAG_STOP.has(t)) return;
    if (!tags.has(t)) tags.set(t, []);
    tags.get(t).push(m.views);
  }));
  const minN = list.length < 30 ? 2 : 3;
  const topT = [...tags.entries()].filter(([, arr]) => arr.length >= minN)
    .map(([t, arr]) => [t, medianOf(arr), arr.length]).sort((a, b) => b[1] - a[1]).slice(0, 20);
  $('#topTags').innerHTML = topT.length
    ? topT.map(([t, med, n]) => `<button class="tag${activeTags.has(t) ? ' on' : ''}" data-tag="${esc(t)}" type="button" title="${n} vidéos, médiane ${fmtNum(med)} vues">#${esc(t)}<b>${fmtNum(med)}</b><i>${n}</i></button>`).join('')
    : '<span class="muted">Pas encore assez de vidéos.</span>';

  const acc = new Map();
  list.forEach(({ v, m, rel }) => {
    const k = v.author.uniqueId; if (!k || rel.mine || !rel.niche) return;
    const e = acc.get(k) || { a: v.author, n: 0, views: 0, best: 0 };
    e.n++; e.views += m.views; e.best = Math.max(e.best, m.views); e.a = { ...e.a, ...v.author }; acc.set(k, e);
  });
  const topA = [...acc.entries()].sort((a, b) => b[1].views - a[1].views).slice(0, 10);
  $('#topAccounts').innerHTML = topA.length ? topA.map(([k, e]) => `<li data-account="${esc(k)}" title="Voir seulement ce compte">
      ${e.a.avatar ? `<img src="${esc(e.a.avatar)}" alt="" data-avatar="1">` : '<span class="avatar-fallback"></span>'}
      <div><div class="n">@${esc(k)}</div><div class="m">${e.n} vidéo${e.n > 1 ? 's' : ''}, meilleure ${fmtNum(e.best)}</div></div>
      <div class="v">${fmtNum(e.views)}</div></li>`).join('') : '<li class="muted">Rien pour l\'instant.</li>';
  wireAvatars($('#topAccounts'));
}

/* ---------------- barre d'état ---------------- */
async function renderStatus() {
  const st = await chrome.storage.local.get(['lastScanAt', 'lastScanReport', 'pauseUntil', 'pauseReason', 'scanSkip', 'scanAck', 'scanHistory']);
  const ref = all.filter((x) => x.rel.niche && !x.v.hidden && x.v.type !== 'photo');
  const day = ref.filter((x) => x.m.ageH !== null && x.m.ageH <= 24).length;
  const hot = ref.filter((x) => x.m.hot).length;
  const next = nextSlot(settings.scanTimes || []);
  const r = st.lastScanReport;
  const paused = st.pauseUntil && st.pauseUntil > Date.now();
  $('#statusbar').innerHTML = `
    <span><b>${fmtNum(ref.length)}</b> vidéos fruits IA</span>
    <span><b>${fmtNum(day)}</b> postées en moins de 24 h</span>
    <span><b>${fmtNum(hot)}</b> accélèrent</span>
    <span>Dernier scan <b>${r ? relTime(r.endedAt || st.lastScanAt) : 'aucun'}</b></span>
    <span>Prochain scan <b>${paused ? 'en pause' : !settings.autoScan || !next ? 'désactivé' : scanReady(settings, st) ? next : 'après ton 1er scan'}</b></span>
    <span>Étendue <b>${esc((BREADTH[settings.breadth] || BREADTH.large).label)}</b></span>`;

  const pb = $('#pauseBanner');
  const skip = !paused && st.scanSkip && settings.scanAccount && Date.now() - st.scanSkip.at < 12 * 3600e3 ? st.scanSkip : null; // dernier scan automatique sauté : mauvais compte connecté
  pb.hidden = !paused && !skip;
  if (skip) pb.innerHTML = `<div><h2>Scan automatique sauté ${esc(relTime(skip.at))}</h2><p>Ce Chrome était connecté à @${esc(skip.uid)}, pas à ton compte de scan @${esc(skip.want)}. Passe sur @${esc(skip.want)} dans TikTok (avatar, « Changer de compte »), puis lance un scan.</p></div><div class="banner-actions"><button class="btn" type="button" data-guide="g-risks">Comprendre</button></div>`;
  if (paused) {
    pb.innerHTML = `<div><h2>Scans auto en pause jusqu'à ${new Date(st.pauseUntil).toLocaleString('fr-FR', { weekday: 'long', hour: '2-digit', minute: '2-digit' })}</h2>
      <p>${esc(st.pauseReason || 'TikTok a montré des signes de blocage')}. FruitRadar attend 24 h par sécurité avant de rescanner.</p></div>
      <div class="banner-actions"><button class="btn" type="button" data-guide="g-risks">Comprendre</button><button class="btn ghost" type="button" data-action="resume">Reprendre maintenant</button></div>`;
  }

  $('#scanReport').innerHTML = r ? `
    <div>${new Date(r.startedAt).toLocaleString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}, ${esc(r.trigger)}${r.breadth && BREADTH[r.breadth] ? `, étendue ${esc(BREADTH[r.breadth].label.toLowerCase())}` : ''}</div>
    <div><b>${r.added}</b> nouvelle(s), <b>${r.refreshed}</b> actualisée(s)${r.refreshFailed ? `, ${r.refreshFailed} échec(s)` : ''}</div>
    <ul>${(r.perQuery || []).slice(0, 60).map((p) => `<li>${esc(p.q)}${p.kind && p.kind !== 'recherche' ? ` <span class="muted">(${esc(p.kind)})</span>` : ''} : +${p.added}${p.block ? ' <span class="warn">(captcha)</span>' : ''}</li>`).join('')}</ul>
    ${(r.warnings || []).map((wn) => `<div class="warn">${esc(wn)}</div>`).join('')}` : '<span class="muted">Aucun scan pour l\'instant.</span>';
}

function relTime(t) {
  if (!t) return '—';
  const h = (Date.now() - t) / H;
  return h < 1 ? `il y a ${Math.max(1, Math.round(h * 60))} min` : h < 24 ? `il y a ${Math.round(h)} h` : new Date(t).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
}
function nextSlot(times) {
  const now = new Date();
  let best = null;
  for (const d of [0, 1]) for (const t of times) {
    const [h, mm] = String(t).split(':').map(Number);
    if (!Number.isFinite(h)) continue;
    const dt = new Date(now); dt.setDate(dt.getDate() + d); dt.setHours(h, mm || 0, 0, 0);
    if (dt > now && (!best || dt < best)) best = dt;
  }
  if (!best) return null;
  return (best.getDate() === now.getDate() ? '' : 'demain ') + best.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

/* ---------------- graphiques (une série, survol) ---------------- */
function lineChart(points, { yFmt = fmtNum, kind = 'line', height = 150 } = {}) {
  if (points.length < (kind === 'bar' ? 1 : 2)) return '<p class="muted" style="margin:8px 0">Pas encore assez de relevés : chaque scan (matin et soir) en ajoute un.</p>';
  const W = 520, Hh = height, pl = 46, pr = 10, pt = 10, pb = 22;
  const xs = points.map((p) => p.x), ys = points.map((p) => p.y);
  const x0 = Math.min(...xs), x1 = Math.max(...xs);
  const y1 = Math.max(...ys) * 1.08 || 1;
  const X = (x) => (x1 === x0 ? (pl + W - pr) / 2 : pl + ((x - x0) / (x1 - x0)) * (W - pl - pr));
  const Y = (y) => pt + (1 - y / y1) * (Hh - pt - pb);
  const ticks = [0, y1 / 2, y1].map((t) => `<line x1="${pl}" x2="${W - pr}" y1="${Y(t)}" y2="${Y(t)}" stroke="var(--line)" stroke-width="1"/><text x="${pl - 6}" y="${Y(t) + 4}" text-anchor="end" font-size="11" fill="var(--muted)">${yFmt(t)}</text>`).join('');
  const fmtX = (t) => new Date(t).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  const xl = `<text x="${pl}" y="${Hh - 4}" font-size="11" fill="var(--muted)">${fmtX(x0)}</text><text x="${W - pr}" y="${Hh - 4}" font-size="11" fill="var(--muted)" text-anchor="end">${fmtX(x1)}</text>`;
  const plotW = W - pl - pr;
  const PX = points.map((p, i) => (kind === 'bar' ? pl + (i + 0.5) * (plotW / points.length) : X(p.x)));
  let marks;
  if (kind === 'bar') {
    const bw = Math.max(4, Math.min(28, plotW / points.length - 8));
    marks = points.map((p, i) => {
      const x = PX[i] - bw / 2, y = Y(p.y), h = Math.max(1, Y(0) - y);
      const r = Math.min(4, bw / 2, h);
      return `<path d="M${x},${Y(0)} V${y + r} Q${x},${y} ${x + r},${y} H${x + bw - r} Q${x + bw},${y} ${x + bw},${y + r} V${Y(0)} Z" fill="var(--mango)"/>`;
    }).join('');
  } else {
    const d = points.map((p, i) => `${i ? 'L' : 'M'}${PX[i].toFixed(1)},${Y(p.y).toFixed(1)}`).join(' ');
    marks = `<path d="${d}" fill="none" stroke="var(--mango)" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>` +
      points.map((p, i) => `<circle cx="${PX[i]}" cy="${Y(p.y)}" r="4" fill="var(--mango)" stroke="var(--surface)" stroke-width="2"/>`).join('');
  }
  const hits = points.map((p, i) => {
    const a = i ? (PX[i - 1] + PX[i]) / 2 : pl, b = i < points.length - 1 ? (PX[i] + PX[i + 1]) / 2 : W - pr;
    return `<rect x="${a}" y="0" width="${Math.max(1, b - a)}" height="${Hh}" fill="transparent" data-tip="${esc(p.label || fmtX(p.x))} : <b>${esc(yFmt(p.y))}</b>" data-tx="${PX[i]}" data-ty="${Y(p.y)}"/>`;
  }).join('');
  return `<svg viewBox="0 0 ${W} ${Hh}" role="img">${ticks}${xl}${marks}<line class="xh" x1="0" x2="0" y1="${pt}" y2="${Hh - pb}" stroke="var(--muted)" stroke-dasharray="3 3" opacity="0"/>${hits}</svg><div class="tip" hidden></div>`;
}
function bindChartHover(root) {
  $$('.box', root).forEach((cb) => {
    const svg = cb.querySelector('svg'), tip = cb.querySelector('.tip');
    if (!svg || !tip) return;
    const xh = svg.querySelector('.xh');
    svg.addEventListener('mousemove', (e) => {
      const r = e.target.closest('rect[data-tip]'); if (!r) return;
      const bb = svg.getBoundingClientRect(), cbb = cb.getBoundingClientRect();
      const s = bb.width / svg.viewBox.baseVal.width;
      tip.innerHTML = r.dataset.tip; tip.hidden = false;
      tip.style.left = (bb.left - cbb.left + Number(r.dataset.tx) * s) + 'px';
      tip.style.top = (bb.top - cbb.top + Number(r.dataset.ty) * s) + 'px';
      xh.setAttribute('x1', r.dataset.tx); xh.setAttribute('x2', r.dataset.tx); xh.setAttribute('opacity', '1');
    });
    svg.addEventListener('mouseleave', () => { tip.hidden = true; xh.setAttribute('opacity', '0'); });
  });
}

/* ---------------- fiche vidéo ---------------- */
function openDrawer(id, tab) {
  if (!byId.has(id)) return;
  if (id !== drawerId) drawerTab = tab || 'stats';
  else if (tab) drawerTab = tab;
  drawerId = id;
  renderDrawer();
  $('#drawer').classList.add('open');
  $('#drawer').setAttribute('aria-hidden', 'false');
  $('#drawerBackdrop').hidden = false;
  $('#drawer').scrollTop = 0;
  $('#drawerClose').focus({ preventScroll: true });
}
function closeDrawer() {
  $('#drawer').classList.remove('open');
  $('#drawer').setAttribute('aria-hidden', 'true');
  $('#drawerBackdrop').hidden = true;
  $('#drawerBody').innerHTML = '';
  const back = drawerId && document.querySelector(`[data-id="${drawerId}"]`);
  drawerId = null;
  if (back) back.focus({ preventScroll: true });
}

function renderDrawer() {
  const x = byId.get(drawerId);
  if (!x) return closeDrawer();
  const { v, m, rel } = x;
  const overridden = v.nicheOverride === true || v.nicheOverride === false;
  const nicheBtn = overridden ? 'Laisser l\'extension décider' : rel.niche ? 'Pas du fruit IA' : 'C\'est du fruit IA';
  $('#drawerBody').innerHTML = `<div class="dwrap">
    <div>
      <div class="player" id="player">
        ${v.cover && !coverExpired(v.cover) ? `<img src="${esc(v.cover)}" alt="">` : ''}
        <button class="playbtn" id="playHere" type="button"><span>${icon('play')}Lire ici</span></button>
      </div>
      <div class="dactions">
        <a class="btn small" href="${esc(v.url)}" target="_blank" rel="noopener">${icon('ext')}Ouvrir sur TikTok</a>
        <a class="btn small" href="https://www.tiktok.com/@${esc(v.author.uniqueId)}" target="_blank" rel="noopener">${icon('user')}Voir le compte</a>
        ${rel.mine || v.type === 'photo' ? '' : `<button class="btn small primary" id="dRepro" type="button">${icon('repeat')}Reproduire</button>`}
        <button class="btn small${rel.mine ? ' primary' : ''}" id="dDownload" type="button">${icon('download')}Télécharger</button>
        <button class="btn small" id="dCopyLink" type="button">${icon('link')}Copier le lien</button>
        <button class="btn small" id="dCopyDesc" type="button">${icon('copy')}Copier la description</button>
        <button class="btn small" id="dRefresh" type="button">${icon('refresh')}Actualiser les chiffres</button>
        <button class="btn small" id="dPin" type="button">${icon('pin')}${v.pinned ? 'Ne plus suivre' : 'Suivre de près'}</button>
        <button class="btn small ghost" id="dHide" type="button">${icon('eyeOff')}${v.hidden ? 'Réafficher' : 'Masquer'}</button>
      </div>
      <div class="dsort">
        <p class="hint">Mal rangée ?</p>
        <button class="btn small" id="dNiche" type="button">${nicheBtn}</button>
        ${rel.mine ? '' : `<button class="btn small ghost danger" id="dBlock" type="button">${icon('ban')}Bloquer @${esc(v.author.uniqueId)}</button>`}
      </div>
    </div>
    <div>
      <div class="dhead">
        ${v.author.avatar ? `<img src="${esc(v.author.avatar)}" alt="" data-avatar="1">` : ''}
        <div><h2>@${esc(v.author.uniqueId)}${v.author.verified ? ' ✔' : ''}${rel.mine ? ' <span class="flag mine">Toi</span>' : ''}</h2>
        <p>${esc(v.author.nickname)}, ${fmtNum(m.followers)} abonnés${v.author.videoCount ? `, ${fmtNum(v.author.videoCount)} vidéos` : ''}</p></div>
      </div>
      <p class="ddesc">${esc(v.desc) || '<span class="muted">Sans description</span>'}</p>
      <div class="dbig">
        <div><b>${fmtNum(m.views)}</b><span>vues</span></div>
        <div><b>${fmtNum(m.likes)}</b><span>likes</span></div>
        <div class="score"><b>${m.score}</b><span>score viral /100</span></div>
      </div>
      <div class="tabs" role="tablist">
        <button type="button" role="tab" data-tab="stats" class="${drawerTab === 'stats' ? 'on' : ''}" aria-selected="${drawerTab === 'stats'}">${icon('trophy')}Chiffres</button>
        <button type="button" role="tab" data-tab="analyse" class="${drawerTab === 'analyse' ? 'on' : ''}" aria-selected="${drawerTab === 'analyse'}">${icon('sparkle')}Analyse${analyzed.has(v.id) ? '<span class="dot" title="Déjà analysée"></span>' : ''}</button>
        <button type="button" role="tab" data-tab="compare" class="${drawerTab === 'compare' ? 'on' : ''}" aria-selected="${drawerTab === 'compare'}">${icon('scale')}Comparer avec mon compte</button>
      </div>
      <div id="tabBody" role="tabpanel"></div>
    </div>
  </div>`;
  wireAvatars($('#drawerBody'));
  const pimg = $('#player > img'); if (pimg) pimg.addEventListener('error', () => pimg.remove(), { once: true });
  $('#playHere').onclick = () => {
    $('#player').innerHTML = `<iframe src="https://www.tiktok.com/player/v1/${encodeURIComponent(v.id)}?autoplay=1&music_info=1&description=1&rel=0" allow="autoplay; fullscreen; encrypted-media" allowfullscreen title="Lecteur TikTok"></iframe>`;
  };
  if ($('#dRepro')) $('#dRepro').onclick = () => reproduce(v.id);
  $('#dDownload').onclick = (e) => download(v, e.currentTarget);
  $('#dCopyLink').onclick = () => copy(v.url, 'Lien copié');
  $('#dCopyDesc').onclick = () => copy(v.desc || (v.hashtags || []).map((h) => '#' + h).join(' '), 'Description copiée');
  $('#dRefresh').onclick = async (e) => {
    e.currentTarget.disabled = true; e.currentTarget.textContent = 'Actualisation…';
    const r = await chrome.runtime.sendMessage({ type: 'refreshOne', id: v.id }).catch(() => null);
    toast(r && r.ok ? 'Chiffres mis à jour' : 'TikTok n\'a pas répondu, réessaie plus tard');
    await loadData();
  };
  $('#dPin').onclick = async () => { await DB.patch(v.id, { pinned: !v.pinned }); await loadData(); };
  $('#dHide').onclick = async () => { await DB.patch(v.id, { hidden: !v.hidden }); toast(v.hidden ? 'Vidéo réaffichée' : 'Vidéo masquée'); closeDrawer(); loadData(); };
  $('#dNiche').onclick = async () => {
    const next = overridden ? null : !rel.niche;
    await DB.patch(v.id, { nicheOverride: next });
    toast(next === null ? 'L\'extension décide à nouveau' : next ? 'Comptée comme fruit IA' : 'Sortie du classement fruits IA');
    await loadData();
  };
  const bb = $('#dBlock');
  if (bb) bb.onclick = async () => {
    const uid = v.author.uniqueId;
    if (!(await ask(`Bloquer @${uid} ?`, { text: 'Ses vidéos disparaissent du radar et ne seront plus captées. Tu peux annuler dans Réglages.', ok: 'Bloquer', danger: true }))) return;
    settings = await saveSettings({ blockedAccounts: [...new Set([...(settings.blockedAccounts || []), uid])] });
    toast(`@${uid} bloqué`); closeDrawer(); loadData();
  };
  renderTab();
}

function renderTab() {
  const x = byId.get(drawerId);
  if (!x) return;
  $$('.tabs [data-tab]').forEach((b) => { const on = b.dataset.tab === drawerTab; b.classList.toggle('on', on); b.setAttribute('aria-selected', String(on)); });
  if (drawerTab === 'analyse') return renderAnalysisTab(x);
  if (drawerTab === 'compare') return renderCompareTab(x);
  return renderStatsTab(x);
}

function scoreBreakdown(m) {
  const rows = [
    ['size', `${fmtNum(m.views)} vues`],
    ['age', m.perfAge !== null ? `${fmtMult(m.perfAge)} par rapport à une vidéo fruits IA normale de ${fmtAge(m.ageSnapH)}` : '—'],
    ['speed', m.rateNow !== null ? `${fmtRate(m)} ${m.rateKind === 'mesuré' ? `(mesuré sur ${fmtAge(m.rateWindowH)})` : '(estimé : un seul relevé pour l\'instant)'}` : '—'],
    ['outlier', m.outlier !== null ? `${fmtMult(m.outlier)} ${m.outlierKind === 'likes' ? `par rapport à sa moyenne (${fmtNum(m.authorBase)} likes par vidéo)` : `par rapport à ses autres vidéos captées (${fmtNum(m.authorBase)} vues)`}` : 'Pas assez d\'infos sur le compte : compté comme moyen.'],
    ['engagement', `${fmtPct(m.engagement)} des vues, dont ${fmtPct(m.shareRate, 2)} de partages`]
  ];
  return rows.map(([k, val]) => {
    const max = Math.round(WEIGHTS[k] * 100), pts = (m.pts && m.pts[k]) ?? 0, p = m.P[k];
    return `<div class="sbrow"><div class="sbtop"><span>${WEIGHT_LABELS[k]}</span><b>${Math.round(pts)}<small> / ${max}</small></b></div>
      <div class="bar"><span style="width:${Math.min(100, (pts / max) * 100)}%"></span></div>
      <div class="sbval">${esc(val)}</div>${p !== null && p !== undefined ? `<div class="sbpct">Mieux que ${Math.round(p * 100)} % de ta base</div>` : ''}</div>`;
  }).join('');
}

function renderStatsTab(x) {
  const { v, m, rel } = x;
  const snaps = (v.snapshots || []).filter((s) => s.v !== null);
  const viewPts = [];
  if (v.createTime && (!snaps.length || snaps[0].t > v.createTime * 1000)) viewPts.push({ x: v.createTime * 1000, y: 0, label: 'Publication' });
  snaps.forEach((s) => viewPts.push({ x: s.t, y: s.v }));
  const vphPts = [];
  for (let i = 1; i < viewPts.length; i++) {
    const dh = (viewPts[i].x - viewPts[i - 1].x) / H;
    if (dh > 0.2) vphPts.push({ x: viewPts[i].x, y: Math.max(0, (viewPts[i].y - viewPts[i - 1].y) / dh), label: `Sur les ${fmtAge(dh)} avant ce relevé` });
  }
  const rk = m.rank || {};
  const ranks = rk.viral ? `<p class="ranks">Dans ta base de ${fmtNum(refCount)} vidéos : <b>#${rk.viral}</b> en score viral, <b>#${rk.views}</b> en vues, <b>#${rk.likes}</b> en likes${rk.speed ? `, <b>#${rk.speed}</b> en vitesse` : ''}${rk.outlier ? `, <b>#${rk.outlier}</b> en surperformance` : ''}.</p>` : '';
  $('#tabBody').innerHTML = `
    <div class="stats">
      <div class="stat"><b>${esc(fmtRate(m))}</b><span>vitesse ${m.rateKind === 'mesuré' ? 'mesurée' : m.rateKind === 'estimé' ? 'estimée' : ''}</span></div>
      <div class="stat"><b>${m.gain24 !== null ? '+' + fmtNum(m.gain24) : '—'}</b><span>vues sur 24 h</span></div>
      <div class="stat"><b>${fmtMult(m.perfAge)}</b><span>pour son âge</span></div>
      <div class="stat"><b>${fmtMult(m.outlier)}</b><span>vs le compte</span></div>
      <div class="stat"><b>${fmtNum(m.comments)}</b><span>commentaires</span></div>
      <div class="stat"><b>${fmtNum(m.shares)}</b><span>partages</span></div>
      <div class="stat"><b>${fmtNum(m.saves)}</b><span>enregistrements</span></div>
      <div class="stat"><b>${fmtPct(m.engagement)}</b><span>engagement</span></div>
      <div class="stat"><b>${fmtAge(m.ageH)}</b><span>en ligne depuis</span></div>
      <div class="stat"><b>${v.type === 'photo' ? 'Photos' : fmtDur(v.duration)}</b><span>durée</span></div>
      <div class="stat"><b>${fmtNum(m.followers)}</b><span>abonnés du compte</span></div>
      <div class="stat"><b>${m.viewsPerFollower !== null ? fmtMult(m.viewsPerFollower) : '—'}</b><span>vues ÷ abonnés</span></div>
    </div>
    ${m.hot ? `<p class="hotline">Elle accélère : ${fmtMult(m.accel)} plus vite que la normale pour une vidéo de son âge.</p>` : ''}
    <div class="box"><h4>Pourquoi ce score : ${m.score} / 100 <button class="helpbtn" type="button" data-guide="g-score">${icon('help')}Comprendre</button></h4>
      <p>Chaque critère compare la vidéo aux ${fmtNum(refCount)} vidéos fruits IA de ta base.</p>
      ${scoreBreakdown(m)}${ranks}</div>
    <div class="box"><h4>Vues cumulées</h4><p>${snaps.length} relevé(s) depuis le ${new Date(v.firstSeen || m.lastT).toLocaleDateString('fr-FR')}</p>${lineChart(viewPts)}</div>
    <div class="box"><h4>Vitesse entre deux relevés</h4><p>Si la barre la plus à droite est la plus haute, la vidéo accélère.</p>${lineChart(vphPts, { kind: 'bar', yFmt: (y) => fmtNum(y) })}</div>
    <dl class="kv">
      <dt>Publiée le</dt><dd>${v.createTime ? new Date(v.createTime * 1000).toLocaleString('fr-FR') : '—'}</dd>
      <dt>Hashtags</dt><dd>${(v.hashtags || []).map((h) => '#' + esc(h)).join(' ') || '—'}</dd>
      <dt>Son</dt><dd>${v.music ? esc(v.music.title) + (v.music.author ? ', ' + esc(v.music.author) : '') + (v.music.original ? ' (son original)' : '') : '—'}</dd>
      <dt>Langue et pays</dt><dd>${esc((v.lang || '—').toUpperCase())}, ${esc(v.country || '—')}</dd>
      <dt>Fruit IA ?</dt><dd><b>${rel.niche ? 'Oui' : 'Non'}</b>${rel.reasons.length ? '. ' + rel.reasons.map(esc).join(', ') : ''}</dd>
      <dt>Trouvée via</dt><dd>${(v.sources || []).map(esc).join(', ') || '—'}</dd>
      <dt>Dernier relevé</dt><dd>${relTime(m.lastT)}</dd>
    </dl>`;
  bindChartHover($('#tabBody'));
}

/* ---------------- analyse ---------------- */
function roleClass(r) {
  const s = String(r || '').toLowerCase();
  if (s.includes('hook')) return 'hook';
  if (s.includes('retourn') || s.includes('twist')) return 'twist';
  if (s.includes('appel') || s.includes('cta')) return 'cta';
  return '';
}
function thumbAt(local, sec) {
  const sc = (local && local.scenes) || [];
  if (!sc.length || sec === null || sec === undefined) return null;
  let best = sc[0];
  for (const s of sc) if (s.start <= sec + 0.6) best = s;
  return best.thumb;
}

async function renderAnalysisTab(x) {
  const box = $('#tabBody');
  if (job && job.id === x.v.id) { box.innerHTML = jobHtml(); wireJob(x); return; }
  box.innerHTML = '<p class="muted">Chargement…</p>';
  const an = await DB.getAnalysis(x.v.id).catch(() => null);
  if (drawerId !== x.v.id || drawerTab !== 'analyse') return;
  box.innerHTML = an ? analysisHtml(x, an) : analysisIntro();
  hydrateIcons(box);
  wireAnalysis(x, an);
}

function analysisIntro() {
  const hasKey = !!settings.geminiKey;
  return `<div class="an-intro">
    <div class="an-option main">
      <h4>Analyse complète par IA</h4>
      <p>Résumé, hook des 3 premières secondes, la question qui fait rester, les scènes avec une image par plan, le retournement, les personnages, ce qui retient les gens, pourquoi ça marche, et 3 idées pour ton compte.</p>
      <div class="row">${hasKey
        ? `<button class="btn primary" id="anAI" type="button">${icon('sparkle')}Analyser cette vidéo</button><span class="muted">Gratuit avec ta clé Gemini, 30 s à 2 min.</span>`
        : `<button class="btn primary" id="anKey" type="button">${icon('gear')}Ajouter ma clé gratuite</button><button class="helpbtn" type="button" data-guide="g-analyse">${icon('help')}Comment l'obtenir (2 min)</button>`}</div>
    </div>
    <div class="an-option">
      <h4>Analyse rapide, sans clé</h4>
      <p>Découpe la vidéo en scènes (une image par plan), mesure le rythme et récupère les sous-titres.</p>
      <div class="row"><button class="btn" id="anLocal" type="button">Découper les scènes</button></div>
    </div>
    <div class="an-option">
      <h4>Dans Grok ou ChatGPT</h4>
      <p>Télécharge la vidéo, copie le prompt, puis envoie les deux dans Grok ou ChatGPT.</p>
      <div class="row"><button class="btn" id="anDownload" type="button">${icon('download')}Télécharger la vidéo</button><button class="btn" id="anPrompt" type="button">${icon('copy')}Copier le prompt</button></div>
    </div>
    <p class="note muted">Chaque analyse charge une seule page TikTok, comme quand tu ouvres la vidéo. L'analyse IA envoie la vidéo à Google.</p>
  </div>`;
}

function kvRows(rows) {
  return `<dl class="an-kv">${rows.filter(([, val]) => val).map(([k, val]) => `<dt>${k}</dt><dd>${esc(val)}</dd>`).join('')}</dl>`;
}
function list(items) { return items && items.length ? `<ul>${items.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>` : '<p class="muted">Rien de notable.</p>'; }

function analysisHtml(x, an) {
  const a = an.ai, lo = an.local || {};
  const sc = lo.scenes || [];
  const rhythm = sc.length > 1 && lo.duration ? `${sc.length} plans sur ${AN.fmtTime(lo.duration)}, soit un changement de plan toutes les ${(lo.duration / sc.length).toFixed(1).replace('.', ',')} s` : '';
  const head = `<div class="an-actions">
      ${a ? `<button class="btn small" id="anCopy" type="button">${icon('copy')}Copier l'analyse</button>` : ''}
      ${settings.geminiKey ? `<button class="btn small${a ? '' : ' primary'}" id="anAI" type="button">${icon('sparkle')}${a ? 'Relancer l\'analyse IA' : 'Analyse complète par IA'}</button>` : `<button class="btn small" id="anKey" type="button">${icon('gear')}Ajouter ma clé gratuite</button>`}
      ${a ? '' : `<button class="btn small" id="anLocal" type="button">${icon('refresh')}Refaire le découpage</button>`}
      <button class="btn small ghost" id="anPrompt" type="button">${icon('copy')}Prompt pour Grok / ChatGPT</button>
      <button class="btn small ghost" id="anDownload" type="button">${icon('download')}Télécharger la vidéo</button>
    </div>`;
  const firstFrame = sc[0] && sc[0].thumb;
  const hookTranscript = (lo.transcript || []).filter((c) => c.start < 3.2).map((c) => c.text).join(' ');
  const transcript = lo.transcript && lo.transcript.length
    ? `<details class="an-sec"><summary><b>Sous-titres</b> <span class="muted">(${lo.transcript.length} lignes)</span></summary><div class="transcript">${lo.transcript.map((c) => `<p><span>${AN.fmtTime(c.start)}</span>${esc(c.text)}</p>`).join('')}</div></details>` : '';
  const foot = `<p class="note muted">${a ? `Analysée le ${new Date(an.at).toLocaleString('fr-FR')} avec ${esc(an.model || 'Gemini')}.` : `Découpée le ${new Date(an.at).toLocaleString('fr-FR')}.`}${lo.scenesError ? ` Découpage impossible : ${esc(lo.scenesError)}.` : ''}</p>`;

  if (!a) {
    return `${head}
      <div class="an-sec"><h4>Analyse rapide</h4><p>Pour le hook, la question qui fait rester, l'histoire et les idées pour ton compte, lance l'analyse complète par IA.</p></div>
      <div class="an-sec"><h4>Le début <small>00:00 à 00:03</small></h4>
        <div class="an-hook">${firstFrame ? `<img src="${firstFrame}" alt="Première image">` : '<span></span>'}
        <div>${hookTranscript ? `<p class="qbox">« ${esc(hookTranscript)} »</p>` : '<p class="muted">Pas de sous-titres pour le début.</p>'}</div></div></div>
      ${sc.length ? `<div class="an-sec"><h4>Les scènes <small>${esc(rhythm)}</small></h4>
        <div class="reel">${sc.map((s) => `<figure><img src="${s.thumb}" alt=""><figcaption>${AN.fmtTime(s.start)}</figcaption></figure>`).join('')}</div></div>` : ''}
      ${transcript}${foot}`;
  }

  const q = a.question;
  return `${head}
    <div class="an-sec"><h4>En bref${a.theme ? ` <small>${esc(a.theme)}</small>` : ''}</h4><p class="an-lead">${esc(a.resume) || '—'}</p></div>
    <div class="an-sec"><h4>Le hook <small>${esc(a.hook.temps)}</small></h4>
      <div class="an-hook">${firstFrame ? `<img src="${firstFrame}" alt="Première image">` : '<span></span>'}
      ${kvRows([['On voit', a.hook.visuel], ['On entend ou lit', a.hook.texte_ou_voix], ['Type de hook', a.hook.type], ['Pourquoi ça accroche', a.hook.pourquoi]])}</div></div>
    <div class="an-sec"><h4>La question qui fait rester</h4>
      ${q.question ? `<p class="qbox">${esc(q.question)}</p>` : '<p class="muted">Pas de question claire posée.</p>'}
      ${kvRows([['Posée à', q.posee_a], ['Réponse', q.reponse || (q.question ? 'La vidéo ne répond pas : elle laisse la question ouverte.' : '')], ['Répondue à', q.repondue_a]])}</div>
    <div class="an-sec"><h4>Les scènes <small>${a.scenes.length} scène${a.scenes.length > 1 ? 's' : ''}${rhythm ? `, ${esc(rhythm)}` : ''}</small></h4>
      <ul class="scenes">${a.scenes.map((s) => {
        const th = thumbAt(lo, AN.parseTime(s.debut));
        return `<li>${th ? `<img src="${th}" alt="">` : '<span class="noimg"></span>'}<div>
          <span class="t">${esc(s.debut)}–${esc(s.fin)}</span>${s.role ? `<span class="role ${roleClass(s.role)}">${esc(s.role)}</span>` : ''}
          <p>${esc(s.action)}</p>${s.dialogue ? `<q>${esc(s.dialogue)}</q>` : ''}${s.emotion ? `<small class="muted">Émotion : ${esc(s.emotion)}</small>` : ''}</div></li>`;
      }).join('')}</ul></div>
    <div class="an-sec"><h4>Retournement et fin</h4>${kvRows([['Retournement', a.retournement.description ? `${a.retournement.description}${a.retournement.moment ? ` (${a.retournement.moment})` : ''}` : 'Pas de retournement.'], ['Fin', a.fin]])}</div>
    ${a.personnages.length || a.decors.length ? `<div class="an-sec"><h4>Personnages et décors</h4>
      <div class="cast">${a.personnages.map((p) => `<div><b>${esc(p.nom || p.fruit)}</b>${esc([p.fruit, p.role].filter(Boolean).join(', '))}${p.look ? `<br><span class="muted">${esc(p.look)}</span>` : ''}</div>`).join('')}</div>
      ${a.decors.length ? `<p style="margin-top:10px"><b>Décors :</b> ${esc(a.decors.join(', '))}</p>` : ''}</div>` : ''}
    <div class="an-sec"><h4>Ce qui retient les gens</h4>${list(a.retention)}
      <div style="margin-top:10px">${kvRows([['Voix', a.audio.voix], ['Musique', a.audio.musique], ['Effets', a.audio.effets], ['Texte à l\'écran', a.texte_ecran], ['Rythme', rhythm]])}</div></div>
    <div class="an-sec"><h4>Pourquoi ça marche</h4>${list(a.pourquoi_ca_marche)}</div>
    <div class="an-sec"><h4>Points faibles</h4>${list(a.points_faibles)}</div>
    <div class="an-sec"><h4>Idées pour ton compte</h4>${list(a.idees_pour_toi)}</div>
    ${transcript}${foot}`;
}

function wireAnalysis(x, an) {
  const on = (id, fn) => { const el = $('#' + id); if (el) el.onclick = fn; };
  on('anAI', () => runAnalysis(x, true));
  on('anLocal', () => runAnalysis(x, false));
  on('anKey', () => openSettings('sGemini'));
  on('anDownload', (e) => download(x.v, e.currentTarget));
  on('anPrompt', () => copy(AN.buildPrompt({ v: x.v, m: x.m, local: an && an.local, brief: settings.accountBrief, external: true }), 'Prompt copié : colle-le dans Grok ou ChatGPT avec la vidéo'));
  on('anCopy', () => copy(AN.analysisToMarkdown(an, x.v), 'Analyse copiée'));
}

function jobHtml() {
  return `<div class="an-sec"><h4>${job.ai ? 'Analyse complète en cours' : 'Découpage en cours'}</h4>
    <ul class="an-steps">${job.steps.map((s) => `<li class="${s.state}"><span class="st">${s.state === 'done' ? '✓' : ''}</span>${esc(s.label)}${s.state === 'on' && job.detail ? ` <span class="muted">${esc(job.detail)}</span>` : ''}</li>`).join('')}</ul>
    ${job.error ? `<p class="an-err">${esc(job.error)}</p><div class="an-actions"><button class="btn small" id="jobRetry" type="button">Réessayer</button><button class="btn small ghost" id="jobClose" type="button">Fermer</button></div>` : '<p class="muted">Tu peux fermer la fiche, l\'analyse continue.</p>'}</div>`;
}
function wireJob(x) {
  const r = $('#jobRetry'), c = $('#jobClose');
  if (r) r.onclick = () => { const ai = job.ai; job = null; runAnalysis(x, ai); };
  if (c) c.onclick = () => { job = null; renderTab(); };
}
function jobStep(k, detail) {
  if (!job) return;
  let reached = false;
  for (const s of job.steps) { if (s.k === k) { s.state = 'on'; reached = true; } else if (!reached) s.state = 'done'; }
  job.detail = detail || '';
  refreshJobView();
}
function refreshJobView() {
  if (job && drawerId === job.id && drawerTab === 'analyse') { $('#tabBody').innerHTML = jobHtml(); wireJob(byId.get(job.id)); }
}

async function fetchVideoBlob(url) {
  const res = await fetch(url, { credentials: 'include' });
  const ct = res.headers.get('content-type') || '';
  if (!res.ok || ct.includes('html')) throw new Error('TikTok a refusé le téléchargement de la vidéo');
  const blob = await res.blob();
  if (blob.size < 20000) throw new Error('fichier vidéo vide');
  return blob.type ? blob : new Blob([blob], { type: 'video/mp4' });
}
async function fetchTranscript(subs) {
  if (!subs || !subs.length) return [];
  const pickSub = subs.find((s) => /^fr|fra/i.test(s.lang)) || subs.find((s) => /^en|eng/i.test(s.lang)) || subs[0];
  const res = await fetch(pickSub.url, { credentials: 'omit' });
  if (!res.ok) return [];
  return AN.parseVtt(await res.text());
}

async function runAnalysis(x, ai) {
  if (job && !job.error) { toast('Une analyse est déjà en cours'); return; }
  if (ai && !settings.geminiKey) { openSettings('sGemini'); return; }
  if (!(await checkBackground())) { toast('Recharge d\'abord l\'extension : suis le bandeau en haut de la page', 4500); return; }
  const v = x.v;
  job = {
    id: v.id, ai, detail: '', error: null,
    steps: [
      { k: 'video', label: 'Récupération de la vidéo', state: 'on' },
      { k: 'scenes', label: 'Découpage des scènes', state: '' },
      { k: 'subs', label: 'Sous-titres', state: '' },
      ...(ai ? [{ k: 'ai', label: 'Analyse par l\'IA', state: '' }] : [])
    ]
  };
  refreshJobView();
  try {
    const r = await chrome.runtime.sendMessage({ type: 'resolvePlay', id: v.id, url: v.url });
    if (!r || !r.ok || !r.playUrl) throw new Error((r && r.error) || 'lien de la vidéo introuvable');
    const blob = await fetchVideoBlob(r.playUrl);
    jobStep('scenes');
    const local = { duration: r.duration || v.duration || null, scenes: [], transcript: [] };
    try {
      const sc = await AN.detectScenes(blob, { onProgress: (p) => { if (job) { job.detail = `${Math.round(p * 100)} %`; if (Math.round(p * 100) % 10 === 0) refreshJobView(); } } });
      local.duration = sc.duration; local.scenes = sc.scenes;
    } catch (e) { local.scenesError = e.message; }
    jobStep('subs');
    try { local.transcript = await fetchTranscript(r.subtitles); } catch (e) { local.transcript = []; }
    let aiData = null, model = null;
    if (ai) {
      jobStep('ai');
      const res = await AN.geminiAnalyze({
        key: settings.geminiKey, model: settings.geminiModel, blob,
        prompt: AN.buildPrompt({ v, m: x.m, local, brief: settings.accountBrief }),
        onStep: (t) => { if (job) { job.detail = t; refreshJobView(); } }
      });
      aiData = res.data; model = res.model;
    }
    const prev = await DB.getAnalysis(v.id).catch(() => null);
    await DB.putAnalysis({ id: v.id, at: Date.now(), local, ai: aiData || (prev && prev.ai) || null, model: model || (prev && prev.model) || null });
    analyzed.add(v.id);
    job = null;
    toast(ai ? 'Analyse terminée' : 'Découpage terminé');
    if (drawerId === v.id) renderDrawer(); else render();
  } catch (e) {
    const msg = friendlyError(e);
    if (job) { job.error = msg; refreshJobView(); }
    toast('Analyse impossible : ' + msg, 4500);
  }
}
function friendlyError(e) {
  const m = (e && e.message) || String(e);
  if (/requested version|less than the existing version|versionerror/i.test(m)) {
    showReloadBanner();
    return 'L\'extension doit être rechargée pour finir la mise à jour : suis le bandeau en haut de la page.';
  }
  if (/failed to fetch|networkerror|load failed/i.test(m)) return 'Connexion impossible (TikTok ou Google). Vérifie ta connexion internet, puis réessaie.';
  return m;
}

/* L'arrière-plan tourne-t-il avec le même code que cette page ? */
async function checkBackground() {
  const ask = async () => { try { return await chrome.runtime.sendMessage({ type: 'hello' }); } catch (e) { return null; } };
  let r = await ask();
  if (!r) { await new Promise((ok) => setTimeout(ok, 900)); r = await ask(); } // service worker lent à démarrer
  if (r && r.rev === CODE_REV) return true;
  showReloadBanner();
  return false;
}
function showReloadBanner() {
  const b = $('#reloadBanner');
  if (!b) return;
  b.hidden = false;
  window.scrollTo({ top: 0 });
}
async function reloadExtension() {
  // Le dashboard se rouvrira tout seul quand l'extension aura été rechargée (dans les 30 min)
  try { await chrome.storage.local.set({ reopenDashboard: Date.now() }); } catch (e) {}
  chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id });
  toast('Clique sur la flèche ↻ en haut à droite, à côté de FruitRadar', 9000);
}

/* ---------------- comparaison avec ton compte ---------------- */
function renderCompareTab(x) {
  const box = $('#tabBody');
  const accts = (settings.myAccounts || []).map(normAccount).filter(Boolean);
  const mine = mineEntries().filter((e) => e.v.id !== x.v.id);
  if (!accts.length || !mine.length) {
    box.innerHTML = `<div class="empty"><h3>${accts.length ? 'Il me faut d\'abord tes vidéos' : 'Ajoute ton compte'}</h3>
      <p>${accts.length ? `Aucune vidéo de @${esc(accts[0])} dans le radar pour l'instant. Récupère-les (une seule page TikTok chargée), puis reviens ici.` : 'Indique ton compte TikTok dans Réglages pour comparer cette vidéo avec les tiennes.'}</p>
      <div class="row">${accts.length ? `<button class="btn primary" type="button" data-action="scanMine">${icon('download')}Récupérer mes vidéos</button>` : `<button class="btn primary" type="button" data-action="settings">${icon('gear')}Ajouter mon compte</button>`}
      <button class="btn" type="button" data-guide="g-compare">${icon('help')}Comment ça marche</button></div></div>`;
    return;
  }
  const { v, m } = x;
  const per1k = (e, k) => (e.m.views ? (e.m[k] / e.m.views) * 1000 : null);
  const hourOf = (e) => (e.v.createTime ? new Date(e.v.createTime * 1000).getHours() : null);
  const med = (f) => median(mine.map(f).filter((val) => val !== null && val !== undefined && Number.isFinite(val)));
  const best = (f) => { const vals = mine.map(f).filter((val) => val !== null && Number.isFinite(val)); return vals.length ? Math.max(...vals) : null; };
  const f1 = (n) => (n === null || n === undefined || !Number.isFinite(n) ? '—' : n.toFixed(n < 10 ? 1 : 0).replace('.', ','));
  const rows = [
    ['Vues', (e) => e.m.views, fmtNum],
    ['Likes', (e) => e.m.likes, fmtNum],
    ['Vues pour son âge', (e) => e.m.perfAge, fmtMult],
    ['Vitesse actuelle', (e) => e.m.rateNow, (n) => (n === null ? '—' : fmtNum(n) + '/h')],
    ['Engagement', (e) => e.m.engagement, (n) => fmtPct(n)],
    ['Partages pour 1 000 vues', (e) => per1k(e, 'shares'), f1],
    ['Enregistrements pour 1 000 vues', (e) => per1k(e, 'saves'), f1],
    ['Commentaires pour 1 000 vues', (e) => per1k(e, 'comments'), f1],
    ['Durée', (e) => e.v.duration ?? null, fmtDur, 'dur'],
    ['Heure de publication', hourOf, (n) => (n === null ? '—' : `${Math.round(n)} h`), 'hour'],
    ['Nombre de hashtags', (e) => (e.v.hashtags || []).length, (n) => (n === null ? '—' : String(Math.round(n))), 'plain']
  ];
  const gapCell = (a, b, kind) => {
    if (a === null || b === null || !Number.isFinite(a) || !Number.isFinite(b)) return '<td>—</td>';
    if (kind === 'dur') return `<td class="gap">${a < b ? 'plus courte' : a > b ? 'plus longue' : 'pareil'}</td>`;
    if (kind === 'hour' || kind === 'plain') { const dlt = Math.round(a - b); return `<td class="gap">${dlt === 0 ? 'pareil' : (dlt > 0 ? '+' : '') + dlt + (kind === 'hour' ? ' h' : '')}</td>`; }
    if (!b) return '<td>—</td>';
    const r = a / b;
    return r >= 1 ? `<td class="gap up">${fmtMult(r)} plus</td>` : `<td class="gap down">${fmtMult(1 / r)} moins</td>`;
  };
  const table = `<table class="cmp"><thead><tr><th>Critère</th><th>Cette vidéo</th><th>Ta médiane</th><th>Ta meilleure</th><th>Écart</th></tr></thead><tbody>
    ${rows.map(([label, f, fmt, kind]) => {
      const a = f(x), b = med(f), c = kind === 'hour' || kind === 'dur' || kind === 'plain' ? null : best(f);
      return `<tr><td>${label}</td><td><b>${fmt(a)}</b></td><td class="me">${fmt(b)}</td><td class="me">${c === null ? '—' : fmt(c)}</td>${gapCell(a, b, kind)}</tr>`;
    }).join('')}</tbody></table>`;

  // phrases simples
  const ins = [], you = [];
  const ratio = (a, b) => (a && b ? a / b : null);
  const rv = ratio(m.views, med((e) => e.m.views));
  if (rv !== null) (rv >= 1 ? ins : you).push(rv >= 1 ? `Elle fait ${fmtMult(rv)} les vues de ta vidéo médiane (${fmtNum(m.views)} contre ${fmtNum(med((e) => e.m.views))}).` : `Elle fait moins de vues que ta vidéo médiane (${fmtNum(m.views)} contre ${fmtNum(med((e) => e.m.views))}).`);
  const ra = ratio(m.perfAge, med((e) => e.m.perfAge));
  if (ra !== null && ra >= 2) ins.push(`Pour son âge, elle part ${fmtMult(ra)} plus fort que tes vidéos.`);
  [['shares', 'Les gens la partagent', 'c\'est le genre d\'histoire qu\'on envoie à quelqu\'un'], ['saves', 'Elle est enregistrée', 'les gens veulent la garder ou la revoir'], ['comments', 'Elle fait commenter', 'la fin ou le sujet fait réagir']].forEach(([k, start, why]) => {
    const a = per1k(x, k), b = med((e) => per1k(e, k));
    const r = ratio(a, b);
    if (r !== null && r >= 1.5) ins.push(`${start} ${fmtMult(r)} plus que tes vidéos (${f1(a)} pour 1 000 vues contre ${f1(b)}) : ${why}.`);
    else if (r !== null && r <= 0.67) you.push(`Sur ${k === 'shares' ? 'les partages' : k === 'saves' ? 'les enregistrements' : 'les commentaires'}, tes vidéos font mieux (${f1(b)} pour 1 000 vues contre ${f1(a)}).`);
  });
  const md = med((e) => e.v.duration ?? null);
  if (v.duration && md && Math.abs(v.duration - md) / md >= 0.3) ins.push(`Elle est ${v.duration < md ? 'plus courte' : 'plus longue'} : ${fmtDur(v.duration)} contre ${fmtDur(md)} en général chez toi.`);
  const hv = hourOf(x), hm = med(hourOf);
  if (hv !== null && hm !== null) { const dh = Math.min(Math.abs(hv - hm), 24 - Math.abs(hv - hm)); if (dh >= 3) ins.push(`Elle a été postée vers ${hv} h ; toi, tu postes plutôt vers ${Math.round(hm)} h.`); }
  const re = ratio(m.engagement, med((e) => e.m.engagement));
  if (re !== null && re <= 0.8 && rv !== null && rv >= 1) you.push(`Ton engagement est meilleur (${fmtPct(med((e) => e.m.engagement))} contre ${fmtPct(m.engagement)}) : ton public accroche, c'est la portée qui manque.`);
  const myTags = new Set(mine.flatMap((e) => e.v.hashtags || []));
  const newTags = (v.hashtags || []).filter((t) => !myTags.has(t) && !TAG_STOP.has(t)).slice(0, 8);
  if (newTags.length) ins.push(`Hashtags qu'elle utilise et pas toi : ${newTags.map((t) => '#' + t).join(' ')}.`);
  const bestMine = [...mine].sort((a, b) => b.m.views - a.m.views)[0];

  box.innerHTML = `<div class="box"><h4>Face à tes ${mine.length} vidéo${mine.length > 1 ? 's' : ''} <button class="btn small ghost" type="button" data-action="scanMine">${icon('refresh')}Mettre à jour mes vidéos</button></h4>
      <p>Médiane = ta vidéo typique. Meilleure = ton record sur ce critère.</p>${table}</div>
    <div class="box"><h4>Ce qu'elle fait mieux que toi</h4>${ins.length ? `<ul class="insights">${ins.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>` : '<p class="muted">Pas de grosse différence avec tes vidéos.</p>'}</div>
    ${you.length ? `<div class="box"><h4>Là où tu fais mieux</h4><ul class="insights">${you.map((t) => `<li class="you">${esc(t)}</li>`).join('')}</ul></div>` : ''}
    ${bestMine ? `<div class="box"><h4>Ta meilleure vidéo pour comparer</h4><p>${esc(bestMine.v.desc || 'Sans description')}</p>
      <p><b>${fmtNum(bestMine.m.views)}</b> vues, <b>${fmtNum(bestMine.m.likes)}</b> likes, score ${bestMine.m.score}.</p>
      <button class="btn small" type="button" data-open="${esc(bestMine.v.id)}">Ouvrir sa fiche</button></div>` : ''}
    ${analyzed.has(v.id) ? '' : `<p class="note muted">Pour comparer aussi le hook et l'histoire, lance l'analyse de cette vidéo (onglet Analyse).</p>`}`;
}

/* ---------------- fenêtre avant un scan manuel ---------------- */
// Le compte qui scanne se choisit ici, au lancement (plus à la création du compte). Rien de choisi encore : le compte de publication, le plus simple.
async function openScanDialog() {
  const st = await chrome.storage.local.get(['scanHistory', 'tiktokSession', 'pauseUntil', 'scanState']);
  if (st.scanState && st.scanState.running) { toast('Un scan est déjà en cours'); return; }
  let breadth = settings.breadth;
  const declared = normAccount(settings.scanAccount || '');
  const who = { same: !declared, scan: declared };
  const chosen = () => ({ ...settings, scanAccount: who.same ? '' : who.scan, scanSame: who.same });
  $('#riskBody').innerHTML = `<div id="riskTop"></div>
    <div class="scanwho"><h3 id="scanWhoTitle">Avec quel compte scanner ?</h3>
      <div class="scanwho-cartes" role="radiogroup" aria-labelledby="scanWhoTitle">
        <label class="wchoix"><input type="radio" name="scanWho" value="same"${who.same ? ' checked' : ''}><span><b>Mon compte de publication</b><small>Le plus simple : rien à changer.</small></span></label>
        <label class="wchoix"><input type="radio" name="scanWho" value="other"${who.same ? '' : ' checked'}><span><b>Un 2e compte, juste pour scanner</b><small>Le plus sûr : ton compte principal n'est jamais en jeu.</small></span></label>
      </div>
      <label class="scanwho-nom"><input id="scanWhoName" placeholder="nom du 2e compte TikTok" autocomplete="off" spellcheck="false" value="${esc(who.scan)}" aria-label="Nom du 2e compte TikTok">
        <small>Connecte-toi à ce compte dans TikTok avant de lancer. Pour publier, repasse sur ton compte principal.</small>
        <small class="warn" id="scanWhoErr" hidden>Écris le nom du 2e compte, ou choisis « Mon compte de publication ».</small></label>
    </div>
    <div id="riskInfo"></div>`;
  const draw = () => {
    const plan = planFor(settings, breadth);
    const risk = scanRisk({ history: st.scanHistory || [], session: st.tiktokSession, settings: chosen(), plan, pauseUntil: st.pauseUntil });
    const lvl = $('#riskLevel');
    lvl.className = 'risk l' + risk.level;
    lvl.textContent = 'Risque ' + risk.label.toLowerCase();
    $('#riskTop').innerHTML = `
      <div class="riskplan"><p>Une fenêtre TikTok réduite va s'ouvrir pendant environ <b>${plan.minutes} min</b> : ${plan.pages} pages (${plan.queries.length} recherches${plan.mine.length ? ', ton compte' : ''}${plan.tags ? `, ${plan.tags} hashtags découverts` : ''}${plan.accounts ? `, ${plan.accounts} comptes découverts` : ''}), puis jusqu'à ${plan.refresh} vidéos relues.</p></div>
      <div class="breadth" role="radiogroup" aria-label="Étendue de ce scan">${Object.values(BREADTH).map((b) => `<label><input type="radio" name="rb" value="${b.key}"${b.key === breadth ? ' checked' : ''}><b>${b.label}</b><small>${esc(b.desc)}</small></label>`).join('')}</div>`;
    $('#riskInfo').innerHTML = `
      <div><h3>Les risques</h3><ul class="plain">
        <li>TikTok n'autorise pas la collecte automatique dans ses conditions d'utilisation.</li>
        <li>S'il remarque les scans, il affiche surtout des captchas ou bloque les recherches un moment. Un compte banni reste possible, mais c'est rare, surtout en suivant les conseils.</li></ul></div>
      <div><h3>Ta situation</h3><ul class="risklist">${risk.items.map((it) => `<li class="${it.ok === true ? 'ok' : it.ok === false ? 'no' : 'unk'}"><span class="mk">${it.ok === true ? '✓' : it.ok === false ? '!' : '?'}</span><span>${esc(it.text)}</span></li>`).join('')}</ul></div>
      <div><h3>Conseils</h3><ul class="plain"><li>Un scan manuel par jour au maximum, en plus des scans auto.</li><li>Si un captcha apparaît, arrête 24 à 48 h.</li></ul></div>`;
    $('#riskGo').textContent = risk.level === 2 ? 'Lancer quand même' : 'Lancer le scan';
    $('#riskGo').className = risk.level === 2 ? 'btn danger' : 'btn primary';
    $$('#riskTop input[name=rb]').forEach((r) => r.addEventListener('change', () => { breadth = r.value; draw(); }));
  };
  $$('#riskBody input[name=scanWho]').forEach((r) => r.addEventListener('change', () => {
    if (!r.checked) return;
    who.same = r.value === 'same'; $('#scanWhoErr').hidden = true;
    if (!who.same) $('#scanWhoName').focus();
    draw();
  }));
  $('#scanWhoName').addEventListener('change', () => { who.scan = normAccount($('#scanWhoName').value); if (who.scan) $('#scanWhoErr').hidden = true; draw(); });
  $('#scanWhoName').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#scanWhoName').dispatchEvent(new Event('change')); } }); // Entrée ne doit pas déclencher « Annuler » (premier bouton du formulaire)
  draw();
  const dlg = $('#riskDlg');
  $('#riskGo').onclick = (e) => { // un 2e compte sans nom : FruitRadar ne pourrait pas vérifier le compte connecté
    who.scan = normAccount($('#scanWhoName').value);
    if (!who.same && !who.scan) { e.preventDefault(); $('#scanWhoErr').hidden = false; $('#scanWhoName').focus(); }
  };
  dlg.onclose = async () => {
    if (dlg.returnValue !== 'go') return;
    try { // le choix est gardé : il sert aux prochains scans, auto compris (modifiable dans Réglages, « Mon compte »)
      const patch = { scan: who.same ? '' : who.scan, scanSame: who.same };
      if (await getAccount().catch(() => null)) await saveAccount(patch);
      else settings = await saveSettings({ scanAccount: patch.scan, scanSame: patch.scanSame });
      await chrome.storage.local.set({ scanAck: Date.now() }); // la fenêtre des risques a été vue : les scans auto peuvent tourner
    } catch (e) { /* le scan part quand même */ }
    chrome.runtime.sendMessage({ type: 'scanNow', breadth });
    toast('Scan lancé : une fenêtre TikTok réduite s\'ouvre');
  };
  dlg.returnValue = '';
  dlg.showModal();
}

/* ---------------- guide ---------------- */
function openGuide(section) {
  $$('dialog[open]:not(#licGate):not(#updDlg)').forEach((d) => d.close()); // jamais l'écran de clé : le guide du premier lancement le refermait
  const g = $('#guide');
  g.hidden = false;
  document.body.style.overflow = 'hidden';
  const target = section && document.getElementById(section);
  const body = $('#guideBody');
  requestAnimationFrame(() => {
    body.scrollTop = target ? target.offsetTop - 16 : 0;
    markGuideNav();
    $('#guideClose').focus({ preventScroll: true });
  });
}
function closeGuide() { $('#guide').hidden = true; document.body.style.overflow = ''; }
function markGuideNav() {
  const body = $('#guideBody');
  let cur = null;
  $$('#guideBody section').forEach((s) => { if (s.offsetTop - 60 <= body.scrollTop) cur = s.id; });
  $$('.guide-nav a').forEach((a) => a.classList.toggle('on', a.getAttribute('href') === '#' + (cur || 'g-start')));
}

/* ---------------- réglages ---------------- */
function renderBreadthOptions() {
  $('#sBreadth').innerHTML = Object.values(BREADTH).map((b) => {
    const p = planFor(settings, b.key);
    return `<label><input type="radio" name="sb" value="${b.key}"${b.key === settings.breadth ? ' checked' : ''}><b>${b.label}</b><small>${esc(b.desc)} Environ ${p.minutes} min par scan.</small></label>`;
  }).join('');
}
function showPane(name) {
  if (!$(`.set-pane[data-pane="${name}"]`) || (name === 'avance' && !IS_ADMIN)) name = 'compte';
  $$('.set-tab').forEach((b) => { const on = b.dataset.pane === name; b.classList.toggle('on', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); });
  $$('.set-pane').forEach((p) => { p.hidden = p.dataset.pane !== name; });
  $('#setBody').scrollTop = 0;
}
function openSettings(focusId, pane) {
  $$('dialog[open]:not(#licGate):not(#updDlg)').forEach((d) => d.close()); // jamais l'écran de clé : le guide du premier lancement le refermait
  renderBreadthOptions();
  $('#sQueries').value = (settings.queries || []).join('\n');
  $('#sTimes').value = (settings.scanTimes || []).join(', ');
  $('#sWindow').value = settings.windowMode;
  $('#sRefreshAge').value = settings.refreshMaxAgeDays;
  $('#sAuto').checked = settings.autoScan;
  $('#sPassive').checked = settings.passiveCapture;
  $('#sNotify').checked = settings.notify;
  $('#sGemini').value = settings.geminiKey || '';
  const sel = $('#sModel');
  if (settings.geminiModel && ![...sel.options].some((o) => o.value === settings.geminiModel)) sel.insertAdjacentHTML('beforeend', `<option value="${esc(settings.geminiModel)}">${esc(settings.geminiModel)}</option>`);
  sel.value = settings.geminiModel || '';
  $('#sGeminiStatus').textContent = settings.geminiKey ? 'Clé enregistrée.' : 'Pas encore de clé.';
  $('#sGeminiStatus').className = 'status-line';
  $('#sBrief').value = settings.accountBrief || '';
  SHELL.fillSettings(settings);
  $('#sBlocked').value = (settings.blockedAccounts || []).join(', ');
  $('#sBoost').value = (settings.boostKeywords || []).join('\n');
  $('#sBlock').value = (settings.blockKeywords || []).join('\n');
  AUTO.fillSettingsForm();
  const target = focusId && $('#' + focusId);
  showPane(pane || (target && target.closest('.set-pane') ? target.closest('.set-pane').dataset.pane : 'compte'));
  $('#settingsDlg').showModal();
  if (target && target.type !== 'hidden') setTimeout(() => { target.focus(); target.scrollIntoView({ block: 'center' }); }, 50);
}
const lines = (s) => s.split(/\n/).map((x) => x.trim()).filter(Boolean);
const csvList = (s) => s.split(/[,;\s]+/).map((x) => x.trim().replace(/^@/, '')).filter(Boolean);
async function saveSettingsFromForm() {
  const times = csvList($('#sTimes').value).filter((t) => /^\d{1,2}(:\d{2})?$/.test(t)).map((t) => { const [h, mm = '00'] = t.split(':'); return `${h.padStart(2, '0')}:${mm}`; });
  const br = ($('#sBreadth input[name=sb]:checked') || {}).value || settings.breadth;
  settings = await saveSettings({
    breadth: br,
    queries: lines($('#sQueries').value),
    scanTimes: times.length ? times : DEFAULTS.scanTimes,
    windowMode: $('#sWindow').value,
    refreshMaxAgeDays: Number($('#sRefreshAge').value) || 10,
    autoScan: $('#sAuto').checked,
    passiveCapture: $('#sPassive').checked,
    notify: $('#sNotify').checked,
    geminiKey: $('#sGemini').value.trim(),
    geminiModel: $('#sModel').value,
    accountBrief: $('#sBrief').value.trim(),
    myAccounts: csvList($('#sMine').value),
    blockedAccounts: csvList($('#sBlocked').value),
    boostKeywords: lines($('#sBoost').value).map((k) => k.toLowerCase()),
    blockKeywords: lines($('#sBlock').value).map((k) => k.toLowerCase())
  });
  await AUTO.saveSettingsForm();
  await SHELL.saveSettings();
  settings = await getSettings();
  toast('Réglages enregistrés');
  if (page === 'home') SHELL.renderHome();
  loadData();
}
async function testKey() {
  const key = $('#sGemini').value.trim();
  const st = $('#sGeminiStatus');
  if (!key) { st.textContent = 'Colle d\'abord ta clé.'; st.className = 'status-line no'; return; }
  st.textContent = 'Test en cours…'; st.className = 'status-line';
  try {
    const r = await AN.testGeminiKey(key);
    const sel = $('#sModel');
    const flash = r.models.filter((n) => /flash/.test(n));
    sel.innerHTML = `<option value="">Automatique (${esc(r.best)})</option>` + flash.map((n) => `<option value="${esc(n)}">${esc(n)}</option>`).join('');
    st.textContent = `Clé valide. Modèle utilisé : ${r.best}. Pense à enregistrer.`;
    st.className = 'status-line ok';
  } catch (e) {
    st.textContent = e.message; st.className = 'status-line no';
  }
}

/* ---------------- navigation (menu de gauche) ---------------- */
const VIEWS = { home: 'viewHome', radar: 'viewRadar', auto: 'viewAuto', prods: 'viewProds', chars: 'viewChars', trash: 'viewTrash', support: 'viewSupport', retours: 'viewRetours', cles: 'viewCles', stats: 'viewStats', promo: 'viewPromo' };
/* « Gestion » (édition de l'auteur) : Clés, Stats, Promo et Retours réunis sous une seule entrée du menu, avec une barre d'onglets en haut */
const GESTION = [['cles', 'Clés', 'key'], ['stats', 'Stats', 'chart'], ['promo', 'Promo', 'sparkle'], ['retours', 'Retours', 'comment']];
const gestionOk = (k) => IS_ADMIN && (k === 'retours' || (k === 'cles' && KEYS) || (k === 'stats' && STATS) || (k === 'promo' && PROMO));
let gestionLast = 'cles';
function paintGestionBar(name) {
  const bar = $('#gestionBar'); if (!bar) return;
  const subs = GESTION.filter(([k]) => gestionOk(k));
  bar.hidden = !subs.some(([k]) => k === name);
  if (bar.hidden) return;
  const n = $('#navRetours'), count = n && !n.hidden ? n.textContent : '';
  bar.innerHTML = `<div class="ptabs">${subs.map(([k, l, ic]) => `<button type="button" data-go="${k}" class="${k === name ? 'on' : ''}"${k === name ? ' aria-current="page"' : ''}>${icon(ic)}${esc(l)}${k === 'retours' && count ? `<small>${esc(count)}</small>` : ''}</button>`).join('')}</div>`;
}
let page = 'home';
function showView(name, { push = true } = {}) {
  if (name === 'gestion') name = gestionOk(gestionLast) ? gestionLast : (GESTION.map(([k]) => k).find(gestionOk) || 'home');
  if (!VIEWS[name] || (name === 'support' && IS_ADMIN) || (GESTION.some(([k]) => k === name) && !gestionOk(name))) name = 'home'; // Support : version vendue · Gestion (Clés, Stats, Promo, Retours) : édition de l'auteur
  page = name;
  const enGestion = GESTION.some(([k]) => k === name);
  if (enGestion) gestionLast = name;
  Object.entries(VIEWS).forEach(([k, id]) => { $('#' + id).hidden = k !== name; });
  $$('#sidenav [data-go]').forEach((b) => { const on = b.dataset.go === name || (b.dataset.go === 'gestion' && enGestion); b.classList.toggle('on', on); if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
  paintGestionBar(name);
  if (push) { try { history.replaceState(null, '', name === 'home' ? location.pathname + location.search : '#' + name); } catch (e) {} }
  document.title = { home: 'FruitRadar', radar: 'Radar — FruitRadar', auto: 'Automatisation — FruitRadar', prods: 'Mes productions — FruitRadar', chars: 'Personnages — FruitRadar', trash: 'Corbeille — FruitRadar', support: 'Support — FruitRadar', retours: 'Retours — FruitRadar', cles: 'Clés — FruitRadar', stats: 'Stats — FruitRadar', promo: 'Promo — FruitRadar' }[name];
  if (name !== 'radar') { if ($('#drawer').classList.contains('open')) closeDrawer(); if (name === 'home') SHELL.renderHome(); else if (name === 'support' || name === 'retours') LICUI.render(name); else if (name === 'cles') KEYS.render(); else if (name === 'stats') STATS.render(); else if (name === 'promo') PROMO.render(); else AUTO.render(name); window.scrollTo({ top: 0 }); }
}
function reproduce(id) {
  const x = byId.get(id);
  if (!x) return;
  AUTO.startRemake(x);
  if ($('#drawer').classList.contains('open')) closeDrawer();
  showView('auto');
}

/* ---------------- actions ---------------- */
let toastT = null;
function toast(msg, ms = 2800) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), ms);
}
/* Demande de confirmation dans la page. Jamais « confirm() » : une boîte native de Chrome fige TOUTES les pages de FruitRadar
   (tableau de bord et fenêtre d'automatisation) tant qu'on n'y a pas répondu, même si elle est cachée derrière une autre fenêtre. */
let askSeq = 0;
function ask(title, { text = '', ok = 'Confirmer', cancel = 'Annuler', danger = false, input = null } = {}) {
  return new Promise((res) => {
    let d = $('#askDlg');
    if (!d) { d = document.createElement('dialog'); d.id = 'askDlg'; d.className = 'askdlg'; d.setAttribute('aria-labelledby', 'askTitle'); document.body.appendChild(d); }
    const n = ++askSeq; let settled = false;
    const end = (v) => { if (settled) return; settled = true; const f = d.querySelector('#askInput'); res(input ? (v && f ? f.value.trim() : '') : v); if (n === askSeq && d.open) d.close(); };
    if (d.__end) d.__end(false); // une question à la fois : la précédente est annulée
    d.__end = end;
    d.innerHTML = `<div class="dlg"><h2 id="askTitle">${esc(title)}</h2>${text ? `<p>${esc(text)}</p>` : ''}${input ? `<input id="askInput" type="text" maxlength="${Number(input.max) || 80}" placeholder="${esc(input.placeholder || '')}" aria-labelledby="askTitle">` : ''}<div class="dlg-actions"><span class="spacer"></span><button class="btn ghost" type="button" data-ask="no">${esc(cancel)}</button><button class="btn ${danger ? 'solid-danger' : 'primary'}" type="button" data-ask="yes">${esc(ok)}</button></div></div>`;
    d.querySelector('[data-ask=yes]').onclick = () => end(true);
    d.querySelector('[data-ask=no]').onclick = () => end(false);
    d.oncancel = () => end(false);                                   // touche Échap
    d.onclose = () => { if (!d.open && n === askSeq) end(false); };  // refermée par autre chose (guide, réglages) ; une fermeture d'avant, arrivée en retard, est ignorée
    if (!d.open) d.showModal();
    const field = d.querySelector('#askInput');
    if (field) { field.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); end(true); } }; field.focus(); }
    else d.querySelector(danger ? '[data-ask=no]' : '[data-ask=yes]').focus();
  });
}
async function copy(text, msg) {
  try { await navigator.clipboard.writeText(text); toast(msg); } catch (e) { toast('Copie impossible'); }
}

async function download(v, btn) {
  const label = btn ? btn.innerHTML : '';
  if (btn) { btn.disabled = true; btn.textContent = 'Préparation…'; }
  const name = `FruitRadar/${(v.author.uniqueId || 'tiktok').replace(/[^\w.-]/g, '_')}_${v.id}.mp4`;
  try {
    const r = await chrome.runtime.sendMessage({ type: 'resolvePlay', id: v.id, url: v.url });
    if (!r || !r.ok || !r.playUrl) throw new Error((r && r.error) || 'lien introuvable');
    let done = false;
    try {
      const blob = await fetchVideoBlob(r.playUrl);
      const url = URL.createObjectURL(blob);
      await chrome.downloads.download({ url, filename: name, saveAs: false });
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      done = true;
    } catch (e) { /* méthode directe */ }
    if (!done) await chrome.downloads.download({ url: r.playUrl, filename: name, saveAs: false });
    toast('Téléchargement lancé (dossier Téléchargements/FruitRadar)');
  } catch (e) {
    toast('Téléchargement impossible : ' + e.message + '. J\'ouvre la vidéo.', 4000);
    chrome.tabs.create({ url: v.url });
  } finally {
    if (btn) { btn.disabled = false; btn.innerHTML = label; }
  }
}

function exportCsv() {
  const lst = sortList(baseFiltered().filter(ELIGIBLE[mode]));
  const head = ['rang', 'score', 'url', 'compte', 'abonnes', 'description', 'hashtags', 'vues', 'likes', 'vitesse_vues_h', 'vitesse_type', 'vues_h_moyenne', 'vues_24h', 'x_pour_son_age', 'x_vs_compte', 'commentaires', 'partages', 'enregistrements', 'engagement_pct', 'duree_s', 'publiee_le', 'age_h', 'langue', 'son', 'fruit_ia'];
  const q = (s) => '"' + String(s ?? '').replace(/"/g, '""') + '"';
  const n2 = (n, d = 2) => (n === null || n === undefined || !Number.isFinite(n) ? '' : n.toFixed(d).replace('.', ','));
  const rows = lst.map(({ v, m, rel }, i) => [i + 1, m.score, v.url, '@' + v.author.uniqueId, m.followers ?? '', v.desc, (v.hashtags || []).map((h) => '#' + h).join(' '),
    m.views, m.likes, m.rateNow !== null ? Math.round(m.rateNow) : '', m.rateKind || '', m.rateAvg !== null ? Math.round(m.rateAvg) : '', m.gain24 !== null ? Math.round(m.gain24) : '',
    n2(m.perfAge), n2(m.outlier), m.comments, m.shares, m.saves, n2(m.engagement * 100), v.duration ?? '',
    v.createTime ? new Date(v.createTime * 1000).toISOString() : '', n2(m.ageH, 1), v.lang || '', v.music ? v.music.title : '', rel.niche ? 'oui' : 'non'].map(q).join(';'));
  const blob = new Blob(['﻿' + [head.join(';'), ...rows].join('\n')], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({ url, filename: `FruitRadar/${mode}_${new Date().toISOString().slice(0, 10)}.csv`, saveAs: true }).finally(() => setTimeout(() => URL.revokeObjectURL(url), 60000));
}

/* ---------------- progression du scan ---------------- */
function showScanState(s) {
  const running = !!(s && s.running), bar = $('#progress');
  bar.hidden = !running;
  document.documentElement.classList.toggle('scanning', running);
  $('#btnScan').disabled = running;
  $('#btnScan').innerHTML = `${icon('radar')}${running ? 'Scan en cours…' : 'Scanner'}`;
  if (running) {
    const paused = !!s.paused, stopping = !!s.stopping, pausing = !!s.pauseAsked && !paused; // pause demandée : elle prend effet après la page en cours
    bar.classList.toggle('paused', paused && !stopping);
    const pct = s.total ? Math.round((s.done / s.total) * 100) : 0;
    $('#progressFill').style.width = pct + '%';
    $('#progressTitle').textContent = stopping ? 'Arrêt du scan…' : paused ? 'Scan en pause' : 'Scan en cours';
    const where = s.phase === 'actualisation'
      ? `Relevé des chiffres ${s.done}/${s.total} ${s.current || ''}`
      : `${s.trigger === 'ton compte' ? 'Récupération de tes vidéos' : 'Recherche'} ${Math.min(s.done + 1, s.total || 1)}/${s.total || 1} : ${s.current || ''}`;
    $('#progressText').textContent = stopping ? 'La fenêtre TikTok se ferme, ce qui a été trouvé est gardé.' : pausing ? `${where} · pause après cette page` : where;
    const pb = $('#btnScanPause'), sb = $('#btnScanStop');
    pb.hidden = stopping; pb.textContent = paused || pausing ? 'Reprendre' : 'Mettre en pause'; pb.dataset.cmd = paused || pausing ? 'scanResume' : 'scanPause';
    sb.disabled = stopping;
  }
  document.documentElement.style.setProperty('--scanbar-h', running ? `${bar.offsetHeight}px` : '0px');
}

/* ---------------- événements ---------------- */
function bind() {
  const rerender = () => { shown = PAGE; render(); };
  FILTER_IDS.forEach((id) => $('#' + id).addEventListener(id === 'fText' ? 'input' : 'change', rerender));
  $$('.seg button').forEach((b) => b.addEventListener('click', () => {
    view = b.dataset.view; $$('.seg button').forEach((x) => x.classList.toggle('on', x === b)); rerender();
  }));
  $$('.seg button').forEach((x) => x.classList.toggle('on', x.dataset.view === view));
  $('#btnMore').onclick = () => { shown += PAGE; render(); };

  document.addEventListener('click', (e) => {
    const g = e.target.closest('[data-guide]');
    if (g) { e.preventDefault(); return openGuide(g.dataset.guide); }
    const navA = e.target.closest('.guide-nav a');
    if (navA) { e.preventDefault(); const t = document.getElementById(navA.getAttribute('href').slice(1)); if (t) $('#guideBody').scrollTop = t.offsetTop - 16; return; }
    const tabBtnS = e.target.closest('.set-tab');
    if (tabBtnS) return showPane(tabBtnS.dataset.pane);
    const go = e.target.closest('[data-go]');
    if (go) { if (go.dataset.go === 'auto' && go.closest('#sidenav')) AUTO.focusLive(); return showView(go.dataset.go); }
    const rp = e.target.closest('[data-repro]');
    if (rp) return reproduce(rp.dataset.repro);
    const act = e.target.closest('[data-action]');
    if (act) {
      const a = act.dataset.action;
      if (a === 'backHome') { // « Retour à l'accueil », depuis le guide ou les réglages : on referme et on revient au menu principal
        closeGuide(); $$('dialog[open]:not(#licGate):not(#updDlg)').forEach((d) => d.close());
        return showView('home');
      }
      if (a === 'openSettings') return openSettings();
      if (a === 'openAccount') return openSettings(null, 'compte');
      if (a === 'openAbout') return openSettings(null, 'apropos');
      if (a === 'autoSettings') return openSettings('sClaudeUrl');
      if (a === 'ideas') { AUTO.startMode('idees'); return showView('auto'); }
      if (a === 'newVideo') { AUTO.startMode(null); return showView('auto'); }
      if (a === 'scan') return openScanDialog();
      if (a === 'settings') return openSettings('acTiktok');
      if (a === 'showMine') { $('#fMine').value = 'mine'; $('#fAge').value = '0'; closeDrawer(); return rerender(); }
      if (a === 'resume') { chrome.runtime.sendMessage({ type: 'resumeScans' }).then(() => { toast('Scans auto relancés'); renderStatus(); }); return; }
      if (a === 'scanMine') {
        chrome.runtime.sendMessage({ type: 'scanMine' }).then((r) => {
          const site = !!(r && r.ok && SITE && SITE.ready());
          toast(r && r.ok ? `Récupération de tes vidéos : une fenêtre TikTok réduite s'ouvre une minute${site ? ', puis tes chiffres partent sur le site' : ''}` : ((r && r.error) || 'Impossible pour le moment'), site ? 4500 : 2800);
          if (site) SITE.asked();
        });
        return;
      }
    }
    const open = e.target.closest('[data-open]');
    if (open) return openDrawer(open.dataset.open, 'stats');
    const tabBtn = e.target.closest('[data-tab]');
    if (tabBtn) { drawerTab = tabBtn.dataset.tab; return renderTab(); }
    const md = e.target.closest('[data-mode]');
    if (md) { mode = md.dataset.mode; tableSort = null; return rerender(); }
    const card = e.target.closest('[data-id]');
    if (card && $('#list').contains(card)) return openDrawer(card.dataset.id);
    const th = e.target.closest('th[data-sort]');
    if (th) {
      const k = th.dataset.sort;
      const cur = tableSort || { key: MODES[mode].sort, dir: -1 };
      tableSort = cur.key === k ? { key: k, dir: -cur.dir } : { key: k, dir: k === 'author' ? 1 : -1 };
      return render();
    }
    const tag = e.target.closest('[data-tag]');
    if (tag) { const t = tag.dataset.tag; if (activeTags.has(t)) activeTags.delete(t); else activeTags.add(t); return rerender(); }
    const untag = e.target.closest('[data-untag]');
    if (untag) { activeTags.delete(untag.dataset.untag); return rerender(); }
    if (e.target.closest('[data-unaccount]')) { accountFilter = null; return rerender(); }
    const acc = e.target.closest('[data-account]');
    if (acc) { accountFilter = accountFilter === acc.dataset.account ? null : acc.dataset.account; return rerender(); }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (!$('#guide').hidden) return closeGuide();
      if ($('#drawer').classList.contains('open')) return closeDrawer();
    }
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.card[data-id]')) { e.preventDefault(); openDrawer(e.target.dataset.id); }
  });
  $('#guideClose').onclick = closeGuide;
  $('#guideBody').addEventListener('scroll', () => { clearTimeout(window.__gs); window.__gs = setTimeout(markGuideNav, 60); });
  $('#drawerClose').onclick = closeDrawer;
  $('#drawerBackdrop').onclick = closeDrawer;

  $('#btnScan').onclick = openScanDialog;
  $('#btnScanPause').onclick = (e) => { chrome.runtime.sendMessage({ type: e.currentTarget.dataset.cmd || 'scanPause' }).catch(() => null); };
  $('#btnScanStop').onclick = () => { chrome.runtime.sendMessage({ type: 'scanStop' }).then((r) => { if (r && r.ok) toast('Scan arrêté : ce qui a été trouvé est gardé', 4000); }).catch(() => null); };
  $('#btnTheme').onclick = () => {
    const dark = document.documentElement.dataset.theme ? document.documentElement.dataset.theme === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches;
    const next = dark ? 'light' : 'dark';
    try { localStorage.setItem('fr-theme', next); } catch (e) {}
    applyTheme(next);
  };
  $('#btnReloadExt').onclick = reloadExtension;
  $('#btnNewsOk').onclick = () => { try { localStorage.setItem('fr-news-v3', '1'); } catch (e) {} $('#newsBanner').hidden = true; };
  $('#sGeminiTest').onclick = testKey;
  $('#settingsForm').addEventListener('submit', (e) => { if (e.submitter && e.submitter.value === 'save') saveSettingsFromForm(); });
  $('#btnCsv').onclick = exportCsv;
  $('#btnExportJson').onclick = async () => {
    const data = { version: 2, exportedAt: Date.now(), settings: { ...settings, geminiKey: '' }, videos: await DB.getAll(), analyses: await DB.getAllAnalyses().catch(() => []) };
    const url = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
    chrome.downloads.download({ url, filename: `FruitRadar/sauvegarde_${new Date().toISOString().slice(0, 10)}.json`, saveAs: true });
  };
  $('#importJson').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    try {
      const data = JSON.parse(await f.text());
      if (!Array.isArray(data.videos)) throw new Error('format');
      await DB.putRaw(data.videos);
      for (const a of data.analyses || []) await DB.putAnalysis(a);
      toast(`${data.videos.length} vidéos restaurées`); loadData();
    } catch (err) { toast('Fichier invalide'); }
  };
  $('#btnWipe').onclick = async () => {
    if (!(await ask('Supprimer toutes les vidéos et analyses enregistrées ?', { text: 'Les réglages sont gardés.', ok: 'Supprimer', danger: true }))) return;
    await DB.clearAll(); toast('Base vidée'); loadData();
  };

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.scanState) {
      showScanState(ch.scanState.newValue);
      clearTimeout(window.__frReload); window.__frReload = setTimeout(loadData, 800);
    }
    if (ch.settings) { settings = { ...DEFAULTS, ...ch.settings.newValue }; renderStatus(); }
    if (ch.pauseUntil || ch.lastScanReport) renderStatus();
  });
}

/* ---------------- démarrage ---------------- */
async function checkPermissions() {
  const origins = (chrome.runtime.getManifest().host_permissions || []).filter((o) => /tiktok/.test(o));
  if (!origins.length || !chrome.permissions) return;
  let ok = true;
  try { ok = await chrome.permissions.contains({ origins }); } catch (e) { ok = true; }
  $('#permBanner').hidden = ok;
  $('#btnGrant').onclick = async () => {
    try {
      const granted = await chrome.permissions.request({ origins });
      $('#permBanner').hidden = granted;
      toast(granted ? 'Accès TikTok accordé, recharge tes onglets TikTok' : 'Accès refusé : l\'extension ne pourra rien capter');
    } catch (e) { toast('Erreur : ' + e.message); }
  };
}

(async function init() {
  hydrateIcons();
  applyTheme(currentTheme());
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => applyTheme(currentTheme()));
  settings = await getSettings();
  checkPermissions();
  checkBackground();
  loadFilters();
  bind();
  const helpers = { $, $$, esc, icon, hydrateIcons, toast, ask, fmtNum, fmtAge, showView, openSettings, relTime,
    hot: (n) => all.filter((x) => x.rel.niche && !x.rel.mine && !x.v.hidden && x.v.type !== 'photo' && x.m.ageH !== null && x.m.ageH <= 168 && x.m.views > 0).sort((a, b) => b.m.score - a.m.score).slice(0, n),
    radarCount: () => all.filter((x) => x.rel.niche && !x.v.hidden && x.v.type !== 'photo').length,
    coverOk: (v) => !!(v.cover && !coverExpired(v.cover)), reload: async () => { settings = await getSettings(); await loadData(); } };
  AUTO.init(helpers);
  await SHELL.init(helpers);
  await LICUI.init(helpers).catch((e) => console.error('licence', e)); // écran de clé (version vendue) · retours (auteur)
  if (IS_ADMIN) { try { KEYS = await import('./keys-ui.js'); KEYS.init(helpers); } catch (e) { KEYS = null; console.error('clés', e); } } // onglet Clés : édition de l'auteur seulement (le fichier n'est pas dans la version vendue)
  if (IS_ADMIN) { try { STATS = await import('./stats-ui.js'); STATS.init(helpers); } catch (e) { STATS = null; console.error('stats', e); } } // onglet Stats : édition de l'auteur seulement (fichier absent de la version vendue)
  if (IS_ADMIN) { try { PROMO = await import('./promo-ui.js'); PROMO.init(helpers); } catch (e) { PROMO = null; console.error('promo', e); } } // rubrique Promo : édition de l'auteur seulement (fichier absent de la version vendue)
  if (IS_ADMIN) { try { SITE = await import('./site-ui.js'); await SITE.init(helpers); } catch (e) { SITE = null; console.error('vitrine', e); } } // chiffres du site : édition de l'auteur seulement (fichier absent de la version vendue)
  { const n = $('#navRetours'); if (n) new MutationObserver(() => paintGestionBar(page)).observe(n, { attributes: true, childList: true, characterData: true, subtree: true }); } // nouveaux retours : le compteur suit aussi dans la barre de Gestion
  window.addEventListener('hashchange', () => { const h = location.hash.slice(1) || 'home'; if (h === 'auto') AUTO.focusLive(); showView(h, { push: false }); });
  showView(VIEWS[location.hash.slice(1)] || location.hash.slice(1) === 'gestion' ? location.hash.slice(1) : 'home', { push: false });
  const { scanState } = await chrome.storage.local.get('scanState');
  showScanState(scanState);
  await loadData();
  if (page === 'home') SHELL.renderHome();
  let seenNews = false;
  try { seenNews = localStorage.getItem('fr-news-v3') === '1'; } catch (e) {}
  $('#newsBanner').hidden = true; // annonce de la v3, plus utile
  const params = new URLSearchParams(location.search);
  if (params.has('scan')) openScanDialog();
  else if (params.has('guide') || params.has('welcome')) openGuide('g-start');
  chrome.runtime.sendMessage({ type: 'clearBadge' }).catch(() => {});
  setInterval(() => { if (page === 'radar' && !$('#drawer').classList.contains('open') && $('#guide').hidden) loadData(); }, 60000);
})();
