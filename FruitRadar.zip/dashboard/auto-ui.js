// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
// FruitRadar — pages Automatisation, Mes productions et Personnages du dashboard.
// Le travail lui-même se fait dans la fenêtre pilote (auto/runner.js) ; ici on lance, on suit et on corrige.
import * as DB from '../lib/db.js';
import { getSettings, saveSettings, AUTO_DEFAULTS } from '../lib/settings.js';
import { SITES, siteConfig, START_URL } from '../auto/sites.js';
import { packageToText, totalDuration, normName, parsePackage, mergePackage, missingParts } from '../auto/protocol.js';
import * as P from '../auto/protocol.js';
import * as META from '../lib/meta.js';
import * as F from '../lib/frames.js';
import { STYLE_PREVIEWS } from '../auto/style-previews.js';
import { railHtml, progressOf, STATUS } from '../auto/steps.js';

/* Fonction INJECTÉE dans la page d'un site (chrome.scripting.executeScript { func }) : sérialisée
   en texte et exécutée DANS la page cible (elle ne référence que son argument et les globals de la page). */
const FRA_DUMP = (c) => window.__FRA.dump(c);

const chrome = globalThis.browser ?? globalThis.chrome;
let H = null;                      // outils prêtés par dashboard.js : $, $$, esc, icon, toast, fmtNum, showView
let view = 'radar';
let currentId = null;              // production affichée dans Automatisation
let state = null;                  // dernier autoState
const draft = { mode: 'remake', video: null, url: '', idea: '', part: 1, prevId: '', prevBible: '', charIds: null, extra: '', style: null, styleText: '', styleName: '', keyText: false, miniStyle: null, hookGemini: null, prevFile: null, miniReuse: true, miniFile: null };
/* Personnages : un seul classement, le style d'apparence. Mêmes filtres dans la page Personnages et dans la fenêtre « Mes personnages ». */
const charFilter = { style: '', q: '' };
const charSel = new Set();   // planches cochées dans la page Personnages (pour les classer ou les mettre à la corbeille)
const groupOpen = new Map(); // histoires dépliées ou repliées à la main
const miniPick = {}; // style de miniature choisi pour « Refaire », par production
const urls = new Map();
let diagRes = null, stateLoaded = false;
let checks = {};                   // dernier verdict par site : { ok, label, detail, at }
const testing = new Set();         // sites en cours de test
let wantLauncher = false;          // vrai quand on a demandé le lanceur alors qu'une vidéo tourne
let prodTab = null;                // 'histoire' ou 'fabrication' (null = choisi d'après l'état)
let prodFilter = 'all';            // filtre de « Mes productions »
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
/* Les sites pilotés, dans l'ordre de la chaîne */
const CONN = [['claude', 'Écrit le package'], ['chatgpt', 'Dessine les planches, les scènes et la miniature'], ['grok', 'Tourne les clips'], ['capcut', 'Reçoit le montage'], ['vt', 'Transcrit la vidéo à reproduire'], ['turbo', 'Transcription de secours'], ['tiktok', 'Reçoit la vidéo finale']];
/* Raccourcis pour orienter les idées */
const ORIENT = ['trahison', 'mariage', 'héritage', 'jalousie', 'vengeance', 'secret de famille', 'riche contre pauvre', 'humiliation publique', 'histoire d\'amour', 'au travail', 'plus drôle', 'fin choquante'];
const chips = (forId) => `<div class="ochips" role="group" aria-label="Raccourcis">${ORIENT.map((w) => `<button type="button" class="ochip" data-chip-for="${forId}" data-chip="${H.esc(w)}">${H.esc(w)}</button>`).join('')}</div>`;
const voiceField = (id, rows, value, placeholder = '') => `<span class="voicewrap"><textarea id="${id}" rows="${rows}"${placeholder ? ` placeholder="${H.esc(placeholder)}"` : ''}>${H.esc(value)}</textarea><button class="mic" type="button" data-voice="${id}" aria-label="Dicter à la voix" title="Dicter à la voix">${H.icon('mic')}</button></span>`;

const MODES = { remake: 'Reproduire une vidéo', idee: 'Mon idée', idees: '10 idées proposées', suite: 'Suite d\'une histoire' };
const STLABEL = (st) => STATUS[st] || st;
const MODE_TILES = [['remake', 'repeat', 'Une vidéo du Radar, refaite avec tes personnages.'], ['idee', 'sparkle', 'Tu écris deux phrases, Claude fait le reste.'], ['idees', 'bolt', 'Claude propose dix histoires résumées, tu en choisis une ou tu en redemandes dix.'], ['suite', 'film', 'Partie 2, 3, 4… avec les mêmes planches.']];
const pad = (n) => String(n).padStart(2, '0');
const when = (t) => (t ? new Date(t).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—');

let held = false, pendingSoft = false, parking = null; // parking : « Mettre de côté » cliqué, en attendant l'arrêt réel
let styleImgs = {}; // { clé du style: image d'aperçu (data URL) }
/* « Autoriser l'accès aux URL de fichier » : réglage de Chrome que seul l'utilisateur peut activer (page de l'extension).
   Avec lui, FruitRadar lit lui-même la vidéo exportée dans les Téléchargements ; sans lui, on le signale sur le lanceur. */
let fileOk = true;
const checkFileAccess = () => new Promise((res) => { try { chrome.extension.isAllowedFileSchemeAccess((ok) => res(!!ok)); } catch (e) { res(true); } })
  .then((ok) => { const changed = ok !== fileOk; fileOk = ok; if (changed && view === 'auto' && !held) renderAuto(true); return ok; });
export function init(helpers) {
  H = helpers;
  checkFileAccess();
  window.addEventListener('focus', checkFileAccess); // on revient de la page des extensions : le message disparaît si l'option est cochée
  document.addEventListener('visibilitychange', () => { if (!document.hidden) checkFileAccess(); });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && ch.styleImgs) { styleImgs = ch.styleImgs.newValue || {}; if (view === 'auto' && !ch.autoState) renderAuto(true); }
    if (area === 'local' && ch.ideaEdits) ideaEdits = ch.ideaEdits.newValue || {}; // idée modifiée dans un autre onglet du dashboard
    if (area !== 'local' || !ch.autoState) return;
    const was = ch.autoState.oldValue || null;
    state = ch.autoState.newValue || null; stateLoaded = true;
    // la vidéo en cours a besoin de toi (pause, choix, validation) : on la remontre, même si tu étais sur le lanceur
    if (state && ['paused', 'waiting'].includes(state.status) && (!was || was.status !== state.status || was.id !== state.id) && !(H.voiceActive && H.voiceActive())) { wantLauncher = false; currentId = state.id; }
    navDot();
    clearTimeout(init.t); init.t = setTimeout(() => { if (view !== 'radar') render(view, true); }, 500);
  });
  chrome.storage.local.get(['autoState', 'siteChecks', 'styleImgs', 'ideaEdits']).then((r) => { state = r.autoState || null; checks = r.siteChecks || {}; styleImgs = r.styleImgs || {}; ideaEdits = r.ideaEdits || {}; stateLoaded = true; navDot(); });
  loadMiniTypes().then(() => { if (view === 'auto') renderAuto(true); }).catch(() => {});
  document.addEventListener('paste', onPaste);
  // un clic = appui puis relâchement sur le même bouton : tant que la souris est enfoncée, on ne redessine pas la page
  // Avant, si le relâchement se perdait (tu passais sur Firefox ou un jeu pendant le clic, une fenêtre s'ouvrait…), la page attendait 4 s puis ne se
  // redessinait plus jusqu'au prochain changement : elle restait figée sur un vieil état. Maintenant le rendu en attente part toujours.
  const flush = () => { held = false; if (pendingSoft) { pendingSoft = false; if (view !== 'radar') render(view, true); } };
  document.addEventListener('pointerdown', () => { held = true; clearTimeout(init.h); init.h = setTimeout(flush, 4000); }, true);
  const release = () => { clearTimeout(init.h); init.h = setTimeout(flush, 250); };
  document.addEventListener('pointerup', release, true); document.addEventListener('pointercancel', release, true);
  window.addEventListener('blur', release); document.addEventListener('visibilitychange', release);
  // filet de sécurité : toutes les 5 s, la page de la production se remet à jour si quelque chose a changé (rien ne bouge sinon)
  setInterval(() => { if (view === 'auto' && !document.hidden && !held) render('auto', true).catch(() => null); }, 5000);
  document.addEventListener('click', onClick);
  { // la vidéo exportée glissée sur la carte « Regarde la vidéo en entier » ; lâchée à côté, elle n'ouvre pas le fichier à la place de FruitRadar
    const zone = (e) => e.target && e.target.closest && e.target.closest('[data-drop="final"]');
    const files = (e) => !!(e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files'));
    document.addEventListener('dragover', (e) => { if (!files(e) || view !== 'auto') return; e.preventDefault(); const z = zone(e); e.dataTransfer.dropEffect = z ? 'copy' : 'none'; document.querySelectorAll('.dropon').forEach((x) => { if (x !== z) x.classList.remove('dropon'); }); if (z) z.classList.add('dropon'); });
    document.addEventListener('dragleave', (e) => { const z = zone(e); if (z && !z.contains(e.relatedTarget)) z.classList.remove('dropon'); });
    document.addEventListener('drop', (e) => {
      if (!files(e) || view !== 'auto') return;
      e.preventDefault(); document.querySelectorAll('.dropon').forEach((x) => x.classList.remove('dropon'));
      if (!zone(e)) return;
      const f = e.dataTransfer.files && e.dataTransfer.files[0]; if (f) depositFinal(f);
    });
  }
  document.addEventListener('change', onChange);
  document.addEventListener('input', onInput);
  document.addEventListener('toggle', (e) => { const d = e.target; if (d && d.matches && d.matches('details.chgroup')) groupOpen.set(d.dataset.group, d.open); }, true);
  const cd = H.$('#charDlg'); if (cd) { cd.addEventListener('close', () => { fillCast(); }); cd.addEventListener('cancel', () => { setTimeout(fillCast, 0); }); } // touche Échap
  document.addEventListener('play', (e) => { const v = e.target; if (!(v instanceof HTMLMediaElement)) return; for (const o of document.querySelectorAll('video, audio')) if (o !== v && !o.paused) o.pause(); }, true); // une seule vidéo lue à la fois
  const zd = H.$('#zoomDlg'); if (zd) zd.addEventListener('close', () => { const im = H.$('#zoomImg'); if (im && im.src.startsWith('blob:')) URL.revokeObjectURL(im.src); if (im) im.removeAttribute('src'); });
  DB.purgeTrash().catch(() => 0); // ce qui est à la corbeille depuis plus de 30 jours est effacé pour de bon
}
function navDot() {
  const d = H.$('#navAutoDot'); if (!d) return;
  const live = state && ['running', 'paused', 'waiting', 'queued'].includes(state.status);
  d.hidden = !live; d.className = 'navdot' + (state && !['running', 'queued'].includes(state.status) ? ' warn' : '');
  const card = H.$('#navLive'); if (!card) return;
  card.hidden = !live;
  if (live) {
    const pct = state.total ? Math.round((state.done / state.total) * 100) : 0;
    card.className = 'navlive ' + state.status;
    card.innerHTML = `<b>${H.esc(state.title || 'Nouvelle vidéo')}</b><span>${H.esc(STATUS[state.status] || '')}${state.total ? `, ${state.done}/${state.total}` : ''}</span><i class="meter${state.total ? '' : ' wait'}"><span style="width:${state.total ? Math.max(4, pct) : 100}%"></span></i>`;
  }
}
const busy = () => state && ['running', 'waiting', 'paused', 'queued'].includes(state.status);
async function runnerAlive() { try { const r = await chrome.runtime.sendMessage({ type: 'autoPing' }); return r && r.ok ? r : null; } catch (e) { return null; } }

/* Clic sur « Automatisation » dans le menu : s'il y a une production en cours, c'est elle qu'on montre */
export function focusLive() { if (state && busy()) { currentId = state.id; wantLauncher = false; } }
/* Depuis l'accueil : ouvrir le lanceur, éventuellement sur un type de vidéo */
export function startMode(mode) { currentId = null; prodTab = null; wantLauncher = true; if (mode) { draft.mode = mode; if (mode !== 'suite') draft.charIds = null; } }

/* Appelé par le bouton « Reproduire » du radar */
export function startRemake(x) {
  const v = x.v;
  draft.mode = 'remake';
  draft.video = { videoId: v.id, url: v.url, author: v.author.uniqueId, desc: v.desc || '', cover: v.cover || '', duration: v.duration || null, stats: `${H.fmtNum(x.m.views)} vues, ${H.fmtNum(x.m.likes)} likes` };
  draft.url = v.url; draft.part = 1;
  currentId = null; prodTab = null; wantLauncher = true;
}

/* ---------- images de la base ---------- */
async function hydrateMedia(root) {
  for (const el of H.$$('[data-media]', root)) {
    const key = el.dataset.media;
    if (!urls.has(key)) { const m = await DB.getMedia(key).catch(() => null); urls.set(key, m && m.blob ? URL.createObjectURL(m.blob) : ''); }
    const u = urls.get(key);
    if (!u) continue;
    if (el.tagName === 'VIDEO') { if (el.src !== u) el.src = u; } else if (el.tagName === 'IMG') el.src = u; else if (el.tagName === 'A') el.href = u;
  }
  for (const el of H.$$('img[data-char]', root)) {
    const id = el.dataset.char;
    if (urls.has('c:' + id)) { if (urls.get('c:' + id)) el.src = urls.get('c:' + id); continue; }
    charThumb(id).then((u) => { if (u && el.isConnected) el.src = u; });
  }
}
/* Afficher 60 planches en taille réelle, c'est lourd : chaque planche a une vignette de 360 px de large, fabriquée au premier
   affichage puis gardée avec elle. La grande image n'est chargée que pour le zoom. */
const thumbJobs = new Map(); let thumbChain = Promise.resolve();
const thumbAt = new Map(); // date de la planche dont on a la vignette en mémoire
function syncThumbs(chars) { for (const c of chars) { if (thumbAt.has(c.id) && thumbAt.get(c.id) !== c.at) forget('c:' + c.id); thumbAt.set(c.id, c.at); } }
function charThumb(id) {
  if (!thumbJobs.has(id)) {
    const job = thumbChain.then(async () => {
      const c = await DB.getChar(id).catch(() => null);
      if (!c || !c.blob) { urls.set('c:' + id, ''); return ''; }
      let th = c.thumb;
      if (!th) {
        try {
          const bm = await createImageBitmap(c.blob, { resizeWidth: 360, resizeQuality: 'high' });
          const cv = new OffscreenCanvas(bm.width, bm.height); cv.getContext('2d').drawImage(bm, 0, 0); try { bm.close(); } catch (e) { /* rien */ }
          th = await cv.convertToBlob({ type: 'image/jpeg', quality: 0.84 });
          const now = await DB.getChar(id); if (now && now.blob === undefined) throw new Error('planche retirée');
          if (now) await DB.putChar({ ...now, thumb: th, at: now.at });
        } catch (e) { th = c.blob; }
      }
      const u = URL.createObjectURL(th); urls.set('c:' + id, u); return u;
    }).catch(() => '').finally(() => thumbJobs.delete(id));
    thumbJobs.set(id, job); thumbChain = job;
  }
  return thumbJobs.get(id);
}
const forget = (key) => { const u = urls.get(key); if (u) URL.revokeObjectURL(u); urls.delete(key); };

/* ---------- rendu ---------- */
export async function render(v, soft = false) {
  view = v;
  if (soft && held) { pendingSoft = true; return; }
  if (v === 'auto') return renderAuto(soft);
  if (v === 'prods') return renderProds();
  if (v === 'chars') return renderChars();
  if (v === 'trash') return renderTrash();
}

function chip(st) { return `<span class="st ${st}">${{ done: 'Fait', todo: 'À faire' }[st] || st}</span>`; }

async function renderAuto(soft) {
  const box = H.$('#viewAuto');
  const keepScroll = soft ? document.scrollingElement.scrollTop : 0;
  const focusId = soft && document.activeElement && box.contains(document.activeElement) ? document.activeElement.id : null;
  if (soft && focusId && /^(aIdea|aExtra|aUrl|aPrevBible|aPart)$/.test(focusId) && (!busy() || !currentId)) return; // on ne casse pas une saisie en cours
  if (soft && (focusId === 'aPkgPaste' || focusId === 'aIdeaNote')) return;
  if (soft && ideaForm && document.activeElement && document.activeElement.closest && document.activeElement.closest('.story.editing')) return; // modification d'une idée en cours
  if (soft && H.voiceActive && H.voiceActive()) return; // dictée en cours : on ne redessine pas le champ
  { const fv = H.$('#finalVideo'); if (soft && fv && (!fv.paused || fv.currentTime > 0.2) && (!state || state.status === 'waiting')) return; } // on ne coupe pas la vidéo que tu regardes (sauf si la production est repartie : miniature refaite, montage refait) // on ne coupe pas la vidéo que tu regardes
  if (!stateLoaded) { state = (await chrome.storage.local.get('autoState')).autoState || null; stateLoaded = true; navDot(); }
  if (!currentId && !wantLauncher && state && busy()) currentId = state.id;
  const prod = currentId ? await DB.getProd(currentId) : null;
  const settings = await getSettings();
  const html = `
    <div class="pagehead"><div><h2>Automatisation</h2></div>
      <div class="row"><button class="btn ghost" type="button" data-guide="g-auto">${H.icon('help')}Comment ça marche</button>${prod ? `<button class="btn" type="button" data-auto="new">${H.icon('sparkle')}Nouvelle vidéo</button>` : ''}</div></div>
    ${prod ? await prodHtml(prod) : `<section class="hero ink idle"><div class="hero-top"><div><h3>De l'idée au montage, sans y toucher</h3><p>Claude écrit le package, ChatGPT dessine les planches, les scènes et la miniature, Grok tourne les clips en 9:16, CapCut les reçoit dans l'ordre. Un son te prévient à la fin.</p></div></div>${railHtml(null)}</section>` + launcherHtml(settings) + connHtml(settings)}`;
  // rien n'a changé à l'écran : on ne redessine pas (redessiner pendant un clic fait rater le clic)
  if (soft && box.__html === html) return;
  if (soft && held) { pendingSoft = true; return; } // bouton de souris enfoncé : on attend qu'il soit relâché
  // le journal garde sa place quand la page se redessine (une nouvelle ligne le ramenait tout en haut) : on reste où on lisait, ou collé en bas si on y était
  const lg0 = box.querySelector('.autolog'), lb0 = box.querySelector('details.logbox');
  const logKeep = lg0 && box.dataset.logOf === String(currentId || '') ? { top: lg0.scrollTop, end: lg0.scrollHeight - lg0.scrollTop - lg0.clientHeight < 30, open: lb0 ? lb0.open : null } : null;
  box.__html = html; box.innerHTML = html; box.dataset.logOf = String(currentId || '');
  { const lg = box.querySelector('.autolog'), lb = box.querySelector('details.logbox');
    if (lb && logKeep && logKeep.open !== null) lb.open = logKeep.open; // replié ou déplié : comme tu l'avais laissé
    if (lg) lg.scrollTop = !logKeep || logKeep.end ? lg.scrollHeight : logKeep.top; }
  await hydrateMedia(box);
  if (soft) document.scrollingElement.scrollTop = keepScroll;
}

/* Choix du style de personnages : styles fournis + tes styles enregistrés, le dernier utilisé en premier */
const styleHue = (k) => { let h = 0; for (const c of String(k)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
let stylesOpen = false; // liste des styles dépliée
const STYLE_FOLD = 7;   // styles montrés d'emblée (avec la tuile « Nouveau style » : deux rangées de quatre)
/* Tous les styles : ceux fournis, puis les tiens. Image d'aperçu = celle que tu as ajoutée, sinon celle fournie avec le style. */
const styleList = (au) => {
  const all = [...Object.entries(P.STYLES).filter(([k]) => k !== 'autre' && k !== 'video').map(([k, st]) => ({ ...st, k, key: k, mine: !!styleImgs[k], img: styleImgs[k] || (STYLE_PREVIEWS.includes(k) ? chrome.runtime.getURL(`auto/styles/${k}.jpg`) : '') })),
    ...(au.customStyles || []).map((c) => ({ k: 'c:' + c.id, key: 'c:' + c.id, label: c.label, short: String(c.brief || '').length > 70 ? String(c.brief).slice(0, 68).replace(/\s+\S*$/, '') + '…' : String(c.brief || ''), brief: c.brief, mine: !!styleImgs['c:' + c.id], img: styleImgs['c:' + c.id] || '', custom: true }))];
  const order = au.styleOrder || [], rank = (k) => { const n = order.indexOf(k); return n < 0 ? 1000 : n; };
  return all.map((x, n) => ({ ...x, n })).sort((a, b) => rank(a.k) - rank(b.k) || a.n - b.n);
};
async function metaText() { // le métaprompt en service : le tien si tu en as importé un, sinon celui fourni
  const { autoMetaprompt } = await chrome.storage.local.get('autoMetaprompt');
  if (autoMetaprompt && autoMetaprompt.text) return autoMetaprompt.text;
  return (await META.provided()).text;
}
/* « Même style que la vidéo » n'a de sens que s'il y a une vidéo à regarder : celle qu'on reproduit, ou la partie précédente donnée en fichier */
const videoStyleOk = () => draft.mode === 'remake' || (draft.mode === 'suite' && !draft.prevId && !!draft.prevFile);
function styleHtml(settings) {
  const au = settings.auto, list = styleList(au);
  const canVideo = videoStyleOk();
  const cur = (draft.style === 'video' && !canVideo ? null : draft.style) || (au.styleOrder || [])[0] || au.charStyle || 'fruits';
  const sel = list.find((x) => x.k === cur) || null, at = list.findIndex((x) => x.k === cur);
  // une tuile = l'image des personnages, le nom du style, une ligne de description
  const tile = (x) => `<button type="button" class="stile st-${H.esc(x.k.replace(':', '-'))}${cur === x.k ? ' on' : ''}" aria-pressed="${cur === x.k}" data-auto="style" data-style="${H.esc(x.k)}">${x.img
    ? `<img class="stile-img" src="${H.esc(x.img)}" alt="" loading="lazy">`
    : `<span class="stile-ph" aria-hidden="true"${x.custom || !/^(porcelaine|bubbletea_porcelaine|oiseaux|oiseaux_porcelaine)$/.test(x.k) ? ` style="background:linear-gradient(135deg, hsl(${styleHue(x.k)} 80% 72%), hsl(${(styleHue(x.k) + 40) % 360} 65% 45%))"` : ''}>Pas encore d'aperçu</span>`}<b>${H.esc(x.label)}</b><small>${H.esc(x.short)}</small></button>`;
  // liste repliée : les premiers styles (les derniers utilisés), plus celui qui est sélectionné s'il est plus loin
  const open = stylesOpen, shown = open ? list : [...list.slice(0, STYLE_FOLD), ...(at >= STYLE_FOLD ? [list[at]] : [])], rest = list.length - shown.length;
  const tiles = shown.map(tile).join('') + `<button type="button" class="stile st-autre${cur === 'autre' ? ' on' : ''}" aria-pressed="${cur === 'autre'}" data-auto="style" data-style="autre"><span class="stile-ph" aria-hidden="true">+</span><b>Nouveau style</b><small>Tu le décris, tu peux l'enregistrer</small></button>`;
  const more = list.length > STYLE_FOLD ? `<button type="button" class="linkbtn stylemore" data-auto="styleMore">${open ? 'Replier la liste' : `Voir les ${rest} autres styles`}</button>` : '';
  let panel = '';
  if (cur === 'video') panel = `<div class="styleinfo"><div><h4>Style repris de la vidéo</h4><p class="hint">Claude regarde les captures de la vidéo, décrit le style de ses personnages (espèce, matière, rendu, proportions) et l'applique ${draft.mode === 'suite' ? 'aux personnages de la suite' : 'à tes nouveaux personnages'}. Deux captures de la vidéo partent avec chaque planche, comme référence de rendu.</p><p class="hint">Pour un autre style, clique sur une tuile.</p></div></div>`;
  else if (cur === 'autre') panel = `<div class="stylenew"><label class="block" for="aStyleName"><span>Nom du style <small>Pour le retrouver ensuite.</small></span><input id="aStyleName" maxlength="40" value="${H.esc(draft.styleName || '')}" placeholder="ex. Légumes en pâte à modeler"></label>
      <div class="block"><label for="aStyleText"><span>Décris la matière ou l'espèce <small>Le métaprompt reste la base (planches, proportions, rendu) : dis seulement ce qui change. Tu peux dicter.</small></span></label>${voiceField('aStyleText', 3, draft.styleText, 'ex. la peau des fruits est en pâte à modeler, avec des traces de doigts ; ou : des cupcakes humanoïdes à la place des fruits…')}</div>
      <div class="row"><button class="btn primary" type="button" data-auto="styleSave">Enregistrer ce style</button><button class="btn" type="button" data-auto="styleGpt">Créer la planche d'aperçu dans ChatGPT</button></div>
      <p class="hint">Sans l'enregistrer, le style sert quand même pour cette vidéo.</p></div>`;
  else if (sel) panel = `<div class="styleinfo">${sel.img ? `<img class="styleprev" src="${H.esc(sel.img)}" alt="Aperçu du style ${H.esc(sel.label)}">` : ''}<div><h4>${H.esc(sel.label)}</h4><p class="hint">${H.esc(sel.k === 'fruits' ? 'Le métaprompt tel quel : fruits et légumes humanoïdes, rendu 3D semi-réaliste.' : String(sel.matiere || sel.brief || '').slice(0, 460))}${String(sel.matiere || sel.brief || '').length > 460 ? '…' : ''}</p>
      <p class="hint">${sel.k === 'fruits' ? '' : `Base : les planches du métaprompt (format, proportions, directive de style) ; le style n'y ajoute que ${sel.espece || sel.cast ? 'son espèce et sa matière' : 'sa matière'}.${sel.img && au.styleRef !== false ? ' Cette image part avec chaque planche, comme référence de rendu.' : ''}`}</p>
      <div class="row"><button class="btn" type="button" data-auto="styleGpt">${sel.img ? 'Refaire' : 'Créer'} la planche d'aperçu dans ChatGPT</button><label class="btn" for="aStyleImg">${sel.img ? 'Changer' : 'Ajouter'} l'image d'aperçu</label><input id="aStyleImg" type="file" accept="image/*" hidden>${sel.mine ? '<button class="btn ghost" type="button" data-auto="styleImgDel">Retirer mon image</button>' : ''}${sel.custom ? '<button class="btn ghost" type="button" data-auto="styleDel">Supprimer ce style</button>' : ''}</div>
      <p class="hint">Pour mettre ton image : dans ChatGPT, clic droit sur la planche, « Copier l'image », puis Ctrl+V ici.</p></div></div>`;
  const videoLink = canVideo ? `<button type="button" class="stylevideo${cur === 'video' ? ' on' : ''}" aria-pressed="${cur === 'video'}" data-auto="style" data-style="video">${H.icon(cur === 'video' ? 'check' : 'film')}Reprendre le même style que les personnages de la vidéo</button>` : '';
  return `<div class="block stylepick"><span>Style des personnages <small>${draft.mode === 'suite' ? 'Par défaut, celui de la partie précédente.' : 'Le dernier utilisé est en premier. Appliqué aux planches, aux images, aux clips et à la miniature.'}</small></span>
      ${videoLink}
      <div class="stiles" role="group" aria-label="Style des personnages">${tiles}</div>${more}${panel}
    </div>`;
}
async function patchAuto(fn) { const st = await getSettings(); const au = { ...st.auto }; fn(au); await saveSettings({ auto: au }); return au; }
async function styleAction(a) {
  readDraft();
  const st = await getSettings(), au = st.auto, cur = draft.style || (au.styleOrder || [])[0] || au.charStyle || 'fruits';
  const sel = styleList(au).find((x) => x.k === cur);
  if (a === 'styleGpt') {
    const st = cur === 'autre' ? { custom: true, key: 'autre', brief: draft.styleText } : sel;
    if (!st || (cur === 'autre' && !String(draft.styleText || '').trim())) { H.toast && H.toast('Décris d\'abord le style.'); return; }
    const prompt = P.stylePreviewPrompt(st, await metaText());
    try { await navigator.clipboard.writeText(prompt); } catch (e) { /* presse-papiers refusé */ }
    window.open('https://chatgpt.com/?q=' + encodeURIComponent(prompt), '_blank', 'noopener');
    return;
  }
  if (a === 'styleSave') {
    const label = (draft.styleName || '').trim(), brief = (draft.styleText || '').trim();
    if (!label || brief.length < 20) { H.toast && H.toast(!label ? 'Donne un nom au style.' : 'Décris le style en une phrase ou deux.'); return; }
    const id = Date.now().toString(36);
    await patchAuto((x) => { x.customStyles = [...(x.customStyles || []), { id, label, brief }]; });
    draft.style = 'c:' + id; draft.styleName = ''; draft.styleText = '';
    return renderAuto();
  }
  if (a === 'styleImgDel' && sel) { const next = { ...styleImgs }; delete next[cur]; styleImgs = next; await chrome.storage.local.set({ styleImgs: next }); return renderAuto(); }
  if (a === 'styleDel' && sel && sel.custom) {
    if (!(await H.ask(`Supprimer le style « ${sel.label} » ?`, { ok: 'Supprimer', danger: true }))) return;
    await patchAuto((x) => { x.customStyles = (x.customStyles || []).filter((c) => 'c:' + c.id !== cur); x.styleOrder = (x.styleOrder || []).filter((k) => k !== cur); });
    if (styleImgs[cur]) { const next = { ...styleImgs }; delete next[cur]; styleImgs = next; await chrome.storage.local.set({ styleImgs: next }); }
    draft.style = null; return renderAuto();
  }
}
async function styleImage(file) { // image d'aperçu d'un style (fourni ou enregistré) : réduite, puis rangée à part des réglages
  const st = await getSettings(), cur = draft.style || (st.auto.styleOrder || [])[0] || st.auto.charStyle || 'fruits';
  const sel = styleList(st.auto).find((x) => x.k === cur);
  if (!file || !sel) { H.toast('Choisis d\'abord un style (ou enregistre le nouveau), puis ajoute son image.', 4500); return false; }
  const bmp = await createImageBitmap(file), k = Math.min(1, 760 / bmp.width), cv = document.createElement('canvas');
  cv.width = Math.round(bmp.width * k); cv.height = Math.round(bmp.height * k); cv.getContext('2d').drawImage(bmp, 0, 0, cv.width, cv.height);
  styleImgs = { ...styleImgs, [cur]: cv.toDataURL('image/jpeg', 0.8) };
  await chrome.storage.local.set({ styleImgs });
  H.toast(`Image d'aperçu enregistrée pour « ${sel.label} »`);
  renderAuto();
  return true;
}
function onPaste(e) { // Ctrl+V d'une image sur le lanceur : l'aperçu du style sélectionné, ou la miniature type (après « Créer la miniature type »)
  const toMini = view === 'auto' && pasteTo === 'mini' && !!H.$('#viewAuto .minipick');
  if (view !== 'auto' || (!toMini && !H.$('#viewAuto .stylepick'))) return;
  const f = [...((e.clipboardData && e.clipboardData.files) || [])].find((x) => /^image\//.test(x.type));
  if (!f) return;
  e.preventDefault();
  if (toMini) miniTypeImage(f).catch(() => H.toast('Image illisible')); else styleImage(f).catch(() => H.toast('Image illisible'));
}
/* Style du texte de la miniature : choisi au lancement, et rechoisi quand on la refait */
const miniKey = (k) => (P.MINI_STYLES[k] ? k : P.MINI_DEFAULT);
/* Miniature type de chaque style : une scène d'exemple faite dans ChatGPT, collée ici (Ctrl+V) ou ajoutée en fichier, puis exportable.
   Rangée dans la base avec les images, à part des productions (clé minitype/<style>). */
const MINI_TYPE = (k) => `minitype/${k}`;
const miniExt = (b) => (/png/.test(b.type) ? 'png' : /webp/.test(b.type) ? 'webp' : 'jpg');
let miniTypes = {}; // { style : extension du fichier } pour les styles qui ont leur miniature type
let pasteTo = 'style'; // Ctrl+V sur le lanceur : l'aperçu du style des personnages, ou la miniature type
async function loadMiniTypes() {
  const out = {};
  for (const k of Object.keys(P.MINI_STYLES)) { const m = await DB.getMedia(MINI_TYPE(k)).catch(() => null); if (m && m.blob) out[k] = miniExt(m.blob); }
  miniTypes = out;
}
async function miniTypeImage(file, key) {
  const k = miniKey(key || draft.miniStyle || (await getSettings()).auto.miniStyle);
  if (!file || !/^image\//.test(file.type || '')) { H.toast('Ce fichier n\'est pas une image'); return false; }
  forget(MINI_TYPE(k));
  await DB.putMedia({ key: MINI_TYPE(k), prodId: 'minitype', name: `miniature-type-${k}.${miniExt(file)}`, blob: file });
  miniTypes = { ...miniTypes, [k]: miniExt(file) };
  H.toast(`Miniature type enregistrée pour « ${P.MINI_STYLES[k].label} »`);
  renderAuto();
  return true;
}
function miniPickHtml(cur, action, extra = '') {
  const k = miniKey(cur), has = !!miniTypes[k], st = P.MINI_STYLES[k];
  const tiles = Object.entries(P.MINI_STYLES).map(([key, x]) => `<button type="button" class="mtile${k === key ? ' on' : ''}" aria-pressed="${k === key}" data-auto="${action}" data-mini="${key}">${miniTypes[key]
    ? `<img class="mtile-img" data-media="${MINI_TYPE(key)}" alt="">` : '<span class="mtile-ph" aria-hidden="true">Aa</span>'}<b>${H.esc(x.label)}</b></button>`).join('');
  return `<div class="block minipick"><span>Style de la miniature <small>Le texte et sa mise en page. Tu pourras la refaire dans un autre style.</small></span>
      <div class="mtiles" role="group" aria-label="Style de la miniature">${tiles}</div>
      <div class="minitype">${has ? `<img class="minitype-img" data-media="${MINI_TYPE(k)}" alt="Miniature type, style ${H.esc(st.label)}">` : ''}
        <div><h4>${H.esc(st.label)}</h4><p class="hint">${H.esc(st.short)}.</p>
          <div class="row"><button class="btn" type="button" data-auto="miniGpt" data-mini="${k}">${H.icon('sparkle')}${has ? 'Refaire' : 'Créer'} la miniature type dans ChatGPT</button>
            <label class="btn" for="aMiniType">${has ? 'Changer' : 'Ajouter'} l'image</label><input id="aMiniType" type="file" accept="image/*" hidden data-mini="${k}">
            ${has ? `<a class="btn" data-media="${MINI_TYPE(k)}" download="miniature-type-${k}.${miniTypes[k]}">${H.icon('download')}Exporter</a><button class="btn ghost" type="button" data-auto="miniTypeDel" data-mini="${k}">Retirer</button>` : ''}</div>
          <p class="hint">Une scène d'exemple avec des fruits, pour voir le texte et la mise en page de ce style. Dans ChatGPT : clic droit sur l'image, « Copier l'image », puis Ctrl+V ici.</p></div>
      </div>${extra}</div>`;
}
const miniSelectHtml = (id, cur) => `<select id="${id}" aria-label="Style de la miniature">${Object.entries(P.MINI_STYLES).map(([key, st]) => `<option value="${key}"${miniKey(cur) === key ? ' selected' : ''}>${H.esc(st.label)}</option>`).join('')}</select>`;
function launcherHtml(settings) {
  const d = draft, v = d.video;
  const tabs = MODE_TILES.map(([k, ic, desc]) => `<button type="button" class="modetile${d.mode === k ? ' on' : ''}" aria-pressed="${d.mode === k}" data-auto="mode" data-mode2="${k}">${H.icon(ic)}<b>${MODES[k]}</b><span>${desc}</span></button>`).join('');
  let body = '';
  if (d.mode === 'remake') {
    const hookOn = (d.hookGemini === null ? !!settings.auto.hookGemini : d.hookGemini) && !!settings.geminiKey;
    body = `${v ? `<div class="srcvid">${v.cover ? `<img src="${H.esc(v.cover)}" alt="">` : `<div class="noimg">${H.icon('play')}</div>`}<div><b>@${H.esc(v.author)}</b><span class="muted"> · ${H.esc(v.stats || '')}</span><p>${H.esc(v.desc || 'Sans description')}</p>
        <button class="btn small ghost" type="button" data-auto="clearVideo">Changer de vidéo</button></div></div>`
      : `<p class="hint">Choisis une vidéo dans le Radar avec le bouton « Reproduire », ou colle son lien TikTok ici.</p>
        <label class="block"><span>Lien de la vidéo TikTok</span><input id="aUrl" placeholder="https://www.tiktok.com/@compte/video/123…" value="${H.esc(d.url)}"></label>`}
      <div class="hookbox${hookOn ? ' on' : ''}">
        <label class="chk"><input type="checkbox" id="aHookGemini"${hookOn ? ' checked' : ''}${settings.geminiKey ? '' : ' disabled'}> <b>Analyser le hook de cette vidéo avec Gemini</b></label>
        <p class="hint">${settings.geminiKey ? 'Gemini regarde la vidéo et explique son hook : ce qu\'on voit, ce qu\'on entend, pourquoi on reste. Son analyse part chez Claude avec la demande. Une analyse déjà faite dans le Radar est reprise.' : 'Il faut ta clé Gemini gratuite : <button class="linkbtn" type="button" data-action="openSettings">ouvre les Réglages</button>, partie Analyse IA, puis reviens cocher la case.'}</p></div>
      <p class="hint">Claude garde la structure de l'histoire (hook, étapes, retournement, fin) et change tout le reste : personnages, décors, dialogues. La vidéo d'origine sert d'inspiration, elle n'est jamais repostée.</p>`;
  } else if (d.mode === 'idee') {
    body = `<label class="block" for="aIdea"><span>Ton idée <small>Une ou deux phrases, avec les fruits ou légumes que tu veux. Tu peux la dicter.</small></span></label>${voiceField('aIdea', 3, d.idea)}`;
  } else if (d.mode === 'idees') {
    body = `<div class="orient"><label class="block" for="aIdea"><span>Oriente les 10 idées <small>Facultatif : un thème, des personnages, un ton, « comme Le Bocal »… Clique sur un raccourci, écris ou dicte.</small></span></label>
      ${voiceField('aIdea', 2, d.idea, 'Ex. : une trahison entre sœurs pendant un mariage, avec des pêches et des cerises, fin choquante')}
      ${chips('aIdea')}</div>
      <p class="hint">Claude propose 10 idées. L'automatisation s'arrête, tu choisis (ou tu redemandes 10 idées dans une autre direction), puis elle repart toute seule.</p>`;
  } else {
    body = `<div id="suiteBox"><p class="muted">Chargement…</p></div>`;
    queueMicrotask(fillSuite);
  }
  queueMicrotask(fillCast);
  if (d.mode === 'suite') queueMicrotask(fillMiniPrev);
  const extraLabel = d.mode === 'remake' ? 'Tes précisions pour cette vidéo <small>Facultatif : le ton, ce que tu veux changer par rapport à l\'originale. Tu peux dicter.</small>' : 'Consignes en plus <small>Facultatif, pour cette vidéo seulement. Tu peux dicter.</small>';
  const step = (n, title, hint, inner, cls = '') => `<div class="lstep${cls}"><h4><span class="lnum" aria-hidden="true">${n}</span><span>${title}${hint ? ` <small>${hint}</small>` : ''}</span></h4>${inner}</div>`;
  return `<section class="panel launch">
      <h3>Nouvelle vidéo</h3>
      ${fileOk ? '' : `<div class="filewarn" role="note"><b>Une option de Chrome à activer, une seule fois</b>
        <p>Active « Autoriser l'accès aux URL de fichier » pour que FruitRadar récupère tout seul la vidéo exportée par CapCut dans tes Téléchargements, puis l'envoie sur TikTok. Sans elle, il te demandera parfois de déposer le fichier à la main.</p>
        <div class="row"><button class="btn small primary" type="button" data-auto="fileAccess">Ouvrir la page de FruitRadar dans Chrome</button><span class="hint">Coche l'option, puis reviens ici : ce message disparaît tout seul.</span></div></div>`}
      ${step(1, 'D\'où part la vidéo', '', `<div class="modegrid" role="group" aria-label="Type de vidéo">${tabs}</div>${body}`)}
      ${step(2, 'Les personnages', 'Ceux que tu reprends, puis le style des nouveaux.', `<div id="castBox" class="block castpick"><p class="muted">Chargement…</p></div>${styleHtml(settings)}`)}
      ${step(3, 'Les réglages de cette vidéo', 'Tout est facultatif.', `<div class="launch-opts">
        <div class="block"><label for="aExtra"><span>${extraLabel}</span></label>${voiceField('aExtra', 2, d.extra, d.mode === 'remake' ? 'ex. même histoire mais dans un restaurant, plus de tension, dialogues plus courts…' : 'ex. plus de décors, dialogues plus drôles…')}</div>
        <label class="chk keytext"><input type="checkbox" id="aKeyText"${d.keyText ? ' checked' : ''}> Mot fort à l'écran <small>Un mot-choc qui fait partie de la scène pour accrocher dès le hook : « trahie », « 50 000 € », « bleus »… Il s'écrit sur un objet ou une surface du décor au moment où il est dit, en 3D, éclairé comme le reste, avec un effet d'apparition et une couleur que Claude tire de l'histoire (les cheveux bleus de la sœur → un mot bleu). Dans le hook et à un autre moment fort au plus, hors de la zone des légendes TikTok. Jamais une phrase. Décoché : aucun texte dans les clips, même pour une suite.</small></label>
        <div class="block partbox"><label for="aPart"><span>Numéro de la partie <small>Écrit sur la miniature.</small></span></label><span class="inline stepper"><span class="partlbl">PARTIE</span><button type="button" class="stepbtn" data-auto="partStep" data-d="-1" aria-label="Partie d'avant">‹</button><input id="aPart" type="number" min="1" max="99" value="${d.part}"><button type="button" class="stepbtn" data-auto="partStep" data-d="1" aria-label="Partie d'après">›</button></span></div>
        ${d.mode === 'suite' ? '<div id="miniPrevBox" class="block miniprev"></div>' : ''}
        ${miniPickHtml(d.miniStyle || settings.auto.miniStyle, 'mini')}
      </div>`)}
      ${step(4, 'Lancer', '', busy() ? `<div class="launch-busy"><p><b>Une vidéo est déjà en cours.</b> Tu peux mettre celle-ci à la suite, ou la lancer tout de suite : la vidéo en cours est alors mise de côté, sans rien perdre, et tu la continues quand tu veux.</p>
        <div class="row"><button class="btn primary big" type="button" data-auto="launch" data-now="1">${H.icon('bolt')}Lancer maintenant</button><button class="btn big" type="button" data-auto="launch">${H.icon('clock')}Ajouter à la file d'attente</button><button class="btn big ghost" type="button" data-auto="backLive">Revenir à la vidéo en cours</button></div></div>`
      : `<div class="row"><button class="btn primary big" type="button" data-auto="launch">${H.icon('sparkle')}Lancer l'automatisation</button><span class="muted">Une vidéo à la fois. Rien n'est publié sans ton accord.</span></div>`, ' last')}
    </section>`;
}
/* ---------- personnages : classés par style d'apparence ---------- */
/* Planches enregistrées avant la 4.4.0 : elles n'ont pas de style. On reprend une fois celui de leur production d'origine, si elle existe encore. */
let charsSorted = false;
async function classifyOld(chars) {
  if (charsSorted) return chars;
  charsSorted = true;
  const todo = chars.filter((c) => c.style === undefined);
  if (!todo.length) return chars;
  const prods = new Map((await DB.allProds().catch(() => [])).map((p) => [p.id, p]));
  for (const c of todo) {
    const p = prods.get(c.from) || [...prods.values()].find((x) => x.series && x.series === c.series) || null;
    const k = (p && (p.styleKey || p.style)) || '';
    c.style = k === 'video' ? '' : k; c.styleLabel = k === 'video' ? '' : ((p && p.styleLabel) || '');
    await DB.putChar({ ...c, at: c.at }).catch(() => {});
  }
  return chars;
}
/* Les styles qui servent à classer : ceux du lanceur (fournis et enregistrés), ceux créés depuis Personnages, et ceux déjà portés par une planche */
function charStyles(settings, chars) {
  const out = new Map();
  for (const x of styleList(settings.auto)) out.set(x.k, x.label);
  for (const n of settings.auto.charStyles || []) out.set('x:' + n, n);
  for (const c of chars) if (c.style && !out.has(c.style)) out.set(c.style, c.styleLabel || (c.style === 'autre' ? 'Style décrit à la main' : c.style.replace(/^x:/, '')));
  return out; // clé → nom
}
const charShown = (c) => (!charFilter.style || (charFilter.style === '?' ? !c.style : c.style === charFilter.style))
  && (!charFilter.q || `${c.name} ${c.seriesTitle || ''}`.toLowerCase().includes(charFilter.q.toLowerCase()));
function charToolbar(chars, styles, where) {
  const count = (fn) => chars.filter(fn).length, used = [...styles.keys()].filter((k) => chars.some((c) => c.style === k));
  const chip = (v, label, n) => `<button type="button" class="fchip${charFilter.style === v ? ' on' : ''}" aria-pressed="${charFilter.style === v}" data-auto="charFilter" data-v="${H.esc(v)}" data-where="${where}">${H.esc(label)} <small>${n}</small></button>`;
  return `<div class="chartools">
    <input id="${where === 'pick' ? 'pQuery' : 'cQuery'}" type="search" placeholder="Chercher un personnage ou une histoire…" value="${H.esc(charFilter.q)}" aria-label="Chercher un personnage ou une histoire">
    <div class="frow" role="group" aria-label="Filtrer par style">${chip('', 'Tous', chars.length)}${used.map((k) => chip(k, styles.get(k), count((c) => c.style === k))).join('')}${count((c) => !c.style) ? chip('?', 'Sans style', count((c) => !c.style)) : ''}</div></div>`;
}
/* Une planche : petite vignette (clic = la voir en grand), case à cocher, corbeille */
function charCard(c, styles, where, checked) {
  const name = H.esc(c.name), id = H.esc(c.id);
  return `<article class="chcard${checked ? ' on' : ''}" data-card="${id}">
    <button type="button" class="chthumb" data-auto="zoomChar" data-id="${id}" title="Voir en grand" aria-label="Voir la planche de ${name} en grand"><img data-char="${id}" alt="" loading="lazy"></button>
    <label class="chtick" title="${where === 'pick' ? 'Reprendre dans cette vidéo' : 'Cocher pour classer ou supprimer'}"><input type="checkbox" data-char-tick="${id}" data-where="${where}"${checked ? ' checked' : ''} aria-label="${where === 'pick' ? 'Reprendre' : 'Cocher'} ${name}"></label>
    <button type="button" class="chdel" data-auto="trashChar" data-id="${id}" data-where="${where}" title="Mettre à la corbeille" aria-label="Mettre ${name} à la corbeille">${H.icon('trash')}</button>
    <div class="chname"><b title="${name}">${name}</b><small>${H.esc((c.style && styles.get(c.style)) || 'Sans style')}</small></div></article>`;
}
/* Les planches rangées par histoire ; les trois premières histoires sont dépliées, les autres se déplient d'un clic */
function charGroups(list, styles, where, isChecked) {
  const groups = new Map();
  list.forEach((c) => { const g = c.seriesTitle || 'Sans histoire'; if (!groups.has(g)) groups.set(g, []); groups.get(g).push(c); });
  const filtered = !!(charFilter.style || charFilter.q);
  return [...groups.entries()].map(([g, items], n) => {
    const key = `${where}:${g}`, open = filtered || (groupOpen.has(key) ? groupOpen.get(key) : n < 3), all = items.every(isChecked);
    return `<details class="chgroup" data-group="${H.esc(key)}"${open ? ' open' : ''}><summary><b>${H.esc(g)}</b><small>${items.length}</small><span class="spacer"></span><button type="button" class="linkbtn" data-auto="charTickAll" data-where="${where}" data-series="${H.esc(g)}" data-on="${all ? '0' : '1'}">${all ? 'Tout décocher' : 'Tout cocher'}</button></summary>
      <div class="chgrid">${items.map((c) => charCard(c, styles, where, isChecked(c))).join('')}</div></details>`;
  }).join('');
}

/* Lanceur, étape 2 : la tuile « + » ouvre la fenêtre « Mes personnages » ; les personnages choisis s'affichent à côté, en petit */
async function fillCast() {
  const box = H.$('#castBox'); if (!box) return;
  const chars = await DB.allChars();
  if (draft.charIds === null) {
    const prev = draft.mode === 'suite' && draft.prevId ? await DB.getProd(draft.prevId).catch(() => null) : null;
    draft.charIds = prev ? chars.filter((c) => c.series === prev.series).map((c) => c.id) : [];
  }
  draft.charIds = draft.charIds.filter((id) => chars.some((c) => c.id === id));
  syncThumbs(chars);
  const picked = draft.charIds.map((id) => chars.find((c) => c.id === id));
  box.innerHTML = `<span>Personnages à reprendre <small>Facultatif. ${draft.mode === 'suite' ? 'Ceux de la partie précédente sont déjà choisis.' : 'L\'histoire se jouera avec eux.'} Leurs planches sont rechargées telles quelles, sans être redessinées.</small></span>
    <div class="castrow">
      <button type="button" class="addtile" data-auto="pickOpen"><span class="plus" aria-hidden="true"></span><span><b>Importer des personnages</b><small>depuis Mes personnages</small></span></button>
      ${picked.map((c) => `<span class="castchip"><button type="button" class="cthumb" data-auto="zoomChar" data-id="${H.esc(c.id)}" title="Voir en grand" aria-label="Voir la planche de ${H.esc(c.name)} en grand"><img data-char="${H.esc(c.id)}" alt=""></button><b>${H.esc(c.name)}</b><button type="button" class="cx" data-auto="castDrop" data-id="${H.esc(c.id)}" aria-label="Retirer ${H.esc(c.name)}">${H.icon('close')}</button></span>`).join('')}
    </div>
    ${chars.length ? '' : '<p class="hint">Aucune planche enregistrée pour l\'instant : elles arrivent dans Personnages après ta première production.</p>'}`;
  hydrateMedia(box);
}
/* Fenêtre « Mes personnages » : on coche ceux qu'on reprend ; clic sur une image = la voir en grand */
async function renderPicker() {
  const body = H.$('#charDlgBody'); if (!body) return;
  const [chars, settings] = await Promise.all([DB.allChars(), getSettings()]);
  await classifyOld(chars);
  if (draft.charIds === null) draft.charIds = [];
  syncThumbs(chars);
  const styles = charStyles(settings, chars), shown = chars.filter(charShown);
  const focus = document.activeElement && document.activeElement.id === 'pQuery', keep = body.scrollTop;
  body.innerHTML = chars.length ? `${charToolbar(chars, styles, 'pick')}
      ${shown.length ? `<div class="chlib">${charGroups(shown, styles, 'pick', (c) => draft.charIds.includes(c.id))}</div>` : '<p class="hint">Aucun personnage ne correspond. Change de style ou efface la recherche.</p>'}`
    : '<div class="empty"><h3>Aucune planche enregistrée</h3><p>Elles arrivent ici après ta première production. Tu peux aussi en ajouter à la main dans l\'onglet Personnages.</p></div>';
  pickCount();
  hydrateMedia(body); body.scrollTop = keep;
  if (focus) { const q = H.$('#pQuery'); if (q) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } }
}
const pickCount = () => { const n = (draft.charIds || []).length, el = H.$('#charDlgCount'); if (el) el.textContent = n ? `${n} personnage${n > 1 ? 's' : ''} choisi${n > 1 ? 's' : ''}` : 'Coche les personnages à reprendre'; };

/* Suite : reprendre la miniature de la partie précédente (même image, seul le numéro change) */
let miniPrevUrl = '';
async function fillMiniPrev() {
  const box = H.$('#miniPrevBox'); if (!box) return;
  const prev = draft.prevId ? await DB.getProd(draft.prevId).catch(() => null) : null;
  const mk = prev && prev.pkg && prev.pkg.miniature && prev.pkg.miniature.status === 'done' ? prev.pkg.miniature.key : '';
  if (miniPrevUrl) { URL.revokeObjectURL(miniPrevUrl); miniPrevUrl = ''; }
  if (!mk && draft.miniFile) miniPrevUrl = URL.createObjectURL(draft.miniFile);
  const has = !!(mk || draft.miniFile);
  box.innerHTML = `<span>Miniature de la partie précédente <small>${has ? 'Son titre est gardé tel quel (mêmes mots, même lettrage, mêmes effets, même place) avec le nouveau numéro. L\'image, elle, est nouvelle : la scène de cette partie.' : 'Donne son image pour garder le même titre (mêmes mots, même lettrage) avec le nouveau numéro. Sinon ChatGPT invente un nouveau titre.'}</small></span>
    ${has ? `<div class="miniprevrow">${mk ? `<img data-media="${H.esc(mk)}" alt="Miniature de la partie précédente">` : `<img src="${miniPrevUrl}" alt="Miniature de la partie précédente">`}
        <span class="minito" aria-hidden="true">→</span><span class="partlbl" id="miniPrevPart">PARTIE ${draft.part}</span>
        <label class="chk"><input type="checkbox" id="aMiniReuse"${draft.miniReuse !== false ? ' checked' : ''}> Garder ce titre</label>
        ${mk ? '' : '<button class="btn small ghost" type="button" data-auto="miniFileClear">Retirer</button>'}</div>`
    : '<input id="aMiniFile" type="file" accept="image/*">'}`;
  hydrateMedia(box);
}
let prevAll = false; // choix de la partie précédente : toutes les histoires affichées, ou seulement les plus récentes
const prodCover = (p) => { const k = p.pkg; return (k && ((k.miniature && k.miniature.status === 'done' && k.miniature.key) || (k.scenes.find((x) => x.imgStatus === 'done') || {}).imgKey)) || ''; };
async function fillSuite() {
  const box = H.$('#suiteBox'); if (!box) return;
  const prods = await DB.allProds();
  const withPkg = prods.filter((p) => p.pkg);
  if (draft.prevId && !withPkg.some((p) => p.id === draft.prevId)) draft.prevId = '';
  const prev = withPkg.find((p) => p.id === draft.prevId);
  const MAX = 7;
  let shown = prevAll ? withPkg : withPkg.slice(0, MAX);
  if (prev && !shown.includes(prev)) shown = [prev, ...shown.slice(0, MAX - 1)];
  // la vidéo finale de la partie choisie est-elle encore dans FruitRadar ? (elle part alors toute seule chez Claude)
  const hasVideo = !!(prev && prev.finalKey && await DB.getMedia(prev.finalKey).catch(() => null));
  const card = (p) => {
    const key = prodCover(p), m = (p.pkg && p.pkg.meta) || {}, on = p.id === draft.prevId;
    return `<button type="button" class="prevcard${on ? ' on' : ''}" role="radio" aria-checked="${on}" data-auto="prevPick" data-id="${H.esc(p.id)}" title="${H.esc(m.titre || p.title || '')}">
        <span class="prevthumb">${key ? `<img data-media="${H.esc(key)}" alt="">` : H.icon('sparkle')}<span class="prevpart">Partie ${H.esc(p.part || 1)}</span></span>
        <span class="prevtxt"><b>${H.esc(m.titre || p.title || 'Sans titre')}</b><small>${when(p.createdAt)}${p.finalKey ? '' : ' · sans vidéo finale'}</small></span></button>`;
  };
  const fileBlock = (hint) => `<div class="block prevfile"><span>Vidéo de la partie précédente <small>${hint}</small></span>
        ${draft.prevFile ? `<p class="pickedfile">${H.icon('film')}<b>${H.esc(draft.prevFile.name)}</b> <span class="muted">${(draft.prevFile.size / 1048576).toFixed(1).replace('.', ',')} Mo</span> <button class="btn small ghost" type="button" data-auto="prevFileClear">Retirer</button></p>` : '<input id="aPrevFile" type="file" accept="video/*">'}</div>`;
  const k = prev && prev.pkg, pm = (k && k.meta) || {}, cover = prev ? prodCover(prev) : '';
  box.innerHTML = `
    <div class="block"><span>Partie précédente <small>Clique sur l'histoire à continuer.</small></span>
      <div class="prevgrid" role="radiogroup" aria-label="Partie précédente">
        ${shown.map(card).join('')}
        <button type="button" class="prevcard other${prev ? '' : ' on'}" role="radio" aria-checked="${!prev}" data-auto="prevPick" data-id="">
          <span class="prevthumb">${H.icon('film')}</span>
          <span class="prevtxt"><b>Une autre histoire</b><small>Faite hors de FruitRadar ou supprimée : je donne la vidéo ou un résumé</small></span></button>
      </div>
      ${withPkg.length > MAX ? `<button class="linkbtn prevmore" type="button" data-auto="prevMore">${prevAll ? 'Réduire la liste' : `Voir les ${withPkg.length} histoires`}</button>` : ''}
    </div>
    ${prev ? `<div class="prevshow">
        <div class="prevvideo">${hasVideo ? `<video data-media="${H.esc(prev.finalKey)}" controls playsinline preload="metadata"></video>` : cover ? `<img data-media="${H.esc(cover)}" alt="">` : `<span class="prevnone">${H.icon('film')}</span>`}</div>
        <div class="previnfo">
          <b>${H.esc(pm.titre || prev.title || 'Sans titre')}</b>
          <small class="muted">Partie ${H.esc(prev.part || 1)} · ${k.scenes.length} scènes · ${totalDuration(k)} s · faite le ${when(prev.createdAt)}</small>
          ${pm.accroche ? `<p class="prevhook">« ${H.esc(pm.accroche)} »</p>` : ''}
          ${hasVideo ? `<p class="prevok">${H.icon('check')}<span>Claude reçoit toute cette vidéo en images (planches de lecture), le script exact de l'histoire jusqu'à sa dernière réplique, et son package. Rien à faire.</span></p>`
    : `<p class="prevwarn">Pas de vidéo finale dans FruitRadar pour cette partie. Claude aura quand même son script exact, jusqu'à la dernière réplique. Pour qu'il voie aussi les images, donne le fichier de la vidéo (je le chercherai sinon dans tes Téléchargements).</p>${fileBlock('Facultatif. Sans vidéo, Claude écrit la suite à partir du script exact de cette partie.')}`}
        </div>
      </div>` : `${fileBlock('Donne le fichier de la vidéo. Claude la regarde en entier pour écrire la suite (personnages, voix, décor, question laissée ouverte).')}
      <div class="block"><label for="aPrevBible"><span>Résumé des parties précédentes <small>${draft.prevFile ? 'Facultatif avec la vidéo : ajoute ce que la vidéo ne montre pas (parties plus anciennes, noms des personnages). Tu peux dicter.' : 'Ce qui s\'est passé, les personnages, leurs voix, la question laissée ouverte. Tu peux dicter.'}</small></span></label>${voiceField('aPrevBible', 4, draft.prevBible)}</div>`}
    <div class="block"><label for="aIdea"><span>Ce que tu veux dans cette partie <small>Facultatif. Tu peux dicter.</small></span></label>${voiceField('aIdea', 2, draft.idea)}</div>`;
  hydrateMedia(box);
}

/* Verdict lisible à partir de ce que la page renvoie */
function verdict(k, r, settings, me) {
  if (!r) return { ok: false, label: 'Erreur', detail: 'Pas de réponse de la page.' };
  if (r.error) return { ok: false, label: 'Erreur', detail: r.error };
  if (r.block === 'connexion') return { ok: false, label: 'À connecter', detail: 'Tu n\'es pas connecté à ce site dans ce Chrome. Ouvre-le, connecte-toi, puis reteste.' };
  if (r.block) return { ok: false, label: 'Vérification demandée', detail: 'Le site demande une vérification (captcha). Ouvre-le, valide-la, puis reteste.' };
  const need = k === 'turbo' || k === 'vt' ? [] : k === 'capcut' || k === 'tiktok' ? [['le champ d\'import', r.fileInputs > 0]] : [['la zone de saisie', r.composer], ['les pièces jointes', r.fileInputs > 0]];
  const miss = need.filter(([, ok]) => !ok).map(([l]) => l);
  if (miss.length) return { ok: false, label: 'Page inattendue', detail: `La page s'ouvre mais je ne retrouve pas ${miss.join(' ni ')}. Vérifie que tu es connecté ; sinon envoie le diagnostic.` };
  if (k === 'tiktok') {
    const want = String(settings.auto.tiktokAccount || '').toLowerCase();
    if (me && me.ok && want && me.uniqueId.toLowerCase() !== want) return { ok: false, label: 'Mauvais compte', detail: `TikTok est connecté sur @${me.uniqueId}, pas sur ton compte de publication @${want}. Change de compte sur tiktok.com.` };
    if (me && me.ok) return { ok: true, label: 'Connecté', detail: `Connecté sur @${me.uniqueId}${want ? ', ton compte de publication' : ''}.` };
  }
  return { ok: true, label: 'Connecté', detail: 'Prêt.' };
}
const agoText = (t) => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'à l\'instant' : m < 60 ? `il y a ${m} min` : m < 1440 ? `il y a ${Math.round(m / 60)} h` : `le ${new Date(t).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}`; };
function connHtml(settings) {
  const a = settings.auto, anyBusy = testing.size > 0;
  const okN = CONN.filter(([k]) => checks[k] && checks[k].ok).length, tested = CONN.filter(([k]) => checks[k]).length;
  const cards = CONN.map(([k, role]) => {
    const c = checks[k], run = testing.has(k);
    const cls = run ? 'busy' : c ? (c.ok ? 'ok' : 'no') : 'idle';
    const pill = run ? 'Test en cours…' : c ? c.label : 'Pas encore testé';
    return `<article class="conn ${cls}">
        <div class="conn-top"><span class="conn-logo" aria-hidden="true">${H.esc(SITES[k].name[0])}</span><div class="conn-name"><b>${H.esc(SITES[k].name)}</b><small>${H.esc(role)}</small></div><span class="conn-pill">${run ? '<span class="spin" aria-hidden="true"></span>' : ''}${H.esc(pill)}</span></div>
        <p class="conn-detail">${run ? 'J\'ouvre le site quelques secondes dans un onglet…' : c ? `${H.esc(c.detail)} <span class="muted">Vérifié ${agoText(c.at)}.</span>` : 'Tu dois être connecté à ce site dans ce Chrome.'}</p>
        <div class="row"><button class="btn small" type="button" data-auto="diag" data-k="${k}"${anyBusy ? ' disabled' : ''}>${H.icon('refresh')}Tester</button>
          <a class="btn small ghost" href="${H.esc(START_URL(k, a))}" target="_blank" rel="noopener">${H.icon('ext')}${c && !c.ok ? 'Ouvrir et me connecter' : 'Ouvrir'}</a></div>
      </article>`;
  }).join('');
  return `<section class="panel" id="connPanel">
      <div class="panel-head"><div><h3>Connexions aux sites</h3><p class="hint">${tested ? `${okN} sur ${CONN.length} connecté${okN > 1 ? 's' : ''}.` : 'FruitRadar pilote ces sites avec tes comptes : il faut être connecté à chacun dans ce Chrome.'} Le test ouvre le site quelques secondes et vérifie que tout y est.</p></div>
        <div class="row"><button class="btn primary" type="button" data-auto="diag"${anyBusy ? ' disabled' : ''}>${H.icon('plug')}${anyBusy ? 'Test en cours…' : 'Tout tester'}</button></div></div>
      <div class="conn-grid">${cards}</div>
      <div class="row">${diagRes && !anyBusy && Object.keys(diagRes).length ? `<button class="btn small ghost" type="button" data-auto="copyDiag" title="À envoyer quand un site ne répond plus : la liste des boutons et des champs que FruitRadar voit">${H.icon('copy')}Copier le diagnostic</button>` : ''}
      <button class="btn small ghost" type="button" data-action="autoSettings">${H.icon('gear')}Réglages de la création</button></div>
    </section>`;
}

/* Les histoires proposées par Claude : une carte claire par idée, le dernier lot en premier */
let ideaNote = '';
let ideaEdits = {}; // { [production] : { [n° de l'idée] : { titre, accroche, histoire, cast: [{ name, role }], at } } } : tes changements, gardés dans ce Chrome jusqu'au choix
let ideaForm = null; // l'idée en cours de modification : { id, n, titre, accroche, histoire, cast }
async function saveIdeaEdits() { // on garde les changements des 40 dernières productions
  const ids = Object.keys(ideaEdits), last = (id) => Math.max(0, ...Object.values(ideaEdits[id] || {}).map((e) => e.at || 0));
  if (ids.length > 40) for (const id of ids.sort((a, b) => last(a) - last(b)).slice(0, ids.length - 40)) delete ideaEdits[id];
  await chrome.storage.local.set({ ideaEdits });
}
function readIdeaForm() { // ce qui est écrit dans la carte en cours de modification
  const box = H.$('.story.editing'); if (!box || !ideaForm) return;
  const v = (sel, d) => { const el = box.querySelector(sel); return el ? el.value : d; };
  ideaForm.titre = v('[data-ie=titre]', ideaForm.titre); ideaForm.accroche = v('[data-ie=accroche]', ideaForm.accroche); ideaForm.histoire = v('[data-ie=histoire]', ideaForm.histoire);
  ideaForm.cast = ideaForm.cast.map((c, k) => ({ name: v(`[data-ie=name][data-i="${k}"]`, c.name), role: v(`[data-ie=role][data-i="${k}"]`, c.role) }));
}
function storyCard(i0, canPick, pid) {
  if (ideaForm && ideaForm.id === pid && ideaForm.n === i0.n) return storyEditHtml(i0);
  const ed = (ideaEdits[pid] || {})[i0.n], i = ed ? P.applyIdeaEdit(i0, ed) : i0;
  const cast = P.parseCast(i.personnages);
  const parts = String(i.parties || '').trim();
  return `<article class="story${ed || i0.edited ? ' edited' : ''}">
      <header class="story-top"><span class="story-n" aria-label="Idée ${i.n}">${i.n}</span><h4>${H.esc(i.titre)}</h4>${ed || i0.edited ? '<span class="story-mod">Modifiée</span>' : ''}</header>
      ${i.accroche ? `<div class="story-hook"><span>Les 2 premières secondes</span><p>${H.esc(i.accroche)}</p></div>` : ''}
      <div class="story-sec"><span>L'histoire</span><p class="story-text">${H.esc(i.histoire || i.pitch || '')}</p></div>
      ${cast.length ? `<div class="story-sec"><span>Les personnages</span><ul class="story-cast">${cast.map((c) => `<li><b>${H.esc(c.name)}</b>${c.role ? `<small>${H.esc(c.role)}</small>` : ''}</li>`).join('')}</ul></div>` : ''}
      ${i.pourquoi ? `<p class="story-why">${H.icon('rocket')}<span><b>Pourquoi ça peut percer :</b> ${H.esc(i.pourquoi)}</span></p>` : ''}
      <footer class="story-foot">${parts ? `<span class="story-parts">${H.icon('film')}${H.esc(parts)} partie${parts === '1' ? '' : 's'} possible${parts === '1' ? '' : 's'}</span>` : '<span></span>'}
        <span class="story-acts"><button class="btn" type="button" data-auto="ideaEdit" data-n="${i.n}" title="Changer le contexte, les noms ou l'apparence des personnages avant de la choisir">${H.icon('pen')}Modifier</button>
        <button class="btn primary story-go" type="button" data-auto="choose" data-n="${i.n}"${canPick ? '' : ' disabled'}>${H.icon('check')}Choisir cette histoire</button></span></footer>
    </article>`;
}
/* La carte d'une idée en modification : titre, accroche, histoire, et chaque personnage (nom, puis qui c'est et à quoi il ressemble) */
function storyEditHtml(i0) {
  const f = ideaForm, ed = (ideaEdits[f.id] || {})[i0.n];
  const row = (c, k) => `<li><input data-ie="name" data-i="${k}" maxlength="40" placeholder="Nom" value="${H.esc(c.name)}" aria-label="Nom du personnage ${k + 1}">
      <input data-ie="role" data-i="${k}" maxlength="200" placeholder="ex. pêche, la grande sœur, robe rouge" value="${H.esc(c.role)}" aria-label="Qui est le personnage ${k + 1}, à quoi il ressemble">
      <button class="btn small ghost ie-del" type="button" data-auto="ideaCastDel" data-i="${k}" aria-label="Retirer ${H.esc(c.name || 'ce personnage')}">${H.icon('close')}</button></li>`;
  return `<article class="story editing" aria-label="Modifier l'idée ${i0.n}">
      <header class="story-top"><span class="story-n" aria-hidden="true">${i0.n}</span><h4>Modifier l'idée</h4></header>
      <label class="ie-field"><span>Titre</span><input data-ie="titre" maxlength="140" value="${H.esc(f.titre)}"></label>
      <label class="ie-field"><span>Les 2 premières secondes</span><textarea data-ie="accroche" rows="2" maxlength="300">${H.esc(f.accroche)}</textarea></label>
      <label class="ie-field"><span>L'histoire <small>Le contexte, ce qui se passe, le retournement, la fin.</small></span><textarea data-ie="histoire" rows="5" maxlength="1500">${H.esc(f.histoire)}</textarea></label>
      <div class="ie-field"><span>Les personnages <small>Le nom, puis qui c'est et à quoi il ressemble : fruit ou légume, rôle, tenue…</small></span>
        <ul class="ie-cast">${f.cast.map(row).join('')}</ul>
        ${f.cast.length < 10 ? `<button class="btn small ghost ie-add" type="button" data-auto="ideaCastAdd">${H.icon('user')}Ajouter un personnage</button>` : ''}</div>
      <footer class="story-foot ie-foot">${ed ? '<button class="btn ghost" type="button" data-auto="ideaReset">Revenir à l\'idée de Claude</button>' : '<span></span>'}
        <span class="story-acts"><button class="btn" type="button" data-auto="ideaCancel">Annuler</button><button class="btn primary" type="button" data-auto="ideaSave">${H.icon('check')}Enregistrer</button></span></footer>
    </article>`;
}
function ideasHtml(p, live) {
  const busyMore = !!p.ideasBusy;
  const canPick = live && p.status === 'waiting' && !busyMore;
  const last = Math.max(...p.ideas.map((x) => x.batch || 1));
  const fresh = p.ideas.filter((x) => (x.batch || 1) === last), older = p.ideas.filter((x) => (x.batch || 1) !== last);
  const range = (list) => `${Math.min(...list.map((x) => x.n))} à ${Math.max(...list.map((x) => x.n))}`;
  return `<section class="pick" aria-label="Choix de l'histoire">
      <div class="pick-head"><div><h3>Choisis ton histoire</h3><p>${p.ideas.length} idées${older.length ? `, les plus récentes d'abord (${range(fresh)})` : ''}. « Modifier » change le contexte, les noms ou l'apparence des personnages avant de choisir. Aucune ne te plaît ? Oriente et redemande-en dix.</p></div></div>
      <div class="pick-ask">
        <label for="aIdeaNote">Oriente la suite <small>Facultatif. Ce texte part avec l'histoire que tu choisis (pour l'ajuster), ou avec les 10 nouvelles idées (pour changer de direction). Tu peux dicter.</small></label>
        <div class="pick-askrow">${voiceField('aIdeaNote', 2, ideaNote, 'Ex. : une trahison entre sœurs, une fin plus choquante, avec des pêches et des cerises…')}
        <button class="btn" type="button" data-auto="moreIdeas"${canPick ? '' : ' disabled'}>${H.icon('refresh')}10 nouvelles idées</button></div>
        ${chips('aIdeaNote')}
      </div>
      ${busyMore ? '<div class="pick-busy" role="status"><span class="spin" aria-hidden="true"></span>Claude écrit 10 nouvelles idées…</div>' : ''}
      ${!live ? '<p class="muted small">La fenêtre d\'automatisation est fermée : clique sur « Continuer » pour pouvoir choisir.</p>' : ''}
      <div class="pick-grid">${fresh.map((i) => storyCard(i, canPick, p.id)).join('')}</div>
      ${older.length ? `<details class="pick-older"><summary>Idées précédentes (${range(older)})</summary><div class="pick-grid">${older.sort((a, b) => a.n - b.n).map((i) => storyCard(i, canPick, p.id)).join('')}</div></details>` : ''}
    </section>`;
}
async function gateHtml(p, live) {
  const au = (await getSettings()).auto, k = p.pkg || {};
  const acc = String(au.tiktokAccount || '').replace(/^@/, '');
  const off = live ? '' : ' disabled title="La fenêtre d\'automatisation est fermée : relance la production"';
  const info = p.finalInfo ? `${p.finalInfo.w} × ${p.finalInfo.h}, ${String(p.finalInfo.dur).replace('.', ',')} s, ${(p.finalInfo.size / 1048576).toFixed(1).replace('.', ',')} Mo` : '';
  const desc = k.description ? `<details class="logbox" open><summary>Description qui sera collée</summary><pre class="descbox">${H.esc(k.description)}</pre></details>` : '';
  const mini = k.miniature && k.miniature.key ? `<img class="gatemini" data-media="${H.esc(k.miniature.key)}" alt="Miniature">` : '';
  if (p.gate === 'montage') {
    const c = p.capcut || {}, sc = k.scenes || [], n = sc.length, tot = sc.reduce((t, x) => t + (Number(x.duree) || 0), 0);
    const mmss = tot < 60 ? `${tot} s` : `${Math.floor(tot / 60)} min ${String(tot % 60).padStart(2, '0')}`;
    const wantFade = n > 1 && c.fadeWanted !== false; // fondus décochés dans les réglages : ni repère sur la bande, ni point à vérifier
    const strip = sc.map((x, i) => `${i && wantFade ? '<span class="mfade" title="Fondu au noir attendu ici" aria-hidden="true"></span>' : ''}<figure class="mclip">${x.imgKey ? `<img data-media="${H.esc(x.imgKey)}" alt="">` : '<span class="nothumb"></span>'}<figcaption><b>${pad(x.n)}</b>${x.duree} s</figcaption></figure>`).join('');
    const line = (ok, title, yes, no) => `<li class="${ok ? 'ok' : 'todo'}"><span class="mstate" aria-hidden="true">${H.icon(ok ? 'check' : 'eye')}</span><div><b>${title}</b><small>${ok ? yes : no}</small></div><em>${ok ? 'Fait par FruitRadar' : 'À regarder'}</em></li>`;
    return `<section class="gate montage" aria-label="Vérification du montage CapCut">
      <div class="gate-head"><h3>Vérifie le montage dans CapCut avant l'export</h3><p>L'export prend 3 à 4 minutes : autant partir d'un montage juste. ${wantFade ? 'Trois' : 'Deux'} points à regarder dans l'onglet CapCut, puis tu lances l'export d'ici.</p></div>
      <div class="mstrip" role="img" aria-label="Les ${n} scènes dans l'ordre attendu">${strip}</div>
      <p class="mtotal">${n} scènes, durée attendue : ${mmss} environ</p>
      <ol class="mchecks">
        ${line((c.placed || 0) >= n && n > 0, 'Les scènes se suivent dans l\'ordre', `${c.placed} clips posés sur ${n}, de la scène 01 à la scène ${pad(n)}.`, `${c.placed || 0} clips posés sur ${n} : compare avec la bande ci-dessus.`)}
        ${line(!!c.oneTrack, 'Tout est sur une seule piste', 'Les clips sont à la suite sur la piste principale, pas en escalier.', 'Regarde la chronologie : si les clips sont en escalier, glisse-les sur la piste du haut.')}
        ${wantFade ? line(!!c.transitions, 'Un fondu au noir entre chaque scène', `${n - 1} transitions Black Fade posées.`, `Il en faut ${n - 1}. Survole la jonction de deux clips, clique sur l'icône de transition, choisis Black Fade, puis « Appliquer à tout ».`) : ''}
      </ol>
      <div class="row">
        <button class="btn" type="button" data-auto="gate" data-v="show"${off}>${H.icon('film')}Ouvrir CapCut</button>
        <button class="btn primary" type="button" data-auto="gate" data-v="mok"${off}>Le montage est bon, exporter</button>
        <button class="btn" type="button" data-auto="gate" data-v="mredo"${off}>Refaire le montage</button>
      </div>
      <p class="muted small">Cette pause se règle dans Réglages, « Vérifier le montage CapCut avant l'export » : seulement si un point n'est pas confirmé, toujours, ou jamais.</p></section>`;
  }
  if (p.gate === 'validate') {
    return `<section class="gate" aria-label="Validation de la vidéo" data-drop="final">
      <div class="gate-head"><h3>Regarde la vidéo en entier avant TikTok</h3><p>${p.finalKey ? 'C\'est le fichier exporté de CapCut. Rien n\'est envoyé sur TikTok tant que tu n\'as pas validé.' : (p.exportFile ? `La vidéo est exportée, dans tes Téléchargements : « ${H.esc(p.exportFile)} ». Je n'ai pas pu la lire moi-même : glisse ce fichier ici, ou clique sur « Déposer la vidéo exportée ». Je continue ensuite tout seul vers TikTok Studio.` : 'Je n\'ai pas pu récupérer l\'export tout seul : clique sur « Télécharger » dans CapCut, puis glisse le fichier ici (ou « Déposer la vidéo exportée »). Je continue ensuite tout seul vers TikTok Studio.')}</p>${!p.finalKey && !fileOk ? `<div class="filewarn" role="note"><b>Pour que ça n'arrive plus : une option de Chrome à activer, une seule fois</b><p>Avec « Autoriser l'accès aux URL de fichier », FruitRadar lit lui-même la vidéo arrivée dans tes Téléchargements.</p><div class="row"><button class="btn small primary" type="button" data-auto="fileAccess">Ouvrir la page de FruitRadar dans Chrome</button></div></div>` : ''}</div>
      <div class="gate-body">
        <div class="gate-video">${p.finalKey ? `<video id="finalVideo" data-media="${H.esc(p.finalKey)}" controls playsinline preload="auto"></video>` : '<div class="nothumb">' + H.icon('download') + '<small>Glisse ici la vidéo exportée</small></div>'}${info ? `<small class="muted">${H.esc(info)}</small>` : ''}</div>
        <div class="gate-side">${mini}${k.miniature && k.miniature.prompt ? `<div class="minitools">${miniSelectHtml('gMiniStyle', miniPick[p.id] || p.miniStyle || au.miniStyle)}<button class="btn small" type="button" data-auto="gate" data-v="mini"${off}>${H.icon('refresh')}Refaire la miniature</button></div>` : ''}${desc}</div>
      </div>
      <div class="row">
        <button class="btn primary" type="button" data-auto="gate" data-v="ok"${p.finalKey ? off : ' disabled'}>Valider et préparer TikTok</button>
        <button class="btn" type="button" data-auto="gate" data-v="redo"${off}>Refaire le montage</button>
        <button class="btn ${p.finalKey ? 'ghost' : 'primary'}" type="button" data-auto="finalPick">${H.icon('download')}${p.finalKey ? 'Remplacer par un autre fichier' : 'Déposer la vidéo exportée'}</button>
        ${p.finalKey ? `<a class="btn ghost" data-media="${H.esc(p.finalKey)}" download="video-finale.mp4">${H.icon('download')}Télécharger</a>` : ''}
      </div></section>`;
  }
  const notes = (p.tiktokNotes || []).length ? `<div class="banner warn inl" role="alert"><div><h2>${p.tiktokNotes.some((x) => /^le son n/i.test(x)) ? 'Le son n\'a pas été ajouté' : 'À vérifier dans TikTok Studio avant de publier'}</h2><ul class="plain">${p.tiktokNotes.map((x) => `<li>${H.esc(x.charAt(0).toUpperCase() + x.slice(1))}</li>`).join('')}</ul></div></div>` : '';
  return `<section class="gate" aria-label="Autorisation de publier">
      <div class="gate-head"><h3>Prête à publier${acc ? ` sur @${H.esc(acc)}` : ''}</h3><p>Regarde l'onglet TikTok Studio (description, couverture, légendes, son), corrige si besoin, puis donne ton accord. Je ne clique sur « Publier » qu'après ton clic ici.</p></div>
      ${p.tiktokRecap ? `<ul class="tkrecap" aria-label="Ce qui a été préparé dans TikTok Studio">${[['desc', 'Description'], ['cover', 'Couverture'], ['caps', 'Légendes'], ['sound', 'Son']].map(([k2, l]) => { const x = p.tiktokRecap[k2]; const st = !x ? 'todo' : x.skip ? 'skip' : x.ok ? 'ok' : 'no'; return `<li class="${st}"><span class="mk" aria-hidden="true">${st === 'ok' ? '✓' : st === 'skip' ? '–' : '!'}</span><b>${l}</b><small>${st === 'ok' ? `fait${k2 === 'sound' && x.why ? ` : ${H.esc(x.why)}` : ''}` : st === 'skip' ? `pas demandé (${H.esc(x.why || '')})` : `pas fait${x && x.why ? ` : ${H.esc(String(x.why).slice(0, 160))}` : ''}`}</small></li>`; }).join('')}</ul>` : ''}
      ${p.publishedBefore ? `<div class="banner warn inl" role="alert"><div><h2>Une version de cette vidéo est déjà publiée</h2><p>Publiée le ${H.esc(new Date(p.publishedBefore).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' }))}. Publier celle-ci en mettra une deuxième sur ton compte : supprime l'ancienne dans TikTok si tu ne veux garder que la nouvelle.</p></div></div>` : ''}
      ${notes}
      <div class="gate-body"><div class="gate-video">${p.finalKey ? `<video id="finalVideo" data-media="${H.esc(p.finalKey)}" controls playsinline preload="metadata"></video>` : ''}</div><div class="gate-side">${mini}</div></div>
      <div class="row">
        <button class="btn primary" type="button" data-auto="gate" data-v="publish"${off}>Publier maintenant${acc ? ` sur @${H.esc(acc)}` : ''}</button>
        <button class="btn" type="button" data-auto="gate" data-v="skip"${off}>Je publie moi-même</button>
        <button class="btn" type="button" data-auto="gate" data-v="mine"${off}>${H.icon('check')}C'est déjà publié</button>
      </div><p class="muted small">« C'est déjà publié » : tu l'as publiée toi-même dans TikTok. La production passe dans les terminées, je ne touche plus à TikTok.</p></section>`;
}
/* Les commandes d'une production : continuer, mettre de côté, recommencer, en faire une autre, supprimer */
/* Les clips sont tous là et la production a atteint CapCut : le montage peut être refait à tout moment, même une fois la vidéo terminée */
const canRemontage = (p) => !!(p && p.pkg && p.pkg.scenes && p.pkg.scenes.length && p.pkg.scenes.every((s) => s.vidStatus === 'done' && s.vidKey) && (p.capcut || p.finalKey || ['capcut', 'valider', 'tiktok', 'done'].includes(p.step)));
/* La vidéo exportée existe et TikTok Studio a déjà été préparé (ou devait l'être) : la préparation peut être refaite sans toucher au montage */
const canRetiktok = (p) => !!(p && p.finalKey && p.tiktokFlow !== false && !p.published && (p.tiktokReady || p.tiktokRecap || p.step === 'tiktok' || p.status === 'done'));
function redoBtns(p) {
  const id = H.esc(p.id);
  return (canRemontage(p) ? `<button class="btn" type="button" data-auto="remontage" data-id="${id}">${H.icon('refresh')}Refaire le montage</button>` : '')
    + (canRetiktok(p) ? `<button class="btn" type="button" data-auto="retiktok" data-id="${id}">${H.icon('refresh')}Refaire TikTok Studio</button>` : '');
}
function controlsHtml(p, live, lost) {
  const del = `<button class="btn ghost danger" type="button" data-auto="delProd" data-id="${H.esc(p.id)}">${H.icon('trash')}Supprimer</button>`;
  if (p.status === 'done') return `<div class="ctrl"><p class="ctrl-note">Production terminée.${canRemontage(p) ? ' Le montage peut encore être refait, avec les mêmes clips.' : ''}</p><div class="ctrl-btns"><button class="btn" type="button" data-auto="another">${H.icon('sparkle')}Faire une autre vidéo</button>${redoBtns(p)}<span class="spacer"></span>${del}</div></div>`;
  const active = live && !lost, b = [];
  let note = 'Mise de côté. Rien n\'est perdu : « Continuer » reprend exactement où elle en était.';
  if (active && p.status === 'paused') { b.push(`<button class="btn primary" type="button" data-auto="resume">${H.icon('play')}Reprendre</button>`); note = 'En pause : corrige ce qui bloque, puis « Reprendre ». Tu peux aussi la mettre de côté et faire une autre vidéo.'; }
  else if (active && (p.stopping || parking === p.id)) note = 'Mise de côté en cours : elle s\'arrête dès que le geste en cours est fini (quelques secondes). Rien n\'est perdu.';
  else if (active) note = p.status === 'waiting' ? 'Elle attend ton choix. Tu peux aussi la mettre de côté pour lancer une autre vidéo.' : 'En cours. « Mettre de côté » garde tout : tu lances une autre vidéo qui perce, puis tu reviens à celle-ci.';
  else if (p.status === 'queued') { b.push(`<button class="btn primary" type="button" data-auto="startNow" data-id="${H.esc(p.id)}">${H.icon('bolt')}Lancer maintenant</button>`, `<button class="btn" type="button" data-auto="unqueue" data-id="${H.esc(p.id)}">Retirer de la file</button>`); note = 'En file d\'attente : elle partira toute seule après la vidéo en cours.'; }
  else b.push(`<button class="btn primary" type="button" data-auto="restart" data-id="${H.esc(p.id)}">${H.icon('play')}Continuer</button>`);
  if (p.mode === 'remake' && p.step === 'source' && !p.sourceDone && ['paused', 'stopped'].includes(p.status)) { b.push(`<label class="btn" for="aSrcFile">${H.icon('film')}Donner le fichier de la vidéo</label><input id="aSrcFile" type="file" accept="video/*" hidden data-id="${H.esc(p.id)}">`); note += ' Si TikTok refuse le téléchargement : enregistre la vidéo toi-même, puis donne son fichier ici.'; }
  if (active) b.push(p.stopping || parking === p.id ? `<button class="btn" type="button" disabled>${H.icon('pause')}Mise de côté…</button>` : `<button class="btn" type="button" data-auto="park">${H.icon('pause')}Mettre de côté</button>`);
  if (p.finalKey || p.tiktokReady || ['valider', 'tiktok'].includes(p.step)) b.push(`<button class="btn" type="button" data-auto="markDone" data-id="${H.esc(p.id)}">${H.icon('check')}Marquer comme terminée</button>`);
  if (p.status !== 'queued') { const rb = redoBtns(p); if (rb) b.push(rb); }
  b.push(`<button class="btn" type="button" data-auto="fresh" data-id="${H.esc(p.id)}">${H.icon('refresh')}Recommencer de zéro</button>`, `<button class="btn" type="button" data-auto="another">${H.icon('sparkle')}Faire une autre vidéo</button>`);
  return `<div class="ctrl"><p class="ctrl-note">${note}</p><div class="ctrl-btns">${b.join('')}<span class="spacer"></span>${del}</div></div>`;
}
/* Les répliques d'une scène, lues dans son prompt vidéo (« RÉPLIQUE 1 — ÉTIQUETTE (…) : "…" ») */
function replicas(video) {
  return String(video || '').split('\n').map((l) => l.trim().match(/^R[ÉE]PLIQUE\s*\d+\s*[—–-]\s*(.+?)\s*:\s*["«“]\s*(.+?)\s*["»”]?\s*$/i)).filter(Boolean)
    .map((m) => ({ who: m[1].replace(/\s*\([^)]*\)\s*$/, '').trim(), text: m[2].replace(/\s*\([^)]*\)\s*/g, ' ').replace(/\s+/g, ' ').trim() }));
}
const lower1 = (s) => { const t = String(s || ''); return t === t.toUpperCase() ? t.charAt(0) + t.slice(1).toLowerCase() : t; };
/* L'histoire en clair : la série, les personnages, chaque scène avec ses répliques, la description */
function storyHtml(p) {
  const k = p.pkg, m = k.meta || {};
  const src = p.source && p.source.url ? `<a href="${H.esc(p.source.url)}" target="_blank" rel="noopener">@${H.esc(p.source.author || 'vidéo d\'origine')}</a>` : '';
  const cover = p.finalKey ? `<video data-media="${H.esc(p.finalKey)}" controls playsinline preload="metadata"></video>` : k.miniature && k.miniature.key ? `<img data-media="${H.esc(k.miniature.key)}" alt="Miniature">` : `<div class="nothumb">${H.icon('film')}<small>Pas encore d'image</small></div>`;
  const cast = k.planches.length ? `<div class="sheet-sec"><h4>Les personnages <small>${k.planches.length}</small></h4><ul class="castlist">${k.planches.map((pl) => `<li>${pl.status === 'done' && pl.key ? `<img data-media="${H.esc(pl.key)}" alt="">` : `<span class="nothumb">${H.icon('user')}</span>`}<b>${H.esc(pl.name)}</b></li>`).join('')}</ul></div>` : '';
  const beats = `<div class="sheet-sec"><h4>L'histoire, scène par scène <small>${k.scenes.length} scènes, ${totalDuration(k)} s</small></h4><ol class="beats">${k.scenes.map((s) => {
    const lines = replicas(s.video);
    return `<li class="beat"><div class="beat-img">${s.imgStatus === 'done' && s.imgKey ? `<img data-media="${H.esc(s.imgKey)}" alt="">` : `<span class="nothumb">${H.icon('sparkle')}</span>`}<span class="beat-n">${pad(s.n)}</span></div>
        <div class="beat-body"><div class="beat-head"><b>${H.esc(s.titre || `Scène ${s.n}`)}</b><span class="muted">${s.duree} s${s.refs && s.refs.length ? ` · ${H.esc(s.refs.join(', '))}` : ''}</span></div>
          ${lines.length ? `<ul class="lines">${lines.map((l) => `<li><span>${H.esc(lower1(l.who))}</span><q>${H.esc(l.text)}</q></li>`).join('')}</ul>` : '<p class="muted small">Scène sans dialogue.</p>'}
          ${s.montage && s.montage.fin ? `<p class="beat-end">${H.icon('share')}${H.esc(s.montage.fin)}</p>` : ''}</div></li>`;
  }).join('')}</ol></div>`;
  return `<section class="panel sheet">
      <div class="sheet-top">
        <div class="sheet-cover">${cover}</div>
        <div class="sheet-info">
          <p class="sheet-serie">${m.serie ? `Série « ${H.esc(m.serie)} » · ` : ''}partie ${H.esc(m.partie || p.part || 1)}</p>
          <h3>${H.esc(m.titre || p.title || 'Sans titre')}</h3>
          ${m.accroche ? `<p class="sheet-hook">${H.esc(m.accroche)}</p>` : ''}
          <dl class="kv">
            <dt>Type</dt><dd>${MODES[p.mode]}${src ? `, d'après ${src}` : ''}</dd>
            <dt>Durée</dt><dd>${totalDuration(k)} s en ${k.scenes.length} scènes</dd>
            ${m.moteur ? `<dt>Ressort de l'histoire</dt><dd>${H.esc(m.moteur)}</dd>` : ''}
            ${m.univers ? `<dt>Univers</dt><dd>${H.esc(m.univers)}</dd>` : ''}
            <dt>Lancée</dt><dd>${when(p.createdAt)}${p.doneAt ? `, terminée ${when(p.doneAt)}` : ''}</dd>
            <dt>État</dt><dd>${H.esc(STLABEL(p.status))}${p.published ? ', publication lancée sur TikTok' : ''}</dd>
          </dl>
          <div class="row">${p.finalKey ? `<a class="btn primary" data-media="${H.esc(p.finalKey)}" download="video-finale.mp4">${H.icon('download')}Télécharger la vidéo finale</a>` : ''}<button class="btn" type="button" data-auto="suite">${H.icon('film')}Faire la partie suivante</button><button class="btn ghost" type="button" data-auto="copy" data-what="all" data-n="0">${H.icon('copy')}Copier tout le package</button></div>
        </div>
      </div>
      ${cast}${beats}
      ${k.bible ? `<details class="sheet-sec bible"><summary>Mémoire de la série <small>ce que Claude retient pour écrire la suite</small></summary><p>${H.esc(k.bible).replace(/\n/g, '<br>')}</p></details>` : ''}
      <div class="sheet-sec"><h4>Description TikTok</h4><p class="descbox">${H.esc(k.description || '—')}</p><div class="row"><button class="btn small ghost" type="button" data-auto="copy" data-what="desc" data-n="0">${H.icon('copy')}Copier</button></div></div>
    </section>`;
}
async function prodHtml(p) {
  const au = (await getSettings()).auto;
  const live = state && state.id === p.id && busy();
  const alive = live ? await runnerAlive() : null;
  const lost = live && (!alive || alive.id !== p.id);
  const k = p.pkg;
  const canRedo = !live || lost;
  const pr = progressOf(p), last = p.log[p.log.length - 1];
  const stamp = lost ? 'paused' : p.status;
  let head = `<section class="hero ink">
      <div class="hero-top"><div><h3>${H.esc(p.title || MODES[p.mode])}</h3><p>${MODES[p.mode]}, partie ${p.part || 1}, lancée ${when(p.createdAt)}${k ? `, ${k.scenes.length} scènes, ${totalDuration(k)} s` : ''}</p></div>
        <span class="stamp ${stamp}">${lost ? 'Interrompue' : STATUS[p.status] || p.status}</span></div>
      ${railHtml(lost ? { ...p, status: 'paused' } : p)}
      ${p.status === 'done' ? '' : `<div class="now ${stamp}"><span class="spin" aria-hidden="true"></span><p>${H.esc(p.status === 'queued' && !live ? 'En file d\'attente : elle partira toute seule après la vidéo en cours.' : p.status === 'paused' ? ((p.pause && p.pause.reason) || 'En pause') : (live && state && state.msg) || (last && last.msg) || 'Démarrage…')}</p><b>${pr.total ? `${pr.done}/${pr.total}` : ''}</b>
        </div>
      <div class="meter${pr.total || p.status !== 'running' ? '' : ' wait'}"><span style="width:${pr.total ? Math.max(3, pr.pct) : 100}%"></span></div>`}
    </section>
    <section class="panel prodhead">${controlsHtml(p, live, lost)}`;
  if (lost) { // fenêtre fermée alors que la vidéo exportée manquait : on peut la déposer ici, la production repart droit vers TikTok Studio
    const drop = p.status === 'waiting' && p.gate === 'validate' && !p.finalKey;
    head += `<div class="banner warn inl"${drop ? ' data-drop="final"' : ''}><div><h2>La fenêtre d'automatisation a été fermée</h2><p>Rien n'est perdu : clique sur « Continuer », elle reprend où elle en était.${drop ? ' Tu as déjà la vidéo exportée de CapCut ? Glisse-la ici, ou dépose-la : la production repart directement vers TikTok Studio.' : ''}</p></div>${drop ? `<div class="banner-actions"><button class="btn primary" type="button" data-auto="finalPick">${H.icon('download')}Déposer la vidéo exportée</button></div>` : ''}</div>`;
  }
  else if (p.status === 'paused') head += `<div class="banner warn inl"><div><h2>En pause</h2><p>Corrige dans la fenêtre du site (connexion, captcha, limite, réglage Grok…), puis reprends : rien n'est perdu.</p></div>${p.lastDump ? `<div class="banner-actions"><button class="btn" type="button" data-auto="copyDump" title="Ce que FruitRadar voit sur la page de ${H.esc(p.lastDump.site)} : à envoyer pour caler les boutons">${H.icon('copy')}Copier le diagnostic ${H.esc(p.lastDump.site)}</button></div>` : ''}</div>`;
  else if (p.ideas && p.ideas.length && !p.pkgReady && (p.status === 'waiting' || p.ideasBusy)) head += ideasHtml(p, live && !lost);
  else if (p.status === 'waiting' && p.gate) head += await gateHtml(p, live && !lost);
  if (p.status === 'done' && p.tiktokFlow) head += `<div class="banner ok inl"><div><h2>${p.published ? 'Publication lancée sur TikTok' : p.publishedByUser ? 'Publiée par toi sur TikTok' : p.markedDone ? 'Terminée : marquée par toi' : 'Terminée : tu publies toi-même'}</h2><p>${p.published ? 'Vérifie dans TikTok Studio, onglet Contenu, que la vidéo est bien en ligne.' : p.publishedByUser ? 'Tu l\'as publiée toi-même.' : p.markedDone ? 'Tu as arrêté l\'automatisation ici.' : 'La vidéo est préparée dans l\'onglet TikTok Studio.'}</p></div>
      <div class="banner-actions">${!p.published && !p.publishedByUser ? `<button class="btn" type="button" data-auto="markPub" data-id="${H.esc(p.id)}">${H.icon('check')}C'est publié</button>` : ''}${p.finalKey ? `<a class="btn" data-media="${H.esc(p.finalKey)}" download="video-finale.mp4">${H.icon('download')}Télécharger la vidéo finale</a>` : ''}<button class="btn" type="button" data-auto="suite">Faire la partie suivante</button></div></div>`;
  else if (p.status === 'done') head += `<div class="banner ok inl"><div><h2>La vidéo est prête pour le montage</h2><p>${H.esc((p.capcut && p.capcut.note) || '')} ${(await getSettings()).auto.saveToDisk ? `Fichiers : Téléchargements/FruitRadar/Productions/${H.esc(p.folder)}.` : 'Tous les fichiers sont ci-dessous, chacun avec son bouton Télécharger.'}</p></div>
      <div class="banner-actions"><a class="btn primary" href="${H.esc((await getSettings()).auto.capcutUrl)}" target="_blank" rel="noopener">${H.icon('ext')}Ouvrir CapCut</a><button class="btn" type="button" data-auto="remontage">Refaire le montage</button><button class="btn" type="button" data-auto="suite">Faire la partie suivante</button></div></div>`;
  if (!p.pkgReady && (lost || ['paused', 'stopped'].includes(p.status)) && p.step === 'package') head += `<details class="logbox"><summary>Coller le package à la main</summary>
      <p class="hint">Si Claude a bien répondu mais que FruitRadar n'a pas su le relire : copie sa réponse entière (bouton Copier sous son message) et colle-la ici. La suite repart en automatique.</p>
      <textarea id="aPkgPaste" rows="6" spellcheck="false" placeholder="@@META@@ …"></textarea>
      <div class="row"><button class="btn" type="button" data-auto="pastePkg">Utiliser ce package</button></div></details>`;
  if (p.lastDump) head += `<p class="muted small">${p.lastDump.fixed ? 'Dernier incident, rattrapé tout seul au nouvel essai' : 'Dernier incident relevé'}${p.lastDump.at ? ` (${new Date(p.lastDump.at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })})` : ''} : ${H.esc(p.lastDump.site)}, ${H.esc(p.lastDump.why || '')}. ${p.lastDump.fixed ? 'Rien à faire.' : ''} <button class="linkbtn" type="button" data-auto="copyDump">Copier le diagnostic</button></p>`;
  head += `<details class="logbox"${p.status === 'done' ? '' : ' open'}><summary>Journal</summary><div class="row"><button class="btn small ghost" type="button" data-auto="copyLog" title="Tout le journal de cette production, à coller dans un message quand quelque chose coince">${H.icon('copy')}Copier le journal</button></div><div class="autolog">${p.log.slice(-80).map((l) => `<p class="${l.level}"><span>${new Date(l.t).toLocaleTimeString('fr-FR')}</span>${H.esc(l.msg)}</p>`).join('')}</div></details></section>`;
  if (!k) return head;
  const tab = prodTab || (p.status === 'done' ? 'histoire' : 'fabrication');
  const tabsBar = `<div class="ptabs" role="tablist" aria-label="Vue de la production">
      <button type="button" role="tab" aria-selected="${tab === 'histoire'}" class="${tab === 'histoire' ? 'on' : ''}" data-auto="ptab" data-tab="histoire">${H.icon('book')}L'histoire</button>
      <button type="button" role="tab" aria-selected="${tab === 'fabrication'}" class="${tab === 'fabrication' ? 'on' : ''}" data-auto="ptab" data-tab="fabrication">${H.icon('sparkle')}Fabrication <small>${pr.done}/${pr.total}</small></button></div>`;
  if (tab === 'histoire') return head + tabsBar + storyHtml(p);

  const item = (title, sub, mediaKey, status, btns, extra = '', isVid = false, cap = '') => `<article class="acard">
      <div class="athumb">${mediaKey ? (isVid ? `<video data-media="${H.esc(mediaKey)}" controls preload="metadata" playsinline></video>` : `<button type="button" class="zoomthumb" data-auto="zoomMedia" data-key="${H.esc(mediaKey)}" data-cap="${H.esc(cap || title)}" title="Voir en grand" aria-label="Voir ${H.esc(cap || title)} en grand"><img data-media="${H.esc(mediaKey)}" alt=""></button>`) : `<div class="nothumb">${H.icon(isVid ? 'play' : 'sparkle')}<small>${status === 'done' ? 'Fichier absent' : 'À générer'}</small></div>`}</div>
      <div class="abody"><div class="who"><b>${title}</b>${chip(status)}</div>${sub ? `<p class="muted">${sub}</p>` : ''}${extra}<div class="row">${btns}</div></div></article>`;
  // pendant que la production fabrique images et clips, « Refaire le clip » reste cliquable : la scène repart chez Grok sans rien arrêter
  const liveClips = !canRedo && ['images', 'videos'].includes(p.step);
  const redoBtn = (kind, n, label, liveOk) => `<button class="btn small" type="button" data-auto="redo" data-kind="${kind}" data-n="${H.esc(n)}"${canRedo || (liveOk && liveClips) ? '' : ' disabled title="Mets d\'abord la production de côté (bouton « Mettre de côté », en haut)"'}>${H.icon('refresh')}${label}</button>`;
  // « Importer » : ton propre fichier à la place de l'élément (image pour une planche ou une scène, vidéo pour un clip)
  const importBtn = (kind, n, liveOk) => { const on = canRedo || (liveOk && liveClips); return `<label class="btn small ghost importbtn${on ? '' : ' off'}" title="${on ? (kind === 'vid' ? 'Mettre ta vidéo à la place de ce clip' : 'Mettre ton image à la place') : 'Mets d\'abord la production de côté (bouton « Mettre de côté », en haut)'}">${H.icon('download')}Importer<input type="file" hidden data-import="${kind}" data-n="${H.esc(n)}" accept="${kind === 'vid' ? 'video/mp4,video/quicktime,video/*' : 'image/*'}"${on ? '' : ' disabled'}></label>`; };
  const dl = (key, name) => key ? `<a class="btn small ghost" data-media="${H.esc(key)}" download="${H.esc(name)}" title="Télécharger">${H.icon('download')}</a>` : '';
  const copyBtn = (what, n, label) => `<button class="btn small ghost" type="button" data-auto="copy" data-what="${what}" data-n="${H.esc(n)}">${H.icon('copy')}${label}</button>`;

  // planches reprises d'une partie précédente ou de la bibliothèque : citées par les scènes, mais pas redessinées dans cette production
  const madeNames = new Set(k.planches.map((x) => normName(x.name)));
  const cited = [...new Map([...k.scenes.flatMap((x) => x.refs || []), ...((k.miniature && k.miniature.refs) || [])].map((n) => [normName(n), n])).entries()].filter(([key]) => key && !madeNames.has(key));
  const lib = cited.length ? await DB.allChars().catch(() => []) : [];
  const reused = cited.map(([key, name]) => ({ name, c: lib.filter((x) => normName(x.name) === key).sort((a, b) => ((p.charIds || []).includes(b.id) ? 1 : 0) - ((p.charIds || []).includes(a.id) ? 1 : 0))[0] || null }));
  const reuseCard = (r) => `<article class="acard reuse">
      <div class="athumb">${r.c ? `<button type="button" class="reusethumb" data-auto="zoomChar" data-id="${H.esc(r.c.id)}" title="Voir en grand" aria-label="Voir la planche de ${H.esc(r.name)} en grand"><img data-char="${H.esc(r.c.id)}" alt=""></button>` : `<div class="nothumb">${H.icon('users')}<small>Introuvable dans tes personnages</small></div>`}</div>
      <div class="abody"><div class="who"><b>${H.esc(r.name)}</b><span class="chip">${r.c ? 'Reprise' : 'Absente'}</span></div><p class="muted">${r.c ? `Planche déjà faite${r.c.seriesTitle ? ` (${H.esc(r.c.seriesTitle)})` : ''} : rechargée telle quelle, pas redessinée.` : 'Les scènes la citent, mais elle n\'est plus dans tes personnages : les images sont faites sans elle.'}</p></div></article>`;
  const planches = k.planches.length || reused.length ? `<section class="panel"><h3>Planches <small class="muted">${k.planches.filter((x) => x.status === 'done').length}/${k.planches.length}${k.planches.length ? ' nouvelles' : ''}${reused.length ? ` · ${reused.length} reprise${reused.length > 1 ? 's' : ''}` : ''}</small></h3><div class="agrid">
      ${k.planches.map((pl, i) => item(H.esc(pl.name), '', pl.key, pl.status, redoBtn('planche', i, 'Refaire') + importBtn('planche', i) + copyBtn('planche', i, 'Prompt') + dl(pl.status === 'done' && pl.key, `planche-${pl.name}.png`), '', false, `Planche de ${pl.name}`)).join('')}
      ${reused.map(reuseCard).join('')}</div></section>` : '';
  const scenes = `<section class="panel"><h3>Scènes <small class="muted">images ${k.scenes.filter((x) => x.imgStatus === 'done').length}/${k.scenes.length} · clips ${k.scenes.filter((x) => x.vidStatus === 'done').length}/${k.scenes.length}</small>${canRedo ? ` <button class="btn small ghost" type="button" data-auto="redo" data-kind="allimg" data-n="0" title="Refait toutes les images de scène, puis leurs clips (les planches sont gardées)">${H.icon('refresh')}Refaire toutes les images de scène</button>` : ''}</h3>
      ${canRedo ? '' : `<p class="muted redonote">${liveClips ? 'La production tourne : « Refaire le clip » marche tout de suite (la scène repart chez Grok, le reste continue). Pour refaire une image ou une scène entière, clique d\'abord sur « Mettre de côté », en haut.' : 'La production tourne : pour refaire un élément, clique d\'abord sur « Mettre de côté », en haut.'}</p>`}
      <div class="scenelist">${k.scenes.map((s) => `<div class="scenerow">
        <div class="snum"><b>${pad(s.n)}</b><span>${s.duree} s</span></div>
        ${item('Image', '', s.imgStatus === 'done' ? s.imgKey : '', s.imgStatus, redoBtn('img', s.n, 'Refaire l\'image') + importBtn('img', s.n) + dl(s.imgStatus === 'done' && s.imgKey, `scene-${pad(s.n)}.png`), '', false, `Scène ${pad(s.n)}${s.titre ? ` — ${s.titre}` : ''}`)}
        ${item('Clip', s.vidStatus === 'done' && s.vidInfo && s.vidInfo.w ? `${s.vidInfo.w} × ${s.vidInfo.h}, ${String(s.vidInfo.dur).replace('.', ',')} s` : '', s.vidStatus === 'done' ? s.vidKey : '', s.vidStatus, redoBtn('vid', s.n, 'Refaire le clip', s.vidStatus === 'done') + importBtn('vid', s.n, true) + dl(s.vidStatus === 'done' && s.vidKey, `${pad(s.n)}_scene.mp4`), '', true)}
        <div class="sinfo"><h4>${H.esc(s.titre || `Scène ${s.n}`)}</h4>
          <div class="sredo">${redoBtn('scene', s.n, 'Refaire la scène')}</div>
          <dl class="kv"><dt>Durée Grok</dt><dd>${s.duree} s${s.version ? `, version ${H.esc(s.version)}` : ''}</dd>
          <dt>Planches</dt><dd>${H.esc(s.refs.join(', ') || 'aucune')}</dd>
          ${s.montage && s.montage.fin ? `<dt>Fin du clip</dt><dd>${H.esc(s.montage.fin)}</dd>` : ''}
          ${s.montage && s.montage.suivant ? `<dt>Plan suivant</dt><dd>${H.esc(s.montage.suivant)}</dd>` : ''}
          ${s.montage && s.montage.montage ? `<dt>Au montage</dt><dd><b>${H.esc(s.montage.montage)}</b></dd>` : ''}</dl>
          <div class="row">${copyBtn('image', s.n, 'Prompt image')}${copyBtn('video', s.n, 'Prompt vidéo')}</div></div>
      </div>`).join('')}</div></section>`;
  const end = `<section class="panel"><h3>Miniature et description</h3><div class="agrid two">
      ${item(`Miniature · PARTIE ${H.esc(k.meta.partie || p.part)}`, H.esc(k.meta.accroche || ''), k.miniature.key, k.miniature.status, miniSelectHtml('pMiniStyle', miniPick[p.id] || p.miniStyle || au.miniStyle) + redoBtn('mini', 0, 'Refaire dans ce style') + importBtn('mini', 0) + copyBtn('mini', 0, 'Prompt') + (k.miniature.key ? `<a class="btn small ghost" data-media="${H.esc(k.miniature.key)}" download="miniature.png">${H.icon('download')}Télécharger</a>` : ''))}
      <article class="acard text"><div class="abody"><div class="who"><b>Description TikTok</b></div><p class="descbox">${H.esc(k.description || '—')}</p><div class="row">${copyBtn('desc', 0, 'Copier')}${copyBtn('all', 0, 'Copier tout le package')}</div></div></article>
    </div></section>`;
  return head + tabsBar + planches + scenes + end;
}

async function renderProds() {
  const box = H.$('#viewProds');
  const prods = await DB.allProds();
  const isLive = (p) => !!(state && state.id === p.id && busy());
  const groups = { all: prods, live: prods.filter((p) => isLive(p) || ['running', 'queued', 'waiting'].includes(p.status)), parked: prods.filter((p) => !isLive(p) && ['stopped', 'paused'].includes(p.status)), done: prods.filter((p) => p.status === 'done') };
  if (!groups[prodFilter]) prodFilter = 'all';
  const tabs = [['all', 'Toutes'], ['live', 'En cours'], ['parked', 'Mises de côté'], ['done', 'Terminées']].map(([k2, l]) => `<button type="button" class="${prodFilter === k2 ? 'on' : ''}" data-auto="pfilter" data-f="${k2}">${l}<small>${groups[k2].length}</small></button>`).join('');
  const card = (p) => {
    const k = p.pkg, m = (k && k.meta) || {}, live = isLive(p);
    const key = k && (k.miniature && k.miniature.key || (k.scenes.find((x) => x.imgStatus === 'done') || {}).imgKey);
    const pr = progressOf(p), last = p.log && p.log[p.log.length - 1];
    const stKey = !live && p.status === 'running' ? 'stopped' : p.status;
    const why = stKey === 'paused' ? (p.pause && p.pause.reason) : stKey === 'stopped' && last ? last.msg : '';
    const canGo = !live && !['done', 'queued'].includes(p.status);
    return `<article class="pcard ${stKey}">
        <button class="pthumb" type="button" data-auto="open" data-id="${H.esc(p.id)}" aria-label="Ouvrir ${H.esc(p.title || 'la production')}">${key ? `<img data-media="${H.esc(key)}" alt="">` : `<span class="nothumb">${H.icon('sparkle')}</span>`}${m.partie || p.part ? `<span class="ppart">Partie ${H.esc(m.partie || p.part)}</span>` : ''}</button>
        <div class="pbody">
          <div class="phead"><span class="st ${stKey}">${H.esc(STLABEL(stKey))}</span><span class="muted">${MODES[p.mode]} · ${when(p.createdAt)}</span></div>
          <h3>${H.esc(m.titre || p.title || MODES[p.mode])}</h3>
          ${m.serie ? `<p class="pserie">Série « ${H.esc(m.serie)} »${k ? ` · ${k.scenes.length} scènes · ${totalDuration(k)} s` : ''}</p>` : k ? `<p class="pserie">${k.scenes.length} scènes · ${totalDuration(k)} s</p>` : ''}
          ${m.accroche ? `<p class="paccroche">${H.esc(m.accroche)}</p>` : ''}
          ${k && k.planches.length ? `<ul class="pcast">${k.planches.slice(0, 5).map((pl) => `<li>${H.esc(pl.name)}</li>`).join('')}${k.planches.length > 5 ? `<li>+${k.planches.length - 5}</li>` : ''}</ul>` : ''}
          ${k && p.status !== 'done' ? `<div class="pprog"><i class="meter"><span style="width:${Math.max(3, pr.pct)}%"></span></i><small>${pr.done}/${pr.total}</small></div>` : ''}
          ${why ? `<p class="pwhy">${H.esc(String(why).slice(0, 180))}</p>` : ''}
          <div class="row"><button class="btn small primary" type="button" data-auto="open" data-id="${H.esc(p.id)}">${H.icon('book')}Ouvrir</button>
            ${canGo ? `<button class="btn small" type="button" data-auto="restart" data-id="${H.esc(p.id)}">${H.icon('play')}Continuer</button>` : ''}
            ${k ? `<button class="btn small" type="button" data-auto="suiteOf" data-id="${H.esc(p.id)}">${H.icon('film')}Faire la suite</button>` : ''}
            ${p.status !== 'done' ? `<button class="btn small ghost" type="button" data-auto="fresh" data-id="${H.esc(p.id)}" title="Efface ce qui a été généré et repart du début">${H.icon('refresh')}Recommencer</button>` : ''}
            <button class="btn small ghost danger" type="button" data-auto="delProd" data-id="${H.esc(p.id)}" title="Mettre à la corbeille">${H.icon('trash')}</button></div>
        </div></article>`;
  };
  const list = groups[prodFilter];
  box.innerHTML = `<div class="pagehead"><div><h2>Mes productions</h2><p>Toutes tes vidéos, avec leur histoire, leurs personnages et leurs fichiers. Ouvre-en une pour lire l'histoire scène par scène.</p></div><button class="btn primary" type="button" data-auto="new">${H.icon('sparkle')}Nouvelle vidéo</button></div>
    ${prods.length ? `<div class="ptabs wide" role="group" aria-label="Filtrer">${tabs}</div>
      ${list.length ? `<div class="plist">${list.map(card).join('')}</div>` : '<div class="empty"><h3>Rien dans cette catégorie</h3><p>Change de filtre pour voir les autres productions.</p></div>'}`
    : `<div class="empty"><h3>Aucune production pour l'instant</h3><p>Lance ta première vidéo depuis Automatisation, ou clique sur « Reproduire » sur une vidéo du Radar.</p><div class="row"><button class="btn primary" type="button" data-auto="new">${H.icon('sparkle')}Nouvelle vidéo</button></div></div>`}`;
  hydrateMedia(box);
}

async function renderChars() {
  const box = H.$('#viewChars');
  const [chars, settings] = await Promise.all([DB.allChars(), getSettings()]);
  await classifyOld(chars);
  const styles = charStyles(settings, chars);
  syncThumbs(chars);
  for (const id of [...charSel]) if (!chars.some((c) => c.id === id)) charSel.delete(id);
  const shown = chars.filter(charShown);
  const allSeries = [...new Set(chars.map((c) => c.seriesTitle || 'Sans histoire'))];
  const focus = document.activeElement && document.activeElement.id === 'cQuery';
  const one = charSel.size === 1 ? chars.find((c) => charSel.has(c.id)) : null;
  box.innerHTML = `<div class="pagehead"><div><h2>Personnages</h2><p>Tes planches, rangées par histoire. Clique sur une image pour la voir en grand. Coche des planches pour leur donner un style ou les mettre à la corbeille.</p></div></div>
    ${chars.length ? `<section class="panel chlibwrap">${charToolbar(chars, styles, 'lib')}
        ${shown.length ? `<div class="chlib">${charGroups(shown, styles, 'lib', (c) => charSel.has(c.id))}</div>` : '<p class="hint">Aucun personnage ne correspond. Change de style ou efface la recherche.</p>'}</section>`
    : '<div class="empty"><h3>Aucune planche enregistrée</h3><p>Elles apparaîtront ici après ta première production.</p></div>'}
    <details class="panel addchar"><summary><h3>Ajouter une planche à la main</h3></summary><p class="hint">Pour une histoire commencée avant FruitRadar : l'image de la planche, avec le nom exact du personnage.</p>
      <div class="grid3"><label class="block"><span>Nom du personnage</span><input id="cName" placeholder="Grenadina"></label>
      <label class="block"><span>Histoire</span><input id="cSeries" placeholder="Le Secret des Grenadines" list="cSeriesList"><datalist id="cSeriesList">${allSeries.map((g) => `<option value="${H.esc(g)}">`).join('')}</datalist></label>
      <label class="block"><span>Image de la planche</span><input id="cFile" type="file" accept="image/*"></label></div>
      <div class="row"><label class="inline">Style <select id="cStyle"><option value="">Sans style</option>${[...styles].map(([k, l]) => `<option value="${H.esc(k)}">${H.esc(l)}</option>`).join('')}</select></label><button class="btn primary" type="button" data-auto="addChar">Ajouter</button></div></details>
    ${charSel.size ? `<div class="selbar" role="region" aria-label="Planches cochées"><b>${charSel.size} cochée${charSel.size > 1 ? 's' : ''}</b>
      <label class="inline">Style <select id="selStyle" aria-label="Donner un style aux planches cochées"><option value="">Choisir…</option>${[...styles].map(([k, l]) => `<option value="${H.esc(k)}">${H.esc(l)}</option>`).join('')}<option value="-">Sans style</option><option value="+">+ Nouveau style…</option></select></label>
      ${one && one.prompt ? `<button class="btn small" type="button" data-auto="copyChar" data-id="${H.esc(one.id)}">${H.icon('copy')}Copier le prompt</button>` : ''}
      <button class="btn small danger" type="button" data-auto="trashSel">${H.icon('trash')}Mettre à la corbeille</button>
      <span class="spacer"></span><button class="btn small ghost" type="button" data-auto="selClear">Tout décocher</button></div>` : ''}`;
  hydrateMedia(box);
  if (focus) { const q = H.$('#cQuery'); if (q) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } }
}
/* Corbeille : vidéos et personnages supprimés, gardés 30 jours */
async function renderTrash() {
  const box = H.$('#viewTrash'); if (!box) return;
  await DB.purgeTrash().catch(() => 0);
  const [prods, chars, settings] = await Promise.all([DB.trashedProds(), DB.trashedChars(), getSettings()]);
  const styles = charStyles(settings, chars);
  const left = (t) => { const d = Math.max(1, DB.TRASH_DAYS - Math.floor((Date.now() - t) / 86400000)); return d <= 1 ? 'effacé demain' : `encore ${d} jours`; };
  box.innerHTML = `<div class="pagehead"><div><h2>Corbeille</h2><p>Ce que tu supprimes arrive ici et y reste ${DB.TRASH_DAYS} jours. Tu peux le restaurer, ou l'effacer pour de bon.</p></div>
      ${prods.length + chars.length ? `<div class="row"><button class="btn solid-danger" type="button" data-auto="trashEmpty">${H.icon('trash')}Vider la corbeille (${prods.length + chars.length})</button></div>` : ''}</div>
    ${prods.length + chars.length ? '' : '<div class="empty"><h3>La corbeille est vide</h3><p>Les vidéos et les personnages que tu supprimes apparaîtront ici.</p></div>'}
    ${prods.length ? `<section class="panel"><h3>Vidéos <small class="muted">${prods.length}</small></h3><ul class="trashlist">${prods.map((p) => `<li>${p.pkg && p.pkg.miniature && p.pkg.miniature.key ? `<img class="trashthumb" data-media="${H.esc(p.pkg.miniature.key)}" alt="" loading="lazy">` : `<span class="trashthumb none" aria-hidden="true">${H.icon('film')}</span>`}<div><b>${H.esc(p.title || MODES[p.mode] || 'Sans titre')}</b><small>${H.esc(MODES[p.mode] || '')} · partie ${p.part || 1} · supprimée ${agoText(p.deletedAt)} · ${left(p.deletedAt)}</small></div>
        <div class="row"><button class="btn small" type="button" data-auto="restoreProd" data-id="${H.esc(p.id)}">${H.icon('refresh')}Restaurer</button><button class="btn small ghost danger" type="button" data-auto="purgeProd" data-id="${H.esc(p.id)}">Effacer</button></div></li>`).join('')}</ul></section>` : ''}
    ${chars.length ? `<section class="panel"><h3>Personnages <small class="muted">${chars.length}</small></h3><div class="chgrid">${chars.map((c) => `<article class="chcard gone"><button type="button" class="chthumb" data-auto="zoomChar" data-id="${H.esc(c.id)}" title="Voir en grand" aria-label="Voir la planche de ${H.esc(c.name)} en grand"><img data-char="${H.esc(c.id)}" alt="" loading="lazy"></button>
        <div class="chname"><b title="${H.esc(c.name)}">${H.esc(c.name)}</b><small>${H.esc(c.seriesTitle || 'Sans histoire')} · ${left(c.deletedAt)}</small></div>
        <div class="chacts"><button class="btn small" type="button" data-auto="restoreChar" data-id="${H.esc(c.id)}">Restaurer</button><button class="btn small ghost danger" type="button" data-auto="purgeChar" data-id="${H.esc(c.id)}" aria-label="Effacer ${H.esc(c.name)} pour de bon">Effacer</button></div></article>`).join('')}</div></section>` : ''}`;
  hydrateMedia(box);
}

/* ---------- actions ---------- */
function readDraft() {
  const g = (id) => H.$('#' + id);
  if (g('aUrl')) draft.url = g('aUrl').value.trim();
  if (g('aIdea')) draft.idea = g('aIdea').value.trim();
  if (g('aExtra')) draft.extra = g('aExtra').value.trim();
  if (g('aPart')) draft.part = Math.max(1, parseInt(g('aPart').value, 10) || 1);
  if (g('aPrevBible')) draft.prevBible = g('aPrevBible').value.trim();
  if (g('aStyleText')) draft.styleText = g('aStyleText').value.trim();
  if (g('aKeyText')) draft.keyText = g('aKeyText').checked;
  if (g('aStyleName')) draft.styleName = g('aStyleName').value.trim();
}
function onInput(e) {
  if (e.target.id === 'cQuery' || e.target.id === 'pQuery') { // recherche d'un personnage : la liste suit la frappe
    const pick = e.target.id === 'pQuery'; charFilter.q = e.target.value.trim();
    clearTimeout(onInput.t); onInput.t = setTimeout(() => (pick ? renderPicker() : renderChars()), 160); return;
  }
  onInputRest(e);
}
function onInputRest(e) { if (e.target.id === 'aPart') { const b = H.$('#miniPrevPart'); if (b) b.textContent = `PARTIE ${Math.max(1, parseInt(e.target.value, 10) || 1)}`; }
  if (e.target.id === 'aIdeaNote') { ideaNote = e.target.value; return; }
  if (e.target.dataset && e.target.dataset.ie) { readIdeaForm(); return; } if (e.target.closest && e.target.closest('#viewAuto .launch')) readDraft(); }
const endMode = () => (document.querySelector('input[name=sEnd]:checked') || {}).value || 'ask';
function paintEnd() {
  const m = endMode(), n = H.$('#sEndNote'), f = H.$('#sFinalCheck'); if (!n) return;
  n.textContent = m === 'capcut' ? 'Rien à demander : FruitRadar s\'arrête au montage, tu exportes et tu publies toi-même.'
    : m === 'auto' ? 'Il publie tout seul. Il ne te demande que s\'il reste un point à vérifier (son non ajouté, couverture, légendes) ou si TikTok Studio n\'est pas sur ton compte de publication.'
    : 'Toujours : la vidéo attend dans TikTok Studio, et il ne publie qu\'après ton clic sur « Publier maintenant » (ou « C\'est déjà publié » si tu l\'as fait toi-même).';
  if (f) { f.disabled = m === 'capcut'; f.closest('li').classList.toggle('off', m === 'capcut'); }
}
function onChange(e) {
  if (e.target && e.target.name === 'sEnd') paintEnd();
  const t = e.target;
  if ((t.id === 'pMiniStyle' || t.id === 'gMiniStyle') && currentId) { miniPick[currentId] = t.value; return; }
  if (t.id === 'aKeyText') { draft.keyText = t.checked; return; }
  if (t.id === 'aHookGemini') { const hb = t.closest('.hookbox'); if (hb) hb.classList.toggle('on', t.checked); draft.hookGemini = t.checked; patchAuto((x) => { x.hookGemini = t.checked; }).catch(() => {}); return; }
  if (t.id === 'aSrcFile' && t.files && t.files[0]) { // vidéo d'origine donnée à la main : rangée là où le pilote l'attend, puis reprise
    const f = t.files[0], id = t.dataset.id;
    if (f.size < 20000) return H.toast('Ce fichier est vide ou trop petit pour être une vidéo.', 4500);
    DB.putMedia({ key: `${id}/source.mp4`, prodId: id, name: 'source.mp4', blob: f }).then(async () => {
      const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id, cmd: 'resume' }).catch(() => null);
      H.toast(r && r.ok ? 'Vidéo reçue : la production reprend.' : 'Vidéo reçue : clique sur « Continuer » pour reprendre.', 4500);
    }).catch((e) => H.toast('Impossible de garder ce fichier : ' + e.message, 5000));
    return;
  }
  if (t.id === 'aPrevFile' && t.files && t.files[0]) { readDraft(); draft.prevFile = t.files[0]; renderAuto(); return; } // tout le lanceur : le lien « style de la vidéo » apparaît
  if (t.dataset && t.dataset.charTick) { // case d'une planche : choisie pour la vidéo (fenêtre Mes personnages) ou cochée (page Personnages)
    const id = t.dataset.charTick;
    if (t.dataset.where === 'pick') {
      draft.charIds = (draft.charIds || []).filter((x) => x !== id); if (t.checked) draft.charIds.push(id);
      const card = t.closest('.chcard'); if (card) card.classList.toggle('on', t.checked);
      pickCount(); return;
    }
    if (t.checked) charSel.add(id); else charSel.delete(id);
    renderChars(); return;
  }
  if (t.id === 'selStyle') { // style donné d'un coup à toutes les planches cochées
    (async () => {
      let v = t.value, label = t.options[t.selectedIndex] ? t.options[t.selectedIndex].textContent : ''; if (!v) return;
      if (v === '+') {
        const n = String(await H.ask('Nom du nouveau style', { input: { placeholder: 'ex. Thés, Cafés, Légumes en pâte à modeler', max: 40 }, ok: 'Créer le style' }) || '').trim().slice(0, 40);
        if (!n) return renderChars();
        await patchAuto((x) => { x.charStyles = [...new Set([...(x.charStyles || []), n])]; }); v = 'x:' + n; label = n;
      }
      if (v === '-') { v = ''; label = ''; }
      let n = 0;
      for (const c of await DB.allChars()) if (charSel.has(c.id)) { await DB.putChar({ ...c, style: v, styleLabel: label, at: c.at }); n++; }
      charSel.clear();
      H.toast(v ? `${n} planche${n > 1 ? 's' : ''} classée${n > 1 ? 's' : ''} : ${label}` : `${n} planche${n > 1 ? 's' : ''} sans style`);
      renderChars();
    })();
    return;
  }
  if (t.dataset && t.dataset.import && t.files && t.files[0]) { const f = t.files[0]; importItem(t.dataset.import, t.dataset.n, f).catch((e) => H.toast(`Import impossible : ${e.message}`, 6000)); t.value = ''; return; }
  if (t.id === 'aMiniReuse') { draft.miniReuse = t.checked; return; }
  if (t.id === 'aMiniFile' && t.files && t.files[0]) { readDraft(); draft.miniFile = t.files[0]; draft.miniReuse = true; fillMiniPrev(); return; }
  if (t.id === 'aStyleImg' && t.files && t.files[0]) { styleImage(t.files[0]).catch(() => {}); return; }
  if (t.id === 'aMiniType' && t.files && t.files[0]) { readDraft(); miniTypeImage(t.files[0], t.dataset.mini).catch(() => H.toast('Image illisible')); t.value = ''; return; }
  if (t.id === 'aPrev') {
    readDraft(); draft.prevId = t.value; draft.charIds = null;
    DB.getProd(t.value).then((pv) => { if (pv && pv.style) { draft.style = pv.style; draft.styleText = pv.styleText || ''; renderAuto(); } }).catch(() => {});
    DB.getProd(t.value).then((p) => { if (p) draft.part = (p.part || 1) + 1; renderAuto(); });
  }
}

/* La vidéo finale déposée par toi (bouton « Déposer la vidéo exportée » ou glisser-déposer sur la carte) : elle remplace l'export de CapCut,
   vaut validation, et la production continue toute seule vers TikTok Studio.
   Le sélecteur de fichier est créé à la volée, hors de la page : avant, il vivait dans la carte, et la page qui se redessinait pendant
   que tu choisissais le fichier le remplaçait par un neuf ; ton choix arrivait alors dans le vide (« le bouton ne récupère pas la vidéo »). */
function pickFinal() {
  const id = currentId; if (!id) return;
  const inp = document.createElement('input');
  inp.type = 'file'; inp.accept = 'video/*,.mp4,.mov,.m4v,.webm';
  inp.addEventListener('change', () => { const f = inp.files && inp.files[0]; if (f) depositFinal(f, id); }, { once: true });
  inp.click();
}
let depositing = false;
async function depositFinal(f, id = currentId) {
  if (!f || !id) return;
  if (depositing) return H.toast('Une vidéo est déjà en train d\'être déposée.', 3500);
  if (!/^video\//.test(f.type || '') && !/\.(mp4|mov|m4v|webm)$/i.test(f.name || '')) return H.toast('Ce fichier n\'est pas une vidéo : dépose le fichier .mp4 exporté de CapCut.', 6000);
  if (f.size < 300000) return H.toast('Ce fichier est trop petit pour être la vidéo exportée : prends le .mp4 de CapCut, dans tes Téléchargements.', 6000);
  depositing = true;
  try {
    H.toast(`Vidéo reçue (${(f.size / 1048576).toFixed(1).replace('.', ',')} Mo), je la vérifie…`, 3000);
    const key = `${id}/final.mp4`;
    await DB.putMedia({ key, prodId: id, name: 'final.mp4', blob: f });
    forget(key);
    // 1. la fenêtre pilote tourne sur cette vidéo : elle prend le fichier et continue
    let r = await chrome.runtime.sendMessage({ type: 'autoOpen', id, cmd: 'final', text: f.name || '' }).catch(() => null);
    if (r && r.ok) { H.toast('Vidéo déposée : je continue vers TikTok Studio.', 5000); return; }
    if (r && r.error && !r.idle && !/ferm[ée]e|ne répond pas/i.test(r.error)) { H.toast(r.error, 7000); return; } // refusée (pas une vidéo, montage pas fait…)
    // 2. fenêtre pilote fermée, ou occupée ailleurs : la vidéo est rangée dans la production, puis la production est relancée
    const p = await DB.getProd(id);
    if (!p) { H.toast('Production introuvable.', 5000); return; }
    if (p.step !== 'valider' && p.gate !== 'validate') { H.toast('La vidéo finale se dépose une fois le montage CapCut fait.', 6000); return; }
    p.finalKey = key; p.finalSaved = true; p.validated = true; p.finalDeposit = Date.now(); p.finalInfo = null; p.exportFile = String(f.name || '').slice(0, 120) || p.exportFile || null;
    p.gate = null; p.validateCmd = null; p.montageOk = true;
    if (['waiting', 'running', 'paused'].includes(p.status)) { p.status = 'paused'; p.pause = { reason: 'Vidéo finale déposée : clique sur « Continuer » pour passer à TikTok Studio.', at: Date.now() }; }
    (p.log = p.log || []).push({ t: Date.now(), level: 'info', msg: `Vidéo finale déposée par toi (« ${p.exportFile || 'vidéo'} »). Elle partira vers TikTok Studio à la reprise.` });
    await DB.putProd(p);
    r = await chrome.runtime.sendMessage({ type: 'autoOpen', id, cmd: 'load' }).catch(() => null);
    H.toast(r && r.ok ? (r.queued ? 'Vidéo gardée : la production reprendra après la vidéo en cours.' : 'Vidéo déposée : la production reprend vers TikTok Studio.') : `Vidéo gardée. ${(r && r.error) || 'Clique sur « Continuer » pour passer à TikTok Studio.'}`, 7000);
  } catch (e) { H.toast(`Impossible de garder ce fichier : ${e.message}`, 7000); }
  finally { depositing = false; renderAuto(); }
}

/* Arrête proprement la production que la fenêtre pilote fait tourner (elle est mise de côté, rien n'est perdu) */
async function stopRunner(onlyId = null) {
  const r = await runnerAlive();
  if (!r || !r.running || (onlyId && r.id !== onlyId)) return;
  await chrome.runtime.sendMessage({ type: 'autoOpen', id: r.id, cmd: 'stop' }).catch(() => null);
  for (let i = 0; i < 50; i++) { await wait(400); const x = await runnerAlive(); if (!x || !x.running) return; }
}
async function launch(now = false) {
  readDraft();
  const d = draft;
  let source = null;
  if (d.mode === 'remake') {
    source = d.video;
    if (!source) {
      const m = d.url.match(/tiktok\.com\/@([^/?#]+)\/video\/(\d+)/);
      if (!m) return H.toast('Choisis une vidéo dans le Radar ou colle un lien TikTok complet (…/@compte/video/123…)', 4500);
      source = { videoId: m[2], url: `https://www.tiktok.com/@${m[1]}/video/${m[2]}`, author: m[1], desc: '', cover: '', duration: null, stats: '' };
    }
  }
  if (d.mode === 'idee' && d.idea.length < 8) return H.toast('Écris ton idée en une ou deux phrases.');
  if (d.mode === 'suite' && !d.prevId && d.prevBible.length < 30 && !d.prevFile) return H.toast('Choisis la partie précédente, donne sa vidéo, ou colle un résumé de l\'histoire.', 4500);
  const dlg = H.$('#autoDlg');
  const badSites = CONN.filter(([k2]) => checks[k2] && !checks[k2].ok && ((k2 !== 'turbo' && k2 !== 'vt') || (d.mode === 'remake' && k2 === 'vt'))).map(([k2]) => SITES[k2].name); // les sites de transcription ne bloquent jamais un lancement (l'un remplace l'autre)
  H.$('#autoDlgBody').innerHTML = `<div class="riskplan"><p><b>${MODES[d.mode]}</b>${source ? ` : @${H.esc(source.author)}` : ''} · badge <b>PARTIE ${d.part}</b>${(d.charIds || []).length ? ` · ${d.charIds.length} personnage${d.charIds.length > 1 ? 's' : ''} repris` : ''}${now && busy() ? ' · <b>la vidéo en cours sera mise de côté</b>' : ''}</p></div>
    ${badSites.length ? `<div class="banner warn inl"><div><h2>À reconnecter d'abord</h2><p>${H.esc(badSites.join(', '))} : au dernier test, la connexion n'était pas bonne. Vérifie dans « Connexions aux sites », sinon la production se mettra en pause à cette étape.</p></div></div>` : ''}
    <div><h3>Ce qui va se passer</h3><ul class="plain">
      <li>Une fenêtre Chrome à part s'ouvre et pilote Claude, ChatGPT, Grok${d.mode === 'remake' ? ', VideoTranscriber' : ''} et CapCut avec tes comptes.</li>
      <li>Compte 1 à 2 h. Laisse cette fenêtre ouverte et visible, sans toucher aux onglets pilotés.</li>
      <li>Aucune génération n'est coupée parce qu'elle est longue : FruitRadar attend le temps qu'il faut.</li>
      <li>À la moindre erreur : une notification. Blocage (connexion, captcha, limite) : 2 essais, puis pause avec un son.</li>
      ${d.mode === 'idees' ? '<li>Elle s\'arrêtera une fois pour que tu choisisses ton idée.</li>' : ''}
      <li>Chaque clip Grok est contrôlé : durée, format vertical 9:16 et qualité. S'il ne correspond pas, pause immédiate.</li>
      <li>À la fin : clips dans CapCut dans l'ordre, miniature et description prêtes, un son et une notification.</li></ul></div>
    <div><h3>À savoir</h3><ul class="plain">
      <li>Piloter ces sites par un outil automatique est contraire à leurs conditions d'utilisation : un compte peut être ralenti ou limité.</li>
      <li>Chaque vidéo consomme tes quotas ChatGPT (environ ${d.mode === 'suite' ? '12' : '15'} images) et Grok (environ 10 clips).</li>
      <li>Quand un site change son interface, une étape peut casser : la pause te dira laquelle.</li></ul></div>`;
  dlg.onclose = async () => {
    if (dlg.returnValue !== 'go') return;
    const id = 'p' + Date.now().toString(36);
    const prev = d.mode === 'suite' && d.prevId ? await DB.getProd(d.prevId) : null;
    const stamp = new Date().toISOString().slice(0, 10);
    const videoOk = d.mode === 'remake' || (d.mode === 'suite' && !d.prevId && !!d.prevFile);
    const sty = await (async () => { // style choisi : fourni, enregistré (envoyé comme un style décrit) ou celui de la partie précédente
      const au = (await getSettings()).auto;
      const key = (d.style === 'video' && !videoOk ? null : d.style) || (prev && prev.style ? null : (au.styleOrder || [])[0]) || null;
      if (key === 'video') return { style: 'video', styleText: '', label: 'Style de la vidéo', key: 'video' }; // lu par Claude dans les captures de la vidéo
      if (!key) return { style: (prev && prev.style) || au.charStyle || 'fruits', styleText: (prev && prev.styleText) || '', label: (prev && prev.styleLabel) || '', key: (prev && (prev.styleKey || prev.style)) || au.charStyle || 'fruits' };
      if (key.startsWith('c:')) { const c = (au.customStyles || []).find((x) => 'c:' + x.id === key); if (c) { await patchAuto((x) => { x.styleOrder = [key, ...(x.styleOrder || []).filter((y) => y !== key)]; }); return { style: 'autre', styleText: c.brief, label: c.label, key }; } return { style: au.charStyle || 'fruits', styleText: '', label: '', key: au.charStyle || 'fruits' }; }
      if (key !== 'autre') await patchAuto((x) => { x.styleOrder = [key, ...(x.styleOrder || []).filter((y) => y !== key)]; });
      return { style: key, styleText: key === 'autre' ? d.styleText : '', label: key === 'autre' ? (d.styleName || '') : '', key };
    })();
    const mini = miniKey(d.miniStyle || (await getSettings()).auto.miniStyle);
    if (d.miniStyle) await patchAuto((x) => { x.miniStyle = mini; });
    const prod = {
      id, createdAt: Date.now(), mode: d.mode, title: prev ? `${prev.title} — partie ${d.part}` : source ? `Remake de @${source.author}` : '', part: d.part, partLocked: true,
      source, idea: d.idea, extra: d.extra, prevId: d.prevId || '', prevBible: d.prevBible, charIds: d.charIds || [],
      series: prev ? prev.series : id, style: sty.style, styleKey: sty.key, styleText: sty.styleText, styleLabel: sty.label, keyText: !!d.keyText, miniStyle: mini, tiktokFlow: (await getSettings()).auto.tiktokFlow !== false, folder: `${stamp}_${id}`, status: 'queued', queuedAt: Date.now(), step: d.mode === 'remake' ? 'source' : 'package', log: [], frames: [], transcript: []
    };
    if (d.mode === 'suite' && d.prevFile) { prod.prevVideoKey = `${id}/previous.mp4`; await DB.putMedia({ key: prod.prevVideoKey, prodId: id, name: 'previous.mp4', blob: d.prevFile }); }
    if (d.mode === 'suite' && d.miniReuse !== false) { // miniature de la partie précédente, copiée dans cette production
      let mb = null, pp = null;
      if (prev && prev.pkg && prev.pkg.miniature && prev.pkg.miniature.status === 'done' && prev.pkg.miniature.key) { const m = await DB.getMedia(prev.pkg.miniature.key).catch(() => null); mb = m && m.blob; pp = prev.part || null; }
      else if (d.miniFile) { mb = d.miniFile; pp = d.part > 1 ? d.part - 1 : null; }
      if (mb) { prod.miniFromKey = `${id}/miniature-precedente.png`; prod.miniPrevPart = pp; await DB.putMedia({ key: prod.miniFromKey, prodId: id, name: 'miniature-precedente.png', blob: mb }); }
    }
    if (d.mode === 'remake') { const st0 = await getSettings(); prod.hookGemini = !!st0.geminiKey && (d.hookGemini === null ? !!st0.auto.hookGemini : !!d.hookGemini); }
    await DB.putProd(prod);
    currentId = id;
    Object.assign(draft, { video: null, url: '', idea: '', extra: '', prevBible: '', charIds: null, styleText: '', prevFile: null, miniFile: null, miniReuse: true });
    prodTab = null; wantLauncher = false;
    if (now) { H.toast('Je mets la vidéo en cours de côté…', 4000); await stopRunner(); }
    const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id }).catch((e) => ({ ok: false, error: e.message }));
    if (r && r.trial) window.dispatchEvent(new CustomEvent('fr-upgrade')); // clé d'essai : on propose l'abonnement au lieu d'un simple message
    else if (!r || !r.ok) H.toast((r && r.error) || 'Impossible d\'ouvrir la fenêtre d\'automatisation', 4500); else if (r.queued) H.toast(`Ajoutée à la file d'attente (n° ${r.pos}) : elle partira toute seule après la vidéo en cours`, 5000); else H.toast('Automatisation lancée dans une fenêtre à part');
    renderAuto();
  };
  dlg.returnValue = ''; dlg.showModal();
}

/* « Refaire le montage » (nouveau projet CapCut, mêmes clips, puis export et TikTok) ou « Refaire TikTok Studio » (la vidéo exportée est gardée,
   elle est renvoyée et tout est repréparé). Marche que la production tourne, attende, soit de côté ou terminée. Une vidéo déjà publiée ne
   repart jamais toute seule : la carte « Prête à publier » redemande toujours. */
async function redoEnd(what, id) {
  const p0 = await DB.getProd(id); if (!p0) return;
  if (what === 'montage' ? !canRemontage(p0) : !canRetiktok(p0)) return H.toast(what === 'montage' ? 'Le montage ne peut pas encore être refait : il manque des clips.' : 'Rien à refaire dans TikTok Studio pour cette production.', 5000);
  const was = p0.published || p0.publishedByUser || p0.publishedBefore || 0, tk = p0.tiktokFlow !== false && (await getSettings()).auto.tiktokFlow !== false;
  const text = (what === 'montage'
    ? `Un nouveau projet CapCut est créé avec les mêmes clips${tk ? ', puis l\'export et la préparation dans TikTok Studio sont refaits' : ''}. Les images et les clips ne changent pas.`
    : 'La vidéo exportée est gardée. Elle est renvoyée dans TikTok Studio : description, couverture, légendes et son sont refaits. L\'onglet TikTok actuel est fermé.')
    + (was ? ' Cette vidéo a déjà été publiée : celle qui est en ligne ne change pas, et la nouvelle version ne partira pas sans ton accord.' : '');
  if (!(await H.ask(what === 'montage' ? 'Refaire le montage ?' : 'Refaire la préparation dans TikTok Studio ?', { text, ok: what === 'montage' ? 'Refaire le montage' : 'Refaire TikTok Studio' }))) return;
  if (state && state.id === id && busy() && await runnerAlive()) {
    if (what === 'montage' && p0.status === 'waiting' && (p0.gate === 'montage' || p0.gate === 'validate')) { // la fenêtre pilote attend justement à cette étape : elle sait le faire sans s'arrêter
      const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id, cmd: 'gate', text: 'redo' }).catch(() => null);
      if (r && r.ok) { H.toast('Je refais le montage'); return renderAuto(); }
    }
    await stopRunner(id);
  }
  const p = await DB.getProd(id); if (!p) return;
  if (what === 'montage') Object.assign(p, { capcut: null, montageOk: false, finalKey: null, finalInfo: null, finalSaved: false, exportFile: null, exportPath: null, validated: false, montageCmd: null, validateCmd: null });
  if (p.published || p.publishedByUser) p.publishedBefore = p.published || p.publishedByUser;
  Object.assign(p, { tiktokReady: null, tiktokNotes: null, tiktokRecap: null, publishCmd: null, published: null, publishedByUser: null, publishSkipped: false, markedDone: null, doneAt: null,
    gate: null, pause: null, dropTiktok: Date.now(), step: what === 'montage' ? 'capcut' : 'tiktok', status: 'queued', queuedAt: Date.now() });
  p.log = [...(p.log || []), { t: Date.now(), level: 'warn', msg: what === 'montage' ? 'Montage à refaire (demandé dans FruitRadar) : nouveau projet CapCut, mêmes clips.' : 'Préparation TikTok Studio à refaire (demandée dans FruitRadar) : la vidéo exportée est gardée.' }];
  await DB.putProd(p); currentId = id;
  const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id }).catch(() => null);
  H.toast(r && r.queued ? `Une autre vidéo tourne : ce sera refait juste après (n° ${r.pos} dans la file)` : r && r.ok ? (what === 'montage' ? 'Je refais le montage' : 'Je refais la préparation TikTok') : (r && r.error) || 'Impossible de relancer', 5000);
  return H.showView('auto');
}

async function redo(kind, n) {
  const p = await DB.getProd(currentId); if (!p || !p.pkg) return;
  if (state && state.id === p.id && busy() && await runnerAlive()) {
    // la production tourne : un clip peut être refait sans rien arrêter (la scène repart chez Grok) ; le reste demande de la mettre de côté d'abord
    if (kind !== 'vid') return H.toast('La production tourne : clique d\'abord sur « Mettre de côté », puis sur Refaire. Seul un clip peut être refait sans rien arrêter.', 7000);
    const r = await chrome.runtime.sendMessage({ type: 'autoOpen', cmd: 'redo', id: p.id, kind, n: Number(n) }).catch(() => null);
    H.toast(r && r.ok ? `Clip de la scène ${n} : je le refais, le reste continue.` : (r && r.error) || 'Mets d\'abord la production de côté, puis reclique sur Refaire.', r && r.ok ? 4000 : 7000);
    return renderAuto();
  }
  const k = p.pkg;
  if (kind === 'planche') { const pl = k.planches[Number(n)]; if (pl) { pl.status = 'todo'; forget(pl.key); } }
  if (kind === 'img' || kind === 'vid' || kind === 'scene') {
    const s = k.scenes.find((x) => x.n === Number(n)); if (!s) return;
    if (kind === 'img' || kind === 'scene') { s.imgStatus = 'todo'; forget(s.imgKey); }
    s.vidStatus = 'todo'; forget(s.vidKey); p.capcut = null; s.grokSent = null; s.grokPost = null;
  }
  if (kind === 'allimg') for (const s of k.scenes) { s.imgStatus = 'todo'; forget(s.imgKey); s.vidStatus = 'todo'; forget(s.vidKey); p.capcut = null; s.grokSent = null; s.grokPost = null; }
  if (kind === 'mini') { const pick = miniPick[p.id] || (H.$('#pMiniStyle') || {}).value; if (P.MINI_STYLES[pick]) p.miniStyle = pick; if (k.miniature.key) k.miniature.variant = (k.miniature.variant || 0) + 1; k.miniature.status = 'todo'; forget(k.miniature.key); }
  if (kind === 'capcut') p.capcut = null;
  p.status = 'queued';
  await DB.putProd(p);
  const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id: p.id }).catch(() => null);
  H.toast(r && r.ok ? 'C\'est reparti pour cet élément' : (r && r.error) || 'Impossible de relancer');
  renderAuto();
}

/* Importer : ton fichier prend la place d'une planche, d'une image de scène ou d'un clip. Rien n'est relancé tout seul. */
async function importItem(kind, n, file) {
  const p = await DB.getProd(currentId); if (!p || !p.pkg) return;
  const isVid = kind === 'vid';
  if (isVid ? !/^video\//.test(file.type) : !/^image\//.test(file.type)) return H.toast(isVid ? 'Il faut un fichier vidéo (MP4 de préférence).' : 'Il faut une image (PNG ou JPG).', 5000);
  if (state && state.id === p.id && busy() && await runnerAlive()) {
    if (!isVid) return H.toast('La production tourne : clique d\'abord sur « Mettre de côté », puis importe ton image.', 7000);
    const key = `${p.id}/import-${Date.now()}.mp4`;
    await DB.putMedia({ key, prodId: p.id, name: 'import.mp4', blob: file });
    const r = await chrome.runtime.sendMessage({ type: 'autoOpen', cmd: 'import', id: p.id, kind, n: Number(n), key }).catch(() => null);
    if (!r || !r.ok) await DB.delMedia(key).catch(() => {});
    H.toast(r && r.ok ? `Clip de la scène ${n} importé : Grok ne le fabriquera pas.` : (r && r.error) || 'Mets d\'abord la production de côté, puis importe ton clip.', r && r.ok ? 4500 : 8000);
    return renderAuto();
  }
  const k = p.pkg, extOf = (b) => (/jpe?g/.test(b.type) ? 'jpg' : /webp/.test(b.type) ? 'webp' : 'png');
  const put = async (name) => { const key = `${p.id}/${name}`; forget(key); await DB.putMedia({ key, prodId: p.id, name, blob: file }); return key; };
  let msg = '';
  if (kind === 'planche') {
    const pl = k.planches[Number(n)]; if (!pl) return;
    forget(pl.key); pl.key = await put(`planche-${P.slug(pl.name)}.${extOf(file)}`); pl.status = 'done';
    // la bibliothèque de personnages suit : c'est cette planche qui sera reprise dans les suites
    const cid = `${p.series}/${normName(pl.name)}`, had = (await DB.getChar(cid).catch(() => null)) || {};
    const { thumb, deletedAt, ...keep } = had;
    await DB.putChar({ ...keep, id: cid, name: pl.name, blob: file, prompt: pl.prompt || keep.prompt || '', series: p.series, seriesTitle: (k.meta && k.meta.serie) || p.title, from: p.id, style: keep.style || ((p.styleKey || p.style) === 'video' ? '' : (p.styleKey || p.style || '')), styleLabel: keep.styleLabel || p.styleLabel || '' });
    forget('c:' + cid); msg = `Planche « ${pl.name} » importée.`;
  } else if (kind === 'mini') {
    forget(k.miniature.key); k.miniature.key = await put(`miniature-import.${extOf(file)}`); k.miniature.status = 'done'; msg = 'Miniature importée.';
  } else {
    const s = k.scenes.find((x) => x.n === Number(n)); if (!s) return;
    if (kind === 'img') {
      forget(s.imgKey); s.imgKey = await put(`scene-${pad(s.n)}.${extOf(file)}`); s.imgStatus = 'done'; s.imgAt = Date.now();
      if (!s.vidImported) { s.vidStatus = 'todo'; forget(s.vidKey); s.grokSent = null; s.grokPost = null; p.capcut = null; }
      msg = s.vidImported ? `Image de la scène ${s.n} importée.` : `Image de la scène ${s.n} importée : son clip sera refait à partir d'elle à la relance.`;
    } else {
      forget(s.vidKey); s.vidKey = await put(`${pad(s.n)}_scene.mp4`); s.vidStatus = 'done'; s.vidImported = true; s.grokSent = null; s.grokPost = null; p.capcut = null;
      const tr = await F.mp4Video(file).catch(() => null);
      s.vidInfo = tr ? { w: tr.rot % 180 ? tr.height : tr.width, h: tr.rot % 180 ? tr.width : tr.height, dur: Math.round(tr.duration * 10) / 10 } : null;
      msg = `Clip de la scène ${s.n} importé${tr ? ` (${s.vidInfo.w}×${s.vidInfo.h}, ${String(s.vidInfo.dur).replace('.', ',')} s)` : ''}.${tr && Math.abs(tr.duration - s.duree) > 2 ? ` Attention : la scène était prévue pour ${s.duree} s.` : ''}`;
    }
  }
  if (p.status === 'done') p.status = 'stopped'; // un élément a changé : la production redevient « mise de côté », à relancer quand tu as fini
  await DB.putProd(p);
  H.toast(`${msg} Clique sur « Relancer » quand tu as fini d'importer.`, 6000);
  renderAuto();
}

/* Package collé à la main : même lecture que pour la réponse de Claude, puis la production repart après l'étape Package */
async function pastePackage() {
  const raw = (H.$('#aPkgPaste') || {}).value || '';
  const p = await DB.getProd(currentId); if (!p) return;
  const known = p.mode === 'suite' ? (await DB.allChars()).filter((c) => (p.charIds || []).includes(c.id)).map((c) => c.name) : [];
  const pkg = mergePackage(null, parsePackage(raw));
  const miss = missingParts(pkg, known).filter((m) => !/BIBLE|s'il en reste/.test(m));
  if (miss.length) return H.toast('Package incomplet, il manque : ' + miss.join(' ; '), 7000);
  if (await runnerAlive()) { await chrome.runtime.sendMessage({ type: 'autoOpen', id: p.id, cmd: 'stop' }).catch(() => null); for (let i = 0; i < 12; i++) { await new Promise((r) => setTimeout(r, 500)); const r = await runnerAlive(); if (!r || !r.running) break; } }
  const fresh = await DB.getProd(p.id);
  pkg.planches.forEach((x) => { x.status = 'todo'; }); pkg.scenes.forEach((x) => { x.imgStatus = 'todo'; x.vidStatus = 'todo'; });
  if (!pkg.miniature) pkg.miniature = { refs: [], prompt: '' };
  pkg.miniature.status = pkg.miniature.prompt ? 'todo' : 'done';
  Object.assign(fresh, { pkg, pkgReady: true, title: pkg.meta.titre || fresh.title, status: 'queued', pause: null });
  await DB.putProd(fresh);
  await chrome.runtime.sendMessage({ type: 'autoOpen', id: fresh.id }).catch(() => null);
  H.toast('Package accepté, la production repart'); renderAuto();
}

async function runDiag(only = null) {
  if (testing.size) return;
  const keys = only && SITES[only] ? [only] : CONN.map(([k]) => k);
  keys.forEach((k) => testing.add(k));
  diagRes = diagRes || {};
  const redraw = () => { if (view === 'auto' && !currentId) renderAuto(true); };
  redraw();
  const settings = await getSettings();
  for (const k of keys) {
    let tab = null, res = null, me = null;
    try {
      tab = await chrome.tabs.create({ url: START_URL(k, settings.auto), active: false });
      for (let i = 0; i < 40; i++) { await wait(700); if ((await chrome.tabs.get(tab.id)).status === 'complete') break; }
      await wait(k === 'capcut' ? 7000 : 3500);
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['auto/page.js'] });
      const out = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: FRA_DUMP, args: [siteConfig(k, settings.auto.selectors)] });
      res = out[0].result;
    } catch (e) { res = { error: /cannot access|permission/i.test(e.message) ? 'Accès refusé : recharge l\'extension' : e.message }; }
    if (tab) chrome.tabs.remove(tab.id).catch(() => {});
    if (k === 'tiktok' && res && !res.error && !res.block) { try { me = await chrome.runtime.sendMessage({ type: 'tiktokMe' }); } catch (e) { me = null; } }
    diagRes[k] = res;
    checks[k] = { ...verdict(k, res, settings, me), at: Date.now() };
    testing.delete(k);
    await chrome.storage.local.set({ siteChecks: checks });
    redraw();
  }
}

/* Repart de zéro : garde la demande (vidéo d'origine, idée, consignes, partie), efface tout ce qui a été généré */
async function freshStart(id) {
  const p = await DB.getProd(id); if (!p) return;
  if (!(await H.ask(`Recommencer « ${p.title || MODES[p.mode]} » de zéro ?`, { text: 'Le package, les images et les clips déjà faits pour cette production sont effacés de FruitRadar. Les fichiers déjà copiés dans Téléchargements restent.', ok: 'Recommencer de zéro', danger: true }))) return;
  await stopRunner(id);
  for (const m of await DB.mediaOf(id).catch(() => [])) { forget(m.key); await DB.delMedia(m.key); }
  const n = {};
  for (const key of ['id', 'createdAt', 'mode', 'part', 'partLocked', 'source', 'idea', 'extra', 'prevId', 'prevBible', 'charIds', 'series', 'folder', 'tiktokFlow']) if (p[key] !== undefined) n[key] = p[key];
  n.title = p.mode === 'remake' && p.source ? `Remake de @${p.source.author}` : p.mode === 'suite' ? p.title : '';
  Object.assign(n, { status: 'queued', queuedAt: Date.now(), restartedAt: Date.now(), step: p.mode === 'remake' ? 'source' : 'package', log: [], frames: [], transcript: [] });
  await DB.putProd(n);
  currentId = id; prodTab = null;
  const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id }).catch(() => null);
  H.toast(r && r.ok ? (r.queued ? `Remise à zéro : en file d'attente (n° ${r.pos})` : 'C\'est reparti de zéro') : (r && r.error) || 'Impossible de relancer', 4000);
  H.showView('auto');
}
async function removeProd(id) {
  const p = await DB.getProd(id); if (!p) return;
  await stopRunner(id);
  await DB.trashProd(id);
  if (currentId === id) currentId = null;
  H.toast(`« ${p.title || MODES[p.mode]} » est dans la corbeille : tu peux la restaurer pendant ${DB.TRASH_DAYS} jours`, 5000);
  if (view === 'auto') H.showView('prods'); else renderProds();
}
/* Une image de la production (planche, scène, miniature) en grand, dans la même fenêtre que les planches de personnages */
async function zoomMedia(key, cap) {
  const m = await DB.getMedia(key).catch(() => null); if (!m || !m.blob) return H.toast('Image introuvable');
  const d = H.$('#zoomDlg'), im = H.$('#zoomImg');
  if (im.src && im.src.startsWith('blob:')) URL.revokeObjectURL(im.src);
  im.src = URL.createObjectURL(m.blob); im.alt = cap || 'Image en grand';
  H.$('#zoomCap').textContent = cap || '';
  if (!d.open) d.showModal();
}
/* Une planche en grand. Un clic à côté de l'image, sur la croix ou la touche Échap la referme. */
async function zoomChar(id) {
  const c = await DB.getChar(id).catch(() => null); if (!c || !c.blob) return;
  const d = H.$('#zoomDlg'), im = H.$('#zoomImg');
  if (im.src && im.src.startsWith('blob:')) URL.revokeObjectURL(im.src);
  im.src = URL.createObjectURL(c.blob); im.alt = `Planche de ${c.name}`;
  H.$('#zoomCap').textContent = `${c.name}${c.seriesTitle ? ` — ${c.seriesTitle}` : ''}`;
  if (!d.open) d.showModal();
}
async function onClick(e) {
  // zoom : tout clic ailleurs que sur l'image le referme ; fenêtre « Mes personnages » : un clic sur le fond la referme
  { const z = e.target.closest && e.target.closest('#zoomDlg'); if (z && !e.target.closest('#zoomImg')) { if (z.open) z.close(); return; } }
  if (e.target.id === 'charDlg') { e.target.close(); return fillCast(); }
  const b = e.target.closest('[data-auto]');
  if (!b) return;
  const a = b.dataset.auto;
  if (a === 'mode') { readDraft(); const was = draft.mode; draft.mode = b.dataset.mode2; if ((was === 'suite') !== (draft.mode === 'suite')) draft.charIds = null; return renderAuto(); }
  if (a === 'partStep') { const i = H.$('#aPart'); if (!i) return; i.value = Math.min(99, Math.max(1, (parseInt(i.value, 10) || 1) + Number(b.dataset.d))); i.dispatchEvent(new Event('input', { bubbles: true })); return; }
  if (a === 'miniFileClear') { draft.miniFile = null; return fillMiniPrev(); }
  if (a === 'pickOpen') { readDraft(); charFilter.q = ''; charFilter.style = ''; await renderPicker(); const d = H.$('#charDlg'); if (!d.open) d.showModal(); return; }
  if (a === 'pickClose') { const d = H.$('#charDlg'); if (d.open) d.close(); return fillCast(); }
  if (a === 'castDrop') { draft.charIds = (draft.charIds || []).filter((x) => x !== b.dataset.id); return fillCast(); }
  if (a === 'zoomChar') { e.preventDefault(); return zoomChar(b.dataset.id); }
  if (a === 'zoomMedia') { e.preventDefault(); return zoomMedia(b.dataset.key, b.dataset.cap); }
  if (a === 'charTickAll') {
    e.preventDefault();
    const on = b.dataset.on === '1', ids = (await DB.allChars()).filter((c) => (c.seriesTitle || 'Sans histoire') === b.dataset.series && charShown(c)).map((c) => c.id);
    if (b.dataset.where === 'pick') { draft.charIds = (draft.charIds || []).filter((x) => !ids.includes(x)); if (on) draft.charIds.push(...ids); return renderPicker(); }
    ids.forEach((id) => (on ? charSel.add(id) : charSel.delete(id))); return renderChars();
  }
  if (a === 'trashChar') {
    const id = b.dataset.id, c = await DB.getChar(id).catch(() => null);
    await DB.trashChar(id); charSel.delete(id); if (draft.charIds) draft.charIds = draft.charIds.filter((x) => x !== id);
    H.toast(`« ${c ? c.name : 'La planche'} » est dans la corbeille`, 3500);
    return b.dataset.where === 'pick' ? renderPicker() : renderChars();
  }
  if (a === 'trashSel') {
    const n = charSel.size; if (!n) return;
    for (const id of charSel) { await DB.trashChar(id); if (draft.charIds) draft.charIds = draft.charIds.filter((x) => x !== id); }
    charSel.clear(); H.toast(`${n} planche${n > 1 ? 's' : ''} dans la corbeille`, 3500); return renderChars();
  }
  if (a === 'selClear') { charSel.clear(); return renderChars(); }
  if (a === 'restoreChar') { await DB.restoreChar(b.dataset.id); H.toast('Planche restaurée : elle est de retour dans Personnages'); return renderTrash(); }
  if (a === 'purgeChar') { if (!(await H.ask('Effacer cette planche pour de bon ?', { text: 'Elle ne pourra plus être récupérée.', ok: 'Effacer', danger: true }))) return; forget('c:' + b.dataset.id); await DB.delChar(b.dataset.id); return renderTrash(); }
  if (a === 'restoreProd') { await DB.restoreProd(b.dataset.id); H.toast('Vidéo restaurée : elle est de retour dans Mes productions, mise de côté', 4500); return renderTrash(); }
  if (a === 'purgeProd') {
    if (!(await H.ask('Effacer cette vidéo et ses fichiers pour de bon ?', { text: 'Elle ne pourra plus être récupérée.', ok: 'Effacer', danger: true }))) return;
    for (const m of await DB.mediaOf(b.dataset.id).catch(() => [])) forget(m.key);
    await DB.delProd(b.dataset.id); return renderTrash();
  }
  if (a === 'trashEmpty') {
    const [tp, tc] = await Promise.all([DB.trashedProds(), DB.trashedChars()]);
    const what = [tp.length ? `${tp.length} vidéo${tp.length > 1 ? 's' : ''}` : '', tc.length ? `${tc.length} planche${tc.length > 1 ? 's' : ''}` : ''].filter(Boolean).join(' et ');
    if (!(await H.ask('Vider la corbeille ?', { text: `${what || 'Tout ce qui s\'y trouve'} : effacé pour de bon, sans retour possible.`, ok: 'Vider la corbeille', danger: true }))) return;
    const n = await DB.purgeTrash(true); H.toast(`Corbeille vidée (${n} élément${n > 1 ? 's' : ''} effacé${n > 1 ? 's' : ''})`); return renderTrash();
  }
  if (a === 'clearVideo') { draft.video = null; return renderAuto(); }
  if (a === 'new' || a === 'another') { currentId = null; prodTab = null; wantLauncher = true; H.showView('auto'); return; }
  if (a === 'backLive') { wantLauncher = false; currentId = state ? state.id : null; return renderAuto(); }
  if (a === 'launch') return launch(b.dataset.now === '1');
  if (a === 'diag') return runDiag(b.dataset.k || null);
  if (a === 'conn') { currentId = null; wantLauncher = true; await renderAuto(); const el = H.$('#connPanel'); if (el) el.scrollIntoView({ block: 'start' }); return; }
  if (a === 'open') { currentId = b.dataset.id; prodTab = null; wantLauncher = false; H.showView('auto'); return; }
  if (a === 'ptab') { prodTab = b.dataset.tab; return renderAuto(); }
  if (a === 'style') { readDraft(); pasteTo = 'style'; draft.style = b.dataset.style; return renderAuto(); }
  if (a === 'mini') { readDraft(); pasteTo = 'mini'; draft.miniStyle = b.dataset.mini; return renderAuto(); }
  if (a === 'miniGpt') { // la miniature type de ce style, faite dans ChatGPT avec la même consigne de texte qu'une vraie miniature
    readDraft(); const k = miniKey(b.dataset.mini), prompt = P.miniTypePrompt(k);
    try { await navigator.clipboard.writeText(prompt); } catch (err) { /* presse-papiers refusé */ }
    window.open('https://chatgpt.com/?q=' + encodeURIComponent(prompt), '_blank', 'noopener');
    pasteTo = 'mini';
    H.toast('ChatGPT s\'ouvre avec la consigne (elle est aussi copiée). Quand l\'image est prête : clic droit, « Copier l\'image », puis Ctrl+V ici.', 7000);
    return;
  }
  if (a === 'miniTypeDel') { readDraft(); const k = miniKey(b.dataset.mini); forget(MINI_TYPE(k)); await DB.delMedia(MINI_TYPE(k)).catch(() => {}); const next = { ...miniTypes }; delete next[k]; miniTypes = next; return renderAuto(); }
  if (a === 'finalPick') return pickFinal();
  if (a === 'fileAccess') { chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` }).catch(() => H.toast('Ouvre chrome://extensions, puis Détails sur FruitRadar', 5000)); return; }
  if (a === 'styleSave' || a === 'styleGpt' || a === 'styleDel' || a === 'styleImgDel') { if (a === 'styleGpt') pasteTo = 'style'; return styleAction(a); }
  if (a === 'styleMore') { readDraft(); stylesOpen = !stylesOpen; return renderAuto(); }
  if (a === 'pfilter') { prodFilter = b.dataset.f; return renderProds(); }
  if (a === 'fresh') return freshStart(b.dataset.id || currentId);
  if (a === 'delProd') return removeProd(b.dataset.id || currentId);
  if (a === 'markPub') { const p = await DB.getProd(b.dataset.id || currentId); if (p) { p.publishedByUser = Date.now(); await DB.putProd(p); } return view === 'prods' ? renderProds() : renderAuto(); }
  if (a === 'markDone') { // la vidéo est faite (publiée à la main, ou plus rien à automatiser) : on range la production dans les terminées
    const id = b.dataset.id || currentId, p0 = await DB.getProd(id); if (!p0) return;
    if (!(await H.ask(`Marquer « ${p0.title || MODES[p0.mode]} » comme terminée ?`, { text: 'L\'automatisation s\'arrête pour cette vidéo et elle passe dans les productions terminées. Rien d\'autre n\'est envoyé sur TikTok.', ok: 'Marquer comme terminée' }))) return;
    if (state && state.id === id && busy() && await runnerAlive()) {
      if (p0.status === 'waiting' && p0.gate === 'publish') { // la fenêtre pilote attend ton accord pour publier : elle termine elle-même, proprement
        const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id, cmd: 'gate', text: 'mine' }).catch(() => null);
        if (r && r.ok) { H.toast('Production terminée'); return renderAuto(); }
      }
      await stopRunner(id);
    }
    const p = await DB.getProd(id); if (!p) return;
    Object.assign(p, { status: 'done', step: 'done', doneAt: Date.now(), gate: null, pause: null, publishSkipped: true, markedDone: Date.now() });
    p.log = [...(p.log || []), { t: Date.now(), level: 'info', msg: 'Marquée comme terminée à la main : l\'automatisation s\'arrête ici pour cette vidéo.' }];
    await DB.putProd(p);
    H.toast('Production terminée : elle est dans « Terminées »', 4000);
    return view === 'prods' ? renderProds() : renderAuto();
  }
  if (a === 'remontage' || a === 'retiktok') return redoEnd(a === 'remontage' ? 'montage' : 'tiktok', b.dataset.id || currentId);
  if (a === 'park') {
    parking = currentId; renderAuto(); // tout de suite à l'écran : « Mise de côté… », sans attendre la fenêtre d'automatisation
    const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id: currentId, cmd: 'stop' }).catch(() => null);
    H.toast(r && r.ok ? 'Mise de côté. Tu peux lancer une autre vidéo et la continuer plus tard.' : 'Déjà mise de côté', 4500);
    setTimeout(() => { parking = null; renderAuto(true); }, 20000); // filet : l'état réel a repris la main depuis longtemps
    return renderAuto(true);
  }
  if (a === 'unqueue') { const p = await DB.getProd(b.dataset.id); if (p && p.status === 'queued') { p.status = 'stopped'; await DB.putProd(p); } return view === 'prods' ? renderProds() : renderAuto(); }
  if (a === 'startNow') { await stopRunner(); currentId = b.dataset.id; await chrome.runtime.sendMessage({ type: 'autoOpen', id: currentId }).catch(() => null); return H.showView('auto'); }
  if (a === 'suite' || a === 'suiteOf') {
    const p = await DB.getProd(a === 'suite' ? currentId : b.dataset.id); if (!p) return;
    Object.assign(draft, { mode: 'suite', prevId: p.id, part: (p.part || 1) + 1, charIds: null, idea: '' });
    currentId = null; wantLauncher = true; H.showView('auto'); return;
  }
  if (a === 'resume' || a === 'stop') {
    b.disabled = true; // un seul clic : le bouton montre que c'est pris en compte
    const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id: currentId, cmd: a }).catch(() => null);
    if (!r || !r.ok) H.toast(a === 'resume' ? 'Fenêtre fermée : clique sur Continuer' : 'Déjà arrêtée');
    else if (a === 'resume') H.toast('Ça repart.', 2500);
    return renderAuto(true);
  }
  if (a === 'restart') {
    const id = b.dataset.id || currentId;
    const p = await DB.getProd(id); if (p) { p.status = 'queued'; p.queuedAt = Date.now(); await DB.putProd(p); }
    currentId = id;
    const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id }).catch(() => null);
    if (r && r.queued) H.toast(`Une autre vidéo tourne : celle-ci reprendra juste après (n° ${r.pos} dans la file)`, 5000);
    return H.showView('auto');
  }
  if (a === 'choose') {
    const n = Number(b.dataset.n), note = ideaNote.trim(), ed = (ideaEdits[currentId] || {})[n] || null;
    const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id: currentId, cmd: 'choose', n, text: note, edit: ed }).catch(() => null);
    if (r && r.ok) { ideaNote = ''; ideaForm = null; H.toast(`Histoire ${n} choisie${ed ? ', avec tes modifications' : ''}${note ? `${ed ? ' et' : ' avec'} ta précision` : ''} : Claude écrit le package`); } else H.toast((r && r.error) || 'Fenêtre fermée : relance la production', 4000);
    return;
  }
  if (a === 'ideaEdit') {
    const p = await DB.getProd(currentId), i0 = p && (p.ideas || []).find((x) => x.n === Number(b.dataset.n)); if (!i0) return;
    if (ideaForm) readIdeaForm();
    const cur = P.applyIdeaEdit(i0, (ideaEdits[p.id] || {})[i0.n]);
    ideaForm = { id: p.id, n: i0.n, titre: cur.titre || '', accroche: cur.accroche || '', histoire: cur.histoire || cur.pitch || '', cast: P.parseCast(cur.personnages) };
    if (!ideaForm.cast.length) ideaForm.cast = [{ name: '', role: '' }];
    await renderAuto();
    const el = H.$('.story.editing [data-ie=titre]'); if (el) { el.closest('.story').scrollIntoView({ block: 'nearest' }); el.focus(); }
    return;
  }
  if (a === 'ideaCastAdd' && ideaForm) { readIdeaForm(); ideaForm.cast.push({ name: '', role: '' }); await renderAuto(); const ins = H.$$('.story.editing [data-ie=name]'); if (ins.length) ins[ins.length - 1].focus(); return; }
  if (a === 'ideaCastDel' && ideaForm) { readIdeaForm(); ideaForm.cast.splice(Number(b.dataset.i), 1); if (!ideaForm.cast.length) ideaForm.cast = [{ name: '', role: '' }]; return renderAuto(); }
  if (a === 'ideaCancel') { ideaForm = null; return renderAuto(); }
  if (a === 'ideaReset' && ideaForm) {
    const { id, n } = ideaForm;
    if (ideaEdits[id]) { delete ideaEdits[id][n]; if (!Object.keys(ideaEdits[id]).length) delete ideaEdits[id]; await saveIdeaEdits(); }
    ideaForm = null; H.toast(`Idée ${n} remise comme Claude l'avait écrite`); return renderAuto();
  }
  if (a === 'ideaSave' && ideaForm) {
    readIdeaForm();
    const f = ideaForm, p = await DB.getProd(f.id), i0 = p && (p.ideas || []).find((x) => x.n === f.n);
    const e = P.cleanIdeaEdit(f);
    if (!e) { H.toast('Écris au moins un titre ou l\'histoire'); return; }
    const base = i0 && P.cleanIdeaEdit({ titre: i0.titre, accroche: i0.accroche, histoire: i0.histoire || i0.pitch, cast: P.parseCast(i0.personnages) });
    if (base && JSON.stringify(base) === JSON.stringify(e)) { if (ideaEdits[f.id]) delete ideaEdits[f.id][f.n]; } // rien de changé : on garde l'idée de Claude
    else ideaEdits[f.id] = { ...(ideaEdits[f.id] || {}), [f.n]: { ...e, at: Date.now() } };
    await saveIdeaEdits();
    ideaForm = null;
    H.toast(base && JSON.stringify(base) === JSON.stringify(e) ? 'Rien de changé' : `Idée ${f.n} modifiée : choisis-la pour que Claude écrive cette version`, 4000);
    return renderAuto();
  }
  if (a === 'gate') {
    let v = b.dataset.v;
    if (v === 'mini') { // la miniature est refaite dans ChatGPT, puis la carte de validation revient
      const st = miniPick[currentId] || (H.$('#gMiniStyle') || {}).value || '';
      const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id: currentId, cmd: 'gate', text: `mini:${st}` }).catch(() => null);
      H.toast(r && r.ok ? 'Je refais la miniature dans ChatGPT : la validation revient dès qu\'elle est prête' : (r && r.error) || 'Fenêtre fermée : relance la production', 4500);
      return renderAuto();
    }
    if (v === 'show') { const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id: currentId, cmd: 'gate', n: 'show' }).catch(() => null); if (!r || !r.ok) H.toast((r && r.error) || 'Fenêtre fermée : relance la production', 4000); return; }
    if (v === 'mredo' && !(await H.ask('Refaire le montage ?', { text: 'Un nouveau projet CapCut est créé, avec les mêmes clips.', ok: 'Refaire le montage' }))) return;
    const montage = v === 'mok' || v === 'mredo';
    if (montage) v = v === 'mok' ? 'ok' : 'redo';
    if (v === 'redo' && !montage && !(await H.ask('Refaire le montage dans CapCut ?', { text: 'La vidéo exportée actuelle sera remplacée.', ok: 'Refaire le montage' }))) return;
    if (v === 'publish') { const acc = String((await getSettings()).auto.tiktokAccount || '').replace(/^@/, ''); if (!(await H.ask(`Publier maintenant${acc ? ` sur @${acc}` : ''} ?`, { text: 'C\'est visible tout de suite par tout le monde.', ok: 'Publier' }))) return; }
    const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id: currentId, cmd: 'gate', text: v }).catch(() => null);
    H.toast(r && r.ok ? { ok: montage ? 'Montage validé : export lancé' : 'Vidéo validée : j\'envoie sur TikTok Studio', redo: 'Je refais le montage', publish: 'Publication lancée', skip: 'D\'accord, tu publies toi-même', mine: 'Notée comme publiée : la production est terminée' }[v] : (r && r.error) || 'Fenêtre fermée : relance la production', 4000);
    return renderAuto();
  }
  if (a === 'moreIdeas') {
    const note = ideaNote.trim();
    const r = await chrome.runtime.sendMessage({ type: 'autoOpen', id: currentId, cmd: 'more', text: note }).catch(() => null);
    if (r && r.ok) { ideaNote = ''; H.toast(`Claude écrit 10 nouvelles idées${note ? ' avec ta précision' : ''}`); } else H.toast((r && r.error) || 'Fenêtre fermée : relance la production', 4000);
    return;
  }
  if (a === 'redo') return redo(b.dataset.kind, b.dataset.n);
  if (a === 'copyLog') { const p = currentId && await DB.getProd(currentId); if (!p) return; const txt = [`FruitRadar ${chrome.runtime.getManifest().version} — « ${p.title || ''} » — étape ${p.step || '?'} — ${p.status}`, ...(p.log || []).slice(-250).map((l) => `${new Date(l.t).toLocaleTimeString('fr-FR')} ${l.level === 'warn' ? '⚠ ' : l.level === 'error' ? '✖ ' : ''}${l.msg}`)].join('\n'); try { await navigator.clipboard.writeText(txt); H.toast('Journal copié : colle-le dans ton message'); } catch (err) { H.toast('Copie impossible'); } return; }
  if (a === 'copyDiag') { try { await navigator.clipboard.writeText(JSON.stringify(diagRes, null, 1)); H.toast('Diagnostic copié'); } catch (err) { H.toast('Copie impossible'); } return; }
  if (a === 'pastePkg') return pastePackage();
  if (a === 'copyDump') { const p = await DB.getProd(currentId); try { await navigator.clipboard.writeText(JSON.stringify(p.lastDump, null, 1)); H.toast('Diagnostic copié'); } catch (err) { H.toast('Copie impossible'); } return; }
  if (a === 'sound') { chrome.runtime.sendMessage({ type: 'autoSound', kind: b.dataset.kind }).catch(() => {}); return; }
  if (a === 'copy') {
    const p = await DB.getProd(currentId); if (!p || !p.pkg) return;
    const k = p.pkg, n = Number(b.dataset.n), s = k.scenes.find((x) => x.n === n), miniDefault = (await getSettings()).auto.miniStyle;
    const text = { planche: () => k.planches[n].prompt, image: () => s.image, video: () => P.withSpeakerLock(s.video), mini: () => P.miniPrompt(k, { ...p, miniStyle: miniPick[p.id] || p.miniStyle }, miniDefault), desc: () => k.description, all: () => packageToText(k) }[b.dataset.what]();
    try { await navigator.clipboard.writeText(text); H.toast('Copié'); } catch (err) { H.toast('Copie impossible'); }
    return;
  }
  if (a === 'addChar') {
    const name = H.$('#cName').value.trim(), series = H.$('#cSeries').value.trim() || 'Sans histoire', f = H.$('#cFile').files[0], st = H.$('#cStyle');
    if (!name || !f) return H.toast('Il faut un nom et une image.');
    await DB.putChar({ id: `m/${normName(series)}/${normName(name)}`, name, blob: f, prompt: '', series: 'm/' + normName(series), seriesTitle: series, from: 'manuel', style: st ? st.value : '', styleLabel: st && st.value ? st.options[st.selectedIndex].textContent : '' });
    forget('c:' + `m/${normName(series)}/${normName(name)}`);
    H.toast('Planche ajoutée'); return renderChars();
  }
  if (a === 'charFilter') { charFilter.style = charFilter.style === b.dataset.v ? '' : b.dataset.v; return b.dataset.where === 'pick' ? renderPicker() : renderChars(); }
  if (a === 'prevFileClear') { readDraft(); draft.prevFile = null; return renderAuto(); }
  if (a === 'prevMore') { readDraft(); prevAll = !prevAll; return fillSuite(); }
  if (a === 'prevPick') { // partie précédente choisie par sa vignette : ses personnages, son style et le numéro de partie suivent
    readDraft();
    const id = b.dataset.id || '';
    if (id === draft.prevId) return;
    draft.prevId = id; draft.charIds = null; draft.prevFile = null;
    const pv = id ? await DB.getProd(id).catch(() => null) : null;
    if (pv) { draft.part = (pv.part || 1) + 1; if (pv.style) { draft.style = pv.style; draft.styleText = pv.styleText || ''; } }
    return renderAuto();
  }
  if (a === 'copyChar') { const c = await DB.getChar(b.dataset.id).catch(() => null); if (c) { try { await navigator.clipboard.writeText(c.prompt); H.toast('Prompt copié'); } catch (err) {} } }
}

/* ---------- réglages de l'automatisation (dans la fenêtre Réglages) ---------- */
export async function fillSettingsForm() {
  const a = (await getSettings()).auto, $ = H.$;
  $('#sClaudeUrl').value = a.claudeUrl; $('#sGrokUrl').value = a.grokUrl; $('#sCapcutUrl').value = a.capcutUrl;
  $('#sAttachMeta').checked = a.attachMetaprompt; $('#sUseTurbo').checked = a.useTurbo; $('#sTranscriber').value = a.transcriber === 'turbo' ? 'turbo' : 'vt'; $('#sCapcutPlace').checked = a.capcutPlace; $('#sCapcutClean').checked = a.capcutClean !== false; $('#sCapcutTrans').checked = a.capcutTransitions; $('#sSendVideo').checked = a.sendVideoToClaude !== false; $('#sSaveDisk').checked = !!a.saveToDisk;
  { const end = a.tiktokFlow === false ? 'capcut' : a.tiktokAutoPublish ? 'auto' : 'ask'; H.$$('input[name=sEnd]').forEach((r) => { r.checked = r.value === end; }); } // jusqu'où FruitRadar va tout seul
  paintEnd();
  $('#sCapcutExport').checked = a.capcutExport !== false; $('#sFinalCheck').checked = a.finalCheck !== false; $('#sStyleRef').checked = a.styleRef !== false; $('#sFinalDownload').checked = a.finalDownload !== false; $('#sCapcutCheck').value = a.capcutCheck === false || a.capcutCheck === 'never' ? 'never' : a.capcutCheck === true || a.capcutCheck === 'always' ? 'always' : 'auto'; $('#sCoverAlign').value = a.tiktokCoverAlign || 'haut'; $('#sSameWindow').checked = a.sameWindow === true; $('#sTiktokCaps').checked = a.tiktokCaptions !== false;
  $('#sTiktokAccount').value = a.tiktokAccount || ''; $('#sTiktokSound').value = a.tiktokSound || 'auto'; $('#sTiktokSoundName').value = a.tiktokSoundName || ''; $('#sTiktokCapY').value = Math.round((!a.tiktokCaptionY || a.tiktokCaptionY === 0.62 ? 0.68 : a.tiktokCaptionY) * 100); $('#sTiktokVol').value = a.tiktokVolume ?? -7;
  $('#sAutoSound').checked = a.sound; $('#sAutoSteps').checked = a.notifySteps; $('#sAutoExtra').value = a.extra || '';
  $('#sAudience').value = a.audience || ''; $('#sTurboWait').value = a.turboWaitMin || 30; $('#sImageWait').value = a.imageWaitMin || 20; $('#sGrokParallel').value = a.grokParallel || 3; $('#sPace').value = String([0.45, 0.7, 1].includes(Number(a.pace)) ? Number(a.pace) : 0.45); $('#sCharStyle').value = a.charStyle || 'fruits';
  $('#sAutoErrors').checked = a.notifyErrors; $('#sGrokCrop').checked = a.grokCrop; $('#sGrokQuality').value = a.grokQuality;
  $('#sSelectors').value = a.selectors && Object.keys(a.selectors).length ? JSON.stringify(a.selectors, null, 2) : '';
  const { autoMetaprompt } = await chrome.storage.local.get('autoMetaprompt');
  $('#sMetaStatus').textContent = autoMetaprompt && autoMetaprompt.text ? `${autoMetaprompt.name} (${Math.round(autoMetaprompt.text.length / 1000)} k caractères), importé ${when(autoMetaprompt.at)}` : 'Metaprompt V6 fourni avec l\'extension';
  $('#sMetaFile').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const text = await f.text();
    if (text.length < 2000) return H.toast('Ce fichier a l\'air trop court pour être ton métaprompt.');
    await chrome.storage.local.set({ autoMetaprompt: { name: f.name, text, at: Date.now() } });
    $('#sMetaStatus').textContent = `${f.name} (${Math.round(text.length / 1000)} k caractères), importé à l'instant`;
    H.toast('Métaprompt remplacé');
  };
  $('#sMetaReset').onclick = async () => { await chrome.storage.local.remove('autoMetaprompt'); $('#sMetaStatus').textContent = 'Metaprompt V6 fourni avec l\'extension'; };
}
export async function saveSettingsForm() {
  const $ = H.$, cur = (await getSettings()).auto;
  let selectors = cur.selectors;
  const raw = $('#sSelectors').value.trim();
  if (!raw) selectors = {}; else { try { selectors = JSON.parse(raw); } catch (e) { H.toast('Corrections de sélecteurs : JSON invalide, gardé tel qu\'avant', 4000); } }
  const url = (id, def) => { const v = $('#' + id).value.trim(); return /^https:\/\//.test(v) ? v : def; };
  await saveSettings({ auto: { ...cur, claudeUrl: url('sClaudeUrl', AUTO_DEFAULTS.claudeUrl), grokUrl: url('sGrokUrl', AUTO_DEFAULTS.grokUrl), capcutUrl: url('sCapcutUrl', AUTO_DEFAULTS.capcutUrl),
    attachMetaprompt: $('#sAttachMeta').checked, useTurbo: $('#sUseTurbo').checked, transcriber: $('#sTranscriber').value === 'turbo' ? 'turbo' : 'vt', capcutPlace: $('#sCapcutPlace').checked, capcutClean: $('#sCapcutClean').checked, capcutTransitions: $('#sCapcutTrans').checked, sendVideoToClaude: $('#sSendVideo').checked, saveToDisk: $('#sSaveDisk').checked, sound: $('#sAutoSound').checked, notifySteps: $('#sAutoSteps').checked,
    tiktokAutoPublish: endMode() === 'auto',
    tiktokFlow: endMode() !== 'capcut', capcutExport: $('#sCapcutExport').checked, finalCheck: $('#sFinalCheck').checked, styleRef: $('#sStyleRef').checked, finalDownload: $('#sFinalDownload').checked, capcutCheck: $('#sCapcutCheck').value, tiktokCoverAlign: $('#sCoverAlign').value, sameWindow: $('#sSameWindow').checked, tiktokCaptions: $('#sTiktokCaps').checked, tiktokAccount: $('#sTiktokAccount').value.trim().replace(/^@/, ''),
    tiktokSound: $('#sTiktokSound').value, tiktokSoundName: $('#sTiktokSoundName').value.trim(), tiktokCaptionY: Math.min(0.9, Math.max(0.3, (Number($('#sTiktokCapY').value) || 68) / 100)), tiktokVolume: Number($('#sTiktokVol').value || -7),
    notifyErrors: $('#sAutoErrors').checked, grokCrop: $('#sGrokCrop').checked, grokQuality: $('#sGrokQuality').value,
    audience: $('#sAudience').value.trim() || AUTO_DEFAULTS.audience, turboWaitMin: Math.min(120, Math.max(5, Number($('#sTurboWait').value) || 30)), imageWaitMin: Math.min(90, Math.max(5, Number($('#sImageWait').value) || 20)), grokParallel: Math.min(6, Math.max(1, Math.round(Number($('#sGrokParallel').value) || 3))), pace: Number($('#sPace').value) || 0.45, charStyle: $('#sCharStyle').value || 'fruits',
    extra: $('#sAutoExtra').value.trim(), selectors } });
}
