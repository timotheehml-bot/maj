// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
/* FruitRadar — automatisation : boîte à outils injectée dans la page pilotée (Claude, ChatGPT, Grok, CapCut, TurboScribe).
   Elle ne décide rien : la fenêtre pilote appelle ces petites actions une par une et lit ce qu'elles renvoient.
   Les sélecteurs viennent de auto/sites.js (et de Réglages → Automatisation → corrections). */
(() => {
  const REV = '4.9.30';
  if (window.__FRA && window.__FRA.rev === REV) return; // une version plus ancienne restée dans la page est remplacée
  /* Pause qui ne ralentit pas quand la fenêtre est cachée : Chrome bride les minuteries d'une page en arrière-plan (1 par seconde,
     puis 1 par minute au bout de 5 minutes). On demande donc aussi le « top » à l'extension, qui, elle, n'est pas bridée. */
  const sleep = (ms) => new Promise((r) => {
    let done = false; const fin = () => { if (!done) { done = true; r(); } };
    setTimeout(fin, ms);
    try { chrome.runtime.sendMessage({ type: 'frTick', ms }, () => { void chrome.runtime.lastError; fin(); }); } catch (e) { /* extension rechargée : la minuterie suffit */ }
  });
  const vis = (el) => {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect(), cs = getComputedStyle(el);
    return r.width > 1 && r.height > 1 && cs.visibility !== 'hidden' && cs.display !== 'none';
  };
  const qAll = (sels, root = document) => {
    const out = [];
    for (const s of sels || []) { try { for (const el of root.querySelectorAll(s)) if (!out.includes(el)) out.push(el); } catch (e) { /* sélecteur invalide */ } }
    return out;
  };
  const firstVis = (sels) => qAll(sels).find(vis) || null;
  const txt = (el) => ((el && (el.innerText || el.textContent)) || '').replace(/\s+/g, ' ').trim();
  const label = (el) => `${txt(el)} ${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''}`.trim();
  const CLICKABLE = 'button, a, [role="button"], [role="menuitem"], [role="menuitemradio"], [role="option"], [role="tab"], [role="radio"], label, summary';
  const fire = (el, type, init = {}) => el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, ...init }));
  /* Un clic comme celui d'une vraie souris : sur l'élément le plus profond sous le pointeur (certains sites n'écoutent que le texte
     ou le dessin à l'intérieur du bouton), avec la prise de focus (les menus qui s'ouvrent « au focus »), puis UN seul événement clic. */
  const click = (el, opt = {}) => {
    el.scrollIntoView({ block: 'center' });
    const r = el.getBoundingClientRect();
    const p = { bubbles: true, cancelable: true, composed: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
    let t = document.elementFromPoint(p.clientX, p.clientY);
    if (!t || !el.contains(t)) t = el;
    try { t.dispatchEvent(new PointerEvent('pointerdown', { ...p, pointerId: 1, pointerType: 'mouse', isPrimary: true, buttons: 1 })); } catch (e) {}
    t.dispatchEvent(new MouseEvent('mousedown', { ...p, buttons: 1 }));
    const f = t.closest('button, a[href], input, select, textarea, [tabindex], label');
    if (f && f.focus) {
      try { f.focus({ preventScroll: true }); } catch (e) {}
      // Fenêtre pas au premier plan : Chrome n'envoie alors aucun événement de focus. Pour les menus chargés « au focus » (TurboScribe),
      // on les envoie nous-mêmes — seulement là où c'est demandé, pour ne pas refermer les menus des autres sites.
      if (opt.fakeFocus && !document.hasFocus()) { try { f.dispatchEvent(new FocusEvent('focus')); f.dispatchEvent(new FocusEvent('focusin', { bubbles: true })); } catch (e) {} }
    }
    try { t.dispatchEvent(new PointerEvent('pointerup', { ...p, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch (e) {}
    t.dispatchEvent(new MouseEvent('mouseup', p));
    t.dispatchEvent(new MouseEvent('click', { ...p, detail: 1 }));
  };
  /* Clic d'envoi sur un site où le bouton est AUSSI le bouton d'un formulaire (Grok Imagine) : un clic simulé y déclenche deux envois,
     celui du bouton puis celui du formulaire (relevé sur le vrai site : 2 vidéos pour 1 clic). On neutralise l'envoi du formulaire :
     il ne reste que celui du bouton, exactement comme avec une vraie souris. */
  const clickOnce = (el) => {
    const stop = (e) => { e.preventDefault(); e.stopImmediatePropagation(); };
    window.addEventListener('submit', stop, true);
    try { click(el); } finally { window.removeEventListener('submit', stop, true); }
  };
  const disabled = (el) => el.disabled || el.getAttribute('aria-disabled') === 'true' || el.getAttribute('data-disabled') === 'true';

  /* ---------- fichiers : reçus en morceaux (base64), reconstruits ici ---------- */
  const inbox = new Map(), outbox = new Map();
  const b64ToBytes = (b64) => { const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };
  function putChunk(id, name, type, b64) {
    if (!inbox.has(id)) inbox.set(id, { name, type, parts: [] });
    inbox.get(id).parts.push(b64ToBytes(b64));
    return inbox.get(id).parts.length;
  }
  const fileOf = (id) => { const f = inbox.get(id); return f ? new File(f.parts, f.name, { type: f.type, lastModified: Date.now() }) : null; };
  function dropFiles(ids) { (ids || [...inbox.keys()]).forEach((id) => inbox.delete(id)); return true; }

  const blobToB64 = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = () => rej(r.error); r.readAsDataURL(blob); });
  async function stash(blob, id) {
    const STEP = 3 * 1024 * 1024, parts = [];
    for (let o = 0; o < blob.size; o += STEP) parts.push(await blobToB64(blob.slice(o, o + STEP)));
    outbox.set(id, parts);
    return { ok: true, id, type: blob.type || '', size: blob.size, n: parts.length };
  }
  /* Récupère un fichier de la page (image générée, clip) : téléchargement direct, sinon copie de l'image affichée */
  /* Téléchargement par morceaux (requêtes « Range »). Vu sur grok.com le 16 novembre 2026 : le serveur des clips coupe un téléchargement
     entier au bout de 3 secondes (« Failed to fetch ») mais sert sans problème des morceaux de 4 Mo, comme pour le lecteur vidéo. */
  async function fetchRanged(url) {
    const ctl = new AbortController();
    const h = await fetch(url, { credentials: 'include', cache: 'no-store', signal: ctl.signal }); // en-tête seulement : taille et type
    const total = Number(h.headers.get('content-length')) || 0, type = h.headers.get('content-type') || '';
    try { ctl.abort(); } catch (e) { /* déjà fini */ }
    if (!h.ok) throw new Error('HTTP ' + h.status);
    if (/html/.test(type)) throw new Error('fichier vide');
    let step = 4 * 1048576, off = 0; const parts = [];
    for (let n = 0; n < 4000 && (!total || off < total); n++) {
      let b = null, res = null, err = null, asked = step;
      for (let t = 0; t < 4 && !b; t++) {
        asked = step;
        try {
          res = await fetch(url, { credentials: 'include', cache: 'no-store', headers: { Range: `bytes=${off}-${off + asked - 1}` } });
          if (res.status === 416) break;
          if (res.status !== 206 && res.status !== 200) throw new Error('HTTP ' + res.status);
          b = await res.blob();
        } catch (e) { err = e; b = null; step = Math.max(262144, Math.floor(step / 2)); await sleep(400 * (t + 1)); }
      }
      if (res && res.status === 416) break;
      if (!b) throw err || new Error('morceau illisible');
      parts.push(b); off += b.size;
      if (res.status === 200 || (!total && b.size < asked)) break;
    }
    if (total && off < total) throw new Error(`fichier incomplet (${off} octets sur ${total})`);
    return new Blob(parts, { type: /^(video|image|audio)\//.test(type) ? type : '' });
  }
  async function fetchOut(url, id, minSize = 2000, byRange = false) {
    try {
      const kept = window.__capExp;
      if (kept && kept.href === url && kept.keep) { await kept.keep; if (kept.blob && kept.blob.size >= minSize) return await stash(kept.blob, id); } // fichier exporté de CapCut, copié au moment du clic
      let blob = null;
      if (byRange && /^https?:/.test(url)) blob = await fetchRanged(url);
      else {
        const res = await fetch(url, { credentials: 'include' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        blob = await res.blob();
      }
      if (blob.size < minSize || /html/.test(blob.type)) throw new Error('fichier vide');
      return await stash(blob, id);
    } catch (e) {
      const img = [...document.images].find((i) => i.currentSrc === url || i.src === url);
      if (img) {
        try {
          const c = document.createElement('canvas'); c.width = img.naturalWidth; c.height = img.naturalHeight;
          c.getContext('2d').drawImage(img, 0, 0);
          const blob = await new Promise((r) => c.toBlob(r, 'image/png'));
          if (blob) return await stash(blob, id);
        } catch (e2) { /* image d'un autre domaine : la fenêtre pilote la téléchargera elle-même */ }
      }
      return { ok: false, error: String(e.message || e) };
    }
  }
  function getChunk(id, i) { const p = outbox.get(id); const c = p ? p[i] : null; if (p && i === p.length - 1) outbox.delete(id); return c; }

  /* ---------- zone de saisie ---------- */
  const hintOf = (el) => [el.getAttribute('placeholder'), el.getAttribute('aria-label'), el.getAttribute('data-placeholder'), (el.querySelector && el.querySelector('[data-placeholder]') || { getAttribute: () => '' }).getAttribute('data-placeholder')].filter(Boolean).join(' ');
  const commonDepth = (a, b) => { const up = new Set(); for (let x = a; x; x = x.parentElement) up.add(x); let d = 0; for (let x = b; x; x = x.parentElement) if (up.has(x)) { for (let y = x; y; y = y.parentElement) d++; break; } return d; };
  function composer(cfg) {
    const all = [];
    for (const sel of cfg.composer || []) for (const el of document.querySelectorAll(sel)) if (vis(el) && !all.some((a) => a === el || a.contains(el) || el.contains(a))) all.push(el);
    if (!all.length) return null;
    const avoid = cfg.composerAvoid ? new RegExp(cfg.composerAvoid, 'i') : null, prefer = cfg.composerPrefer ? new RegExp(cfg.composerPrefer, 'i') : null;
    let c = avoid ? all.filter((el) => !avoid.test(hintOf(el))) : all;
    if (!c.length) return cfg.composerStrict ? null : all[0];
    if (prefer) { const p = c.filter((el) => prefer.test(hintOf(el))); if (p.length) c = p; }
    if (cfg.composerNearAttach && c.length > 1) { // la boîte la plus proche de l'image jointe
      const anchor = [...document.querySelectorAll('img')].filter((i) => vis(i) && /^(blob:|data:)/.test(i.currentSrc || i.src)).pop();
      if (anchor) c = [...c].sort((a, b) => commonDepth(anchor, b) - commonDepth(anchor, a));
    }
    return c[0];
  }
  /* Le cadre de saisie quand il a une barre d'outils (Grok Imagine : + · Vidéo · 1080p · 10s · 9:16 · ↑) :
     le plus petit bloc autour du champ qui contient aussi ces réglages. On n'agit jamais en dehors. */
  function inputCard(cfg) {
    const comp = composer(cfg); if (!comp) return null;
    if (cfg.cardMarker) {
      const re = new RegExp(cfg.cardMarker, 'i');
      for (let up = comp.parentElement, i = 0; up && up !== document.body && i < 10; up = up.parentElement, i++)
        if ([...up.querySelectorAll(CLICKABLE)].some((b) => vis(b) && re.test(txt(b)))) return up;
    }
    return composerCard(cfg);
  }
  const isOn = (el) => ['aria-checked', 'aria-pressed', 'aria-selected'].some((a) => el.getAttribute(a) === 'true') || /^(on|active|checked|selected)$/i.test(el.getAttribute('data-state') || '') || /\b(active|selected|is-active)\b/i.test(String(el.className || ''));
  const isOff = (el) => ['aria-checked', 'aria-pressed', 'aria-selected'].some((a) => el.getAttribute(a) === 'false') || /^(off|inactive|unchecked)$/i.test(el.getAttribute('data-state') || '');
  /* Mode Vidéo : on ne clique que s'il n'est pas déjà choisi (un deuxième clic pourrait le désactiver) */
  async function ensureVideo(cfg) {
    const card = inputCard(cfg) || document.body, re = new RegExp(cfg.videoMode, 'i');
    const el = [...card.querySelectorAll(CLICKABLE)].filter((b) => vis(b) && (re.test(txt(b)) || re.test(b.getAttribute('aria-label') || '') || re.test(b.getAttribute('title') || '')))[0];
    if (!el) return { ok: false, notFound: true };
    if (isOn(el) || (!isOff(el) && re.test(txt(el)))) return { ok: true, how: 'déjà sur Vidéo' }; // le libellé « Vidéo » ne s'affiche que sur le mode choisi
    click(el); await sleep(900);
    return { ok: true, how: 'Vidéo choisi' };
  }
  /* Un réglage affiché comme un bouton qui montre sa valeur (« 1080p », « 10s », « 9:16 ») et ouvre un menu.
     Si la valeur est déjà la bonne : on ne touche à rien. Sinon : menu, option, vérification, menu refermé. */
  async function ensureOption(triggerPattern, wantPattern, cfg) {
    const card = inputCard(cfg) || document.body;
    const tre = new RegExp(triggerPattern, 'i'), wre = new RegExp(wantPattern, 'i');
    const lre = cfg.labelNow ? new RegExp(cfg.labelNow, 'i') : null;
    const trig = () => (lre && [...document.querySelectorAll('button[aria-label]')].find((el) => vis(el) && lre.test(el.getAttribute('aria-label')))) || [...card.querySelectorAll(CLICKABLE)].filter((el) => vis(el) && tre.test(txt(el)))[0];
    const kev = (el, key, code) => { for (const type of ['keydown', 'keyup']) el.dispatchEvent(new KeyboardEvent(type, { bubbles: true, cancelable: true, composed: true, key, code: key === ' ' ? 'Space' : key, keyCode: code, which: code })); };
    const openMenus = () => [...document.querySelectorAll('[role="menu"], [role="listbox"]')].filter(vis);
    // Échap sur le menu lui-même, sur l'élément actif et sur la page : un menu resté ouvert bloquerait le réglage suivant
    const esc = () => { for (const el of new Set([...openMenus(), document.activeElement, document].filter(Boolean))) kev(el, 'Escape', 27); };
    let t = trig();
    if (!t) return { ok: false, notFound: true };
    if (wre.test(txt(t))) return { ok: true, how: 'déjà réglé', value: txt(t) };
    const before = txt(t);
    const MENU = '[role="menu"], [role="listbox"], [role="dialog"], [data-radix-popper-content-wrapper], [data-radix-menu-content], [class*="popover" i], [class*="dropdown" i], [class*="menu" i]';
    const options = () => [...document.querySelectorAll(CLICKABLE + ', [role="menuitemcheckbox"], [cmdk-item], li, [data-value], div, span')]
      .filter((el) => vis(el) && el !== t && !t.contains(el) && !el.contains(t) && wre.test(txt(el)) && txt(el).length < 40)
      .sort((a, b) => (!!b.closest(MENU) - !!a.closest(MENU)) || (b.matches(CLICKABLE) - a.matches(CLICKABLE)) || (txt(a).length - txt(b).length));
    const menuOpen = () => openMenus().length > 0;
    const shut = async () => { if (!menuOpen()) return; esc(); await sleep(250); if (menuOpen()) { const tt = trig(); if (tt) { click(tt); await sleep(250); } } }; // Échap ignoré : recliquer le bouton referme son menu
    for (let round = 0; round < 3; round++) {
      t = trig() || t;
      if (wre.test(txt(t))) return { ok: true, how: 'menu', value: txt(t) };
      let opts = options();
      // ouvrir le menu : un clic ; s'il ne s'affiche pas (page pas encore prête, menu refermé aussitôt), on reclique
      // un menu d'un AUTRE réglage est resté ouvert : on le ferme d'abord, sinon notre bouton ne s'ouvre pas
      if (!opts.length && menuOpen()) { esc(); await sleep(250); opts = options(); }
      for (let k = 0; k < 3 && !opts.length; k++) { if (!menuOpen()) click(t); for (let w = 0; w < 6 && !opts.length; w++) { await sleep(200); opts = options(); } }
      // le clic n'ouvre pas le menu (onglet passé à l'arrière-plan, page occupée) : on l'ouvre au clavier
      for (const [key, code] of [['ArrowDown', 40], ['Enter', 13], [' ', 32]]) { if (opts.length || menuOpen()) break; try { t.focus(); } catch (e) {} kev(t, key, code); for (let w = 0; w < 4 && !opts.length; w++) { await sleep(200); opts = options(); } }
      if (!opts.length) { await shut(); if (round < 2) { await sleep(400); continue; } return { ok: false, error: 'option absente du menu', value: before }; }
      const radios = [...document.querySelectorAll('[role="menuitemradio"], [role="option"]')].filter((el) => vis(el) && wre.test(txt(el)));
      await sleep(250); // un menu qui vient de s'ouvrir ignore un clic trop immédiat
      click(radios[0] || opts[0]);
      for (let w = 0; w < 9 && !wre.test(txt(trig() || t)); w++) await sleep(100); // relecture dès que le libellé change
      t = trig() || t;
      await shut();
      if (wre.test(txt(trig() || t))) return { ok: true, how: 'menu', value: txt(trig() || t) };
    }
    const now = txt(trig() || t);
    return { ok: false, error: `la valeur reste « ${now} »`, value: now };
  }
  /* Toute la zone de saisie (texte + pièces jointes affichées) : le plus grand bloc autour du champ qui ne contient aucun message */
  function composerCard(cfg) {
    const comp = composer(cfg); if (!comp) return null;
    const turnSel = [...(cfg.userTurn || []), ...(cfg.answer || [])].join(',');
    let card = (cfg.composerBox || ['form', '[data-testid*="composer" i]', '[class*="composer" i]']).map((sel) => comp.closest(sel)).find(Boolean) || comp.parentElement;
    if (turnSel) { let up = comp; while (up.parentElement && up.parentElement !== document.body && !up.parentElement.querySelector(turnSel)) up = up.parentElement; if (up.contains(card)) card = up; }
    return card;
  }
  async function setText(text, cfg) {
    const el = composer(cfg);
    if (!el) return { ok: false, error: 'zone de saisie introuvable' };
    el.focus();
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, text);
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return { ok: el.value.length > 0, how: 'champ' };
    }
    const filled = () => txt(el).length >= Math.min(12, text.trim().length);
    const selectAll = () => { const r = document.createRange(); r.selectNodeContents(el); const s = getSelection(); s.removeAllRanges(); s.addRange(r); };
    if (txt(el)) { selectAll(); document.execCommand('delete'); }
    const order = cfg.textOrder || ['paste', 'exec', 'set'];
    for (const how of order) {
      el.focus();
      try {
        if (how === 'paste') {
          const dt = new DataTransfer(); dt.setData('text/plain', text);
          el.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt }));
        } else if (how === 'exec') {
          selectAll(); getSelection().collapseToEnd();
          document.execCommand('insertText', false, text);
        } else {
          el.textContent = text;
          el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
        }
      } catch (e) { /* méthode suivante */ }
      await sleep(350);
      if (filled()) return { ok: true, how };
      // un long texte collé peut devenir une pièce jointe (Claude) : la zone reste vide mais une vignette apparaît
      if (how === 'paste' && text.length > 3000 && cfg.pasteMayAttach) { await sleep(900); if (!filled()) return { ok: true, how: 'collé en pièce jointe' }; }
    }
    return { ok: false, error: 'le texte ne rentre pas dans la zone de saisie' };
  }

  async function attach(ids, cfg) {
    const files = ids.map(fileOf).filter(Boolean);
    if (!files.length) return { ok: false, error: 'fichiers non reçus par la page' };
    const dt = new DataTransfer(); files.forEach((f) => dt.items.add(f));
    const accepts = (inp) => {
      const acc = (inp.getAttribute('accept') || '').toLowerCase();
      if (!acc) return true;
      return files.every((f) => acc.split(',').some((a) => { a = a.trim(); return a === f.type || (a.endsWith('/*') && f.type.startsWith(a.slice(0, -1))) || (a.startsWith('.') && f.name.toLowerCase().endsWith(a)); }));
    };
    const card = cfg.cardMarker ? inputCard(cfg) : null;
    const inCard = card ? [...card.querySelectorAll((cfg.fileInput || ['input[type="file"]']).join(','))].filter(accepts) : [];
    let inputs = inCard;
    if (!inputs.length) for (const sel of cfg.fileInput || ['input[type="file"]']) { inputs = [...document.querySelectorAll(sel)].filter(accepts); if (inputs.length) break; }
    const inp = inputs.find((i) => i.multiple) || inputs[0];
    if (inp && (inp.multiple || files.length === 1)) {
      inp.files = dt.files;
      if (!cfg.changeOnly) inp.dispatchEvent(new Event('input', { bubbles: true }));
      inp.dispatchEvent(new Event('change', { bubbles: true }));
      return { ok: true, how: 'sélecteur de fichiers', n: files.length };
    }
    const target = composer(cfg) || firstVis(cfg.dropZone || []) || document.body;
    try {
      target.focus && target.focus();
      const ev = new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt });
      const handled = !target.dispatchEvent(ev);
      if (handled) return { ok: true, how: 'collage', n: files.length };
    } catch (e) {}
    try {
      for (const type of ['dragenter', 'dragover', 'drop']) target.dispatchEvent(new DragEvent(type, { bubbles: true, cancelable: true, dataTransfer: dt }));
      return { ok: true, how: 'glisser-déposer', n: files.length, unsure: true };
    } catch (e) { return { ok: false, error: 'aucune façon de joindre un fichier sur cette page' }; }
  }

  async function send(cfg, waitMs = 90000) {
    const t0 = Date.now();
    let btn = null;
    const card = cfg.cardMarker ? inputCard(cfg) : null;
    const pick = () => {
      if (!card) {
        // d'abord le bouton d'envoi DE la zone de saisie : un autre « Envoyer » peut exister plus haut dans la page (message en cours de modification)
        const box = composerCard(cfg);
        const own = box && (cfg.send || []).map((sel) => [...box.querySelectorAll(sel)].find(vis)).find(Boolean);
        return own || firstVis(cfg.send);
      }
      const inCard = (cfg.send || []).map((sel) => [...card.querySelectorAll(sel)].find(vis)).find(Boolean);
      if (inCard) return inCard;
      // pas de libellé connu : le dernier bouton de la barre (la flèche), hors micro
      const bs = [...card.querySelectorAll('button, [role="button"]')].filter((b) => vis(b) && !/(micro|voice|voix|dict|audio|son\b|speaker)/i.test(label(b)));
      return bs[bs.length - 1] || null;
    };
    while (Date.now() - t0 < waitMs) {
      btn = pick();
      if (btn && !disabled(btn)) break;
      await sleep(500);
    }
    if (btn && !disabled(btn)) { (cfg.sendNoSubmit ? clickOnce : click)(btn); return { ok: true, how: 'bouton' }; }
    if (cfg.noEnterFallback) return { ok: false, error: 'bouton d\'envoi introuvable ou désactivé' };
    const el = composer(cfg);
    if (!el) return { ok: false, error: 'bouton d\'envoi introuvable' };
    el.focus();
    for (const type of ['keydown', 'keypress', 'keyup']) el.dispatchEvent(new KeyboardEvent(type, { bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 }));
    return { ok: true, how: 'touche Entrée', unsure: true };
  }

  /* ---------- lecture de la page ---------- */
  function detectBlock(cfg) {
    if (document.querySelector('iframe[src*="captcha" i], iframe[src*="challenges.cloudflare" i], #challenge-form, .cf-turnstile, #tiktok-verify-ele')) return 'captcha';
    const head = ((document.body && document.body.innerText) || '').slice(0, 1500);
    if (/verify you are human|vérifiez que vous êtes (un )?humain|checking your browser/i.test(head)) return 'captcha';
    if (/\/(login|signin|sign-in|log-in|auth)(\/|$|\?)/i.test(location.pathname) || /^(auth|accounts|login)\./i.test(location.hostname)) return 'connexion';
    if (cfg && cfg.loginText) {
      const b = [...document.querySelectorAll(CLICKABLE)].find((el) => vis(el) && new RegExp(cfg.loginText, 'i').test(txt(el)));
      if (b) return 'connexion';
    }
    return null;
  }
  const after = (a, b) => !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING); // b est après a

  /* Retrouve DANS la conversation le message de ce prompt, et l'image qui lui répond : celle rangée entre ce message et le message suivant.
     C'est ce qui rattache chaque image à son propre prompt — jamais « la dernière image arrivée ».
     hint.from : rang à partir duquel chercher ; hint.strict : ce rang est celui relevé juste avant l'envoi (le 1er message nouveau est donc le nôtre,
     même si la page n'en affiche que le début) ; hint.only : ne jamais remonter plus haut que ce rang. */
  const imgDoneOf = (cfg, i) => {
    if (!cfg.imgDone) return false;
    const re = new RegExp(cfg.imgDone, 'i'), box = i.closest(cfg.turn || 'article') || i.closest('article, [data-turn]');
    return !!box && [...box.querySelectorAll('button[aria-label], a[aria-label]')].some((b) => re.test(b.getAttribute('aria-label')));
  };
  function chatFind(cfg, text, hint = {}) {
    const norm = (t) => String(t || '').replace(/\s+/g, '');
    const want = norm(text), W = want.length;
    // « le même texte » = identique à quelques caractères près, ou contenu tel quel dans la bulle. Deux prompts différents ont souvent le même début
    // et la même fin (consignes, style) : une simple ressemblance les confondrait.
    const meas = (raw) => {
      const got = norm(raw), G = got.length, n = Math.min(W, G), tol = Math.max(6, Math.round(W * 0.005)); let a = 0, b = 0;
      while (a < n && want[a] === got[a]) a++;
      while (b < n - a && want[W - 1 - b] === got[G - 1 - b]) b++;
      const same = W > 0 && G > 0 && (got === want || (Math.abs(G - W) <= tol && a + b >= Math.max(G, W) - tol) || (W >= 40 && got.includes(want)));
      return { sim: same ? 1 : 0, pre: a };
    };
    // tes messages, dans l'ordre de la page, sans doublons emboîtés (une bulle et son cadre ne comptent qu'une fois)
    let users = qAll(cfg.userTurn || []).filter(vis);
    users = users.filter((u) => !users.some((o) => o !== u && u.contains(o))).sort((x, y) => (x === y ? 0 : after(x, y) ? -1 : 1));
    const M = users.map((u) => meas(txt(u)));
    const from = Math.max(0, Number(hint.from) || 0);
    let k = -1, how = '';
    for (let i = users.length - 1; i >= from && k < 0; i--) if (M[i].sim >= 0.9) { k = i; how = 'texte'; }
    if (k < 0 && hint.strict) { const need = Math.min(200, Math.floor(W * 0.6)); for (let i = from; i < users.length && k < 0; i++) if (M[i].pre >= need) { k = i; how = 'début'; } }
    if (k < 0 && !hint.only) for (let i = Math.min(from, users.length) - 1; i >= 0 && k < 0; i--) if (M[i].sim >= 0.9) { k = i; how = 'texte, plus haut'; }
    // envoi prouvé (zone de saisie vidée) : notre message EST celui du rang relevé à l'envoi, même si la page affiche son texte autrement
    if (k < 0 && hint.sure && users.length) { k = users.length > from ? from : users.length - 1; how = users.length > from ? 'rang' : 'dernier'; }
    const st = state(cfg), comp = composer(cfg);
    const out = { found: k >= 0, how, index: k, users: users.length, hidden: document.hidden, block: st.block, alerts: st.alerts,
      comp: comp ? meas(txt(comp)).sim : 0, compLen: comp ? norm(txt(comp)).length : 0, busy: st.busy, pageBusy: st.busy, tail: st.answerTail, isLast: false, img: null, pending: 0 };
    if (k < 0) return out;
    const me = users[k], next = users[k + 1] || null, compBox = composerCard(cfg), minImg = cfg.minImg || 400;
    out.isLast = !next;
    const mine = (i) => after(me, i) && (!next || after(i, next)) && !(compBox && compBox.contains(i));
    let gens = (cfg.genImg ? [...document.querySelectorAll(cfg.genImg)] : []).filter(mine);
    if (!gens.length && cfg.genAlt) { const re = new RegExp(cfg.genAlt, 'i'); gens = [...document.querySelectorAll('img[alt]')].filter((i) => re.test(i.alt || '') && mine(i)); }
    // page cachée : une image hors écran peut ne jamais se charger toute seule, on la force
    for (const i of gens) if (!i.complete || !i.naturalWidth) { try { i.loading = 'eager'; i.decoding = 'sync'; if (!vis(i) || i.getBoundingClientRect().top > innerHeight) i.scrollIntoView({ block: 'center' }); } catch (e) {} }
    // dernier secours : toute grande image apparue après notre message, hors de tes messages (planches jointes) et de la zone de saisie
    if (!gens.length) gens = [...document.querySelectorAll('img')].filter((i) => mine(i) && !users.some((u) => u.contains(i) || (u.closest('article') && u.closest('article').contains(i) && !after(u, i))) && (!i.complete || i.naturalWidth >= minImg) && i.getBoundingClientRect().width >= 150);
    const okImgs = gens.filter((i) => i.complete && i.naturalWidth >= minImg), im = okImgs[okImgs.length - 1] || null;
    out.pending = gens.length - okImgs.length;
    // ChatGPT travaille encore : bouton d'arrêt (quel que soit son nom), ou image en cours de chargement
    const stopBtn = [...document.querySelectorAll('button[aria-label], button[data-testid]')].some((x) => vis(x) && /(stop|arr[êe]ter|interrompre)/i.test((x.getAttribute('aria-label') || '') + ' ' + (x.getAttribute('data-testid') || '')));
    if (stopBtn || out.pending > 0) { out.busy = true; out.pageBusy = true; }
    if (im) out.img = { src: im.currentSrc || im.src, w: im.naturalWidth, h: im.naturalHeight, ready: imgDoneOf(cfg, im) };
    if (!out.isLast) { out.busy = false; out.tail = ''; } out.tailLen = (st.answerLen || 0); // « occupé » et le texte de la réponse ne valent que pour le dernier message
    return out;
  }
  /* Le prompt est-il encore dans la zone de saisie (jamais parti), ou est-il le dernier message de la conversation (bien parti) ?
     Ressemblance de 0 à 1, espaces ignorés : début commun + fin commune, rapportés à la longueur. */
  function chatProbe(cfg, text) {
    const norm = (t) => String(t || '').replace(/\s+/g, '');
    const want = norm(text);
    const sim = (raw) => { // 1 = le même texte (à quelques caractères près, ou contenu tel quel), 0 sinon
      const got = norm(raw), W = want.length, G = got.length; if (!W || !G) return 0;
      const n = Math.min(W, G), tol = Math.max(6, Math.round(W * 0.005)); let a = 0, b = 0;
      while (a < n && want[a] === got[a]) a++;
      while (b < n - a && want[W - 1 - b] === got[G - 1 - b]) b++;
      return got === want || (Math.abs(G - W) <= tol && a + b >= Math.max(G, W) - tol) || (W >= 40 && got.includes(want)) ? 1 : 0;
    };
    const comp = composer(cfg), users = qAll(cfg.userTurn || []).filter(vis), last = users[users.length - 1] || null;
    const st = state(cfg);
    // pièces jointes encore dans la zone de saisie : une croix « Supprimer … » par fichier (à défaut, les vignettes)
    const card = composerCard(cfg), rm = new RegExp(cfg.removeAttach || '^(remove|supprimer|retirer|enlever)\\b', 'i');
    const crosses = card ? [...card.querySelectorAll('button[aria-label], [role="button"][aria-label]')].filter((x) => vis(x) && rm.test(x.getAttribute('aria-label') || '')).length : 0;
    return { comp: comp ? sim(txt(comp)) : 0, compLen: comp ? norm(txt(comp)).length : 0, last: last ? sim(txt(last)) : 0, lastLen: last ? norm(txt(last)).length : 0, users: users.length, busy: st.busy, wantLen: want.length, attach: crosses || attachedCount(cfg) };
  }
  /* Fin du texte de la page, sans les commandes qui affichent un pourcentage sans rien générer : le zoom d'Imagine (« 75 % »,
     selon la taille de la fenêtre) passait pour une génération en cours (vu le 23 novembre 2026). */
  const busyTail = (root, cfg) => {
    let t = txt(root).slice(-600);
    if (cfg.busyIgnore) { try { for (const el of root.querySelectorAll(cfg.busyIgnore)) { const x = txt(el); if (x) t = t.split(x).join(' '); } } catch (e) { /* sélecteur invalide : texte entier */ } }
    return t;
  };
  function state(cfg) {
    const users = qAll(cfg.userTurn || []).filter(vis), lastUser = users[users.length - 1] || null;
    const answers = qAll(cfg.answer || []).filter(vis).filter((el) => !lastUser || after(lastUser, el));
    const root = firstVis(cfg.scope || ['main']) || document.body;
    const minImg = cfg.minImg || 400;
    // Les planches jointes s'affichent dans le message envoyé et dans la zone de saisie : ce ne sont pas des images générées.
    const answerSel = (cfg.answer || []).join(',');
    const boxOf = (el) => { const b = el.closest((cfg.turnBox || ['article', '[data-testid^="conversation-turn"]', '[data-turn]']).join(',')); return b && !(answerSel && b.querySelector(answerSel)) ? b : el; };
    const userBoxes = users.map(boxOf), lastBox = userBoxes[userBoxes.length - 1] || null;
    const compBox = composerCard(cfg);
    const exact = cfg.genImg ? [...document.querySelectorAll(cfg.genImg)] : [];
    // fenêtre cachée : une image hors écran peut ne jamais se charger toute seule, on la force
    for (const i of exact) if (!i.complete || !i.naturalWidth) { try { i.loading = 'eager'; i.decoding = 'sync'; if (!vis(i) || i.getBoundingClientRect().top > innerHeight) i.scrollIntoView({ block: 'center' }); } catch (e) {} }
    // image terminée = ses boutons (Modifier / Partager / Copier / Télécharger l'image) sont là : pas besoin d'attendre que le site « se calme »
    const doneRe = cfg.imgDone ? new RegExp(cfg.imgDone, 'i') : null;
    const readyOf = (i) => { if (!doneRe) return false; const box = i.closest(cfg.turn || 'article') || i.closest('article, [data-turn]'); return !!box && [...box.querySelectorAll('button[aria-label], a[aria-label]')].some((b) => doneRe.test(b.getAttribute('aria-label'))); };
    const altRe = cfg.genAlt ? new RegExp(cfg.genAlt, 'i') : null;
    const imgs = (exact.length ? exact : [...root.querySelectorAll('img')].filter((i) => !(cfg.genAlt && /^(blob:|data:)/.test(i.currentSrc || i.src) && !altRe.test(i.alt || ''))))
      .filter((i, k, a) => a.indexOf(i) === k && i.complete && i.naturalWidth >= minImg && vis(i) && (!lastBox || after(lastBox, i)) && !userBoxes.some((b) => b.contains(i)) && !(compBox && compBox.contains(i)))
      .map((i) => ({ src: i.currentSrc || i.src, w: i.naturalWidth, h: i.naturalHeight, ready: readyOf(i) }));
    const vids = [...document.querySelectorAll('video')].map((v) => ({ src: v.currentSrc || v.src || (v.querySelector('source') || {}).src || '', dur: Number.isFinite(v.duration) ? v.duration : 0, w: v.videoWidth, h: v.videoHeight, main: !!(cfg.resultVideo && v.matches(cfg.resultVideo)), area: vis(v) ? Math.round(v.getBoundingClientRect().width * v.getBoundingClientRect().height) : 0 }))
      .filter((v) => v.src);
    const alerts = [...document.querySelectorAll('[role="alert"], [data-sonner-toast], [class*="toast" i], [class*="error" i]')].filter(vis).map(txt).filter((t) => t && t.length < 400).slice(0, 6);
    // repères de réponse introuvables (interface changée) : on lit toute la page, pour ne jamais rester aveugle
    const turns = cfg.turn ? [...document.querySelectorAll(cfg.turn)] : [], lastTurn = turns[turns.length - 1] || null;
    const blind = !answers.length && !lastTurn && (cfg.answer || []).length > 0;
    let answerText = blind ? txt(root) : answers.map(txt).join('\n');
    if (!answers.length && lastTurn) { const u = lastUser && lastTurn.contains(lastUser) ? txt(lastUser) : ''; const all = txt(lastTurn); answerText = u && all.includes(u) ? all.slice(all.indexOf(u) + u.length) : all; }
    const stEl = cfg.turnState && lastTurn ? lastTurn.querySelector(`[${cfg.turnState}]`) : null;
    const turnBusy = !!stEl && !/^(complete|done|finished)$/i.test(stEl.getAttribute(cfg.turnState) || '');
    // la dernière image générée de la page, où qu'elle soit rangée (secours quand le fil de la conversation est lu de travers)
    const lastEl = exact.filter((i) => i.complete && i.naturalWidth >= minImg && !(compBox && compBox.contains(i))).pop();
    const lastGen = lastEl ? { src: lastEl.currentSrc || lastEl.src, w: lastEl.naturalWidth, h: lastEl.naturalHeight, ready: readyOf(lastEl) } : null;
    return {
      hidden: document.hidden, lastGen,
      answerEnd: cfg.endMark ? new RegExp(cfg.endMark).test(answerText.slice(blind ? -2500 : -400)) : false,
      url: location.href, title: document.title,
      busy: turnBusy || !!firstVis(cfg.stop) || !!firstVis(cfg.streaming || []) || (cfg.busyText ? new RegExp(cfg.busyText, 'i').test(busyTail(root, cfg)) : false),
      composer: !!composer(cfg), users: users.length, answers: answers.length, answerLen: answerText.length, answerTail: answerText.slice(-240),
      imgs, vids, alerts, block: detectBlock(cfg)
    };
  }

  /* Texte de la réponse : les blocs de code d'abord (texte exact), sinon tout le message */
  function answerText(cfg) {
    const users = qAll(cfg.userTurn || []).filter(vis), lastUser = users[users.length - 1] || null;
    const answers = qAll(cfg.answer || []).filter(vis).filter((el) => !lastUser || after(lastUser, el));
    const roots = answers.length ? answers : [firstVis(cfg.scope || ['main']) || document.body];
    const codes = [];
    for (const r of roots) for (const pre of r.querySelectorAll('pre')) { const c = pre.querySelector('code') || pre; const t = c.textContent || ''; if (t.includes('@@') && !codes.includes(t)) codes.push(t); }
    if (codes.length) return { text: codes.join('\n'), from: 'bloc de code' };
    return { text: roots.map((r) => r.innerText || '').join('\n'), from: 'message' };
  }

  /* ---------- clics par texte (durée Grok, boutons d'import…) ---------- */
  function findByText(pattern, scopeSel) {
    const re = new RegExp(pattern, 'i');
    const root = (scopeSel && document.querySelector(scopeSel)) || document;
    const els = [...root.querySelectorAll(CLICKABLE)].filter((el) => vis(el) && re.test(label(el)));
    // le plus précis d'abord : le texte le plus court
    return els.sort((a, b) => label(a).length - label(b).length)[0] || null;
  }
  function clickText(pattern, scopeSel) {
    const el = findByText(pattern, scopeSel);
    if (!el) return { ok: false };
    click(el);
    return { ok: true, text: label(el).slice(0, 80) };
  }
  /* Choisit une option (ex. « 10s ») : directement si elle est visible, sinon en ouvrant d'abord un menu */
  async function setOption(optionPattern, triggerPattern) {
    let r = clickText(optionPattern);
    if (r.ok) return { ...r, how: 'direct' };
    if (triggerPattern) {
      const t = clickText(triggerPattern);
      if (t.ok) {
        await sleep(700); r = clickText(optionPattern);
        if (r.ok) return { ...r, how: 'menu' };
        // option absente : on referme le menu ouvert pour ne pas gêner la suite
        for (const type of ['keydown', 'keyup']) document.dispatchEvent(new KeyboardEvent(type, { bubbles: true, cancelable: true, key: 'Escape', code: 'Escape', keyCode: 27, which: 27 }));
      }
    }
    return { ok: false };
  }
  function clickSel(sels) { const el = firstVis(sels); if (!el) return { ok: false }; click(el); return { ok: true }; }

  /* ---------- CapCut ---------- */
  const base = (n) => n.replace(/\.[a-z0-9]+$/i, '');
  function mediaItem(name, cfg) {
    const b = base(name).toLowerCase();
    const cand = [...document.querySelectorAll('[title], img[alt], span, div, p')].filter((el) => {
      const t = `${el.getAttribute('title') || ''} ${el.getAttribute('alt') || ''} ${el.childElementCount ? '' : el.textContent || ''}`.toLowerCase();
      return t.includes(b) && vis(el);
    });
    let el = cand[0];
    if (!el) return null;
    // remonte jusqu'à la « carte » du média
    const cardSel = (cfg.mediaCard || ['[class*="material" i]', '[class*="media-item" i]', '[class*="card" i]', 'li']).join(',');
    return el.closest(cardSel) || el.parentElement || el;
  }
  function capcutState(names, cfg) {
    const timeline = firstVis(cfg.timeline || ['[class*="timeline" i]', '[class*="track" i]']);
    const segs = timeline ? timeline.querySelectorAll((cfg.segment || ['[class*="segment" i]', '[class*="clip" i]']).join(',')).length : null;
    // Envoi en cours ? Sur le vrai CapCut, l'onglet de la bibliothèque s'appelle « Téléversements » : chercher ce mot dans la page répondait toujours oui
    // (1 min 30 d'attente pour rien à chaque montage). Un fichier en cours d'envoi, c'est une vignette qui affiche un pourcentage
    // (« Téléversement en cours : 40 % », puis « Transcodage : 60 % »).
    const lib = [...document.querySelectorAll('[class*="compact-card"]')].filter(vis);
    const uploading = cfg.busyText ? new RegExp(cfg.busyText, 'i').test(txt(document.body).slice(0, 6000))
      : lib.length ? lib.some((c) => /\d\s*%/.test(txt(c)))
        : /uploading|importation|téléversement|chargement en cours/i.test(txt(document.body).slice(0, 6000));
    return { url: location.href, input: qAll(cfg.fileInput || ['input[type="file"]']).length, present: names.map((n) => !!mediaItem(n, cfg)), segments: segs, block: detectBlock(cfg), uploading };
  }

  /* CapCut : temps affichés (courant / total) et déplacement du curseur de lecture à la fin de la timeline.
     La règle de CapCut : un clip importé se pose à l'endroit du curseur. Curseur à la fin = clip à la suite des autres. */
  function capcutTimes() {
    const t = [...document.querySelectorAll('*')].filter((e) => e.children.length === 0 && /^\d\d:\d\d:\d\d$/.test((e.textContent || '').trim())).map((e) => e.textContent.trim());
    return { cur: t[0] || '', total: t[1] || '', ok: t.length >= 2 };
  }
  /* Transcodage raté. Les vignettes « Transcodage impossible » RESTENT dans la bibliothèque de CapCut, d'un projet à l'autre
     (vu sur le site le 16 novembre 2026) : leur simple présence ne dit rien du clip qu'on vient d'envoyer.
     On compte donc les vignettes en échec : c'est une vignette DE PLUS qu'avant l'envoi (base) qui signale un échec, ou un message hors bibliothèque. */
  /* Bibliothèque de CapCut, vue sur le vrai site (16 novembre 2026) :
     - la liste est « virtuelle » : seules les vignettes affichées existent dans la page, et elles changent quand on fait défiler ;
     - tout en haut : « Téléverser », puis le dernier fichier téléversé, puis les dossiers et les fichiers plus anciens (de tous les projets) ;
     - pendant l'envoi, la vignette du fichier affiche « Téléversement en cours : 40 % » puis « Transcodage : 60 % » (étape normale), puis sa durée ;
       un fichier refusé garde « Transcodage impossible », et reste là d'un projet à l'autre.
     On remonte donc la liste tout en haut avant de la lire, et on ne se fie à l'ordre que si « Téléverser » est bien la première vignette. */
  async function capcutLib() {
    const all = () => [...document.querySelectorAll('[class*="compact-card"]')].filter(vis);
    const isUp = (c) => !!c.querySelector('[class*="asset-import"]') || /^(téléverser|upload|importer|import)$/i.test(txt(c));
    let a = all();
    if (a.length && !isUp(a[0])) {
      let sc = a[0].parentElement;
      while (sc && sc !== document.body && !(sc.scrollHeight > sc.clientHeight + 20 && /(auto|scroll)/.test(getComputedStyle(sc).overflowY))) sc = sc.parentElement;
      if (sc && sc !== document.body) {
        sc.scrollTop = 0;
        for (let i = 0; i < 12 && !((a = all()).length && isUp(a[0])); i++) await sleep(200);
        for (let i = 0; i < 12 && (a = all()).length > 1 && !txt(a[1]); i++) await sleep(200); // les vignettes réapparaissent vides une fraction de seconde
      }
    }
    return { top: !!(a.length && isUp(a[0])), media: a.filter((c) => !isUp(c)) };
  }
  /* Le fichier qu'on vient d'envoyer est-il refusé ? `n` = nombre de vignettes « transcodage impossible » placées EN TÊTE de la bibliothèque :
     il n'augmente que si le dernier envoi échoue. Les vieux échecs, plus bas dans la liste, ne comptent pas (ils faisaient croire que chaque clip échouait). */
  /* Clips encore en cours dans la bibliothèque : « Téléversement en cours : 40 % », « Transcodage : 90 % ». Tant qu'il y en a, CapCut travaille :
     on attend, on ne renvoie surtout pas le fichier (vu le 16 novembre 2026 : trois copies du même clip bloquées à 90 %). */
  async function capcutBusy() {
    const bad = /(impossible|échou|echou|échec|echec|fail|error|erreur)/i;
    const lib = await capcutLib();
    const cards = lib.media.map((c) => txt(c)).filter((t) => /\d\s*%/.test(t) && !bad.test(t));
    return { n: cards.length, sig: cards.map((t) => (t.match(/[\d.,]+\s*%/) || [''])[0]).join('|'), top: lib.top };
  }
  /* Clic droit simulé (bouton 2, puis l'événement « contextmenu »), au centre de l'élément. */
  const rclick = (el) => {
    el.scrollIntoView({ block: 'center' });
    const r = el.getBoundingClientRect();
    const p = { bubbles: true, cancelable: true, composed: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 2 };
    let t = document.elementFromPoint(p.clientX, p.clientY);
    if (!t || !el.contains(t)) t = el;
    try { t.dispatchEvent(new PointerEvent('pointerdown', { ...p, buttons: 2, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch (e) {}
    t.dispatchEvent(new MouseEvent('mousedown', { ...p, buttons: 2 }));
    try { t.dispatchEvent(new PointerEvent('pointerup', { ...p, buttons: 0, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch (e) {}
    t.dispatchEvent(new MouseEvent('mouseup', { ...p, buttons: 0 }));
    t.dispatchEvent(new MouseEvent('contextmenu', { ...p, buttons: 0 }));
  };
  /* CapCut : vide la bibliothèque « Téléversements » avant un nouveau montage (réglage « capcutClean ») : les clips des vidéos
     précédentes y restent sinon, et remplissent le stockage du compte. Relevé sur le vrai site le 19 novembre 2026 :
     clic droit sur une vignette → menu « Télécharger, Supprimer, … » (ou « Supprimer » seul pour un fichier en « Transcodage impossible »)
     → fenêtre « Supprimer les éléments sélectionnés ? … Cette action est irréversible. » → bouton rouge « Supprimer ».
     Pas de corbeille pour ces fichiers. Un clic droit simulé ouvre bien le menu (essayé sur le vrai site).
     On ne touche ni aux dossiers, ni aux fichiers encore en cours d'envoi. */
  /* Un bouton pas encore prêt : désactivé, en chargement (roue qui tourne), ou masqué derrière un état « occupé ». */
  const notReady = (b) => {
    if (!b || !b.isConnected || !vis(b)) return true;
    if (b.disabled || b.getAttribute('aria-disabled') === 'true' || b.getAttribute('aria-busy') === 'true') return true;
    const cls = String(typeof b.className === 'string' ? b.className : (b.className && b.className.baseVal) || '');
    if (/(^|[\s_-])(disabled|loading)(\b|$)/i.test(cls)) return true;
    return !!b.querySelector('[class*="loading" i], [class*="spinner" i], [class*="spin" i]');
  };
  const whenReady = async (get, ms) => { const t0 = Date.now(); for (;;) { const b = get(); if (b && !notReady(b)) return b; if (Date.now() - t0 > ms) return null; await sleep(250); } };
  async function capcutClean(max = 80) {
    const DEL = /^(supprimer|delete)$/i;
    const inModal = (e) => !!e.closest('.lv-modal-wrapper, [role="dialog"]');
    const delItems = () => [...document.querySelectorAll('body *')].filter((e) => e.children.length === 0 && /^\s*(supprimer|delete)\s*$/i.test(e.textContent || '') && !inModal(e) && vis(e));
    const modal = () => [...document.querySelectorAll('.lv-modal-wrapper, [role="dialog"]')].filter(vis).find((m) => /irr[ée]versible|supprimer les|delete/i.test(txt(m)));
    const esc = () => { try { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true })); } catch (e) {} };
    const tab = [...document.querySelectorAll('[role="tab"]')].find((e) => /^(téléversements|uploads)$/i.test(txt(e)) && vis(e));
    if (tab && tab.getAttribute('aria-selected') === 'false') { click(tab); await sleep(800); }
    const skip = (c) => /\d\s*%/.test(txt(c)) || !!c.querySelector('[class*="folder" i]');
    let deleted = 0, fails = 0, idx = 0, cards = [];
    for (let n = 0; n < max && fails < 6; n++) {
      const lib = await capcutLib();
      cards = lib.media.filter((c) => !skip(c));
      if (idx >= cards.length) break;
      const c = cards[idx], label = txt(c), count = lib.media.length;
      const old = new Set(delItems());
      rclick(c);
      let it = null;
      for (let w = 0; w < 20 && !it; w++) { await sleep(150); it = delItems().find((e) => !old.has(e)) || null; }
      if (!it) { esc(); fails++; idx++; continue; }
      // « Supprimer » met un moment à devenir cliquable (vu le 22 novembre 2026 : un temps de chargement) : cliqué trop tôt, il ne fait rien.
      // On attend donc qu'il le soit, dans le menu puis dans la fenêtre de confirmation.
      const item = await whenReady(() => (it.isConnected ? it.closest('[role="menuitem"], li, button') || it : null), 10000);
      if (!item) { esc(); fails++; idx++; continue; }
      click(item);
      let m = null;
      for (let w = 0; w < 40 && !(m = modal()); w++) await sleep(150);
      const yesBtn = () => { const mm = modal(); return mm ? [...mm.querySelectorAll('button')].find((b) => DEL.test(txt(b))) || null : null; };
      const yes = m ? await whenReady(yesBtn, 15000) : null;
      if (!yes) { const mm = modal(), no = mm && [...mm.querySelectorAll('button')].find((b) => /^(annuler|cancel)$/i.test(txt(b))); if (no) click(no); esc(); fails++; idx++; continue; }
      click(yes);
      // la suppression elle-même prend un moment (le bouton tourne) ; si la fenêtre est toujours là avec le bouton de nouveau cliquable, le clic n'a pas été pris : un second
      let again = false;
      for (let w = 0; w < 100 && modal(); w++) { await sleep(200); if (!again && w === 20) { const y2 = yesBtn(); if (y2 && !notReady(y2)) { click(y2); again = true; } } }
      let gone = false;
      for (let w = 0; w < 25 && !gone; w++) { await sleep(200); gone = !c.isConnected || txt(c) !== label || [...document.querySelectorAll('[class*="compact-card"]')].filter(vis).length < count + 1; }
      if (gone) { deleted++; await sleep(600); } else { fails++; idx++; } // un petit temps entre deux suppressions : CapCut rafraîchit sa bibliothèque
    }
    const left = (await capcutLib()).media.filter((c) => !skip(c)).length;
    return { ok: left === 0, deleted, left, error: left ? `${left} fichier(s) n'ont pas pu être supprimés` : '' };
  }
  async function capcutIssue(base) {
    const re = /(transcod\w*[^.\n]{0,40}(impossible|échou|echou|échec|echec|fail|error|erreur))|((impossible|échec|echec|échou|echou|fail\w*|unable|erreur)[^.\n]{0,40}transcod)/i;
    const lib = await capcutLib();
    let n = 0; if (lib.top) while (n < lib.media.length && re.test(txt(lib.media[n]))) n++;
    let outside = '';
    for (const el of document.querySelectorAll('[class*="toast" i], [class*="message" i], [class*="notice" i], [role="alert"], [role="dialog"], [class*="modal" i]')) {
      if (vis(el) && !el.closest('[class*="compact-card"]') && !el.querySelector('[class*="compact-card"]') && txt(el).length < 300 && re.test(txt(el))) { outside = txt(el).slice(0, 80); break; }
    }
    return { n, top: lib.top, transcode: (typeof base === 'number' && n > base) || !!outside, text: outside || (n ? txt(lib.media[0]).slice(0, 80) : '') };
  }
  /* Curseur à la fin de la timeline. La règle n'affiche qu'une partie d'un long montage : un seul clic sur son bord droit n'atteint pas toujours la fin
     (et un clip posé ailleurs qu'à la fin part sur une autre piste). On essaie la touche Fin, puis on clique le bord droit autant de fois qu'il faut :
     la vue défile quand le curseur approche du bord ; s'il n'avance plus, on dézoome la timeline (Ctrl −). */
  async function capcutSeekEnd() {
    const cv = document.querySelector('canvas[class*="zoom-axis"]');
    if (!cv) return { ok: false, error: 'règle de la timeline introuvable' };
    if (!cv.getBoundingClientRect().width) return { ok: false, error: 'règle de la timeline invisible' };
    const secs = (t) => { const m = /^(\d\d):(\d\d):(\d\d)$/.exec(t || ''); return m ? +m[1] * 60 + +m[2] + +m[3] / 30 : -1; };
    const atEnd = () => { const t = capcutTimes(); return t.ok && t.cur === t.total; };
    if (atEnd()) return { ok: true, how: 'déjà à la fin', ...capcutTimes() };
    const key = (k, code, kc, mod = {}) => { const o = { bubbles: true, cancelable: true, composed: true, key: k, code, keyCode: kc, which: kc, view: window, ...mod }; document.body.dispatchEvent(new KeyboardEvent('keydown', o)); document.body.dispatchEvent(new KeyboardEvent('keyup', o)); };
    key('End', 'End', 35); await sleep(350);
    if (atEnd()) return { ok: true, how: 'touche Fin', ...capcutTimes() };
    const clickAt = async (x) => {
      const r = cv.getBoundingClientRect();
      const ev = (type, C) => cv.dispatchEvent(new C(type, { bubbles: true, cancelable: true, clientX: x, clientY: r.top + r.height / 2, button: 0, buttons: /up|click/.test(type) ? 0 : 1, pointerId: 1, pointerType: 'mouse', isPrimary: true, view: window }));
      ev('pointerdown', PointerEvent); ev('mousedown', MouseEvent); await sleep(110);
      ev('pointerup', PointerEvent); ev('mouseup', MouseEvent); ev('click', MouseEvent);
    };
    let last = -1, stuck = 0, zooms = 0;
    for (let i = 0; i < 40; i++) {
      await clickAt(cv.getBoundingClientRect().right - 8); await sleep(450);
      if (atEnd()) return { ok: true, how: `règle, ${i + 1} clic(s)${zooms ? `, ${zooms} dézoom(s)` : ''}`, ...capcutTimes() };
      const c = secs(capcutTimes().cur);
      if (c > last + 0.05) { stuck = 0; last = c; continue; } // le curseur avance : la vue défile, on continue
      if (++stuck >= 2) { if (zooms >= 8) break; zooms++; stuck = 0; key('-', 'Minus', 189, /mac/i.test(navigator.platform || '') ? { metaKey: true } : { ctrlKey: true }); await sleep(500); }
    }
    return { ok: false, ...capcutTimes(), error: 'curseur non placé à la fin' };
  }
  /* Annuler (Ctrl+Z) : retire la dernière pose ; le clip reste dans la bibliothèque. Vérifié sur le vrai CapCut. */
  function capcutUndo() {
    for (const mod of [{ ctrlKey: true }, { metaKey: true }]) {
      const k = { bubbles: true, cancelable: true, composed: true, key: 'z', code: 'KeyZ', keyCode: 90, which: 90, view: window, ...mod };
      document.body.dispatchEvent(new KeyboardEvent('keydown', k)); document.body.dispatchEvent(new KeyboardEvent('keyup', k));
      if (mod.ctrlKey && !/mac/i.test(navigator.platform || '')) break;
    }
    return { ok: true };
  }
  /* Rétablir (Ctrl+Maj+Z) : rattrape un Ctrl+Z de trop */
  function capcutRedo() {
    const mac = /mac/i.test(navigator.platform || '');
    const k = { bubbles: true, cancelable: true, composed: true, key: 'Z', code: 'KeyZ', keyCode: 90, which: 90, view: window, shiftKey: true, ...(mac ? { metaKey: true } : { ctrlKey: true }) };
    document.body.dispatchEvent(new KeyboardEvent('keydown', k)); document.body.dispatchEvent(new KeyboardEvent('keyup', k));
    return { ok: true };
  }
  /* La vignette du dernier clip téléversé : est-elle marquée « Ajouté » (donc posée quelque part sur la timeline) ? */
  function capcutNewest() {
    const card = [...document.querySelectorAll('[class*="compact-card"]')].filter((c) => vis(c) && !c.querySelector('[class*="asset-import"]') && /\d\s*\d\s*:\s*\d\s*\d/.test(txt(c)))[0];
    return card ? { found: true, added: /(ajouté|added)/i.test(txt(card)), text: txt(card).slice(0, 40) } : { found: false };
  }
  async function capcutAddNewest() {
    const lib = await capcutLib();
    if (!lib.top) return { ok: false, error: 'bibliothèque CapCut : le haut de la liste (« Téléverser ») n\'est pas affiché' };
    const card = lib.media[0];
    if (!card || !/\d\s*\d\s*:\s*\d\s*\d/.test(txt(card))) return { ok: false, error: `vignette du clip pas prête (${card ? txt(card).slice(0, 40) : 'aucune'})` };
    // Le badge « Ajouté » ne dit pas si le clip est sur la timeline (il peut rester après une annulation) : on clique toujours ;
    // c'est la durée de la timeline, lue ensuite par le pilote, qui confirme la pose.
    card.scrollIntoView({ block: 'nearest' });
    click(card);
    return { ok: true, badge: /(ajouté|added)/i.test(txt(card)) };
  }
  async function capcutAdd(name, cfg) {
    const card = mediaItem(name, cfg);
    if (!card) return { ok: false, error: 'média introuvable dans le panneau' };
    card.scrollIntoView({ block: 'center' });
    fire(card, 'mouseenter'); fire(card, 'mouseover'); fire(card, 'mousemove');
    await sleep(500);
    const addSel = (cfg.addButton || ['[class*="add" i]', '[aria-label*="add" i]', '[aria-label*="ajouter" i]', '[class*="plus" i]']).join(',');
    const btn = [...card.querySelectorAll(addSel)].find(vis) || [...(card.parentElement || card).querySelectorAll(addSel)].find(vis);
    if (btn) { click(btn); return { ok: true, how: 'bouton +' }; }
    return { ok: false, error: 'bouton d\'ajout introuvable sur le média' };
  }

  /* Événements souris sur la chronologie de CapCut (un canvas) : vérifié sur le vrai site, un clic envoyé ainsi sélectionne bien le clip visé */
  function canvasPress(x, y) {
    const el = document.elementFromPoint(x, y); if (!el) return Promise.resolve(false);
    const init = (type) => ({ bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: /down/.test(type) ? 1 : 0, pointerId: 1, pointerType: 'mouse', isPrimary: true });
    const ev = (type) => el.dispatchEvent(new (/^pointer/.test(type) ? PointerEvent : MouseEvent)(type, init(type)));
    for (const t of ['pointerover', 'mouseover', 'pointermove', 'mousemove', 'pointerdown', 'mousedown']) ev(t);
    return sleep(90).then(() => { for (const t of ['pointerup', 'mouseup', 'click']) ev(t); return true; });
  }
  /* Vrai CapCut (novembre 2026). Ce qui est sûr, vu sur le site : une transition sélectionnée ouvre à droite un panneau « Basique »
     (Nom : Black Fade, Durée, « Appliquer à tout ») et « Appliquer à tout » pose la même transition sur tous les raccords.
     On sélectionne donc le 1er clip, on pose « Fondu au noir » depuis l'onglet Transitions, puis « Appliquer à tout ».
     Si un point ne se confirme pas, on le dit : la carte « Vérifie le montage » de FruitRadar prend le relais. */
  /* Fondu au noir sur le vrai CapCut — gestes vérifiés sur le site le 16 novembre 2026, tous avec des clics envoyés par la page :
     1. cliquer une transition dans l'onglet Transitions la pose AU DÉBUT du clip où se trouve le curseur (raccord avec le clip d'avant).
        Curseur dans le premier clip : CapCut refuse (« entre 2 clips consécutifs »). On met donc le curseur dans le dernier clip.
     2. la transition qui vient d'être posée est sélectionnée d'office : la barre d'outils de droite ne montre plus que « Basique ».
     3. « Basique » ouvre le panneau (Nom : Fondu au noir, Durée, « Appliquer à tout ») ; « Appliquer à tout » la pose sur tous les raccords. */
  async function capcutFadeReal(cfg) {
    const done = [], FADE = /(black fade|fondu au noir|fondu noir|fade to black|dip to black)/i;
    const press = async (el) => { const r = el.getBoundingClientRect(); await canvasPress(r.left + r.width / 2, r.top + r.height / 2); };
    const bars = () => [...document.querySelectorAll('.tool-bar-title, [class*="tool-bar-title"]')].filter((e) => vis(e) && e.getBoundingClientRect().left < innerWidth);
    const onlyBasic = () => { const b = bars(); return b.length === 1 && /^(basique|basic|de base)$/i.test(txt(b[0])); };
    const applyBtn = () => [...document.querySelectorAll('span, div, button, p')].filter((el) => el.childElementCount === 0 && vis(el) && txt(el).length < 30 && new RegExp(`^${cfg.applyAll}`, 'i').test(txt(el)))[0] || null;
    const panelName = (btn) => { let box = btn; for (let i = 0; i < 7 && box.parentElement && !/(nom|name)/i.test(txt(box)); i++) box = box.parentElement; return txt(box).replace(/\s+/g, ' ').slice(0, 200); };
    const openPanel = async () => { // panneau de droite replié : on l'ouvre par « Basique »
      for (let i = 0; i < 3 && !applyBtn(); i++) { const b = bars()[0]; if (!b) break; await press(b.closest('.workbench-tool-bar, [class*="tool-bar"]') || b); await sleep(1300); }
      return applyBtn();
    };
    // reprise : une transition est déjà sélectionnée, il ne reste qu'à l'étendre
    let btn = onlyBasic() ? await openPanel() : null;
    if (!(btn && FADE.test(panelName(btn)))) {
      btn = null;
      const sk = await capcutSeekEnd().catch(() => null);
      if (!(sk && sk.ok)) return { ok: false, error: `curseur de la timeline : ${(sk && sk.error) || 'pas à la fin'}`, done };
      // quelques images en arrière : le curseur est alors DANS le dernier clip, pas après lui
      for (let i = 0; i < 8; i++) { const k = { bubbles: true, cancelable: true, composed: true, key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37, which: 37, view: window }; document.body.dispatchEvent(new KeyboardEvent('keydown', k)); document.body.dispatchEvent(new KeyboardEvent('keyup', k)); await sleep(60); }
      done.push('curseur dans le dernier clip');
      const tab = clickText(cfg.transitionsTab);
      if (!tab.ok) return { ok: false, error: 'onglet « Transitions » introuvable', done };
      done.push('onglet Transitions'); await sleep(2200);
      const want = new RegExp(cfg.transitionText, 'i');
      const findCard = () => [...document.querySelectorAll('[class*="name-"], span, p, div, figcaption')].filter((el) => el.childElementCount === 0 && want.test(txt(el)) && txt(el).length < 40 && el.getBoundingClientRect().width > 0)
        .sort((x, y) => (/^fondu au noir$|^black fade$|^fade to black$/i.test(txt(y)) ? 1 : 0) - (/^fondu au noir$|^black fade$|^fade to black$/i.test(txt(x)) ? 1 : 0) || txt(x).length - txt(y).length)[0];
      let hit = null; for (let i = 0; i < 8 && !(hit = findCard()); i++) await sleep(500);
      if (!hit) return { ok: false, error: 'transition « Fondu au noir » introuvable dans l\'onglet Transitions', done };
      const card = hit.closest('[class*="container-"]') || hit.parentElement || hit;
      card.scrollIntoView({ block: 'nearest', inline: 'center' }); await sleep(500);
      for (let n = 0; n < 2 && !onlyBasic(); n++) { // deux essais : le premier clic tombe parfois pendant le chargement des vignettes
        await press(card.querySelector('img') || card);
        for (let i = 0; i < 10 && !onlyBasic(); i++) await sleep(400);
      }
      const refus = [...document.querySelectorAll('div, span')].find((el) => el.childElementCount === 0 && vis(el) && /(2 clips cons[ée]cutifs|two consecutive clips|between 2 clips)/i.test(txt(el)));
      if (!onlyBasic()) return { ok: false, error: refus ? 'CapCut refuse la transition : le curseur n\'est pas dans un clip qui en suit un autre' : 'la transition n\'a pas été posée (ou il y en avait déjà une à cet endroit, que CapCut n\'a pas sélectionnée)', done };
      done.push(`« ${txt(hit)} » posé sur le dernier raccord`);
      btn = await openPanel();
    }
    if (!btn) return { ok: false, error: 'panneau de la transition introuvable (« Appliquer à tout » absent)', done };
    const nm = panelName(btn);
    if (!FADE.test(nm)) return { ok: false, error: `une autre transition est sélectionnée (${nm.slice(0, 50)})`, done };
    await press(btn); await sleep(1500);
    done.push('appliquée à tous les raccords');
    return { ok: true, done, real: true };
  }
  /* Fondu au noir sur le vrai CapCut, par le logo du raccord — méthode montrée par l'auteur le 18 novembre 2026, rejouée ce jour-là sur le site
     avec des gestes envoyés par la page (aucune vraie souris) :
     - quand la souris passe sur le raccord entre deux clips, un petit logo blanc apparaît ([class*="transition-add-icon"], classe « show-icon ») ;
       UN clic dessus pose « Black Fade » (0,5 s) à ce raccord. Rien à choisir dans l'onglet Transitions.
     - pourquoi l'ancienne méthode était refusée (« entre 2 clips consécutifs ») : cliquer un fondu dans l'onglet Transitions le pose APRÈS le clip
       sélectionné ; après la pose des clips, c'est le dernier qui est sélectionné, et il n'a pas de suivant. Les touches fléchées envoyées par la
       page, elles, sont ignorées par CapCut.
     - les clips sont dessinés dans un canevas (Konva) bien plus large que la fenêtre quand on a zoomé : la partie visible est celle de
       [class*="timeline-scroll-wrap"], qui défile avec scrollLeft.
     Pour trouver un raccord : on étalonne la règle (clic → temps affiché, en trois points), on dézoome si l'échelle est trop grande (bouton « − »
     à gauche de la réglette de zoom), puis raccord = part des durées des clips rapportée à la durée totale lue dans CapCut. Le logo, une fois
     apparu, donne la position exacte : c'est lui qu'on clique. Chaque raccord est vérifié (transition sélectionnée, nom « Black Fade »). */
  async function capcutFadeJunctions(cfg, durs) {
    const done = [], FADE = /(black fade|fondu au noir|fondu noir|fade to black|dip to black)/i;
    const ruler = document.querySelector('canvas[class*="zoom-axis"]'), stage = document.querySelector('[class*="timeline-canvas-stage"] canvas, .konvajs-content canvas');
    const wrap = document.querySelector('[class*="timeline-scroll-wrap"]') || (stage && stage.closest('[class*="timeline-bd-container"]'));
    if (!ruler || !stage || !wrap) return { ok: false, soft: true, error: 'piste de la timeline introuvable', done };
    const n = (durs || []).length, sum = (durs || []).reduce((a, b) => a + (Number(b) || 0), 0);
    if (n < 2 || !(sum > 0) || durs.some((d) => !(Number(d) > 0))) return { ok: false, soft: true, error: 'durées des clips inconnues', done };
    const secs = (t) => { const m = /^(\d\d):(\d\d):(\d\d)$/.exec(t || ''); return m ? +m[1] * 60 + +m[2] + +m[3] / 30 : -1; };
    const cur = () => secs(capcutTimes().cur), tot = secs(capcutTimes().total);
    if (!(tot > 0)) return { ok: false, soft: true, error: 'durée du montage illisible', done };
    const mk = (type, x, y, down) => new (/^pointer/.test(type) ? PointerEvent : MouseEvent)(type, { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: down ? 1 : 0, pointerId: 1, pointerType: 'mouse', isPrimary: true });
    const tap = async (el, x, y) => { el.dispatchEvent(mk('pointerdown', x, y, true)); el.dispatchEvent(mk('mousedown', x, y, true)); await sleep(100); for (const k of ['pointerup', 'mouseup', 'click']) el.dispatchEvent(mk(k, x, y)); };
    const rclick = async (x) => { const r = ruler.getBoundingClientRect(); await tap(ruler, x, r.top + r.height / 2); await sleep(380); return cur(); };
    // la partie de la piste réellement à l'écran (66 px à gauche : l'en-tête de la piste, posé par-dessus)
    const view = () => { const s = stage.getBoundingClientRect(), w = wrap.getBoundingClientRect(); return { left: Math.max(s.left, w.left + 66), right: Math.min(s.right, w.right, innerWidth) - 8, y: s.top + s.height / 2 }; };
    const calibrate = async () => {
      const v = view(), w = v.right - v.left; if (w < 200) return null;
      const xa = v.left + w * 0.06; let xb = v.left + w * 0.4;
      const s0 = wrap.scrollLeft, ta = await rclick(xa); let tb = -1;
      for (let i = 0; i < 5; i++) { tb = await rclick(xb); if (tb > ta + 0.3 && tb < tot - 0.05) break; xb = xa + (xb - xa) / 2; tb = -1; }
      if (ta < 0 || tb < 0) return null;
      const pps = (xb - xa) / (tb - ta), xc = (xa + xb) / 2, tc = await rclick(xc);
      if (Math.abs(tc - (ta + (xc - xa) / pps)) > 0.2 || wrap.scrollLeft !== s0) return null; // règle non régulière ici (butée), ou vue qui a défilé pendant la mesure
      return { xa, ta, pps, s0 };
    };
    let cal = await calibrate() || await calibrate();
    const zoomOut = () => { const sl = document.querySelector('[class*="timeline-tools-right"] [class*="lv-slider"]'); const b = sl && sl.previousElementSibling; return b && b.tagName === 'BUTTON' ? b : null; };
    let zooms = 0;
    while (cal && cal.pps > 45 && zooms < 10) { // échelle trop grande : une erreur d'un dixième de seconde ferait rater le raccord de plusieurs pixels
      const b = zoomOut(); if (!b || disabled(b)) break;
      const r = b.getBoundingClientRect(), before = cal.pps; await canvasPress(r.left + r.width / 2, r.top + r.height / 2); await sleep(600); zooms++;
      cal = await calibrate() || await calibrate(); if (cal && cal.pps >= before - 0.5) break;
    }
    if (!cal) return { ok: false, soft: true, error: 'règle de la timeline illisible (étalonnage impossible)', done };
    done.push(`règle étalonnée (${cal.pps.toFixed(1)} px par seconde${zooms ? `, ${zooms} dézoom(s)` : ''})`);
    const bars = () => [...document.querySelectorAll('.tool-bar-title, [class*="tool-bar-title"]')].filter((e) => vis(e) && e.getBoundingClientRect().left < innerWidth);
    const onlyBasic = () => { const b = bars(); return b.length === 1 && /^(basique|basic|de base)$/i.test(txt(b[0])); };
    const applyBtn = () => [...document.querySelectorAll('span, div, button, p')].filter((el) => el.childElementCount === 0 && vis(el) && txt(el).length < 30 && new RegExp(`^${cfg.applyAll}`, 'i').test(txt(el)))[0] || null;
    const openPanel = async () => { for (let i = 0; i < 3 && !applyBtn(); i++) { const b = bars()[0]; if (!b) break; const t = b.closest('.workbench-tool-bar, [class*="tool-bar"]') || b, r = t.getBoundingClientRect(); await canvasPress(r.left + r.width / 2, r.top + r.height / 2); await sleep(1300); } return applyBtn(); };
    const panelName = () => { const btn = applyBtn(); if (!btn) return ''; let box = btn; for (let i = 0; i < 7 && box.parentElement && !/(nom|name)/i.test(txt(box)); i++) box = box.parentElement; return txt(box).replace(/\s+/g, ' ').replace(/^(nom|name)\s*/i, '').replace(/\s*(durée|duration).*$/i, '').slice(0, 60); };
    const icon = () => document.querySelector('[class*="transition-add-icon"][class*="show-icon"]');
    const xOf = (t) => cal.xa + (t - cal.ta) * cal.pps - (wrap.scrollLeft - cal.s0);
    const timeAt = (x) => cal.ta + (x + (wrap.scrollLeft - cal.s0) - cal.xa) / cal.pps; // l'inverse : la position d'un logo → son temps sur la piste
    await rclick(cal.xa); // le curseur revient au 1er point de mesure, loin des raccords : posé dessus, il masquerait le logo
    const selected = async (wait = 10) => { for (let i = 0; i < wait && !onlyBasic(); i++) await sleep(250); if (!onlyBasic()) return null; await openPanel(); return panelName() || '?'; };
    /* Sélectionner une transition déjà posée : sa marque ne fait que ~4 px de large (mesuré sur le site le 25 novembre 2026 : à 4 px du centre, c'est le clip qui est pris).
       On essaie donc tous les 2 px, curseur de lecture écarté d'abord (posé sur le raccord, il prend le clic). */
    const mark = async (x, y, range) => { await rclick(cal.xa); for (let d = 0; d <= range; d += 2) for (const sg of d ? [d, -d] : [0]) { await tap(stage, x + sg, y); const nm = await selected(2); if (nm) return nm; } return null; };
    /* Après un clic sur le logo : CapCut pose le fondu mais ne le sélectionne pas toujours (ou le charge lentement). On attend, puis on va chercher sa marque. */
    const placed = async (cx, y) => { let nm = await selected(); if (!nm) { await sleep(2500); nm = await selected(4) || await mark(cx, y, 8); } return nm; };
    const hover = async (x, y) => { // une souris qui arrive par la gauche et s'arrête sur le raccord
      let ic = null;
      for (const dx of [-40, -24, -12, -5, -1, 0, 1]) { const el = document.elementFromPoint(x + dx, y) || stage; for (const k of ['pointerover', 'mouseover', 'pointermove', 'mousemove']) el.dispatchEvent(mk(k, x + dx, y)); await sleep(120); if ((ic = icon())) break; }
      for (let i = 0; i < 5 && !ic; i++) { await sleep(120); ic = icon(); }
      return ic;
    };
    const junction = async (t) => {
      { let p = cur(); for (let i = 0; i < 8; i++) { await sleep(250); const q = cur(); if (q === p) break; p = q; } } // CapCut rejoue la transition qu'on vient de poser : on attend que le curseur s'arrête
      let v = view(), x = xOf(t);
      for (let k = 0; k < 4 && (x < v.left + 50 || x > v.right - 50); k++) { wrap.scrollLeft = Math.max(0, wrap.scrollLeft + x - (v.left + v.right) / 2); await sleep(450); v = view(); x = xOf(t); } // raccord hors de l'écran : on fait défiler la piste
      if (x < v.left + 4 || x > v.right - 4) return { fail: 'raccord hors de la partie visible de la piste' };
      const y = v.y, span = Math.max(12, Math.min(60, Math.round(cal.pps * 0.15)));
      let ic = await hover(x, y);
      for (let d = 6; d <= span && !ic; d += 6) { ic = await hover(x + d, y); if (!ic) ic = await hover(x - d - 40, y); } // durées arrondies : le raccord peut être à quelques pixels
      if (ic) {
        const r = ic.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
        if (Math.abs(cx - x) > span + 16) return { fail: `logo trop loin du raccord attendu (${Math.round(cx - x)} px)` };
        const at = timeAt(cx);
        for (const k of ['pointerover', 'mouseover', 'pointermove', 'mousemove']) ic.dispatchEvent(mk(k, cx, cy));
        await tap(ic, cx, cy);
        const nm = await placed(cx, y); return nm ? { name: nm, added: true, at } : { fail: 'logo cliqué, mais aucune transition posée' };
      }
      // pas de logo : une transition est peut-être déjà là — un clic sur sa marque la sélectionne (un clic à côté sélectionne un clip)
      { const nm = await mark(x, y, Math.max(6, Math.min(14, span))); if (nm) return { name: nm, already: true }; }
      return { fail: 'le logo du raccord n\'est pas apparu' };
    };
    /* Raccord absent là où les durées le placent (un clip de 15 s plus long ou plus court que prévu décale tous les raccords suivants) :
       la souris glisse le long de la piste depuis le raccord précédent ; le premier logo qui apparaît est celui du raccord cherché. */
    const sweep = async (from, to) => {
      const step = Math.max(0.04, 5 / cal.pps);
      for (let t = from, k = 0; t <= to && k < 600; t += step, k++) {
        let v = view(), x = xOf(t);
        if (x < v.left + 20 || x > v.right - 20) { wrap.scrollLeft = Math.max(0, wrap.scrollLeft + x - (v.left + 80)); await sleep(450); v = view(); x = xOf(t); if (x < v.left + 4 || x > v.right - 4) break; }
        const el = document.elementFromPoint(x, v.y) || stage;
        for (const e of ['pointerover', 'mouseover', 'pointermove', 'mousemove']) el.dispatchEvent(mk(e, x, v.y));
        await sleep(60);
        const ic = icon();
        if (ic) {
          const r = ic.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2, at = timeAt(cx);
          for (const e of ['pointerover', 'mouseover', 'pointermove', 'mousemove']) ic.dispatchEvent(mk(e, cx, cy));
          await tap(ic, cx, cy);
          const nm = await placed(cx, v.y); return nm ? { name: nm, added: true, at, swept: true } : { fail: 'logo trouvé en balayant la piste, mais aucune transition posée' };
        }
      }
      return { fail: 'aucun logo en balayant la piste' };
    };
    const res = []; let acc = 0, drift = 0, prev = 0, spread = false;
    for (let j = 0; j < n - 1; j++) {
      acc += Number(durs[j]); const t0 = tot * acc / sum, t = Math.min(tot - 0.2, Math.max(0.2, t0 + drift)); // drift : l'écart vu au raccord précédent, reporté sur les suivants
      let r = await junction(t); if (!r.name) { await sleep(600); r = await junction(t); } // 2e essai : une vraie souris qui bouge au même moment fait disparaître le logo
      if (!r.name) { const w = await sweep(prev + 0.8, tot - 0.3); if (w.name) r = w; else r.fail = `${r.fail} ; ${w.fail}`; }
      if (r.at != null) { drift = r.at - t0; prev = r.at; } else prev = Math.max(prev, t);
      r.t = r.at != null ? r.at : t; res.push(r); await sleep(250);
      /* Un fondu est en place et sélectionné : « Appliquer à tout » le pose sur tous les raccords d'un coup (un seul geste au lieu d'un par raccord).
         On ne le revérifie PAS en recliquant sur la piste : la vérification d'avant (4.8.29 à 4.9.7) cliquait autour des raccords, et si elle ne
         reconnaissait pas le fondu, FruitRadar repassait sur chaque scène comme pour en reposer un. On s'arrête là ; le contrôle se fait à l'œil. */
      if (!spread && r.name && FADE.test(r.name) && n > 2) {
        spread = true;
        const btn = applyBtn() || await openPanel();
        if (btn) {
          const b = btn.getBoundingClientRect(); await canvasPress(b.left + b.width / 2, b.top + b.height / 2); await sleep(1800);
          done.push(`fondu au noir posé au raccord ${j + 1}, puis « Appliquer à tout » sur les ${n - 1} raccords`);
          return { ok: true, done, real: true, count: n - 1, want: n - 1, extended: true };
        }
        done.push('bouton « Appliquer à tout » introuvable : suite raccord par raccord');
      }
    }
    const swept = res.filter((r) => r.swept).length;
    if (swept) done.push(`${swept} raccord(s) trouvé(s) en balayant la piste`);
    const good = res.filter((r) => r.name && FADE.test(r.name)), other = res.filter((r) => r.name && !FADE.test(r.name));
    if (good.length) done.push(`fondu au noir posé par le logo du raccord : ${good.length} sur ${n - 1}${good.some((r) => r.already) ? ' (certains y étaient déjà)' : ''}`);
    if (good.length && good.length < n - 1 && !other.length) { // il en manque : la transition d'un raccord réussi est étendue aux autres
      const again = await junction(good[good.length - 1].t), btn = again.name && FADE.test(again.name) ? await openPanel() : null;
      if (btn) { const r = btn.getBoundingClientRect(); await canvasPress(r.left + r.width / 2, r.top + r.height / 2); await sleep(1500); done.push('raccords restants : « Appliquer à tout »'); return { ok: true, done, real: true, count: good.length, want: n - 1, extended: true }; }
    }
    if (good.length === n - 1) return { ok: true, done, real: true, count: good.length, want: n - 1 };
    const bad = res.find((r) => !r.name);
    return { ok: false, soft: !good.length && !other.length, done, real: true, count: good.length, want: n - 1,
      error: other.length ? `CapCut a posé « ${other[0].name} » au lieu d'un fondu au noir (raccord ${res.indexOf(other[0]) + 1}) : remplace-la à la main` : `raccord ${res.indexOf(bad) + 1} sur ${n - 1} : ${bad.fail}` };
  }
  async function capcutTransitions(cfg, durs) {
    const ruler = document.querySelector('canvas[class*="zoom-axis"]');
    if (ruler) {
      // d'abord le logo du raccord (un clic par raccord) ; l'ancienne méthode (onglet Transitions) seulement si la piste n'a pas pu être lue du tout
      const j = await capcutFadeJunctions(cfg, durs).catch((e) => ({ ok: false, soft: true, error: e.message, done: [] }));
      if (j.ok || !j.soft) return j;
      const old = await capcutFadeReal(cfg);
      return { ...old, done: [...(j.done || []), `logo du raccord : ${j.error}`, ...(old.done || [])] };
    }
    const done = [];
    const tl = firstVis(cfg.timeline || ['[class*="timeline" i]']);
    const seg = tl && tl.querySelector((cfg.segment || ['[class*="segment" i]']).join(','));
    if (seg) { click(seg); done.push('clip 1 sélectionné'); await sleep(800); }
    const tab = clickText(cfg.transitionsTab);
    if (!tab.ok) return { ok: false, error: 'onglet « Transitions » introuvable', done };
    done.push('onglet Transitions'); await sleep(2000);
    // les vignettes d'effets sont souvent de simples blocs (pas des boutons) : on cherche le texte, puis la vignette qui l'entoure
    let card = findByText(cfg.transitionText);
    if (!card) {
      const re = new RegExp(cfg.transitionText, 'i');
      const hit = [...document.querySelectorAll('span, p, div, li, figcaption')].filter((el) => vis(el) && el.childElementCount <= 3 && re.test(txt(el)) && txt(el).length < 60)
        .sort((a, b) => txt(a).length - txt(b).length)[0];
      if (hit) { card = hit; for (let up = hit, i = 0; up && i < 5; up = up.parentElement, i++) if (/(card|item|effect|resource|material|transition)/i.test(up.className || '') || getComputedStyle(up).cursor === 'pointer') { card = up; break; } }
    }
    if (!card) return { ok: false, error: 'transition « fondu au noir » introuvable dans le panneau', done };
    card.scrollIntoView({ block: 'center' }); fire(card, 'mouseenter'); fire(card, 'mouseover'); await sleep(500);
    const plus = [...card.querySelectorAll((cfg.addButton || ['[class*="add" i]']).join(','))].find(vis);
    click(plus || card); done.push(`« ${label(card).slice(0, 40)} »`); await sleep(1500);
    const all = clickText(cfg.applyAll);
    if (!all.ok) return { ok: false, error: 'bouton « Appliquer à tout » introuvable : la transition n\'est peut-être que sur le premier raccord', done };
    done.push('appliquée à tous les raccords');
    return { ok: true, done };
  }


  /* ---------- TikTok Studio (calé sur une capture de l'éditeur : onglets Légendes / Texte / Sons, panneau Préréglages) ---------- */
  const btnByText = (re, root = document) => [...root.querySelectorAll(CLICKABLE)].find((el) => vis(el) && re.test(txt(el)) && txt(el).length < 40) || null;
  /* Repères relevés sur le vrai TikTok Studio le 16 novembre 2026 (page d'envoi puis éditeur « Monter ») :
     - « Modifier la couverture » est un simple <div> (DIV.edit-container), pas un bouton ;
     - les barres latérales de l'éditeur (Légendes, Texte, Sons, Modèles à gauche ; Basique, Préréglages, Audio à droite) sont aussi des <div> :
       DIV.EditorLeftSideMenu__menuItem. Recliquer l'entrée déjà ouverte REFERME son panneau ;
     - légendes : lignes DIV.CaptionClip__Input ; cadre de la légende choisie sur l'aperçu : DIV.StageCanvas__widget dans DIV.StageCanvas__screen ;
     - modèles de légende : DIV.EffectList__item (le 1er = aucun, le 2e = « Life in Motion ») ;
     - sons : lignes DIV.MusicPanelMusicItem__content (titre .MusicPanelMusicItem__infoBasicTitle, bouton + dans .MusicPanelMusicItem__operation),
       onglets [role=tab] « Pour toi / Favoris / Illimité / Récent » ; le son se pose à l'endroit du curseur de lecture (clip DIV.AudioClip__root). */
  const tkLeaf = (re, root = document) => [...root.querySelectorAll('button, [role="button"], [role="tab"], label, div, span')].filter((el) => vis(el) && re.test(txt(el)) && txt(el).length < 60)
    .sort((x, y) => x.querySelectorAll('*').length - y.querySelectorAll('*').length)[0] || null;
  const tkRailItem = (re) => [...document.querySelectorAll('[class*="SideMenu__menuItem"]')].filter(vis).find((e) => re.test(txt(e))) || btnByText(re);
  const tkPress = async (el) => { // appui complet au centre de l'élément : survol, appui, relâchement, clic
    el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    const r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
    let t = document.elementFromPoint(x, y); if (!t || !el.contains(t)) t = el;
    const init = (type) => ({ bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: /down/.test(type) ? 1 : 0, pointerId: 1, pointerType: 'mouse', isPrimary: true });
    const ev = (type) => t.dispatchEvent(new (/^pointer/.test(type) ? PointerEvent : MouseEvent)(type, init(type)));
    for (const k of ['pointerover', 'mouseover', 'pointermove', 'mousemove', 'pointerdown', 'mousedown']) ev(k);
    await sleep(90);
    for (const k of ['pointerup', 'mouseup', 'click']) ev(k);
  };
  const tkStage = () => [...document.querySelectorAll('[class*="StageCanvas__screen"], [class*="StageCanvas__root"]')].filter(vis)[0] || null; // l'aperçu de l'éditeur
  const tkWidget = () => { // cadre de la légende sélectionnée, posé sur l'aperçu
    const st = tkStage(); if (!st) return null; const pv = st.getBoundingClientRect();
    return [...document.querySelectorAll('[class*="StageCanvas__widget"]')].filter((e) => { if (!vis(e)) return false; const r = e.getBoundingClientRect(); return r.height < pv.height * 0.5 && r.left >= pv.left - 6 && r.right <= pv.right + 6; })[0] || null;
  };
  const tkCapRows = () => [...document.querySelectorAll('[class*="CaptionClip__Input"]')].filter(vis);
  function tiktokState(cfg) {
    const body = txt(document.body);
    const publish = tkPublishBtn();
    const bigVideo = [...document.querySelectorAll('video, canvas')].filter(vis).sort((a, b) => b.getBoundingClientRect().height - a.getBoundingClientRect().height)[0];
    return { path: location.pathname, input: qAll(cfg.fileInput || ['input[type="file"]']).length, publish: !!publish, publishOff: !!(publish && disabled(publish)),
      desc: !!composer(cfg), preview: !!bigVideo, edit: !!btnByText(/^(monter|edit)$/i), save: !!btnByText(/^(enregistrer|save)$/i),
      captionsTab: !!tkRailItem(/^(légendes|captions)$/i), uploading: /(téléversement en cours|importation en cours|uploading|upload in progress)/i.test(body.slice(0, 5000)),
      text: body.slice(0, 8000), block: detectBlock(cfg) };
  }
  /* Ouvre un panneau de l'éditeur par sa barre de gauche, sans le refermer s'il est déjà ouvert. */
  async function tiktokRail(which) {
    const isOpen = which === 'sounds' ? () => [...document.querySelectorAll('input')].some((i) => vis(i) && /(sons|sounds|musique|music)/i.test(i.placeholder || '')) || [...document.querySelectorAll('[class*="MusicPanel"]')].some(vis) || [...document.querySelectorAll('[role="tab"]')].some((t) => vis(t) && /^(favoris|favorites|récents?|recent)$/i.test(txt(t)))
      : () => tkCapRows().length > 0 || !!tkLeaf(/^(générer|generate|tout supprimer|delete all)$/i);
    if (isOpen()) return { ok: true, already: true };
    const re = which === 'sounds' ? /^(sons?|sounds?)$/i : /^(légendes?|captions?)$/i;
    let it = null; for (let i = 0; i < 20 && !(it = tkRailItem(re)); i++) await sleep(300);
    if (!it) return { ok: false, error: `entrée « ${which === 'sounds' ? 'Sons' : 'Légendes'} » introuvable dans l'éditeur` };
    click(it);
    for (let i = 0; i < 15 && !isOpen(); i++) await sleep(300);
    if (!isOpen()) { await tkPress(it); for (let i = 0; i < 15 && !isOpen(); i++) await sleep(300); } // un simple clic n'est pas toujours pris : appui complet
    return { ok: isOpen() || !document.querySelector('[class*="SideMenu__menuItem"]'), error: 'le panneau ne s\'est pas ouvert' };
  }
  /* Le bouton « Publier » de la page d'envoi : tout en bas du formulaire, à gauche, dans la rangée « Publier · Enregistrer le brouillon · Supprimer »
     (relevé du 18 novembre 2026). On ne prend que de vrais boutons, jamais un lien ni une entrée de menu qui porterait le même mot et ferait
     quitter la page d'envoi ; s'il y en a plusieurs, celui de cette rangée, sinon le plus bas de la page. */
  const tkPublishBtn = () => {
    const re = /^(publier|post|publish)$/i, mate = /^(enregistrer le brouillon|save draft|brouillon|drafts?|supprimer|discard|ignorer)$/i;
    const all = [...document.querySelectorAll('button, [role="button"]')].filter((el) => vis(el) && re.test(txt(el)) && !el.closest('a[href]'));
    if (!all.length) return null;
    const score = (el) => {
      let s = el.closest('[role="dialog"], [aria-modal="true"]') ? 0 : 1;
      for (let box = el.parentElement, i = 0; box && i < 3; box = box.parentElement, i++) if ([...box.querySelectorAll('button, [role="button"]')].some((x) => x !== el && mate.test(txt(x)))) { s += 4; break; }
      return s;
    };
    return all.map((el) => ({ el, s: score(el), y: el.getBoundingClientRect().top + scrollY })).sort((a, b) => b.s - a.s || b.y - a.y)[0].el;
  };
  /* Publier : un appui complet (survol, appui, relâchement) sur le bouton, pas un simple clic simulé que TikTok ignore parfois.
     Le bouton reste grisé tant que TikTok téléverse ou vérifie la vidéo : on le dit, pour que le pilote attende. */
  async function tiktokPublish(plain) {
    const el = tkPublishBtn();
    if (!el) return { ok: false, error: 'bouton Publier introuvable' };
    const b = el.closest('button, [role="button"]') || el;
    if (disabled(b) || b.getAttribute('aria-disabled') === 'true' || b.getAttribute('data-disabled') === 'true') return { ok: false, off: true };
    b.scrollIntoView({ block: 'center' }); await sleep(250);
    if (plain) click(b); else await tkPress(b);
    return { ok: true, text: txt(b).slice(0, 40) };
  }
  /* Fenêtre de confirmation de TikTok après « Publier » (« Publier maintenant », « Publier quand même »…) : on ne clique que dans une fenêtre, jamais sur la page. */
  async function tiktokConfirm() {
    const boxes = [...document.querySelectorAll('[role="dialog"], [class*="Modal" i], [class*="Dialog" i], [class*="common-modal" i]')].filter(vis);
    for (const box of boxes) {
      const el = [...box.querySelectorAll('button, [role="button"]')].filter(vis).find((x) => /^(publier maintenant|post now|publish now|publier quand même|post anyway|publier|post|publish)$/i.test(txt(x)));
      if (el) { await tkPress(el); return { ok: true, text: txt(el).slice(0, 40), box: txt(box).slice(0, 160) }; }
    }
    return { ok: false, open: boxes.length ? txt(boxes[0]).slice(0, 160) : '' };
  }
  function tiktokClick(pattern) { const el = btnByText(new RegExp(pattern, 'i')); if (!el) return { ok: false }; click(el); return { ok: true, text: txt(el).slice(0, 40) }; }
  /* Légendes : dans l'éditeur, onglet « Légendes », bouton « Générer » (langue automatique). La liste arrive en 10 à 20 s,
     avec « Tout supprimer » et « Générer à nouveau » en bas. Vu sur le vrai site. */
  /* Légendes. « Générer » ne donne parfois rien au premier clic (signalé par l'auteur, 18 novembre 2026) : on retente UNE fois, et seulement
     si la 1re tentative n'a rien donné. Légendes arrivées du premier coup : on passe à la suite sans rien recliquer. */
  async function tiktokCaptions() {
    const leaf = (re) => [...document.querySelectorAll('button, [role="button"], div, span')].filter((el) => vis(el) && re.test(txt(el)) && txt(el).length < 40).sort((x, y) => x.querySelectorAll('*').length - y.querySelectorAll('*').length)[0] || null;
    const has = () => tkCapRows().length > 0 || !!leaf(/^(tout supprimer|delete all|générer à nouveau|regenerate)$/i);
    const none = () => /(aucune parole|aucun propos|aucun discours|no speech|pas de voix|n.a d.tect. aucun)/i.test(txt(document.body).slice(0, 6000));
    const genBtn = () => { const g = leaf(/^(générer|generate)$/i); return g ? (g.closest('button') || g) : null; };
    if (has()) return { ok: true, already: true };
    if (!genBtn()) return { ok: false, error: 'bouton « Générer » des légendes introuvable' };
    let said = false, reacted = false;
    for (let attempt = 1; attempt <= 2; attempt++) {
      let b = genBtn();
      if (attempt > 1) {
        // « Générer » doit être revenu, cliquable. S'il ne revient pas, TikTok travaille encore : on attend les légendes sans rien recliquer.
        for (let i = 0; i < 10 && (!b || disabled(b)); i++) { await sleep(1000); if (has()) return { ok: true, tries: 1 }; b = genBtn(); }
        if (!b || disabled(b)) { for (let i = 0; i < 40; i++) { await sleep(1500); if (has()) return { ok: true, tries: 1 }; } break; }
      }
      /* Relevé du 26 novembre 2026 : « Générer » toujours là après deux clics simulés, sans légendes. Le 1er essai est donc un appui complet
         (survol, appui, relâchement), le 2e un clic simulé ; et si le bouton n'a toujours pas bougé au bout de 6 s, le clic natif du navigateur. */
      if (attempt === 1) await tkPress(b); else click(b);
      let moved = false, idle = 0; said = false;
      for (let i = 0, max = attempt === 1 ? 30 : 60; i < max; i++) { // 45 s pour la 1re tentative, 90 s pour la 2e
        await sleep(1500);
        if (has()) return { ok: true, tries: attempt };
        if (none() && (attempt === 1 || i >= 4)) { said = true; break; } // 2e tentative : l'ancien message peut encore être affiché quelques secondes
        const g = genBtn();
        if (i === 3 && !moved && g && !disabled(g)) { try { g.click(); } catch (e) { /* bouton parti entre-temps */ } }
        if (!g || disabled(g)) { moved = true; reacted = true; idle = 0; } else if (moved && ++idle >= 4) break; // « Générer » est revenu, cliquable, sans légendes : TikTok a abandonné sans rien dire
      }
    }
    return said ? { ok: false, none: true, tries: 2 } : { ok: false, tries: 2, reacted, error: reacted ? 'TikTok a lancé la génération, mais les légendes ne sont pas arrivées (2 tentatives)' : 'le bouton « Générer » n\'a pas réagi (2 tentatives, 3 façons de cliquer)' };
  }
  /* Hashtags : collés d'un bloc, ils restent du texte simple. Il faut écrire chaque hashtag, attendre la liste de suggestions (2 à 4 s)
     et valider (Entrée, ou clic sur la ligne exacte) : il passe alors en gras, cliquable (span.mention). Vu sur le vrai site. */
  async function tiktokHashtags(tags, cfg) {
    const el = composer(cfg); if (!el) return { ok: false, error: 'zone de description introuvable' };
    const linked = () => el.querySelectorAll('span.mention').length;
    const end = () => { el.focus(); const r = document.createRange(); r.selectNodeContents(el); r.collapse(false); const sl = getSelection(); sl.removeAllRanges(); sl.addRange(r); };
    const type = (t) => { end(); document.execCommand('insertText', false, t); };
    const row = (tag) => {
      const hit = [...document.querySelectorAll('div, span, li, p')].filter((x) => !el.contains(x) && vis(x) && x.childElementCount <= 1 && txt(x).toLowerCase() === tag.toLowerCase())[0];
      if (!hit) return null;
      let r = hit; for (let i = 0; i < 3 && r.parentElement && !/(publication|post|vue|view)/i.test(txt(r)); i++) r = r.parentElement;
      return /(publication|post|vue|view)/i.test(txt(r)) ? r : hit;
    };
    const key = (k) => { for (const t of ['keydown', 'keypress', 'keyup']) (document.activeElement || el).dispatchEvent(new KeyboardEvent(t, { bubbles: true, cancelable: true, key: k, code: k, keyCode: 13, which: 13 })); };
    const plain = []; let ok = 0;
    for (const tag of tags) {
      const before = linked();
      type((/\s$/.test(el.innerText.replace(/\n+$/, '')) ? '' : ' ') + tag);
      const spaced = () => /\s$/.test(el.innerText.replace(/\n+$/, ''));
      let r = null;
      for (let i = 0; i < 16 && !r; i++) { await sleep(450); r = row(tag); if (!r && i >= 5 && linked() > before && spaced()) break; } // TikTok valide parfois tout seul
      // Entrée seulement si la liste est ouverte (sinon : saut de ligne). On ne clique la ligne que si Entrée n'a PAS lié le hashtag :
      // cliquer après une Entrée réussie l'écrivait une 2e fois (« #partie1#partie1 », vu le 16 novembre 2026).
      if (r) { end(); key('Enter'); for (let i = 0; i < 6 && linked() <= before; i++) await sleep(250); if (linked() <= before) { const still = row(tag); if (still) { click(still); await sleep(700); } } }
      if (!spaced()) type(' ');
      await sleep(300);
      if (linked() > before) ok++; else plain.push(tag);
    }
    return { ok: plain.length === 0, linked: ok, plain };
  }
  /* Couverture (vrai site, 16 novembre 2026) : « Modifier la couverture » ouvre une fenêtre (DIV.Dialog__content) avec « Importer une couverture »
     (champ de fichier image), l'image dans un grand canevas, un aperçu du profil en 3:4, et « Annuler / Enregistrer » en haut à droite.
     L'aperçu ne montre que le milieu de l'image : on la fait glisser vers le bas pour voir le haut (le titre de la miniature), TikTok bloque en butée. */
  const tkCoverInput = () => [...document.querySelectorAll('input[type="file"][accept*="image"]')].find((i) => i.parentElement && vis(i.parentElement) && !i.closest('[hidden]')) || null;
  const tkCoverDlg = () => [...document.querySelectorAll('[class*="Dialog__content"], [role="dialog"]')].filter(vis).find((d) => /(modifier la couverture|edit cover)/i.test(txt(d).slice(0, 300)) && /(échelle|scale|annuler|cancel)/i.test(txt(d)))
    || (tkCoverInput() ? (tkCoverInput().closest('[class*="Dialog__content"], [role="dialog"]') || tkCoverInput().parentElement) : null);
  async function tiktokCoverOpen() {
    if (tkCoverInput()) return { ok: true, already: true };
    const b = tkLeaf(/^(modifier la couverture|edit cover)$/i);
    if (!b) return { ok: false, error: '« Modifier la couverture » introuvable' };
    click(b);
    for (let i = 0; i < 30 && !tkCoverInput(); i++) await sleep(300);
    return tkCoverInput() ? { ok: true } : { ok: false, error: 'la fenêtre de la couverture ne s\'est pas ouverte' };
  }
  async function tiktokCoverAlign(where = 'haut') {
    if (where === 'centre') return { ok: true, skipped: true };
    const dlg = tkCoverDlg(); if (!dlg) return { ok: false, error: 'fenêtre de la couverture introuvable' };
    let cv = null;
    for (let i = 0; i < 20 && !cv; i++) { cv = [...dlg.querySelectorAll('canvas')].filter(vis).sort((a, b) => b.getBoundingClientRect().width - a.getBoundingClientRect().width)[0] || null; if (!cv) await sleep(300); }
    if (!cv) return { ok: false, error: 'image de la couverture introuvable' };
    const sig = () => { // empreinte de ce que montre le canevas : elle change quand l'image bouge
      try { const c = document.createElement('canvas'); c.width = 31; c.height = 17; const g = c.getContext('2d', { willReadFrequently: true }); g.drawImage(cv, 0, 0, 31, 17); const d = g.getImageData(0, 0, 31, 17).data; let h = 0, flat = true; for (let i = 0; i < d.length; i += 4) { h = (h * 31 + d[i] + d[i + 1] * 3 + d[i + 2] * 7) % 1000000007; if (d[i] !== d[0] || d[i + 1] !== d[1] || d[i + 2] !== d[2]) flat = false; } return flat ? 'plat' : String(h); } catch (e) { return 'illisible'; }
    };
    let s0 = sig(); for (let i = 0; i < 8; i++) { await sleep(400); const s = sig(); if (s === s0 && i >= 2) break; s0 = s; } // l'image importée finit de s'afficher
    const r = cv.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2, dy = (where === 'bas' ? -1 : 1) * Math.round(r.height * 0.6);
    const el = document.elementFromPoint(x, y) || cv;
    const init = (type, yy) => ({ bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: yy, screenX: x, screenY: yy, button: 0, buttons: /up$/.test(type) ? 0 : 1, pointerId: 1, pointerType: 'mouse', isPrimary: true });
    const ev = (target, type, yy) => target.dispatchEvent(new (/^pointer/.test(type) ? PointerEvent : MouseEvent)(type, init(type, yy)));
    ev(el, 'pointerdown', y); ev(el, 'mousedown', y);
    for (let i = 1; i <= 12; i++) { const yy = y + dy * (i / 12); for (const t of ['pointermove', 'mousemove']) { ev(el, t, yy); ev(document, t, yy); } await sleep(40); }
    for (const t of ['pointerup', 'mouseup']) { ev(el, t, y + dy); ev(document, t, y + dy); }
    await sleep(800);
    const s1 = sig();
    if (s0 === 'plat' || s0 === 'illisible' || s1 === 'plat' || s1 === 'illisible') return { ok: true, unsure: true }; // canevas non lisible : le geste est fait, on ne peut pas le confirmer
    return { ok: s1 !== s0, error: 'l\'image de couverture n\'a pas bougé' };
  }
  async function tiktokCoverSave() {
    const dlg = tkCoverDlg();
    const re = /^(enregistrer|confirmer|terminé|done|save|confirm)$/i;
    const b = (dlg && btnByText(re, dlg)) || btnByText(re);
    if (!b) return { ok: false, error: 'bouton « Enregistrer » de la couverture introuvable' };
    click(b);
    for (let i = 0; i < 30 && tkCoverDlg(); i++) await sleep(300);
    return tkCoverDlg() ? { ok: false, error: 'la fenêtre de la couverture est restée ouverte' } : { ok: true };
  }
  /* Modèle de légende (vrai site) : panneau « Préréglages » à droite (il s'ouvre tout seul quand les légendes arrivent), onglet « Avancé »,
     vignettes DIV.EffectList__item : la 1re = aucun modèle, la 2e = « Life in Motion ». « Appliquer à tous » est coché d'origine.
     L'ancienne version prenait les entrées de la barre de droite pour des vignettes et refermait le panneau au lieu de choisir le modèle. */
  async function tiktokPreset(which = 1) {
    const out = { ok: false, notes: [] };
    const items = () => [...document.querySelectorAll('[class*="EffectList__item"]')].filter(vis);
    if (!tkWidget() && tkCapRows().length) { click(tkCapRows()[0]); await sleep(900); } // une légende doit être sélectionnée : le modèle s'applique à elle (et à toutes)
    if (!items().length) { const rail = [...document.querySelectorAll('[class*="RightSideBar"] [class*="menuItem"]')].filter(vis).find((e) => /^(préréglages|presets)$/i.test(txt(e))); if (rail) { click(rail); out.notes.push('panneau Préréglages ouvert'); } }
    for (let i = 0; i < 20 && !items().length && document.querySelector('[class*="SideMenu__menuItem"]'); i++) await sleep(300);
    const adv = [...document.querySelectorAll('[role="tab"]')].filter(vis).find((t) => /^(avancé|advanced)$/i.test(txt(t))) || btnByText(/^(avancé|advanced)$/i);
    if (adv && adv.getAttribute('aria-selected') !== 'true') { click(adv); await sleep(900); out.notes.push('onglet Avancé'); }
    let tiles = items();
    if (!tiles.length) { // autre interface : vignettes carrées de la colonne de droite, hors barres latérales
      const W = innerWidth;
      tiles = qAll(['[role="button"]', 'button', 'div[class*="preset" i]', 'div[class*="item" i]', 'li', 'img', 'canvas']).filter((el) => {
        if (!vis(el) || el.closest('[class*="SideMenu"]')) return false; const r = el.getBoundingClientRect();
        return r.left > W * 0.7 && r.width > 50 && r.width < 140 && r.height > 50 && r.height < 140;
      }).map((el) => { const r = el.getBoundingClientRect(); return { el, x: Math.round(r.left), y: Math.round(r.top) }; })
        .filter((t, i, a) => !a.some((o, k) => k < i && Math.abs(o.x - t.x) < 6 && Math.abs(o.y - t.y) < 6))
        .sort((a, b) => (a.y - b.y) || (a.x - b.x)).map((t) => t.el);
    }
    if (tiles.length <= which) { out.error = `modèles introuvables (${tiles.length} vignettes vues)`; return out; }
    // Le cadre de la légende change de taille quand le modèle (autre police) s'applique : c'est notre preuve. Un premier appui peut seulement
    // charger le modèle : on appuie jusqu'à 3 fois, en laissant 2,5 s à chaque fois.
    const size = () => { const w = tkWidget(); if (!w) return ''; const r = w.getBoundingClientRect(); return Math.round(r.width) + 'x' + Math.round(r.height); };
    const s0 = size(); let applied = false, n = 0;
    for (; n < 3 && !applied; n++) {
      await tkPress(tiles[which].querySelector('img, canvas, video') || tiles[which]);
      for (let i = 0; i < 9 && !applied; i++) { await sleep(280); applied = !!s0 && size() !== s0 && size() !== ''; }
      if (!s0) break; // pas de cadre à comparer : un seul appui
    }
    out.ok = true; out.applied = applied; out.notes.push(`modèle n°${which + 1} sur ${tiles.length}${applied ? '' : ', non confirmé'}`);
    const lab = [...document.querySelectorAll('label, div, span')].find((el) => vis(el) && /^(appliquer à tous|apply to all)$/i.test(txt(el)));
    if (lab) {
      const box = lab.querySelector('input[type="checkbox"]') || lab.closest('label')?.querySelector('input[type="checkbox"]') || lab.parentElement.querySelector('input[type="checkbox"], [role="checkbox"]');
      const on = box ? (box.checked === true || box.getAttribute('aria-checked') === 'true') : null;
      if (box && on === false) { click(box.closest('label') || box); out.notes.push('« Appliquer à tous » coché'); } else out.notes.push('« Appliquer à tous » déjà coché');
    }
    return out;
  }
  /* Hauteur de la légende (vrai site) : on clique une ligne de la liste « Légendes » ; son cadre (DIV.StageCanvas__widget) apparaît sur l'aperçu
     (DIV.StageCanvas__screen) et se fait glisser. Toutes les légendes suivent. rel : 0 = haut de l'écran du téléphone, 1 = bas. */
  async function tiktokRaiseCaption(rel = 0.68) {
    const st = tkStage();
    if (!st || !tkCapRows().length) return tiktokRaiseCaptionOld(rel);
    const pvOf = () => (tkStage() || st).getBoundingClientRect();
    const relOf = (w) => { const pv = pvOf(), r = w.getBoundingClientRect(); return (r.top + r.height / 2 - pv.top) / pv.height; };
    // Aperçu en lecture : le cadre d'une légende disparaît dès que sa phrase est passée, en plein geste. On le met en pause.
    for (const v of document.querySelectorAll('video')) { try { if (!v.paused) v.pause(); } catch (e) { /* lecteur fermé */ } }
    // Le cadre doit être immobile avant d'être saisi : juste après le modèle « Life in Motion », il change encore de taille et de place.
    const steady = async () => {
      let last = '', same = 0;
      for (let i = 0; i < 16; i++) {
        const w = tkWidget(), r = w && w.getBoundingClientRect(), k = r ? [r.left, r.top, r.width, r.height].map(Math.round).join(',') : '';
        if (k && k === last) { if (++same >= 2) return w; } else same = 0;
        last = k; await sleep(200);
      }
      return tkWidget();
    };
    let from = null, to = null;
    for (let tryN = 1; tryN <= 3; tryN++) { // une fois sur cinq, le premier geste n'était pas pris : on vérifie et on recommence
      if (!tkWidget()) { const row = tkCapRows()[0]; if (row) click(row); for (let i = 0; i < 12 && !tkWidget(); i++) await sleep(250); }
      const fr = await steady();
      if (!fr) { await sleep(600); continue; }
      const now = relOf(fr); if (from === null) from = now;
      if (Math.abs(now - rel) < 0.025) return { ok: true, already: tryN === 1, at: Math.round(now * 100), tries: tryN };
      const pv = pvOf(), r0 = fr.getBoundingClientRect(), cx = r0.left + r0.width / 2, cy = r0.top + r0.height / 2, ty = pv.top + pv.height * rel;
      let t = document.elementFromPoint(cx, cy); if (!t || !fr.contains(t)) t = fr; // le geste part du cadre lui-même, pas d'un élément posé par-dessus
      const mv = (target, type, y) => target.dispatchEvent(new (/^pointer/.test(type) ? PointerEvent : MouseEvent)(type, { bubbles: true, cancelable: true, composed: true, view: window, clientX: cx, clientY: y, screenX: cx, screenY: y, button: 0, buttons: /up$/.test(type) ? 0 : 1, pointerId: 1, pointerType: 'mouse', isPrimary: true }));
      for (const k of ['pointerover', 'mouseover', 'pointermove', 'mousemove']) mv(t, k, cy); // la souris arrive sur le cadre
      mv(t, 'pointerdown', cy); mv(t, 'mousedown', cy); await sleep(80);
      for (let i = 1; i <= 20; i++) { const y = cy + (ty - cy) * (i / 20); for (const k of ['pointermove', 'mousemove']) { mv(t, k, y); mv(document, k, y); } await sleep(35); }
      await sleep(80);
      for (const k of ['pointerup', 'mouseup']) { mv(t, k, ty); mv(document, k, ty); }
      for (let i = 0; i < 10; i++) { await sleep(250); const w = tkWidget(); if (w && Math.abs(relOf(w) - rel) < 0.06) break; } // la nouvelle place s'affiche parfois avec un temps de retard
      const w = tkWidget(); to = w ? relOf(w) : null;
      if (to !== null && Math.abs(to - rel) < 0.06) return { ok: true, from: Math.round(from * 100), to: Math.round(to * 100), tries: tryN };
      await sleep(500);
    }
    if (from === null) return { ok: false, error: 'cadre de la légende introuvable sur l\'aperçu' };
    return { ok: false, from: Math.round(from * 100), to: to === null ? null : Math.round(to * 100),
      error: to === null ? 'le cadre de la légende a disparu pendant le geste (3 essais)' : `la légende est à ${Math.round(to * 100)} % de la hauteur au lieu de ${Math.round(rel * 100)} % (3 essais)` };
  }
  /* même geste sur une interface sans ces repères : cadre bleu cherché à sa couleur */
  async function tiktokRaiseCaptionOld(rel = 0.68) {
    const W = innerWidth;
    const head = [...document.querySelectorAll('div, span, h1, h2, h3, p')].find((el) => vis(el) && /^(légendes|captions)$/i.test(txt(el)) && el.getBoundingClientRect().left < W * 0.3 && el.getBoundingClientRect().top < 300);
    if (!head) return { ok: false, error: 'liste des légendes introuvable' };
    const hr = head.getBoundingClientRect();
    const rows = [...document.querySelectorAll('div, li, p, span')].filter((el) => {
      if (!vis(el) || el.querySelector('button, input') || el.children.length > 3) return false;
      const r = el.getBoundingClientRect(); const t = txt(el);
      return r.left < W * 0.3 && r.top > hr.bottom + 10 && r.height < 90 && t.length > 1 && t.length < 160 && !/(tout supprimer|générer à nouveau|regenerate|delete all)/i.test(t);
    }).sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
    if (!rows.length) return { ok: false, error: 'aucune légende dans la liste' };
    click(rows[0]); await sleep(1000);
    const vids = [...document.querySelectorAll('video, canvas')].filter(vis).sort((a, b) => b.getBoundingClientRect().height - a.getBoundingClientRect().height);
    const pv = vids[0] ? vids[0].getBoundingClientRect() : null;
    if (!pv) return { ok: false, error: 'aperçu introuvable' };
    const cyan = (c) => { const m = String(c).match(/[\d.]+/g); if (!m || m.length < 3) return false; const [r, g, b] = m.map(Number); return b > 170 && g > 130 && r < 120; };
    const frameOf = () => [...document.querySelectorAll('div, span')].filter((el) => {
      const r = el.getBoundingClientRect(); if (r.width < 30 || r.height < 12 || r.width > pv.width * 0.98 || r.left < pv.left - 4 || r.right > pv.right + 4 || r.top < pv.top - 4 || r.bottom > pv.bottom + 4) return false;
      const cs = getComputedStyle(el); return (parseFloat(cs.borderTopWidth) >= 1 && cyan(cs.borderTopColor)) || (parseFloat(cs.outlineWidth) >= 1 && cyan(cs.outlineColor));
    }).sort((a, b) => (b.getBoundingClientRect().width * b.getBoundingClientRect().height) - (a.getBoundingClientRect().width * a.getBoundingClientRect().height))[0] || null;
    const fr = frameOf(); if (!fr) return { ok: false, error: 'cadre bleu de la légende introuvable' };
    const r0 = fr.getBoundingClientRect(); const cx = r0.left + r0.width / 2, cy = r0.top + r0.height / 2, ty = pv.top + pv.height * rel;
    const mv = (type, y, C = MouseEvent) => { const init = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: y, button: 0, buttons: type.endsWith('up') ? 0 : 1, pointerId: 1, pointerType: 'mouse', isPrimary: true }; fr.dispatchEvent(new C(type, init)); document.dispatchEvent(new C(type.replace('pointer', 'mouse'), init)); };
    mv('pointerdown', cy, PointerEvent); mv('mousedown', cy);
    const steps = 14; for (let i = 1; i <= steps; i++) { const y = cy + (ty - cy) * (i / steps); mv('pointermove', y, PointerEvent); mv('mousemove', y); await sleep(40); }
    mv('pointerup', ty, PointerEvent); mv('mouseup', ty); await sleep(700);
    const r1 = (frameOf() || fr).getBoundingClientRect(); const moved = Math.round((r0.top + r0.height / 2) - (r1.top + r1.height / 2));
    return { ok: moved > 8, moved, from: Math.round(cy - pv.top), to: Math.round(ty - pv.top), error: moved > 8 ? '' : 'le cadre ne s\'est pas déplacé' };
  }
  /* aperçu en « Mode téléphone » (bouton sous l'aperçu, « Mode de base » par défaut) : on voit les icônes likes / commentaires / enregistrements */
  async function tiktokPhoneMode() {
    const on = /^(mode téléphone|phone mode)$/i, any = /^(mode de base|basic mode|mode téléphone|phone mode)$/i;
    const cur = btnByText(any) || [...document.querySelectorAll('div, span, button')].find((el) => vis(el) && any.test(txt(el)) && el.children.length <= 2);
    if (!cur) return { ok: false, error: 'bouton du mode d\'aperçu introuvable' };
    if (on.test(txt(cur))) return { ok: true, already: true };
    click(cur); await sleep(800);
    const opt = [...document.querySelectorAll('[role="option"], [role="menuitem"], li, div, span, button')].filter((el) => vis(el) && on.test(txt(el)) && el !== cur).sort((x, y) => x.getBoundingClientRect().width * x.getBoundingClientRect().height - y.getBoundingClientRect().width * y.getBoundingClientRect().height)[0];
    if (!opt) return { ok: false, error: 'choix « Mode téléphone » introuvable' };
    click(opt); await sleep(1200);
    const now = btnByText(any); return { ok: !now || on.test(txt(now)), error: 'le mode téléphone ne s\'est pas activé' };
  }
  /* Volume du son ajouté (panneau Audio à droite), en dB.
     La case peut réafficher la valeur autrement qu'on l'a écrite (« -7.0 », « −7 dB ») : on compare des nombres, pas des textes.
     Chaque échec rend un relevé (see) de ce que le panneau montrait, pour corriger sans deviner. */
  async function tiktokVolume(db) {
    const W = innerWidth, want = Number(db);
    const num = (v) => { const m = String(v == null ? '' : v).replace(/[−–]/g, '-').replace(',', '.').match(/-?\d+(\.\d+)?/); return m ? Number(m[0]) : NaN; };
    const same = (v) => Math.abs(num(v) - want) < 0.11;
    const heads = () => [...document.querySelectorAll('div, span, p, label, h3, h4')].filter((el) => vis(el) && /^volume\b/i.test(txt(el)) && txt(el).length <= 24 && el.childElementCount <= 1).sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left);
    for (let i = 0; i < 12 && !heads().length; i++) await sleep(250);
    const head = heads()[0];
    const about = (el) => `${el.type || 'text'}${el.className ? '.' + String(el.className).split(/\s+/)[0].slice(0, 30) : ''}=« ${String(el.value).slice(0, 12)} »${el.type === 'range' ? ` [${el.min}..${el.max}]` : ''}${vis(el) ? '' : ' caché'}`;
    const panel = () => [...document.querySelectorAll('input')].filter((el) => !/^(checkbox|radio|file)$/.test(el.type) && el.getBoundingClientRect().left > W * 0.55 || /PropSetting|Slider/i.test(String(el.className))).slice(0, 8).map(about);
    if (!head) return { ok: false, error: 'réglage Volume introuvable (le son est-il sélectionné ?)', see: { titres: [...document.querySelectorAll('[class*="PropSettingGroup"], [class*="PropSetting"] label, [class*="PropSetting"] span')].filter(vis).map((el) => txt(el).slice(0, 30)).filter(Boolean).slice(0, 10), cases: panel() } };
    const hr = head.getBoundingClientRect();
    let box = null, group = null;
    for (let p = head.parentElement, i = 0; p && i < 4 && !box; p = p.parentElement, i++) { box = [...p.querySelectorAll('input')].find((el) => vis(el) && !/^(range|checkbox|radio|file)$/.test(el.type)) || null; if (box) group = p; }
    if (!box) box = [...document.querySelectorAll('input')].filter((el) => vis(el) && !/^(range|checkbox|radio|file)$/.test(el.type) && el.getBoundingClientRect().left > W * 0.6 && el.getBoundingClientRect().top > hr.top - 10)
      .sort((x, y) => x.getBoundingClientRect().top - y.getBoundingClientRect().top)[0] || null;
    if (!box) return { ok: false, error: 'case du volume introuvable', see: { cases: panel() } };
    if (same(box.value)) return { ok: true, value: box.value, already: true };
    const before = box.value, tried = [];
    const enter = () => { for (const type of ['keydown', 'keypress', 'keyup']) box.dispatchEvent(new KeyboardEvent(type, { bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 })); };
    const settle = async () => { enter(); box.blur(); await sleep(700); return same(box.value); };
    // 1) la valeur posée d'un bloc, comme un collage
    box.focus(); box.select && box.select();
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(box, String(db));
    box.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: String(db) }));
    box.dispatchEvent(new Event('change', { bubbles: true }));
    tried.push('collage'); if (await settle()) return { ok: true, value: box.value, how: 'collage' };
    // 2) la valeur tapée dans la case (sélection entière remplacée)
    box.focus(); box.select && box.select();
    try { document.execCommand('insertText', false, String(db)); } catch (e) { /* case en lecture seule */ }
    tried.push('frappe'); if (await settle()) return { ok: true, value: box.value, how: 'frappe' };
    // 3) le curseur du même réglage, s'il est gradué en dB
    const range = group ? [...group.querySelectorAll('input[type="range"]')][0] : null;
    if (range && Number(range.min) < 0 && want >= Number(range.min) && want <= Number(range.max)) {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(range, String(db));
      range.dispatchEvent(new Event('input', { bubbles: true })); range.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(700); tried.push('curseur'); if (same(box.value)) return { ok: true, value: box.value, how: 'curseur' };
    }
    return { ok: false, value: box.value, error: `le volume est resté à « ${box.value} » (avant : « ${before} » ; essais : ${tried.join(', ')})`, see: { cases: (group ? [...group.querySelectorAll('input')] : [box]).slice(0, 6).map(about) } };
  }
  /* Un son (vrai site, 16 novembre 2026) : panneau « Sons », onglets « Pour toi / Favoris / Illimité / Récent ».
     - Le son d'une vidéo virale n'est PAS dans la recherche (elle ne rend que des musiques du commerce) : il arrive dans « Récent » une fois la
       vidéo d'origine ouverte sur TikTok, ou il est dans « Favoris » si on l'y a mis.
     - Le bouton + pose le son à l'endroit du curseur de lecture : on remet d'abord le curseur au début (clic tout à gauche de la règle).
     opts : { tab: 'recent' | 'favorites', pick: nom du son (facultatif), orFirst: prendre le 1er de la liste si le nom n'y est pas } */
  async function tiktokSound(opts = {}) {
    const open = await tiktokRail('sounds'); if (!open.ok) return { ok: false, noPanel: true, error: open.error || 'onglet Sons introuvable' };
    const norm = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[^\p{L}\p{N}]+/gu, '');
    const box = [...document.querySelectorAll('input')].find((i) => vis(i) && /(sons|sounds)/i.test(i.placeholder || ''));
    if (box && box.value) { // une recherche restée dans la case cache les onglets
      box.focus(); Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(box, '');
      box.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
      for (const type of ['keydown', 'keypress', 'keyup']) box.dispatchEvent(new KeyboardEvent(type, { bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 }));
      box.blur(); await sleep(1200);
    }
    const tabRe = opts.tab === 'recent' ? /^(récents?|recent)$/i : /^(favoris|favorites)$/i, tabName = opts.tab === 'recent' ? 'Récent' : 'Favoris';
    let tab = null; for (let i = 0; i < 12 && !(tab = [...document.querySelectorAll('[role="tab"]')].filter(vis).find((t) => tabRe.test(txt(t))) || btnByText(tabRe)); i++) await sleep(300);
    if (!tab) return { ok: false, error: `onglet « ${tabName} » introuvable` };
    if (tab.getAttribute('aria-selected') !== 'true') click(tab);
    const rows = () => {
      const real = [...document.querySelectorAll('[class*="MusicPanelMusicItem__content"]')].filter(vis);
      if (real.length || document.querySelector('[class*="SideMenu__menuItem"]')) return real;
      const W = innerWidth; // autre interface : lignes avec une image, dans la colonne de gauche
      return [...document.querySelectorAll('div, li')].filter((el) => { if (!vis(el)) return false; const r = el.getBoundingClientRect(); return r.left < W * 0.35 && r.width > 150 && r.height > 40 && r.height < 120 && el.querySelector('img') && txt(el).length > 2; })
        .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
    };
    await sleep(900);
    for (let i = 0; i < 16 && !rows().length; i++) await sleep(400);
    const list = rows();
    if (!list.length) return { ok: false, error: `aucun son dans « ${tabName} »` };
    const title = (row) => txt(row.querySelector('[class*="infoBasicTitle"]') || row).slice(0, 80);
    let row = list[0];
    if (opts.pick) {
      const want = norm(opts.pick);
      const hit = list.find((r) => norm(title(r)) === want) || list.find((r) => norm(title(r)).includes(want) || (norm(title(r)).length > 5 && want.includes(norm(title(r)))));
      if (!hit && !opts.orFirst) return { ok: false, error: `« ${opts.pick} » absent de « ${tabName} »`, seen: list.slice(0, 5).map(title) };
      if (hit) row = hit;
    }
    // curseur de lecture au début : le son commence avec la vidéo
    const ruler = [...document.querySelectorAll('[class*="TimeRuler"] canvas')].filter(vis)[0];
    if (ruler) {
      const r = ruler.getBoundingClientRect(), x = r.left + 0.1, y = r.top + r.height / 2;
      const init = (type) => ({ bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, button: 0, buttons: /down/.test(type) ? 1 : 0, pointerId: 1, pointerType: 'mouse', isPrimary: true });
      for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) ruler.dispatchEvent(new (/^pointer/.test(t) ? PointerEvent : MouseEvent)(t, init(t)));
      await sleep(500);
    }
    const clips = () => [...document.querySelectorAll('[class*="AudioClip__root"]')].filter(vis);
    const n0 = clips().length;
    row.scrollIntoView({ block: 'center' }); await sleep(300);
    row.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
    const add = row.querySelector('[class*="operation"] button, [class*="operation"] [role="button"]') || btnByText(/^(utiliser|ajouter|use|add|\+)$/i, row) || [...row.querySelectorAll('button, [role="button"]')].filter(vis).pop();
    if (!add) return { ok: false, error: 'bouton + du son introuvable', name: title(row) };
    click(add);
    if (!document.querySelector('[class*="SideMenu__menuItem"]')) { await sleep(1500); return { ok: true, name: title(row), unsure: true }; } // autre interface : pas de piste à vérifier
    for (let i = 0; i < 30 && clips().length <= n0; i++) await sleep(300);
    if (clips().length <= n0) return { ok: false, error: 'le son n\'est pas arrivé sur la timeline', name: title(row) };
    return { ok: true, name: title(row), picked: !!opts.pick && norm(title(row)).includes(norm(opts.pick)) };
  }


  /* CapCut : exporter la vidéo. « open » clique Exporter (en haut à droite) ; « confirm » clique le bouton de la boîte d'export, puis Télécharger (une seule fois chacun) */
  /* Compte TikTok connecté : la page de TikTok Studio n'affiche pas le pseudo, on le demande à TikTok (même requête que le site). */
  async function tiktokAccount() {
    for (const u of ['/passport/web/account/info/', '/api/user/detail/self/']) {
      try {
        const r = await fetch(u, { credentials: 'include' }); if (!r.ok) continue;
        const j = await r.json(), d = j.data || j.userInfo || j;
        const name = d.username || (d.user && d.user.uniqueId) || d.unique_id || '';
        if (name) return { ok: true, username: String(name) };
      } catch (e) { /* on essaie l'autre adresse */ }
    }
    return { ok: false };
  }
  /* Export CapCut, calé sur le vrai site (novembre 2026) :
     bouton « Exporter » (en haut à droite) → ligne « Télécharger » → « Paramètres d'exportation » (déjà réglés : 1080p, haute qualité, 50 fps, MP4)
     → bouton « Exporter » → fenêtre de progression « 24.5 % » → « Exporté » + bouton « Télécharger », qui contient le lien du fichier.
     On lit ce lien et on récupère la vidéo directement : rien n'est téléchargé dans le dossier Téléchargements. Appelée en boucle par la fenêtre pilote. */
  async function capcutExport(mode) {
    const W = (window.__capExp = window.__capExp || {});
    const few = (x, y) => x.querySelectorAll('*').length - y.querySelectorAll('*').length;
    const leaf = (re, root) => [...(root || document).querySelectorAll('button, [role="button"], a, div, span, p')].filter((el) => vis(el) && re.test(txt(el))).sort(few)[0] || null;
    const header = () => [...document.querySelectorAll('button')].filter((el) => vis(el) && /^(exporter|export)$/i.test(txt(el)) && !disabled(el) && !el.closest('[class*="fake-render"], [class*="export-modal"], [class*="share_export"]')).sort((x, y) => x.getBoundingClientRect().top - y.getBoundingClientRect().top || y.getBoundingClientRect().left - x.getBoundingClientRect().left)[0] || null;
    if (mode === 'open') {
      if (W.grab) document.removeEventListener('click', W.grab, true);
      for (const k of Object.keys(W)) delete W[k];
      const b = header(); if (!b) return { ok: false, error: 'bouton Exporter introuvable' };
      click(b); W.openAt = Date.now();
      return { ok: true };
    }
    // export bloqué : « Annuler » dans la fenêtre de progression (et la confirmation éventuelle), avant de relancer
    if (mode === 'cancel') {
      const bx = [...document.querySelectorAll('[class*="share_export" i]')].filter(vis)[0];
      const c = bx && [...bx.querySelectorAll('button')].filter((el) => vis(el) && /^(annuler|cancel)$/i.test(txt(el)))[0];
      if (c) { click(c); await sleep(1200); const y = [...document.querySelectorAll('[role="dialog"] button, [class*="modal" i] button')].filter((el) => vis(el) && /^(confirmer|confirm|oui|yes|ok|arrêter|stop|annuler l.export\w*)$/i.test(txt(el)))[0]; if (y) { click(y); await sleep(800); } }
      else { const x = bx && [...bx.querySelectorAll('[class*="close" i], [aria-label*="close" i], [aria-label*="fermer" i]')].filter(vis)[0]; if (x) click(x); }
      if (W.grab) document.removeEventListener('click', W.grab, true);
      for (const k of Object.keys(W)) delete W[k];
      return { ok: true, cancelled: !!c };
    }
    // 3. la fenêtre de résultat : progression, puis « Exporté » et le lien du fichier
    const box = [...document.querySelectorAll('[class*="share_export" i]')].filter(vis)[0];
    if (box) {
      const t = txt(box), pct = (t.match(/(\d{1,3}(?:[.,]\d)?)\s?%/) || [])[1];
      if (/(échec|echec|failed|erreur|error)/i.test(t) && !/(exporté|exported)/i.test(t)) return { ok: false, error: `CapCut : ${t.slice(0, 120)}` };
      const dl = [...box.querySelectorAll('button, a')].filter((el) => vis(el) && /^(télécharger|download)$/i.test(txt(el)))[0];
      if (dl && /(exporté|exported)/i.test(t)) {
        /* Vu sur le vrai site (16 novembre 2026) : à la fin de l'export, CapCut télécharge la vidéo TOUT SEUL (cadre caché ajouté à la page) et le bouton
           « Télécharger » contient un lien vers le même fichier. On lit donc l'adresse sans cliquer : cliquer lançait un 2e téléchargement. */
        const link = () => {
          const a = box.querySelector('a[download][href^="http"], a[href*="capcut.com"][href*="origin"]'); if (a) return a.href;
          const f = [...document.querySelectorAll('iframe[src^="http"]')].find((x) => /capcut\.com\/origin\//i.test(x.src) && !vis(x)); return f ? f.src : '';
        };
        let href = link() || W.href || '';
        if (!href && !W.doneAt) W.doneAt = Date.now();
        if (!href && Date.now() - W.doneAt < 10000) return { ok: true, waiting: true, step: 'lien du fichier' }; // on laisse 10 s au lien et au téléchargement automatique avant de cliquer
        if (!href && W.dlAt && Date.now() - W.dlAt < 120000) return { ok: true, waiting: true, step: 'lien du fichier' }; // déjà cliqué : UN seul clic, le téléchargement met quelques secondes à démarrer
        if (!href) {
          /* UN clic sur « Télécharger », et le téléchargement suit son cours normal vers le dossier Téléchargements (rien n'est annulé).
             L'écouteur reste en place : si CapCut passe par un lien, on note son adresse ; si c'est une adresse blob: (vite révoquée),
             on en garde tout de suite une copie pour FruitRadar. */
          if (!W.grab) {
            W.grab = (e) => {
              const a = e.target && e.target.closest && e.target.closest('a[href]');
              if (!a || !/^(https?|blob):/.test(a.href)) return;
              W.href = a.href;
              if (/^blob:/.test(a.href) && !W.keep) W.keep = fetch(a.href).then((r) => r.blob()).then((b2) => { W.blob = b2; }).catch(() => {});
            };
            document.addEventListener('click', W.grab, true);
          }
          W.dlAt = Date.now();
          click(dl); await sleep(1500);
          href = W.href || link();
        }
        return href ? { ok: true, done: true, href } : { ok: true, waiting: true, step: 'lien du fichier' };
      }
      return { ok: true, busy: true, pct: pct ? Number(pct.replace(',', '.')) : null, step: 'export en cours' };
    }
    // 2. le panneau « Paramètres d'exportation » : son bouton « Exporter »
    const panel = [...document.querySelectorAll('[class*="export-modal" i]')].filter(vis)[0];
    const go = panel && [...panel.querySelectorAll('button')].filter((el) => vis(el) && /^(exporter|export)$/i.test(txt(el)) && !disabled(el))[0];
    if (go) { if (!W.goAt || Date.now() - W.goAt > 12000) { click(go); W.goAt = Date.now(); } return { ok: true, step: 'Exporter (paramètres)' }; }
    // 1. le menu d'export : la ligne « Télécharger »
    const row = leaf(/^(télécharger|download)$/i);
    if (row && !row.closest('[class*="compact-card"], [class*="asset"]')) { if (!W.rowAt || Date.now() - W.rowAt > 4000) { click(row); W.rowAt = Date.now(); } return { ok: true, step: 'Télécharger (menu)' }; }
    // rien d'ouvert : le menu s'est refermé, on le rouvre
    if (!W.openAt || Date.now() - W.openAt > 8000) { const b = header(); if (b) { click(b); W.openAt = Date.now(); } }
    return { ok: true, waiting: true, step: 'ouverture du menu' };
  }

  /* ---------- TurboScribe : calé sur le vrai site (novembre 2026) ----------
     - « Transcrire des fichiers » : le clic doit viser le texte du bouton (c'est lui qui écoute).
     - La page contient plusieurs fenêtres invisibles mais présentes : la bonne est la seule marquée « ouverte » qui contient un champ fichier.
     - Une ligne terminée porte une coche verte ; pendant le travail elle affiche un pourcentage.
     - « … » de la ligne s'ouvre au focus ; « Exporter la transcription » ouvre un formulaire qu'on envoie nous-mêmes pour lire le texte,
       sans rien télécharger sur le PC. */
  const spinning = (root) => [root, ...root.querySelectorAll('*')].some((el) => { if (!vis(el)) return false; const cs = getComputedStyle(el); return (cs.animationName && cs.animationName !== 'none' && cs.animationPlayState !== 'paused') || el.matches('[role="progressbar"], progress'); });
  const turboKey = (name) => base(name).toLowerCase();
  function turboRowEl(name) {
    const b = turboKey(name);
    const tr = [...document.querySelectorAll('tbody tr')].find((r) => txt(r).toLowerCase().includes(b));
    if (tr) return tr;
    // interface changée : le plus petit bloc assez large qui contient le nom et un bouton
    const leaves = [...document.querySelectorAll('body *')].filter((el) => vis(el) && el.children.length <= 2 && txt(el).toLowerCase().includes(b) && txt(el).length < b.length + 40 && !el.closest('[role="dialog"], dialog, [aria-modal="true"], [class*="modal-open"]'));
    for (const leaf of leaves) {
      let el = leaf;
      for (let i = 0; i < 8 && el && el !== document.body; i++, el = el.parentElement) {
        const r = el.getBoundingClientRect();
        if (r.width > innerWidth * 0.35 && r.height < 160 && el.querySelector('button, [role="button"]')) return el;
      }
    }
    return null;
  }
  function turboRow(name) {
    const row = turboRowEl(name);
    if (!row) return { found: false, block: detectBlock() };
    const t = txt(row), pct = (t.match(/(\d{1,3})\s?%/) || [])[1];
    const done = !!row.querySelector('svg.text-success, .text-success svg, [class*="text-success"]');
    const failed = !done && (!!row.querySelector('svg.text-error, [class*="text-error"]') || /(échec|echec|failed|erreur|error)/i.test(t));
    const a = row.querySelector('a[href*="/transcript/"]') || row.querySelector('a[href]');
    const busy = !done && !failed && (pct !== undefined || spinning(row) || /(traitement|processing|en attente|pending|queued|transcription en cours|téléversement)/i.test(t));
    return { found: true, done, failed, busy, pct: pct === undefined ? null : Number(pct), href: a ? a.href : '', row: t.slice(0, 300) };
  }
  /* La fenêtre d'envoi réellement ouverte */
  function turboModal() {
    const open = [...document.querySelectorAll('[class*="modal-open"], dialog[open], [role="dialog"], [aria-modal="true"]')].filter(vis);
    return open.find((m) => m.querySelector('input[type="file"]')) || null;
  }
  /* Ouvre « Transcrire des fichiers » et y pose la vidéo (un seul fichier, un seul dépôt) */
  async function turboUpload(ids, cfg) {
    const files = ids.map(fileOf).filter(Boolean);
    if (!files.length) return { ok: false, error: 'fichier non reçu par la page' };
    const re = new RegExp(`^${(cfg && cfg.openUpload) || '(transcrire des fichiers|transcribe files)'}$`, 'i');
    let m = turboModal(), opened = '';
    for (let i = 0; i < 4 && !m; i++) {
      const leaf = [...document.querySelectorAll('span, button, a, [role="button"]')].filter((el) => vis(el) && re.test(txt(el))).sort((x, y) => x.querySelectorAll('*').length - y.querySelectorAll('*').length)[0];
      if (leaf) { click(leaf); opened = 'bouton'; }
      await sleep(900); m = turboModal();
    }
    const inp = (m && m.querySelector('input[type="file"]')) || [...document.querySelectorAll('form input[type="file"]')].find((i) => /(audio|video)/i.test(i.getAttribute('accept') || '')) || document.querySelector('input[type="file"]');
    if (!inp) return { ok: false, error: 'champ fichier de TurboScribe introuvable' };
    const dt = new DataTransfer(); dt.items.add(files[0]);
    inp.files = dt.files;
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    for (let i = 0; i < 10 && !turboModal(); i++) await sleep(400); // poser le fichier ouvre aussi la fenêtre
    return turboModal() ? { ok: true, how: opened || 'champ fichier' } : { ok: false, error: 'la fenêtre « Transcrire des fichiers » ne s\'ouvre pas' };
  }
  const turboSubmitEl = (m) => m.querySelector('button[type="submit"], input[type="submit"]') || [...m.querySelectorAll('button, [role="button"]')].filter((b) => vis(b) && /(transcrire|transcribe)/i.test(txt(b))).pop() || null;
  function turboDialog(name) {
    const m = turboModal();
    if (!m) return { open: false };
    const t = txt(m), key = turboKey(name).slice(0, 18);
    const line = [...m.querySelectorAll('*')].filter((el) => el.children.length <= 2 && txt(el).toLowerCase().includes(key)).map(txt).sort((x, y) => x.length - y.length)[0] || '';
    const pct = (line.match(/(\d{1,3})\s?%/) || [])[1];
    const btn = turboSubmitEl(m);
    return { open: true, hasFile: !!line, uploading: pct !== undefined, pct: pct === undefined ? null : Number(pct), submit: !!btn, disabled: !!(btn && disabled(btn)), text: t.slice(0, 400) };
  }
  /* UN clic sur « Transcrire » (jamais deux : chaque envoi consomme une transcription du jour) */
  function turboSubmit() {
    const m = turboModal(); if (!m) return { ok: false, error: 'fenêtre fermée' };
    const btn = turboSubmitEl(m); if (!btn) return { ok: false, error: 'bouton « Transcrire » introuvable' };
    if (window.__frTurboSent && Date.now() - window.__frTurboSent < 20000) return { ok: true, already: true };
    window.__frTurboSent = Date.now();
    click(btn);
    return { ok: true, text: label(btn).slice(0, 40) };
  }
  /* « … » de la ligne → « Exporter la transcription » → on envoie nous-mêmes le formulaire (TXT + minutage) et on lit le fichier */
  async function turboExport(name) {
    const row = turboRowEl(name);
    if (!row) return { ok: false, error: 'ligne du fichier introuvable' };
    const itemRe = /^(exporter la transcription|export transcript)$/i;
    // le menu n'est affiché par le site que si la fenêtre est au premier plan : on cherche l'entrée même invisible, d'abord dans la ligne
    const leafOf = (root) => [...root.querySelectorAll('p, span, a, button, li, [role="menuitem"]')].filter((el) => itemRe.test(txt(el))).sort((x, y) => x.querySelectorAll('*').length - y.querySelectorAll('*').length)[0] || null;
    const findItem = () => leafOf(row) || [...document.querySelectorAll('p, span, a, button, li, [role="menuitem"]')].filter((el) => vis(el) && itemRe.test(txt(el))).sort((x, y) => x.querySelectorAll('*').length - y.querySelectorAll('*').length)[0] || null;
    const findForm = () => [...document.querySelectorAll('form[hx-post]')].find((f) => f.querySelector('input[name^="bool:txt"]')) || null;
    let form = findForm();
    if (!form) {
      const btns = [...row.querySelectorAll('button, [role="button"]')].filter(vis);
      const dots = btns.find((el) => /^(…|\.\.\.|⋯|⋮)$/.test(txt(el)) || /(plus|more|options|actions|menu)/i.test(el.getAttribute('aria-label') || '')) || btns[btns.length - 1];
      if (!dots) return { ok: false, error: 'bouton « … » de la ligne introuvable' };
      let item = null;
      for (let i = 0; i < 4 && !item; i++) { click(dots, { fakeFocus: true }); for (let w = 0; w < 10 && !item; w++) { await sleep(250); item = findItem(); } }
      if (!item) return { ok: false, error: '« Exporter la transcription » introuvable dans le menu « … »' };
      click(item, { fakeFocus: true });
      for (let w = 0; w < 32 && !form; w++) { await sleep(250); form = findForm(); }
      if (!form) return { ok: false, error: 'fenêtre d\'export introuvable' };
    }
    const p = new URLSearchParams();
    for (const el of form.querySelectorAll('input[name], select[name], textarea[name]')) {
      if (el.type === 'checkbox' || el.type === 'radio') {
        const on = /^bool:(txt|timestamps)/.test(el.name) ? true : /^bool:(pdf|docx|csv|srt|vtt)/.test(el.name) ? false : el.checked;
        if (on) p.append(el.name, el.value || 'on');
      } else if (el.type !== 'file' && el.type !== 'submit') p.append(el.name, el.value);
    }
    let href = '', text = '';
    try {
      const res = await fetch(form.getAttribute('hx-post'), { method: 'POST', body: p, credentials: 'include', headers: { 'HX-Request': 'true', 'HX-Current-URL': location.href, 'Content-Type': 'application/x-www-form-urlencoded' } });
      if (!res.ok) return { ok: false, error: `export refusé par TurboScribe (HTTP ${res.status})` };
      const doc = new DOMParser().parseFromString(await res.text(), 'text/html');
      const a = doc.querySelector('a[download][href]') || [...doc.querySelectorAll('a[href]')].find((x) => /\.txt(\?|$)/i.test(x.getAttribute('href')));
      if (!a) return { ok: false, error: 'lien du fichier exporté introuvable' };
      href = new URL(a.getAttribute('href'), location.href).href;
      try { const r2 = await fetch(href, { credentials: 'include' }); if (r2.ok) text = await r2.text(); } catch (e) { /* la fenêtre pilote le lira avec l'adresse */ }
    } catch (e) { return { ok: false, error: `export impossible (${e.message})` }; }
    const x = [...document.querySelectorAll('[class*="modal-open"] [class*="btn-circle"], [class*="modal-open"] [aria-label*="close" i], [class*="modal-open"] [aria-label*="fermer" i]')].find(vis);
    if (x) click(x);
    return { ok: text.trim().length > 10 || !!href, text: text.slice(0, 200000), href };
  }
  /* TurboScribe, page d'un fichier (/transcript/…) — relevé sur le vrai site le 18 novembre 2026 :
     chaque phrase est un <span data-start data-end> (en millisecondes), posé par le site un instant après le chargement ;
     le panneau « Exporter » porte un lien direct « Télécharger le TXT » (texte sans minutage). Aucun menu à ouvrir, aucun clic. */
  async function turboRead() {
    const pick = () => [...document.querySelectorAll('span[data-start][data-end]')].filter((s) => txt(s));
    let segs = [], calm = 0;
    for (let i = 0; i < 50 && calm < 2; i++) { const now = pick(); calm = now.length && now.length === segs.length ? calm + 1 : 0; segs = now; if (calm < 2) await sleep(400); }
    const clock = (ms) => { const s = Math.max(0, Math.floor((Number(ms) || 0) / 1000)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
    if (segs.length) return { ok: true, how: 'page', n: segs.length, text: segs.map((s) => `(${clock(s.dataset.start)} - ${clock(s.dataset.end)}) ${txt(s)}`).join('\n').slice(0, 200000) };
    const a = [...document.querySelectorAll('a[href]')].find((x) => /(t[ée]l[ée]charger|download)\W*(le\s+)?txt\b/i.test(txt(x)));
    if (a) {
      try {
        const r = await fetch(new URL(a.getAttribute('href'), location.href).href, { credentials: 'include' });
        if (r.ok) { const t = await r.text(); if (t.trim().length > 10 && !/^\s*(<!doctype|<html|%PDF)/i.test(t)) return { ok: true, how: 'txt', n: t.split('\n').filter((l) => l.trim()).length, text: t.slice(0, 200000) }; }
      } catch (e) { /* lien refusé : on le dit ci-dessous */ }
    }
    return { ok: false, error: a ? 'le fichier TXT du site est illisible' : 'aucune phrase ni lien TXT sur la page du fichier', block: detectBlock() };
  }
  function pageText(sels) {
    const el = firstVis(sels || ['[class*="transcript" i]', 'article', 'main']) || document.body;
    return { text: (el.innerText || '').slice(0, 60000) };
  }

  /* Vide la zone de saisie sur place (texte + pièces jointes), sans quitter la conversation */
  async function clearComposer(cfg) {
    const card = composerCard(cfg);
    if (!card) return { ok: false, error: 'zone de saisie introuvable' };
    const re = new RegExp(cfg.removeAttach || '(remove|supprimer|retirer|enlever|delete|effacer)', 'i');
    let removed = 0;
    for (let round = 0; round < 16; round++) {
      const b = [...card.querySelectorAll(CLICKABLE)].find((x) => vis(x) && re.test(label(x)) && !(cfg.send && x.matches(cfg.send.join(','))));
      if (!b) break;
      click(b); removed++; await sleep(450);
    }
    const el = composer(cfg);
    if (el) {
      el.focus();
      if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') { const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, ''); el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' })); }
      else if (txt(el)) { const r = document.createRange(); r.selectNodeContents(el); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); document.execCommand('delete'); }
    }
    await sleep(300);
    const left = attachedCount(cfg), textLeft = el ? txt(el).length : 0;
    return { ok: left === 0 && textLeft === 0, removed, left, textLeft };
  }
  /* ---------- Grok Imagine : calé sur le vrai site (novembre 2026) ----------
     Tout se passe sur la page Imagine (grok.com/imagine), dans SON formulaire : jamais dans une conversation, jamais sur la page d'une vidéo
     déjà faite (elle garde une boîte pré-remplie avec le même prompt : y toucher relance une génération). */
  const imaginePath = (cfg) => location.pathname.replace(/\/+$/, '') === String((cfg && cfg.imaginePath) || '/imagine').replace(/\/+$/, '') && !/\/imagine\/post\//.test(location.href);
  const grokForm = (cfg) => { const c = composer(cfg); return c ? c.closest('form') : null; };
  const ariaBtn = (root, pattern) => { const re = new RegExp(pattern, 'i'); return [...root.querySelectorAll('button[aria-label], [role="button"][aria-label]')].find((b) => vis(b) && re.test(b.getAttribute('aria-label'))) || null; };
  // images jointes : les vignettes du formulaire, hors zone de texte (« @image1 » y devient une petite pastille « Image 1 »)
  const grokImages = (form) => [...form.querySelectorAll('img')].filter((i) => vis(i) && /^(blob:|data:)/.test(i.currentSrc || i.src) && !i.closest('[contenteditable="true"]')).length;
  const grokSendBtn = (form) => form.querySelector('button[aria-label="Valider"], button[aria-label="Submit"]') || form.querySelector('button[type="submit"]');
  async function grokCheck(cfg) {
    // Compte sans Imagine : grok.com/imagine s'affiche puis renvoie au chat 2 à 3 s plus tard (vu le 27 novembre 2026) → on attend l'un ou l'autre
    for (let i = 0; i < 32 && imaginePath(cfg) && !grokForm(cfg) && !chatPage(); i++) await sleep(250);
    const form = imaginePath(cfg) ? grokForm(cfg) : null, L = (cfg && cfg.labels) || {};
    if (!form && chatPage()) { const f = chatForm(); return { ok: true, chat: true, imagine: false, path: location.pathname, chip: chatChip(), images: chatAttach(f), textLen: chatPlain().length, fired: !!window.__frFired, block: detectBlock(cfg) }; }
    if (!form) return { ok: false, path: location.pathname, imagine: imaginePath(cfg), block: detectBlock(cfg) };
    const val = (pat) => { const b = pat && ariaBtn(form, pat); return b ? txt(b) : ''; };
    const video = ariaBtn(form, '^(vid[ée]os?)$'), send = grokSendBtn(form), ed = composer(cfg);
    return { ok: true, path: location.pathname, imagine: true, video: !!video && video.getAttribute('aria-pressed') !== 'false', duration: val(L.duration), quality: val(L.quality), ratio: val(L.ratio),
      images: grokImages(form), textLen: ed ? txt(ed).length : 0, sendReady: !!send && !disabled(send), fired: !!window.__frFired, block: detectBlock(cfg) };
  }
  /* Page d'un clip Grok : à gauche, une bande de vignettes (le clip, marqué de sa durée « 0:06 », et l'image de départ). Quand c'est l'image
     qui est affichée en grand, il n'y a aucune vidéo dans la page : on clique sur la vignette du clip. Vu le 17 novembre 2026. */
  /* Grok : ton identifiant dans les adresses de ses fichiers (assets.grok.com/users/<id>/…, photo de profil, image de départ).
     Le clip d'une page /imagine/post/<clip> est alors à assets.grok.com/users/<id>/generated/<clip>/generated_video.mp4 : FruitRadar
     le télécharge à cette adresse, sans attendre que la page l'affiche (une page cachée, fenêtre réduite, n'affiche rien). */
  function grokUser() {
    const re = /assets\.grok\.com\/users\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\//i;
    for (const el of document.querySelectorAll('img, video, source, link[href]')) { const m = re.exec(el.currentSrc || el.src || el.getAttribute('src') || el.getAttribute('href') || ''); if (m) return m[1]; }
    const m = re.exec(document.documentElement.innerHTML.slice(0, 4000000));
    return m ? m[1] : '';
  }
  /* Grok, nouvelle version d'Imagine (vu le 23 novembre 2026) : après l'envoi, l'onglet reste souvent sur la page de l'IMAGE de départ
     (/imagine/post/<image>?conversation=<…>), et le clip a son propre numéro : il n'apparaît qu'en vignette (« 0:06 », en haut ou en bas
     de la bande), et une page cachée ne se met pas à jour. On demande donc à Grok la conversation Imagine de la scène : elle contient
     l'image envoyée et la vidéo générée, avec l'adresse exacte de son fichier. Rien à afficher ni à cliquer : marche onglet caché et
     fenêtre réduite. Rend { ok, cid, vids: [{ id, url, at, size, moderated }] } (vids vide tant que Grok génère). */
  async function grokClips(postId, convId) {
    const get = async (u) => { const r = await fetch(u, { credentials: 'include', cache: 'no-store' }); if (!r.ok) throw new Error(`réponse ${r.status} de Grok`); return r.json(); };
    try {
      const here = (/\/imagine\/post\/([\w-]{8,})/.exec(location.pathname) || [])[1] || '', id = String(postId || here);
      let cid = String(convId || (id === here ? new URLSearchParams(location.search).get('conversation') : '') || ''); // la conversation de l'adresse ne vaut que pour la page affichée
      if (!cid && id && !/^tmp_/.test(id)) { const a = await get(`/rest/assets/${encodeURIComponent(id)}`); cid = String((a && (a.currentConversationId || a.sourceConversationId || a.rootAssetSourceConversationId)) || ''); }
      if (!cid) return { ok: false, error: 'conversation Imagine introuvable' };
      const j = await get(`/rest/app-chat/conversations/${encodeURIComponent(cid)}/responses?conversationKind=CONVERSATION_KIND_IMAGINE`);
      const list = (j && Array.isArray(j.responses)) ? j.responses : [], vids = [];
      for (const r of list) {
        if (!r || /^human$/i.test(String(r.sender || ''))) continue; // le message envoyé porte l'image de départ, pas le clip
        const meta = Array.isArray(r.fileAttachmentAssetMetadata) ? r.fileAttachmentAssetMetadata : [];
        for (const f of Array.isArray(r.fileAttachmentsMetadata) ? r.fileAttachmentsMetadata : []) {
          if (!f || (!/^video\//i.test(f.fileMimeType || '') && !/\.mp4$/i.test(f.fileName || ''))) continue;
          const m = meta.find((x) => x && x.assetId === f.fileMetadataId) || {};
          const k = String(f.fileUri || m.key || '').replace(/^\/+/, '');
          if (!k) continue;
          vids.push({ id: String(f.fileMetadataId || m.assetId || ''), url: /^https?:\/\//i.test(k) ? k : `https://assets.grok.com/${k}`, at: Date.parse(f.createTime || m.createTime || r.createTime || '') || 0, size: Number(m.sizeBytes) || 0, moderated: String((m.auxKeys || {}).moderated || '') === 'true' });
        }
      }
      return { ok: true, cid, n: list.length, vids };
    } catch (e) { return { ok: false, error: String((e && e.message) || e).slice(0, 160) }; }
  }
  async function grokShowVideo(index = 0) {
    const big = [...document.querySelectorAll('video')].filter((v) => vis(v) && v.getBoundingClientRect().height > 240 && /\.mp4(\?|#|$)/i.test(v.currentSrc || v.src || ''));
    if (big.length) return { ok: true, already: true };
    // étiquettes de durée : un petit texte « 0:06 », « 0:15 »… posé sur une vignette
    // jamais dans le menu de gauche ni sur un lien vers une autre publication : on ne quitte pas la page de ce clip
    const elsewhere = (el) => { if (el.closest('nav, aside, [data-sidebar], [class*="sidebar" i]')) return true; const a = el.closest('a[href]'); return !!(a && /\/imagine\/post\//.test(a.getAttribute('href') || '') && !(a.getAttribute('href') || '').includes(location.pathname.split('/').pop())); };
    const labels = [...document.querySelectorAll('span, div, p, small, time')].filter((el) => vis(el) && !el.children.length && /^\d{1,2}:\d{2}$/.test(txt(el)) && !elsewhere(el));
    const thumbs = [];
    for (const lab of labels) {
      let box = lab;
      for (let i = 0; i < 6 && box.parentElement; i++) { // on remonte jusqu'au cadre de la vignette (un petit carré cliquable)
        box = box.parentElement; const r = box.getBoundingClientRect();
        if (r.width >= 40 && r.width <= 220 && r.height >= 40 && r.height <= 260 && (box.querySelector('img, video, canvas') || /^(button|a)$/i.test(box.tagName) || box.getAttribute('role') === 'button')) break;
      }
      const r = box.getBoundingClientRect();
      if (r.width >= 40 && r.width <= 220 && r.height >= 40 && r.height <= 260 && !thumbs.includes(box)) thumbs.push(box);
    }
    if (!thumbs.length) return { ok: false, n: 0 };
    const el = thumbs[Math.min(index, thumbs.length - 1)];
    await tkPress(el.closest('button, a, [role="button"]') || el.querySelector('img, video') || el);
    for (let i = 0; i < 12; i++) { await sleep(400); if ([...document.querySelectorAll('video')].some((v) => vis(v) && v.getBoundingClientRect().height > 240)) return { ok: true, clicked: true, n: thumbs.length }; }
    click(el.querySelector('img, video') || el); await sleep(900); // deuxième essai, clic simple
    return { ok: [...document.querySelectorAll('video')].some((v) => vis(v) && v.getBoundingClientRect().height > 240), clicked: true, n: thumbs.length };
  }
  /* Prépare UNE scène : mode Vidéo, qualité, durée, format, image de départ, prompt. N'envoie rien. */
  async function grokPrepare(cfg, o) {
    if (!imaginePath(cfg)) return { ok: false, wrongPage: true, error: `ce n'est pas la page Imagine (${location.pathname})` };
    const form = grokForm(cfg);
    if (!form) return { ok: false, error: 'boîte de prompt d\'Imagine introuvable' };
    const notes = [], miss = [], L = cfg.labels || {};
    if (grokImages(form) > 0) return { ok: false, dirty: true, error: 'la page contient déjà une image jointe (reste d\'une scène précédente)' };
    // 1. mode Vidéo
    const video = ariaBtn(form, '^(vid[ée]os?)$');
    if (video && video.getAttribute('aria-pressed') === 'false') { click(video); for (let i = 0; i < 10; i++) { await sleep(100); const vv = ariaBtn(form, '^(vid[ée]os?)$'); if (vv && vv.getAttribute('aria-pressed') !== 'false') break; } await sleep(150); }
    const v2 = ariaBtn(form, '^(vid[ée]os?)$');
    if (v2 && v2.getAttribute('aria-pressed') === 'false') return { ok: false, error: 'le mode Vidéo d\'Imagine ne s\'active pas' };
    if (!v2) notes.push('bouton Vidéo non trouvé');
    // 2. réglages, AVANT l'image (ensuite « Proportions » disparaît : le format suit l'image, envoyée en 9:16)
    const set = async (trig, want, lab, name) => {
      if (!want) return '';
      const r = await ensureOption(trig, want, { ...cfg, labelNow: lab || '' });
      if (r && r.ok) return r.value || name;
      miss.push(`${name}${r && r.error ? ` (${r.error})` : r && r.notFound ? ' (réglage introuvable)' : ''}`);
      return (r && r.value) || '';
    };
    const q = o.quality ? await set(cfg.qTrig, o.quality, L.quality, 'qualité') : '';
    const d = await set(cfg.dTrig, o.duration, L.duration, `durée ${o.duree} s`);
    const rr = ariaBtn(form, L.ratio || 'proportions') ? await set(cfg.rTrig, cfg.ratioOption, L.ratio, 'format 9:16') : '9:16 (format de l\'image)';
    // 3. l'image de la scène : champ fichier du formulaire d'Imagine, un seul dépôt
    const file = fileOf(o.fileId);
    if (!file) return { ok: false, error: 'image de départ non reçue par la page' };
    const inp = form.querySelector('input[type="file"][name="files"]') || form.querySelector('input[type="file"]');
    if (!inp) return { ok: false, error: 'champ image d\'Imagine introuvable' };
    const dt = new DataTransfer(); dt.items.add(file);
    inp.files = dt.files;
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    let n = 0;
    for (let i = 0; i < 40 && !(n = grokImages(form)); i++) await sleep(300);
    if (!n) return { ok: false, error: 'l\'image de départ n\'apparaît pas dans la boîte d\'Imagine' };
    if (n > 1) return { ok: false, dirty: true, error: `${n} images sont jointes au lieu d'une` };
    for (let i = 0; i < 60; i++) { const b = grokSendBtn(form); if (b && !disabled(b)) break; await sleep(200); } // fin du téléversement de l'image
    await sleep(300);
    if (!imaginePath(cfg)) return { ok: false, started: true, error: 'Grok a quitté la page Imagine dès l\'ajout de l\'image (génération automatique ?)' };
    // 4. le prompt vidéo de la scène
    const t = await setText(o.text, cfg);
    if (!t || !t.ok) return { ok: false, error: 'prompt impossible à saisir dans la boîte d\'Imagine' };
    await sleep(250);
    const ed = composer(cfg), len = ed ? txt(ed).length : 0;
    if (len < Math.min(40, o.text.length * 0.5)) return { ok: false, error: 'le prompt n\'est pas entré en entier dans la boîte d\'Imagine' };
    // 5. relecture : la durée affichée doit être la bonne (un clip de 6 s au lieu de 10 ne se rattrape pas)
    const readD = () => { const b = L.duration && ariaBtn(grokForm(cfg) || form, L.duration); return b ? txt(b) : d; };
    let dNow = readD();
    if (dNow && o.duration && !new RegExp(o.duration, 'i').test(dNow)) {
      // la durée n'est pas (ou plus) la bonne : réglage non pris, ou remis par Grok à l'ajout de l'image ou par un autre onglet Grok.
      // On la remet maintenant, image et prompt en place ; l'envoi la relira encore une fois juste avant de cliquer.
      const r2 = await ensureOption(cfg.dTrig, o.duration, { ...cfg, labelNow: L.duration || '' });
      await sleep(250); dNow = readD();
      if (!new RegExp(o.duration, 'i').test(dNow)) return { ok: false, error: `la durée affichée est « ${dNow} » au lieu de ${o.duree} s${r2 && r2.error ? ` (${r2.error})` : ''}` };
      const mi = miss.findIndex((m) => /^durée/.test(m)); if (mi >= 0) miss.splice(mi, 1);
      notes.push('durée remise juste avant l\'envoi');
    }
    return { ok: true, quality: q, duration: dNow || d, ratio: rr, images: n, textLen: len, notes, miss };
  }
  /* L'envoi : une seule fois par page, seulement depuis Imagine, seulement si l'image ET le prompt sont en place */
  async function grokFire(cfg, o) {
    if (window.__frFired) return { ok: false, already: true, error: 'cette page a déjà envoyé sa scène' };
    if (!imaginePath(cfg)) return { ok: false, wrongPage: true, error: `ce n'est pas la page Imagine (${location.pathname})` };
    // Dernier contrôle, juste avant le clic : la durée affichée. Mauvaise, on la remet ; si elle ne tient pas, on n'envoie pas
    // (un clip de la mauvaise durée, c'est une génération perdue).
    const L = cfg.labels || {};
    if (o && o.duration && L.duration) {
      const readD = () => { const f = grokForm(cfg), b = f && ariaBtn(f, L.duration); return b ? txt(b) : ''; };
      const good = (v) => !v || new RegExp(o.duration, 'i').test(v);
      let dv = readD();
      if (!good(dv)) { await ensureOption(cfg.dTrig, o.duration, { ...cfg, labelNow: L.duration }); await sleep(200); dv = readD(); }
      if (!good(dv)) return { ok: false, error: `la durée affichée est « ${dv} » au lieu de ${o.duree} s` };
      if (window.__frFired) return { ok: false, already: true, error: 'cette page a déjà envoyé sa scène' };
    }
    const form = grokForm(cfg), ed = composer(cfg);
    if (!form || !ed) return { ok: false, error: 'boîte de prompt d\'Imagine introuvable' };
    const n = grokImages(form), len = txt(ed).length;
    if (n !== 1) return { ok: false, error: `${n} image(s) jointe(s) au lieu d'une` };
    if (len < Math.min(40, ((o && o.textLen) || 80) * 0.5)) return { ok: false, error: 'le prompt a disparu de la boîte' };
    const btn = grokSendBtn(form);
    if (!btn || disabled(btn)) return { ok: false, error: 'flèche d\'envoi indisponible' };
    window.__frFired = Date.now();
    clickOnce(btn);
    return { ok: true };
  }
  /* ---------- Grok sans la page Imagine (vu le 27 novembre 2026 sur un compte Premium) ----------
     Sur certains comptes, grok.com/imagine renvoie au chat : la vidéo s'y fait avec la commande « /video » (une pastille « Video » dans
     la boîte), les réglages par le bouton « Video options » (menus Aspect ratio · Resolution · Duration, valeurs en role=menuitemradio),
     l'image par le champ fichier du formulaire, l'envoi par la flèche « Envoyer ». Le clip arrive dans la réponse de Grok, dans la
     conversation /c/<id> : on lit cette conversation (comme celle d'Imagine), rien à afficher ni à cliquer. */
  const chatEd = () => [...document.querySelectorAll('form [role="textbox"][contenteditable="true"], form .ProseMirror[contenteditable="true"]')].find(vis) || null;
  const chatForm = () => { const e = chatEd(); return e ? e.closest('form') : null; };
  const chatPage = () => !/^\/(imagine|bots?)(\/|$)/.test(location.pathname) && !!chatForm(); // la page d'un Bot a aussi une boîte de chat : ce n'est pas le chat
  const chatChip = () => { const e = chatEd(), c = e && e.querySelector('[data-composer-chip]'); return c ? txt(c) : ''; };
  const chatPlain = () => { const e = chatEd(); if (!e) return ''; const c = e.cloneNode(true); c.querySelectorAll('[contenteditable="false"]').forEach((x) => x.remove()); return txt(c); }; // le texte tapé, sans la pastille ni l'aide grisée
  const chatAttach = (form) => (form ? [...form.querySelectorAll('button[aria-label]')].filter((b) => vis(b) && /^(supprimer|remove|retirer|delete)\b/i.test(b.getAttribute('aria-label'))).length : 0); // un bouton « Supprimer <fichier> » par pièce jointe
  const chatThumbReady = (form) => !!form && [...form.querySelectorAll('img')].some((i) => vis(i) && /^https:/.test(i.currentSrc || i.src || '') && !i.closest('[contenteditable="true"]'));
  const chatOptBtn = (form) => (form ? [...form.querySelectorAll('button[aria-label]')].find((b) => vis(b) && /(video|vid[ée]o)\s*options|options\s*(de la |vid[ée]o|video)/i.test(b.getAttribute('aria-label'))) : null);
  const chatSendBtn = (form) => (form ? form.querySelector('button[aria-label="Envoyer"], button[aria-label="Send"], button[aria-label="Submit"], button[aria-label="Valider"]') || form.querySelector('button[type="submit"]') : null);
  const isVideoChip = (t) => /^vid[ée]os?$/i.test(String(t || '').trim());
  const caretEnd = (el) => { el.focus(); const r = document.createRange(); r.selectNodeContents(el); r.collapse(false); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); };
  const chatMenus = () => [...document.querySelectorAll('[role="menu"]')].filter(vis);
  const OPT_ROW = /(aspect|ratio|format|proportion|resolution|résolution|qualit|duration|durée)/i;
  const isOptMenu = (m) => [...m.querySelectorAll('[role="menuitem"]')].some((r) => OPT_ROW.test(txt(r)));
  const chatRoot = () => chatMenus().find(isOptMenu) || null;
  /* 4.9.27 (erreur « la durée affichée est « ? » » chez l'auteur, alors que le menu marchait au même moment dans un onglet affiché) :
     le menu peut être ouvert (data-open) sans être encore placé à l'écran, quand la fenêtre de Chrome est réduite ou cachée. On le lit quand même. */
  const chatRootAny = () => [...document.querySelectorAll('[role="menu"]')].find((m) => (vis(m) || m.hasAttribute('data-open')) && isOptMenu(m)) || null;
  async function chatMenuClose() { for (let i = 0; i < 4 && chatMenus().length; i++) { const m = chatMenus().pop(); m.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true })); await sleep(150); } { const h = chatRootAny(); if (h && !vis(h)) { h.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true })); await sleep(150); } } return !chatMenus().length; }
  async function chatMenuOpen(form) {
    if (chatRoot()) return chatRoot();
    const b = chatOptBtn(form); if (!b) return null;
    const ways = [ // comme une souris, puis un clic simple, puis le clavier (flèche bas : ouvre un menu sans souris)
      () => tkPress(b),
      async () => { try { b.focus({ preventScroll: true }); } catch (e) {} b.click(); },
      async () => { try { b.focus({ preventScroll: true }); } catch (e) {} for (const t of ['keydown', 'keyup']) b.dispatchEvent(new KeyboardEvent(t, { key: 'ArrowDown', code: 'ArrowDown', keyCode: 40, which: 40, bubbles: true, cancelable: true })); },
    ];
    for (const go of ways) {
      if (chatRoot() || chatRootAny()) break;
      await go();
      for (let i = 0; i < 40 && !chatRoot() && !(i >= 10 && chatRootAny()); i++) await sleep(100);
    }
    for (let i = 0; i < 20 && !chatRoot() && chatRootAny(); i++) await sleep(100); // ouvert mais pas encore placé : encore 2 s
    return chatRoot() || chatRootAny();
  }
  /* Les trois réglages tels que Grok les affiche : { ratio: '9:16', res: '1080p', dur: '6s' } ('' si la ligne manque) */
  async function chatReadOpts(form) {
    const m = await chatMenuOpen(form); const rows = m ? [...m.querySelectorAll('[role="menuitem"]')].map(txt) : []; await chatMenuClose();
    const val = (re) => { const r = rows.find((x) => re.test(x)); return r ? r.replace(re, '').trim() : ''; };
    return { menu: !!m, rows, ratio: val(/^(aspect ratio|aspect|ratio|format|proportions?)\s*/i), res: val(/^(resolution|résolution|qualité|quality)\s*/i), dur: val(/^(duration|durée)\s*/i) };
  }
  /* Durée pas confirmée : la raison exacte (menu fermé, ligne absente, mauvaise valeur), plus « ? » (relevé le 28/11/2026). */
  const durWhy = (opts, d) => (!opts.menu ? { nomenu: true, dirty: true, error: 'le menu « Video options » de Grok ne s\'ouvre pas : durée, format et qualité impossibles à régler (fenêtre de Chrome réduite ou cachée ?)' }
    : !opts.rows.some((r) => /^(duration|durée)/i.test(r)) ? { nodur: true, error: `le menu « Video options » de Grok n'a pas de ligne « Duration » (lu : ${opts.rows.join(' · ').slice(0, 120) || 'rien'})` }
    : !opts.dur ? { error: 'la ligne « Duration » du menu « Video options » de Grok ne montre pas sa valeur, et les réglages enregistrés par Grok ne confirment pas la durée' }
    : { error: `la durée affichée est « ${opts.dur} » au lieu de ${d} s` });
  async function chatSetOpt(form, rowRe, valRe) {
    const m = await chatMenuOpen(form); if (!m) return { ok: false, error: 'menu « Video options » introuvable' };
    const row = [...m.querySelectorAll('[role="menuitem"]')].find((r) => rowRe.test(txt(r)));
    if (!row) { await chatMenuClose(); return { ok: false, error: 'réglage absent du menu' }; }
    await tkPress(row); // ouvre la liste des valeurs
    let opt = null; for (let i = 0; i < 30 && !opt; i++) { await sleep(100); const all = [...document.querySelectorAll('[role="menuitemradio"]')].filter((o) => valRe.test(txt(o))); opt = all.find(vis) || (i >= 12 ? all.find((o) => o.isConnected) : null) || null; } // fenêtre cachée : la valeur est là sans être placée
    if (!opt) { await chatMenuClose(); return { ok: false, error: 'valeur absente du menu' }; }
    if (opt.getAttribute('aria-checked') !== 'true') { await tkPress(opt); await sleep(300); }
    const checked = opt.isConnected ? opt.getAttribute('aria-checked') === 'true' : null; // null : la liste s'est refermée toute seule
    await chatMenuClose();
    return { ok: true, checked };
  }
  /* Les réglages vidéo du chat, tels que Grok les enregistre dans ce navigateur dès qu'une valeur est choisie dans le menu
     (localStorage « video-skill-settings » = { aspectRatio: '9:16', resolution: '480p', duration: 10 }, relevé le 28/11/2026).
     Sert de seconde preuve quand le menu se règle mais ne se relit pas (erreur « la durée affichée est « ? » » chez l'auteur). */
  const chatSaved = () => { try { const v = JSON.parse(localStorage.getItem('video-skill-settings') || 'null'); return v && typeof v === 'object' ? v : null; } catch (e) { return null; } };
  const savedDurOk = (pick, d) => { const v = chatSaved(); return !!(pick && pick.ok && pick.checked !== false && v && Number(v.duration) === Number(d)); };
  const RATIO_ROW = /^(aspect ratio|aspect|ratio|format|proportions?)/i, RES_ROW = /^(resolution|résolution|qualité|quality)/i, DUR_ROW = /^(duration|durée)/i;
  const durRe = (d) => new RegExp(`^${Number(d)}\\s*s(ec(ondes?)?)?$`, 'i'), resRe = (q) => new RegExp(`^${String(q).replace(/p$/i, '')}\\s*p$`, 'i');
  /* Prépare UNE scène dans le chat : pastille Video, 9:16, qualité, durée, image de départ, prompt. N'envoie rien.
     o = { fileId, text, duree: 6 | 10 | 15, res: '1080p' | '720p' | '' } */
  async function grokChatPrepare(cfg, o) {
    if (!chatPage()) return { ok: false, wrongPage: true, error: `ce n'est pas le chat de Grok (${location.pathname})` };
    if (/^\/c\//.test(location.pathname)) return { ok: false, dirty: true, error: 'la page est une conversation déjà commencée' };
    let form = chatForm(); const ed = chatEd(), notes = [], miss = [];
    if (chatAttach(form) > 0 || chatPlain()) return { ok: false, dirty: true, error: 'la boîte de Grok n\'est pas vide (reste d\'une scène précédente)' };
    // 1. la pastille « Video » : comme à la main, « /video » puis Entrée (Entrée prend la proposition « Video » de la liste ouverte)
    if (!isVideoChip(chatChip())) {
      caretEnd(ed); await sleep(150);
      document.execCommand('insertText', false, '/video');
      const vidOpt = () => [...document.querySelectorAll('[role="listbox"] [role="option"], [role="option"]')].find((x) => vis(x) && !ed.contains(x) && /^vid[ée]os?\b/i.test(txt(x))) || null;
      let opt = null; for (let i = 0; i < 30 && !opt; i++) { await sleep(100); opt = vidOpt(); }
      if (!opt) return { ok: false, dirty: true, error: 'la commande /video de Grok ne propose pas « Video »' };
      // Entrée SEULEMENT liste ouverte, « Video » en tête (ou en surbrillance) et rien d'autre que /video dans la boîte : sans la liste, Entrée enverrait le message
      const list = opt.closest('[role="listbox"]'), first = list ? [...list.querySelectorAll('[role="option"]')].find(vis) : null;
      if ((first === opt || opt.getAttribute('aria-selected') === 'true') && /^\/vid[ée]os?$/i.test(chatPlain())) {
        const e = chatEd(), k = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true, composed: true };
        e.focus(); e.dispatchEvent(new KeyboardEvent('keydown', k)); await sleep(60); e.dispatchEvent(new KeyboardEvent('keyup', k));
        for (let i = 0; i < 15 && !isVideoChip(chatChip()); i++) await sleep(100);
        if (isVideoChip(chatChip())) notes.push('/video + Entrée');
      }
      if (!isVideoChip(chatChip()) && vidOpt()) { await tkPress(vidOpt()); notes.push('/video + clic'); } // secours : la proposition cliquée
      for (let i = 0; i < 20 && !isVideoChip(chatChip()); i++) await sleep(100);
      if (!isVideoChip(chatChip())) return { ok: false, dirty: true, error: 'le mode Vidéo de Grok ne s\'active pas avec /video' };
      if (chatPlain()) return { ok: false, dirty: true, error: `il reste du texte après /video (« ${chatPlain().slice(0, 30)} »)` };
    }
    // 2. réglages : 9:16, qualité, durée (relus ensuite)
    form = chatForm();
    const want = [['format 9:16', RATIO_ROW, /^9\s*[:/]\s*16$/], o.res ? [`qualité ${o.res}`, RES_ROW, resRe(o.res)] : null, [`durée ${o.duree} s`, DUR_ROW, durRe(o.duree)]].filter(Boolean);
    let durPick = null, noMenu = false;
    for (const [name, rre, vre] of want) {
      if (noMenu) { miss.push(`${name} (menu « Video options » introuvable)`); continue; } // le menu ne s'ouvre pas : inutile de réessayer trois fois (≈ 12 s chacune)
      const r = await chatSetOpt(form, rre, vre); if (rre === DUR_ROW) durPick = r;
      if (!r.ok) { miss.push(`${name} (${r.error})`); if (/introuvable/.test(r.error)) noMenu = true; }
    }
    if (noMenu) return { ok: false, ...durWhy({ menu: false, rows: [], dur: '' }, o.duree) };
    let opts = await chatReadOpts(form);
    if (!durRe(o.duree).test(opts.dur)) { durPick = await chatSetOpt(form, DUR_ROW, durRe(o.duree)); opts = await chatReadOpts(form); }
    if (!durRe(o.duree).test(opts.dur)) {
      if (!opts.dur && savedDurOk(durPick, o.duree)) { opts.dur = `${o.duree}s`; notes.push('durée choisie dans le menu et confirmée par les réglages enregistrés de Grok (menu impossible à relire)'); }
      else return { ok: false, ...durWhy(opts, o.duree) };
    }
    window.__frDurPick = { d: Number(o.duree), pick: durPick };
    // 3. l'image de la scène : le champ fichier du formulaire, un seul dépôt
    const file = fileOf(o.fileId);
    if (!file) return { ok: false, error: 'image de départ non reçue par la page' };
    const inp = form.querySelector('input[type="file"]') || document.querySelector('input[type="file"]');
    if (!inp) return { ok: false, error: 'champ image du chat de Grok introuvable' };
    const dt = new DataTransfer(); dt.items.add(file); inp.files = dt.files; inp.dispatchEvent(new Event('change', { bubbles: true }));
    let n = 0; for (let i = 0; i < 60 && !(n = chatAttach(chatForm())); i++) await sleep(250);
    if (!n) return { ok: false, error: 'l\'image de départ n\'apparaît pas dans la boîte de Grok' };
    if (n > 1) return { ok: false, dirty: true, error: `${n} images sont jointes au lieu d'une` };
    for (let i = 0; i < 120 && !chatThumbReady(chatForm()); i++) await sleep(250); // fin du téléversement : la vignette prend son adresse définitive
    if (!chatThumbReady(chatForm())) notes.push('téléversement de l\'image non confirmé');
    if (!isVideoChip(chatChip())) return { ok: false, dirty: true, error: 'la pastille Video a disparu à l\'ajout de l\'image' };
    // 4. le prompt vidéo, collé APRÈS la pastille (jamais à sa place)
    const pasteEnd = async (how) => {
      const e = chatEd(); caretEnd(e); await sleep(150);
      if (how === 'paste') { const d2 = new DataTransfer(); d2.setData('text/plain', o.text); e.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: d2 })); }
      else document.execCommand('insertText', false, o.text);
      await sleep(400);
    };
    const enough = () => chatPlain().length >= Math.min(40, o.text.trim().length * 0.5);
    await pasteEnd('paste'); if (!chatPlain()) await pasteEnd('exec');
    if (!enough()) return { ok: false, dirty: true, error: 'le prompt n\'est pas entré en entier dans la boîte de Grok' };
    if (!isVideoChip(chatChip())) return { ok: false, dirty: true, error: 'la pastille Video a disparu en collant le prompt' };
    return { ok: true, chat: true, quality: opts.res, duration: opts.dur, ratio: opts.ratio, images: chatAttach(chatForm()), textLen: chatPlain().length, notes, miss };
  }
  /* L'envoi dans le chat : une seule fois par page, seulement si pastille, image, prompt et durée sont en place. */
  async function grokChatFire(cfg, o) {
    if (window.__frFired) return { ok: false, already: true, error: 'cette page a déjà envoyé sa scène' };
    if (!chatPage() || /^\/c\//.test(location.pathname)) return { ok: false, wrongPage: true, error: `ce n'est pas un chat neuf de Grok (${location.pathname})` };
    let form = chatForm();
    if (!isVideoChip(chatChip())) return { ok: false, error: 'la pastille Video n\'est plus dans la boîte' };
    if (o && o.duree) { // dernier contrôle de la durée : un clip de la mauvaise durée est une génération perdue
      let opts = await chatReadOpts(form), pick = window.__frDurPick && window.__frDurPick.d === Number(o.duree) ? window.__frDurPick.pick : null;
      if (!durRe(o.duree).test(opts.dur) && opts.menu) { const r = await chatSetOpt(form, DUR_ROW, durRe(o.duree)); if (r.ok) pick = r; opts = await chatReadOpts(form); }
      if (!durRe(o.duree).test(opts.dur) && !(!opts.dur && savedDurOk(pick, o.duree))) { const w = durWhy(opts, o.duree); return { ok: false, nomenu: !!w.nomenu, nodur: !!w.nodur, error: w.error }; }
    }
    form = chatForm();
    const n = chatAttach(form), len = chatPlain().length;
    if (n !== 1) return { ok: false, error: `${n} image(s) jointe(s) au lieu d'une` };
    if (len < Math.min(40, ((o && o.textLen) || 80) * 0.5)) return { ok: false, error: 'le prompt a disparu de la boîte' };
    const btn = chatSendBtn(form);
    if (!btn || disabled(btn)) return { ok: false, error: 'flèche d\'envoi indisponible' };
    if (window.__frFired) return { ok: false, already: true, error: 'cette page a déjà envoyé sa scène' };
    window.__frFired = Date.now();
    const gone = () => /^\/c\//.test(location.pathname) || !chatPlain() || !chatAttach(chatForm());
    clickOnce(btn); // le clic du bouton, sans le double envoi du formulaire
    for (let i = 0; i < 12 && !gone(); i++) await sleep(250); // dans le chat (vu le 27 novembre 2026), c'est le formulaire qui envoie : rien ne part ici, on passe à l'envoi du formulaire
    if (gone()) return { ok: true, how: 'clic' };
    const b2 = chatSendBtn(chatForm()); // rien n'est parti : ce chat envoie par le formulaire, on laisse passer UN envoi
    if (b2 && !disabled(b2)) { click(b2); for (let i = 0; i < 16 && !gone(); i++) await sleep(250); }
    return gone() ? { ok: true, how: 'formulaire' } : { ok: false, unsure: true, error: 'le clic d\'envoi n\'a rien changé dans la boîte' };
  }
  /* Le clip, lu dans la conversation de la scène (/rest/app-chat/conversations/<id>/responses). On prend toute adresse de fichier .mp4 des
     réponses de Grok (pièces jointes, cartes de génération), où qu'elle soit rangée. Rend { ok, cid, vids: [{ url, at, moderated }],
     pending, done, cards, progress, moderated, message } ; vids vide tant que Grok génère. */
  async function grokChatClips(convId) {
    const get = async (u) => { const r = await fetch(u, { credentials: 'include', cache: 'no-store' }); if (!r.ok) throw new Error(`réponse ${r.status} de Grok`); return r.json(); };
    try {
      const cid = String(convId || (/^\/c\/([\w-]{8,})/.exec(location.pathname) || [])[1] || '');
      if (!cid) return { ok: false, error: 'conversation de la scène introuvable' };
      const j = await get(`/rest/app-chat/conversations/${encodeURIComponent(cid)}/responses`);
      const list = Array.isArray(j && j.responses) ? j.responses : [];
      const vids = [], seen = new Set(), ids = new Set(); let pending = false, done = false, cards = 0, progress = null, moderated = false, message = '', toolText = false, streamErr = '';
      const add = (u, at) => { let k = String(u || '').trim().replace(/^\/+/, ''); if (!/\.mp4(\?|#|$)/i.test(k)) return; if (/^users\//i.test(k)) k = `https://assets.grok.com/${k}`; if (!/^https:\/\//i.test(k) || seen.has(k)) return; seen.add(k); vids.push({ url: k, at, moderated: false }); };
      const walk = (v, at, depth) => {
        if (depth > 14 || v == null) return;
        if (typeof v === 'string') {
          const t = v.trim();
          if (/^[[{]/.test(t) && /(mp4|video|vid[ée]o)/i.test(t)) { try { walk(JSON.parse(t), at, depth + 1); return; } catch (e) { /* pas du JSON */ } }
          (t.match(/(https:\/\/[^\s"'<>]+?\.mp4|users\/[\w./-]+?\.mp4)/gi) || []).forEach((u) => add(u, at));
          return;
        }
        if (Array.isArray(v)) { v.forEach((x) => walk(x, at, depth + 1)); return; }
        if (typeof v === 'object') {
          const videoish = Object.keys(v).some((k) => /video/i.test(k)) || /video/i.test(String(v.cardType || v.type || ''));
          for (const [k, x] of Object.entries(v)) {
            if (videoish && /progress/i.test(k) && typeof x === 'number') progress = Math.max(progress || 0, x);
            if (/moderat/i.test(k) && (x === true || x === 'true')) moderated = true;
            if (/video.*(id|uuid)$/i.test(k) && typeof x === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x)) ids.add(x);
            walk(x, at, depth + 1);
          }
        }
      };
      for (const r of list) {
        if (!r || /^human$/i.test(String(r.sender || ''))) continue; // le message envoyé porte l'image de départ, pas le clip
        const at = Date.parse(r.createTime || '') || 0;
        if (r.partial) pending = true; else done = true;
        cards += Array.isArray(r.cardAttachmentsJson) ? r.cardAttachmentsJson.length : 0;
        if (r.message) message = String(r.message).slice(0, 400);
        // Vu le 27 novembre 2026 (scène 8) : Grok écrit parfois sa commande vidéo comme du texte (« create_video … ») au lieu de la lancer :
        // « Some content couldn't be rendered », aucune génération ne part. Les réponses qui marchent ne contiennent jamais ce mot.
        if (!r.partial && /create_?video/i.test(String(r.message || ''))) toolText = true;
        { const se = r.error || r.errorMessage || (Array.isArray(r.streamErrors) && r.streamErrors[0]); if (se && !streamErr) streamErr = String(typeof se === 'string' ? se : (se.message || JSON.stringify(se))).replace(/\s+/g, ' ').slice(0, 160); }
        walk(r, at, 0);
      }
      if (!vids.length && ids.size) { const uid = grokUser(); if (uid) for (const id of ids) add(`users/${uid}/generated/${id}/generated_video.mp4`, 0); } // seulement le numéro du clip : son adresse habituelle
      if (moderated) vids.forEach((v) => { v.moderated = true; });
      return { ok: true, cid, n: list.length, vids, pending, done, cards, progress, moderated, message, toolText, streamErr };
    } catch (e) { return { ok: false, error: String((e && e.message) || e).slice(0, 160) }; }
  }
  /* ---------- Grok Bot (grok.com/bot/<id>), depuis la 4.9.26 ----------
     Relevé sur le vrai site le 28 novembre 2026 : la page d'un Bot est UN fil (tout ce qui a été dit à ce Bot, tous onglets confondus :
     deux onglets ouverts sur le même Bot montrent le même fil). Chaque ligne du fil porte data-plane-row = t<N>ua<k> (pièce jointe du
     message n° N), t<N>u (le message envoyé) ou t<N>s<k> (réponse du Bot). Un clip est un bouton « nom.mp4 » qui contient une <video>
     (adresse blob:, 720 × 1264, 6 s au test). La boîte d'envoi est un formulaire : éditeur tiptap, champ fichier, bouton data-testid="chat-submit". */
  const botPath = () => /^\/bots?\/[\w-]{6,}/.test(location.pathname);
  const botEd = () => [...document.querySelectorAll('form .tiptap.ProseMirror[contenteditable="true"], form .ProseMirror[contenteditable="true"], form [role="textbox"][contenteditable="true"]')].find(vis) || null;
  const botForm = () => { const e = botEd(); return e ? e.closest('form') : null; };
  const botPlain = () => { const e = botEd(); return e ? txt(e) : ''; };
  const botThumbs = (f) => (f ? [...f.querySelectorAll('img')].filter((i) => vis(i) && !i.closest('[contenteditable="true"]')) : []);
  const botUploaded = (f) => botThumbs(f).some((i) => /^https:\/\//.test(i.currentSrc || i.src)); // téléversement fini : la vignette passe de data:/blob: à son adresse définitive
  const BOT_ROW = /^t(\d+)(ua\d+|u|s\d+)$/;
  const botRowList = () => [...document.querySelectorAll('[data-plane-row]')].map((el) => { const m = BOT_ROW.exec(el.getAttribute('data-plane-row') || ''); return m ? { el, id: m[0], turn: Number(m[1]), kind: m[2] === 'u' ? 'u' : (m[2][0] === 's' ? 's' : 'a') } : null; }).filter(Boolean);
  const botLastTurn = () => botRowList().reduce((m, r) => Math.max(m, r.turn), 0);
  const botScroller = () => document.querySelector('[data-testid="bot-transcript-scroller"]');
  /* Première ouverture d'un Bot : Grok demande de lui choisir un nom, une forme… (pas d'exemple sous la main le 28 novembre 2026).
     Repère : une page de Bot sans boîte d'envoi, avec un champ à remplir ou des mots de création/personnalisation. */
  const botSetupHint = () => {
    if (botEd() || !/\/bots?(\/|$)/.test(location.pathname)) return '';
    const t = txt(document.querySelector('main') || document.body).slice(0, 4000);
    const m = /(choisi\w*|choose|donne[rz]?\s+(lui\s+)?un nom|nomme\w*|name (your|it|the)|ton bot|your bot|forme|shape|couleur|colou?r|avatar|personnalis\w*|customi[sz]\w*|bienvenue|welcome|cr[ée]e[rz]? (ton|un|le) bot|create (your|a) bot|bot principal|primary bot)/i.exec(t);
    const field = [...document.querySelectorAll('input[type="text"], input:not([type]), textarea')].find((x) => vis(x));
    return m ? m[0] : (field ? 'champ à remplir' : '');
  };
  async function botCheck(cfg) {
    for (let i = 0; i < 80 && !botEd() && !botSetupHint() && !detectBlock(cfg); i++) await sleep(250); // jusqu'à 20 s : le fil se charge après la page
    if (botEd()) for (let i = 0; i < 24 && !botRowList().length && botScroller(); i++) await sleep(250); // le fil arrive un peu après la boîte d'envoi
    const ed = botEd();
    return { ok: true, path: location.pathname, bot: botPath(), url: botPath() ? location.origin + location.pathname : '', composer: !!ed, setup: ed ? '' : botSetupHint(),
      lastTurn: botLastTurn(), textLen: botPlain().length, images: botThumbs(botForm()).length, block: detectBlock(cfg), hidden: document.hidden };
  }
  /* Trouver le Bot du compte : menu de gauche de grok.com, rubrique « Bots », premier Bot de la liste. Relevé sur le vrai site le
     28 novembre 2026 : <div data-reorder-item="bots"> contient le titre (bouton data-panel-open, aria-controls → le panneau, aria-expanded),
     deux boutons-icônes data-icon-button (« Grouper par section », « Nouveau bot »), puis le panneau : un bouton par Bot (avatar
     data-bot-gaze-mark / data-bot-gaze-head, nom dans data-sidebar-item-label) et son bouton-icône « Actions pour … ».
     Le Bot est reconnu à sa FORME, jamais à son nom (demandé le 28/11/2026 : chacun nomme son Bot comme il veut, ou pas du tout) :
     sans nom, nommé « Bot », « Nouveau bot », « Projet », « Imagine »… il est trouvé pareil. Rubrique repliée : on la déplie. */
  const BOT_CTRL = /^(bots?|grouper par section|group by section|nouveau bot|new bot|cr[ée]er un bot|create (a )?bot|actions? (pour|for)\b.*|more actions?|plus d'actions|options?\b.*|plus d'options|afficher plus|show more|voir tout|see all)$/i;
  const botMark = (b) => b.matches('a[href*="/bot/"], [draggable="true"]') || !!b.querySelector('[data-sidebar-item-label], [data-bot-gaze-mark], [data-bot-gaze-head]'); // un Bot du menu se déplace à la souris (draggable)
  const botCtrl = (b) => b.hasAttribute('data-icon-button') || b.hasAttribute('data-panel-open') || b.hasAttribute('aria-controls') || BOT_CTRL.test(b.getAttribute('aria-label') || '') || (!botMark(b) && BOT_CTRL.test(txt(b)));
  const botName = (b) => (txt(b.querySelector('[data-sidebar-item-label]') || b) || b.getAttribute('aria-label') || '').slice(0, 40);
  const botItems = (box, head, any = false) => {
    const l = [...box.querySelectorAll('a[href*="/bot/"], button, [role="button"]')].filter((b) => (any || vis(b)) && b !== head && !(head && (b.contains(head) || head.contains(b))) && !botCtrl(b) && (botMark(b) || (txt(b).length > 0 && txt(b).length < 80)));
    const marked = l.filter(botMark);
    return marked.length ? marked : l; // un bouton reconnu à sa forme passe avant un simple texte (titre de groupe, par exemple)
  };
  async function botFind() {
    if (botPath()) return { ok: true, url: location.origin + location.pathname, already: true };
    const isHead = (b) => /^bots$/i.test(txt(b));
    let sec = null, head = null;
    for (let i = 0; i < 40 && !sec && !head; i++) {
      sec = document.querySelector('[data-reorder-item="bots"]');
      if (!sec) head = [...document.querySelectorAll('button, [role="button"], h2, h3, h4')].find((b) => vis(b) && isHead(b)) || null;
      if (!sec && !head) await sleep(250);
    }
    // le titre : ouvert, il porte data-panel-open et aria-controls ; replié, il ne garde qu'aria-expanded="false" (relevé le 28/11/2026)
    if (sec) head = sec.querySelector('[data-panel-open], [aria-controls][aria-expanded]') || sec.querySelector('button[aria-expanded]:not([data-icon-button]):not([aria-haspopup])') || [...sec.querySelectorAll('button, [role="button"], h2, h3, h4')].find(isHead) || null;
    if (!sec && !head) return { ok: false, none: true, error: 'pas de rubrique « Bots » dans le menu de Grok' };
    if (head && head.getAttribute('aria-expanded') === 'false') { // rubrique repliée : ses Bots ne sont pas dans la page tant qu'elle reste fermée
      click(head);
      for (let i = 0; i < 16 && head.getAttribute('aria-expanded') === 'false'; i++) await sleep(250);
      await sleep(400);
    }
    let list = [];
    // Parfois les Bots n'apparaissent qu'au survol de « Bots » (signalé par l'auteur le 28/11/2026) : la souris passe dessus si la liste est vide,
    // et on regarde aussi dans une fenêtre flottante ouverte par ce survol.
    const hover = (el) => { if (!el) return; const r = el.getBoundingClientRect(), p = { cancelable: true, composed: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 }; for (const t of ['pointerover', 'pointerenter', 'mouseover', 'mouseenter', 'pointermove', 'mousemove']) { try { el.dispatchEvent(new (/^pointer/.test(t) ? PointerEvent : MouseEvent)(t, { ...p, bubbles: !/enter$/.test(t), pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch (e) { /* événement refusé */ } } };
    const popItems = () => [...document.querySelectorAll('[data-side], [role="menu"], [role="dialog"], [role="tooltip"], [data-radix-popper-content-wrapper]')].filter(vis).flatMap((p) => botItems(p, head)).filter(botMark);
    if (sec) {
      const panelOf = () => { const pid = head && head.getAttribute('aria-controls'); return (pid && document.getElementById(pid)) || sec; };
      const look = () => { const l = botItems(panelOf(), head); return l.length ? l : popItems(); };
      for (let i = 0; i < 12 && !list.length; i++) { list = look(); if (!list.length) await sleep(250); }
      if (!list.length) { hover(head || sec); hover(sec); for (let i = 0; i < 16 && !list.length; i++) { await sleep(250); list = look(); } }
      if (!list.length) list = botItems(panelOf(), head, true).filter(botMark); // menu de gauche réduit : les Bots sont dans la page sans être affichés
    } else {
      // ancienne forme du menu (sans data-reorder-item) : on remonte depuis le titre « Bots », au plus de 3 niveaux, jamais jusqu'aux autres
      // rubriques (vu en test le 28/11/2026 : rubrique vide → on serait remonté jusqu'au menu entier et on aurait cliqué « Nouveau chat »)
      const OTHER = /^(nouveau chat|new chat|imagine|biblioth[eè]que|library|projets?|projects?|nouveau projet|new project|discussions?|historique|history|recherche|search|afficher plus|show more)$/i;
      const climb = () => {
        let s = head, l = [];
        for (let i = 0; i < 3 && s.parentElement && !l.length; i++) {
          s = s.parentElement;
          if ([...s.querySelectorAll('button, [role="button"], a, h2, h3, h4')].some((b) => b !== head && vis(b) && !botMark(b) && (OTHER.test(txt(b)) || OTHER.test(b.getAttribute('aria-label') || '')))) break;
          l = botItems(s, head).filter((b) => head.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
        }
        return l.length ? l : popItems();
      };
      list = climb();
      if (!list.length) { hover(head); for (let i = 0; i < 16 && !list.length; i++) { await sleep(250); list = climb(); } }
    }
    if (!list.length) return { ok: false, empty: true, error: 'aucun Bot dans la rubrique « Bots »' };
    const pick = list[0], name = botName(pick);
    click(pick);
    for (let i = 0; i < 80 && !botPath() && !botSetupHint(); i++) await sleep(250);
    if (botPath()) return { ok: true, url: location.origin + location.pathname, name, count: list.length };
    return botSetupHint() ? { ok: false, setup: botSetupHint(), name } : { ok: false, error: `le clic sur ${name ? `le Bot « ${name} »` : 'ton Bot'} n'ouvre pas sa page` };
  }
  function botRowData(r) {
    const d = { id: r.id, turn: r.turn, kind: r.kind };
    if (r.kind === 'a') { d.files = [...r.el.querySelectorAll('button[aria-label]')].map((b) => b.getAttribute('aria-label')).filter((a) => /\.\w{2,4}$/.test(a || '')).slice(0, 4); return d; }
    const t = txt(r.el); d.text = t.slice(0, r.kind === 'u' ? 160 : 700); d.len = t.length;
    if (r.kind === 's') d.files = [...r.el.querySelectorAll('video')].map((v, idx) => { const b = v.closest('button[aria-label], [aria-label]'); return { idx, name: (b && b.getAttribute('aria-label')) || `clip-${idx + 1}`, src: v.currentSrc || v.src || '', w: v.videoWidth || 0, h: v.videoHeight || 0, dur: Number.isFinite(v.duration) ? v.duration : 0 }; });
    return d;
  }
  /* Les lignes du fil à partir du message n° from. sweep : remonter le fil pour lire aussi les lignes que la page a retirées de l'écran (fil long). */
  async function botRows(o = {}) {
    const from = Number(o.from) || 0, seen = new Map();
    const grab = () => { for (const r of botRowList()) if (r.turn >= from) seen.set(r.id, botRowData(r)); };
    grab();
    const sc = botScroller();
    if (o.sweep && sc && from > 0 && !botRowList().some((r) => r.turn <= from)) {
      for (let g = 0; g < 60 && sc.scrollTop > 0 && !botRowList().some((r) => r.turn <= from); g++) { sc.scrollTop = Math.max(0, sc.scrollTop - sc.clientHeight * 0.7); await sleep(300); grab(); }
      sc.scrollTop = sc.scrollHeight; await sleep(250); grab();
    }
    const rows = [...seen.values()].sort((a, b) => a.turn - b.turn || a.id.localeCompare(b.id));
    return { ok: true, rows, lastTurn: botLastTurn(), composer: !!botEd(), textLen: botPlain().length, setup: botSetupHint(), hidden: document.hidden };
  }
  /* Le fichier d'un clip du fil : la ligne est ramenée à l'écran (une vidéo hors écran peut ne pas se charger), puis son adresse blob: est lue. */
  async function botFetch(rowId, idx, id) {
    const sc = botScroller(), find = () => document.querySelector(`[data-plane-row="${CSS.escape(rowId)}"]`);
    let row = find();
    if (!row && sc) { sc.scrollTop = sc.scrollHeight; await sleep(250); for (let g = 0; g < 60 && !(row = find()) && sc.scrollTop > 0; g++) { sc.scrollTop = Math.max(0, sc.scrollTop - sc.clientHeight * 0.7); await sleep(300); } }
    if (!row) return { ok: false, error: `ligne ${rowId} introuvable dans le fil du Bot` };
    try { row.scrollIntoView({ block: 'center' }); } catch (e) {}
    const vid = () => [...((find() || row).querySelectorAll('video'))][Number(idx) || 0] || null;
    let v = vid();
    for (let i = 0; i < 80 && !(v && (v.currentSrc || v.src)); i++) { if (v) { try { v.preload = 'auto'; } catch (e) {} } await sleep(250); v = vid(); }
    if (!v || !(v.currentSrc || v.src)) return { ok: false, error: 'la vidéo du Bot ne se charge pas' };
    const src = v.currentSrc || v.src, w = v.videoWidth || 0, h = v.videoHeight || 0;
    const r = await fetchOut(src, id, 20000, false);
    if (sc) sc.scrollTop = sc.scrollHeight;
    return r && r.ok ? { ...r, w, h, src: src.slice(0, 40) } : { ok: false, src: src.slice(0, 40), error: (r && r.error) || 'fichier du clip illisible' };
  }
  /* UN envoi : image (facultative) + texte, puis le bouton d'envoi. Jamais deux envois en même temps dans le même onglet.
     Rend { ok, turn } (n° du message envoyé) ; dirty : rien n'est parti mais la boîte est à vider ; unsure : le clic est parti sans preuve. */
  async function botSend(o = {}) {
    if (window.__frBotSending && Date.now() - window.__frBotSending < 120000) return { ok: false, busy: true, error: 'un envoi est déjà en cours dans cet onglet' };
    window.__frBotSending = Date.now();
    try {
      let form = botForm();
      if (!form) return { ok: false, error: 'boîte d\'envoi du Bot introuvable' };
      if (botPlain() || botThumbs(form).length) { // reste d'un essai raté : on vide la boîte (pièces jointes puis texte)
        for (const b of [...form.querySelectorAll('button[aria-label]')].filter((x) => vis(x) && /^(supprimer|retirer|remove|delete)\b/i.test(x.getAttribute('aria-label')))) { click(b); await sleep(300); }
        const e0 = botEd(); if (e0 && botPlain()) { e0.focus(); const r0 = document.createRange(); r0.selectNodeContents(e0); const s0 = getSelection(); s0.removeAllRanges(); s0.addRange(r0); document.execCommand('delete'); await sleep(300); }
        form = botForm();
        if (!form || botPlain() || botThumbs(form).length) return { ok: false, dirty: true, error: 'la boîte du Bot n\'est pas vide et ne se vide pas' };
      }
      const before = botLastTurn();
      if (o.fileId) {
        const file = fileOf(o.fileId);
        if (!file) return { ok: false, error: 'image de départ non reçue par la page' };
        const inp = form.querySelector('input[type="file"]') || document.querySelector('input[type="file"]');
        if (!inp) return { ok: false, error: 'champ fichier du Bot introuvable' };
        const dt = new DataTransfer(); dt.items.add(file); inp.files = dt.files; inp.dispatchEvent(new Event('change', { bubbles: true }));
        let n = 0; for (let i = 0; i < 60 && !(n = botThumbs(botForm()).length); i++) await sleep(250);
        if (!n) return { ok: false, dirty: true, error: 'l\'image n\'apparaît pas dans la boîte du Bot' };
        if (n > 1) return { ok: false, dirty: true, error: `${n} images jointes au lieu d'une` };
        for (let i = 0; i < 360 && !botUploaded(botForm()); i++) await sleep(250); // jusqu'à 90 s pour le téléversement
        if (!botUploaded(botForm())) return { ok: false, dirty: true, error: 'téléversement de l\'image pas terminé au bout de 90 s' };
      }
      const ed = botEd(); ed.focus();
      { const sel = getSelection(), rg = document.createRange(); rg.selectNodeContents(ed); rg.collapse(false); sel.removeAllRanges(); sel.addRange(rg); }
      const want = String(o.text || ''), enough = () => botPlain().length >= Math.min(30, want.trim().length * 0.5);
      if (want) {
        const dt2 = new DataTransfer(); dt2.setData('text/plain', want);
        ed.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt2 }));
        await sleep(500);
        if (!enough()) { document.execCommand('insertText', false, want); await sleep(500); }
        if (!enough()) return { ok: false, dirty: true, error: 'le texte n\'entre pas dans la boîte du Bot' };
      }
      const kept = botPlain().length;
      const btnOf = () => { const f = botForm(); return f && (f.querySelector('[data-testid="chat-submit"]') || [...f.querySelectorAll('button')].find((b) => vis(b) && /^(envoyer|send|submit)$/i.test(b.getAttribute('aria-label') || ''))); };
      let b = btnOf(); for (let i = 0; i < 60 && (!b || disabled(b)); i++) { await sleep(250); b = btnOf(); }
      if (!b || disabled(b)) return { ok: false, dirty: true, error: 'bouton d\'envoi du Bot indisponible' };
      if (o.dry) return { ok: true, dry: true, kept, images: botThumbs(botForm()).length }; // essai à blanc : tout est prêt, rien ne part (diagnostic)
      b.click(); // le clic natif du bouton (testé le 28 novembre 2026 : un seul message part)
      const gone = () => !botPlain() && !botThumbs(botForm()).length;
      for (let i = 0; i < 60 && !gone(); i++) await sleep(250);
      if (!gone()) return { ok: false, unsure: true, error: 'le message ne part pas (la boîte reste pleine)' };
      // Le n° du message envoyé : la ligne « message » la plus récente du fil, et seulement si elle contient bien notre texte.
      // (Vu le 28/11/2026 : juste après l'ouverture du Bot, les anciennes lignes du fil arrivent 6 à 9 s plus tard ; avant cette
      // vérification, une ancienne ligne chargée en retard pouvait passer pour le nouveau message.)
      const norm = (x) => String(x || '').replace(/[*_`#>~]/g, '').replace(/\s+/g, ' ').trim();
      const key = (() => { const ls = want.split('\n').map(norm).filter(Boolean); return (ls[1] || ls[0] || '').slice(0, 40); })(); // la 2e ligne (le prompt) est propre à ce message
      let turn = 0;
      for (let i = 0; i < 80 && !turn; i++) {
        const us = botRowList().filter((r) => r.kind === 'u'), mx = us.length ? Math.max(...us.map((r) => r.turn)) : 0, top = us.find((r) => r.turn === mx);
        if (mx > before && top && (!key || norm(txt(top.el)).includes(key))) turn = mx; else await sleep(250);
      }
      if (!turn) { const t = botRowList().filter((r) => r.kind === 'u' && r.turn > before).map((r) => r.turn); if (t.length) turn = Math.max(...t); } // secours : l'ancienne règle
      return { ok: true, turn, before, kept };
    } finally { window.__frBotSending = 0; }
  }
  /* Une carte FruitRadar posée DANS la page (ici CapCut) quand l'automatisation attend un accord : on voit tout de suite pourquoi rien ne bouge,
     et on répond sur place. o = null pour la retirer. */
  function frGate(o) {
    const old = document.getElementById('fr-gate'); if (old) old.remove();
    if (!o) return { ok: true, removed: !!old };
    const host = document.createElement('div'); host.id = 'fr-gate';
    host.style.cssText = 'position:fixed;top:64px;left:50%;transform:translateX(-50%);z-index:2147483647;';
    const root = host.attachShadow({ mode: 'open' });
    const esc = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    root.innerHTML = `<style>
      :host { all: initial; }
      .card { width: min(560px, 92vw); background: #1B1220; color: #FFF7EC; border-radius: 18px; box-shadow: 0 18px 60px rgba(0,0,0,.45), 0 0 0 1px rgba(255,255,255,.08); font: 14px/1.45 system-ui, -apple-system, 'Segoe UI', sans-serif; overflow: hidden; }
      .top { display: flex; align-items: center; gap: 10px; padding: 14px 16px 10px; }
      .dot { width: 10px; height: 10px; border-radius: 50%; background: #FFB23F; box-shadow: 0 0 0 4px rgba(255,178,63,.25); flex: none; }
      h2 { margin: 0; font-size: 16px; font-weight: 700; flex: 1; }
      .fold { background: none; border: 0; color: #CDBFD6; font-size: 13px; cursor: pointer; padding: 4px 8px; border-radius: 8px; }
      .fold:hover { background: rgba(255,255,255,.08); color: #fff; }
      .body { padding: 0 16px 16px; }
      p { margin: 0 0 10px; color: #E4D8EA; }
      ul { list-style: none; margin: 0 0 14px; padding: 0; display: grid; gap: 6px; }
      li { display: grid; grid-template-columns: 22px 1fr; gap: 8px; align-items: start; padding: 8px 10px; border-radius: 10px; background: rgba(255,255,255,.06); }
      li b { display: block; font-weight: 600; } li span.s { color: #CDBFD6; font-size: 13px; }
      li i { font-style: normal; width: 22px; height: 22px; border-radius: 50%; display: grid; place-items: center; font-size: 13px; font-weight: 700; }
      li.ok i { background: #1F8F5F; color: #fff; } li.todo i { background: #FFB23F; color: #2A1500; } li.todo { box-shadow: inset 0 0 0 1px #FFB23F; }
      .row { display: flex; flex-wrap: wrap; gap: 8px; }
      button.act { font: inherit; font-weight: 700; border: 0; border-radius: 12px; padding: 10px 14px; cursor: pointer; background: rgba(255,255,255,.1); color: #fff; }
      button.act.go { background: #FFB23F; color: #2A1500; } button.act:hover { filter: brightness(1.1); } button.act:disabled { opacity: .55; cursor: default; }
      .msg { margin: 10px 0 0; font-size: 13px; color: #FFB23F; min-height: 1em; }
      .card.min .body { display: none; }
    </style>
    <div class="card" role="dialog" aria-label="FruitRadar attend ton accord">
      <div class="top"><span class="dot" aria-hidden="true"></span><h2>${esc(o.title)}</h2><button class="fold" type="button" aria-expanded="true">Réduire</button></div>
      <div class="body">
        ${o.text ? `<p>${esc(o.text)}</p>` : ''}
        <ul>${(o.points || []).map((x) => `<li class="${x.ok ? 'ok' : 'todo'}"><i aria-hidden="true">${x.ok ? '✓' : '!'}</i><div><b>${esc(x.title)}</b><span class="s">${esc(x.note)}</span></div></li>`).join('')}</ul>
        <div class="row">${(o.buttons || []).map((b) => `<button class="act${b.primary ? ' go' : ''}" type="button" data-v="${esc(b.value)}"${b.confirm ? ` data-c="${esc(b.confirm)}"` : ''}>${esc(b.label)}</button>`).join('')}</div>
        <p class="msg" role="status"></p>
      </div>
    </div>`;
    const card = root.querySelector('.card'), fold = root.querySelector('.fold'), msg = root.querySelector('.msg');
    fold.addEventListener('click', () => { const m = card.classList.toggle('min'); fold.textContent = m ? 'Ouvrir' : 'Réduire'; fold.setAttribute('aria-expanded', String(!m)); });
    root.querySelectorAll('button.act').forEach((b) => b.addEventListener('click', () => {
      if (b.dataset.c && b.dataset.armed !== '1') { // à confirmer : un second clic sur le même bouton (pas de boîte native, elle bloque la page)
        root.querySelectorAll('button.act').forEach((x) => { delete x.dataset.armed; });
        b.dataset.armed = '1'; msg.textContent = `${b.dataset.c} Clique encore une fois sur « ${b.textContent} » pour confirmer.`;
        setTimeout(() => { if (b.dataset.armed === '1') { delete b.dataset.armed; if (/Clique encore une fois/.test(msg.textContent)) msg.textContent = ''; } }, 8000);
        return;
      }
      root.querySelectorAll('button.act').forEach((x) => { x.disabled = true; });
      msg.textContent = 'Bien reçu…';
      try {
        chrome.runtime.sendMessage({ type: 'autoOpen', id: o.id, cmd: 'gate', text: b.dataset.v }, (r) => {
          void chrome.runtime.lastError;
          if (r && r.ok) host.remove();
          else { msg.textContent = (r && r.error) || 'FruitRadar ne répond pas : réponds depuis son onglet.'; root.querySelectorAll('button.act').forEach((x) => { x.disabled = false; }); }
        });
      } catch (e) { msg.textContent = 'FruitRadar ne répond pas : réponds depuis son onglet.'; }
    }));
    (document.body || document.documentElement).appendChild(host);
    return { ok: true };
  }
  async function dismiss(cfg) {
    let n = 0;
    for (let k = 0; k < 4; k++) { const x = qAll(cfg.dismiss || []).find(vis); if (!x) break; click(x); n++; await sleep(600); }
    // CapCut, projet rouvert alors qu'il a des modifications non enregistrées (« Mettre à jour le projet ? ») : on garde les modifications
    if (/capcut\.com$/i.test(location.hostname)) {
      const up = [...document.querySelectorAll('button')].find((b) => vis(b) && /^(mettre à jour|update)$/i.test(txt(b)) && /(modifications non enregistr|unsaved changes)/i.test(txt(b.closest('[role="dialog"], [class*="modal"], [class*="dialog"]') || b.parentElement.parentElement.parentElement || b)));
      if (up) { click(up); n++; await sleep(900); }
      // « Installer une application pour ouvrir CapCut Web » (vue le 16 novembre 2026, après un export) : elle couvre l'éditeur et bloque les clics → « Annuler »
      const pwa = [...document.querySelectorAll('.lv-pwa-modal, [class*="pwa-modal"]')].find(vis);
      const no = pwa && [...pwa.querySelectorAll('button')].find((x) => vis(x) && /^(annuler|cancel|plus tard|later|not now|pas maintenant)$/i.test(txt(x)));
      if (no) { click(no); n++; await sleep(900); }
    }
    return { ok: true, n };
  }
  function attachedCount(cfg) {
    const root = inputCard(cfg) || document;
    return [...root.querySelectorAll('img')].filter((i) => vis(i) && /^(blob:|data:)/.test(i.currentSrc || i.src)).length;
  }
  function diag(cfg) {
    return { url: location.href, composer: !!composer(cfg), fileInputs: qAll(cfg.fileInput || ['input[type="file"]']).length, send: !!firstVis(cfg.send), answers: qAll(cfg.answer || []).length, block: detectBlock(cfg) };
  }

  /* Relevé détaillé de la page, à copier quand un site ne répond plus : ce que FruitRadar voit comme boutons et champs */
  function dump(cfg) {
    const short = (s) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, 60);
    const scope = firstVis(['main', 'form', '[role="main"]']) || document.body;
    const desc = (el) => [el.tagName.toLowerCase(), el.id ? '#' + el.id : '', el.getAttribute('data-testid') ? `[testid=${el.getAttribute('data-testid')}]` : '', el.getAttribute('role') ? `[role=${el.getAttribute('role')}]` : '',
      el.getAttribute('aria-label') ? `aria="${short(el.getAttribute('aria-label'))}"` : '', el.getAttribute('placeholder') ? `placeholder="${short(el.getAttribute('placeholder'))}"` : '',
      el.getAttribute('accept') ? `accept="${short(el.getAttribute('accept'))}"` : '', disabled(el) ? '(désactivé)' : '', txt(el) && el.tagName !== 'TEXTAREA' ? `« ${short(txt(el))} »` : ''].filter(Boolean).join(' ');
    return {
      ...diag(cfg), title: document.title,
      boutons: ((sel) => { const inScope = [...scope.querySelectorAll(sel)].filter(vis); return (inScope.length >= 4 ? inScope : [...document.querySelectorAll(sel)].filter(vis)).slice(0, 70).map(desc); })('button, [role="button"], [role="tab"], [role="radio"], [role="menuitem"]'),
      champs: [...document.querySelectorAll('textarea, [contenteditable="true"], input:not([type="hidden"])')].slice(0, 20).map((el) => `${desc(el)}${vis(el) ? '' : ' (caché)'}`),
      videos: document.querySelectorAll('video').length, images: [...document.images].filter((i) => i.naturalWidth >= 400).length
    };
  }


  /* ---------- VideoTranscriber (videotranscriber.ai) — relevé sur le vrai site le 17 novembre 2026 ----------
     Le fichier se dépose dans le champ de la page d'accueil, puis « Transcribe ». L'état et le texte se lisent dans les données du site
     (/api/v1/transcriptions…) : la liste affichée n'est que partielle, et son pourcentage n'est qu'une animation pendant la file d'attente. */
  const vtApi = async (path) => {
    const r = await fetch(path, { credentials: 'include', cache: 'no-store' });
    if (!r.ok) throw new Error(`réponse ${r.status}`);
    const j = await r.json();
    if (!j || j.code !== 100000) throw new Error((j && j.message) || 'réponse refusée');
    return j.data || {};
  };
  const vtBase = (n) => String(n || '').replace(/\.[a-z0-9]{2,5}$/i, '').trim().toLowerCase();
  /* Où en est la transcription de ce fichier ? (since : ne regarder que les envois faits après cette heure) */
  async function vtFind(name, since, skip) {
    try {
      const d = await vtApi('/api/v1/transcriptions/status?page_no=1&page_size=20');
      const key = vtBase(name);
      const out = new Set((skip || []).map(String)); // essais ratés déjà vus : on ne les reprend pas pour le nouvel envoi
      const r = (d.transcription_records || []).filter((x) => vtBase(x.title) === key && !out.has(String(x.record_id || '')) && (!since || Number(x.created_at) * 1000 >= since - 120000)).sort((a, b) => Number(b.created_at) - Number(a.created_at))[0];
      if (!r) return { found: false, block: detectBlock() };
      const sc = r.transcription_scope || {};
      return { found: true, id: String(r.record_id || ''), status: String(r.status || ''), queue: String(r.queue_state || ''), locked: !!sc.is_locked, done: Number(sc.processed_duration_ms) || 0, total: Number(sc.total_duration_ms) || 0, error: String(r.error_message || ''), model: String((r.settings && r.settings.transcription_model) || '') };
    } catch (e) { return { found: false, error: e.message, block: detectBlock() }; }
  }
  /* Transcriptions encore disponibles aujourd'hui (basic : le modèle simple ; premium : « Advanced ») */
  async function vtCredits() {
    try {
      const d = await vtApi('/api/v1/credits/user');
      const n = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0);
      const basic = d.is_unlimited_ordinary ? 999 : (d.ordinary_available !== undefined ? n(d.ordinary_available) : Math.max(n(d.available), n(d.anonymous_transcription_available)));
      return { ok: true, basic, premium: n(d.premium_available), resetAt: n(d.free_transcription_reset_at) * 1000 };
    } catch (e) { return { ok: false, error: e.message }; }
  }
  /* Les fenêtres de publicité (application de bureau…) : on les ferme, jamais leur bouton de téléchargement */
  function vtClosePopups(cfg) {
    const re = new RegExp((cfg && cfg.popup) || '(desktop app|download for windows)', 'i');
    let n = 0;
    for (const d of [...document.querySelectorAll('[role="dialog"], dialog[open], [aria-modal="true"]')].filter(vis)) {
      if (d.querySelector('input[type="file"]') || !re.test(txt(d))) continue;
      const b = [...d.querySelectorAll('button, [role="button"]')].find((x) => /^(close|fermer)/i.test(x.getAttribute('aria-label') || txt(x)));
      if (b) { click(b); n++; }
    }
    return n;
  }
  /* La page est-elle vraiment affichée ? (fenêtre d'automatisation réduite ou recouverte : « hidden ») */
  const pageShown = () => document.visibilityState === 'visible' && document.documentElement.dataset.frHidden !== '1';
  function visible() { return pageShown(); }
  /* Dépose la vidéo, choisit le modèle, puis UN clic sur « Transcribe ».
     Relevé sur le vrai site le 18 novembre 2026 : au dépôt, le site lit la durée du fichier avec un lecteur vidéo, et « Transcribe » reste grisé
     tant qu'il ne l'a pas. Or Chrome ne charge aucune vidéo dans une page qui n'est pas affichée : fenêtre cachée = bouton grisé pour toujours.
     Page cachée : on ne dépose rien, on le dit (hidden), et la fenêtre pilote affiche la page avant de recommencer (force). */
  async function vtUpload(ids, cfg, model, force) {
    const files = ids.map(fileOf).filter(Boolean);
    if (!files.length) return { ok: false, error: 'fichier non reçu par la page' };
    if (!force && !pageShown()) return { ok: false, hidden: true, error: 'page cachée' };
    vtClosePopups(cfg); await sleep(300);
    const tab = [...document.querySelectorAll('[role="tab"]')].find((t) => /video/i.test(txt(t)) && /audio/i.test(txt(t)));
    if (tab && tab.getAttribute('aria-selected') === 'false') { click(tab); await sleep(500); }
    const inp = [...document.querySelectorAll('input[type="file"]')].find((i) => !i.disabled);
    if (!inp) return { ok: false, error: 'champ fichier de VideoTranscriber introuvable' };
    const dt = new DataTransfer(); dt.items.add(files[0]);
    inp.files = dt.files;
    inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true }));
    const key = vtBase(files[0].name);
    const btnRe = new RegExp((cfg && cfg.submit) || '^(transcribe|transcrire)$', 'i');
    const submitEl = () => [...document.querySelectorAll('button, [role="button"]')].filter((b) => vis(b) && btnRe.test(txt(b))).pop() || null;
    // fichier pris en compte = sa ligne est là, avec son bouton « Remove <nom> » (ou le compteur « 1/50 files selected »)
    const listedNow = () => [...document.querySelectorAll('button, [role="button"]')].some((b) => vis(b) && /^(remove|supprimer|retirer)\b/i.test(b.getAttribute('aria-label') || txt(b)) && (b.getAttribute('aria-label') || txt(b)).toLowerCase().includes(key))
      || (/\b\d+\s*\/\s*\d+\s*(files?|fichiers?)\s*(selected|sélectionn)/i.test(document.body.innerText || '') && (document.body.innerText || '').toLowerCase().includes(key));
    let listed = false;
    for (let i = 0; i < 40 && !(listed && submitEl()); i++) { await sleep(300); listed = listedNow(); }
    if (!listed) return { ok: false, error: 'le fichier n\'apparaît pas dans la page après le dépôt' };
    if (!submitEl()) return { ok: false, error: 'bouton « Transcribe » introuvable' };
    if (model) { // « Basic » ou « Advanced »
      const m = [...document.querySelectorAll('button, [role="button"], [role="tab"], [role="radio"]')].find((b) => vis(b) && new RegExp(`^${model}$`, 'i').test(txt(b)));
      if (m) { click(m); await sleep(400); }
    }
    vtClosePopups(cfg);
    let b = submitEl();
    for (let i = 0; i < 110 && b && disabled(b); i++) { await sleep(400); b = submitEl(); } // le site lit d'abord la durée de la vidéo : jusqu'à 45 s pour un gros fichier
    if (!b || disabled(b)) return { ok: false, grey: true, hidden: !pageShown(), error: `bouton « Transcribe » grisé : le site n'a pas pu lire la durée de la vidéo${pageShown() ? '' : ' (sa page n\'est pas affichée)'}` };
    if (window.__frVtSent && Date.now() - window.__frVtSent < 20000) return { ok: true, already: true };
    window.__frVtSent = Date.now();
    click(b);
    return { ok: true, model: model || '' };
  }
  /* Le texte, avec le minutage et les voix repérées : « (0:00 - 0:03) Voix 1 : … » */
  async function vtText(id) {
    try {
      const d = await vtApi(`/api/v1/transcriptions?record_id=${encodeURIComponent(id)}`);
      const clock = (v) => { const q = String(v || '').split(':').map((x) => parseInt(x, 10) || 0); const sec = q.length === 3 ? q[0] * 3600 + q[1] * 60 + q[2] : q.length === 2 ? q[0] * 60 + q[1] : q[0] || 0; return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`; };
      const who = (v) => { const m = String(v || '').match(/(\d+)\s*$/); return m ? `Voix ${Number(m[1]) + 1}` : ''; };
      const segs = (d.transcript || []).filter((x) => x && String(x.text || '').trim());
      const text = segs.map((x) => `(${clock(x.start)} - ${clock(x.end)}) ${who(x.speaker) ? `${who(x.speaker)} : ` : ''}${String(x.text).replace(/\s+/g, ' ').trim()}`).join('\n');
      const sc = d.transcription_scope || {};
      return { ok: true, text, n: segs.length, locked: !!sc.is_locked, mode: String(sc.mode || '') };
    } catch (e) { return { ok: false, error: e.message }; }
  }

  window.__FRA = { rev: REV, visible, turboRead, vtFind, vtCredits, vtUpload, vtText, vtClosePopups, tiktokRail, tiktokCoverOpen, tiktokCoverSave, frGate, capcutRedo, capcutNewest, chatFind, chatProbe, tiktokCaptions, tiktokHashtags, tiktokCoverAlign, grokCheck, grokPrepare, grokShowVideo, grokFire, grokUser, grokClips, grokChatPrepare, grokChatFire, grokChatClips, botCheck, botFind, botRows, botFetch, botSend, turboUpload, turboExport, turboDialog, turboSubmit, tiktokPhoneMode, tiktokVolume, capcutIssue, capcutBusy, capcutClean, capcutExport, capcutUndo, capcutAddNewest, tiktokAccount, tiktokState, tiktokClick, tiktokPublish, tiktokConfirm, tiktokPreset, tiktokRaiseCaption, tiktokSound, dismiss, dump, attachedCount, clearComposer, capcutTransitions, capcutTimes, capcutSeekEnd, ensureVideo, ensureOption, putChunk, dropFiles, fetchOut, getChunk, setText, attach, send, state, answerText, clickText, setOption, clickSel, capcutState, capcutAdd, turboRow, pageText, diag, ping: () => true };
})();
