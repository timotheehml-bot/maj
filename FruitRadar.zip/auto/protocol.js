// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
// FruitRadar — automatisation : ce qu'on demande au rédacteur (Claude) et comment on relit sa réponse.
// Le métaprompt reste la référence pour le FOND. L'annexe ci-dessous ne change que la FORME de la réponse,
// pour qu'un programme puisse retrouver chaque prompt sans se tromper.

export const DURATIONS = [6, 10, 15];

export const ANNEX = `# ANNEXE AUTOMATISATION — FRUITRADAR (prioritaire sur les règles de mise en forme du métaprompt)

Tu es appelé par un programme, pas par un humain. Personne ne lit ta réponse : elle est découpée automatiquement puis envoyée à ChatGPT (images) et à Grok (vidéos). Toutes les lois et règles du métaprompt joint s'appliquent au CONTENU. Seule la FORME de la réponse change, comme suit.

## 1. Pas de question, pas d'attente
- La PHASE 0 est sautée : l'option choisie est donnée dans le message.
- Tu ne poses aucune question et tu n'attends aucun choix. Quand le métaprompt prévoit un choix de l'utilisateur (3 angles, version, ouverture), tu choisis toi-même la meilleure option et tu continues.
- Avant d'écrire, tu imagines 3 ouvertures différentes pour la scène 1 (première image, première réplique exacte, ce qui change avant la 5e seconde) et tu gardes la plus accrocheuse : un geste précis qui change quelque chose, une image et une réplique qui se complètent, une question précise, une réaction entre 2 et 5 secondes. Tu ne les affiches pas.
- Le tableau de script, le test du petit cousin et la proposition finale de l'autre version sont faits mentalement et ne sont PAS écrits.

## 2. Une seule forme de sortie
- Toute ta réponse tient dans UN SEUL bloc de code (ouvert par trois accents graves suivis de text). Rien avant, rien après, aucun artefact, aucun fichier. Cette règle remplace la règle « texte brut, jamais de bloc code ».
- Tu réponds directement dans le chat. Tu ne crées ni artefact, ni page, ni document, ni fichier, et tu n'utilises aucun outil (pas de recherche, pas de mémoire à consulter), même si mes préférences enregistrées ou ta mémoire disent que j'aime recevoir mes packages sous forme de page : ici, c'est un programme qui lit.
- Dans ce bloc, uniquement les blocs balisés ci-dessous. Chaque balise est seule sur sa ligne. Les valeurs sont entre guillemets droits. Chaque bloc se ferme par @@FIN@@.
- Si la réponse risque d'être coupée par la limite de longueur : termine le bloc en cours, écris @@SUITE@@ seul sur la dernière ligne, et arrête-toi. Quand tu reçois le message SUITE, tu reprends au bloc suivant, au même format, sans rien répéter.
- Quand tout est livré, la dernière ligne est @@FINI@@.

## 3. Les blocs, dans cet ordre

@@META@@
titre: [titre complet de l'histoire]
serie: [titre court de la série pour la miniature, 3 à 5 mots, ex. Le Secret des Grenadines]
partie: [numéro de la partie, donné dans le message]
accroche: [le gros titre de la miniature, 5 mots maximum, en capitales, une question ou une promesse qui donne envie de cliquer, sans révéler la fin]
duree: [somme des durées en secondes]
moteur: [moteur de conflit]
univers: [univers]
@@FIN@@

@@BIBLE@@
[Mémoire de la série, pour écrire la partie suivante plus tard, 250 mots maximum : résumé de cette partie scène par scène en une ligne chacune ; pour chaque personnage : nom, espèce, rôle, étiquette Grok, verrou de voix complet ; la question laissée ouverte.]
@@FIN@@

@@PLANCHE nom="[nom unique de la planche]"@@
[prompt complet de la planche de référence, tel que le métaprompt le définit, Directive de Style Planche comprise]
@@FIN@@
(une par personnage et par état de tenue ou de coiffure ; si un personnage a deux états, deux planches avec deux noms différents, ex. nom="Grenadina" et nom="Grenadina mariée")

@@SCENE n="1" duree="6" refs="[noms exacts des planches visibles, séparés par |]" titre="[titre court]" version="normale"@@
@@IMAGE@@
[prompt image complet de la scène, VERROU DE CADRAGE et Directive de Style de Scène compris]
@@VIDEO@@
[prompt vidéo complet, version recommandée uniquement, commençant par la phrase d'ouverture commune]
@@MONTAGE@@
fin: [le mouvement de caméra ou le geste qui termine ce clip]
suivant: [la première image du clip suivant]
montage: [ce qu'on fait au montage entre les deux : coupe franche sur le mouvement, balayage 0,2 s dans le même sens, etc.]
@@FIN@@
(une par scène, numérotées 1, 2, 3… sans saut ; duree vaut 6, 10 ou 15 ; refs reprend lettre pour lettre les noms des planches)

@@MINIATURE refs="[noms exacts des planches à charger, séparés par |]"@@
[prompt image complet de la miniature, voir point 5]
@@FIN@@

@@DESCRIPTION@@
[description TikTok, voir point 6]
@@FIN@@

@@FINI@@

## 4. Rythme et transitions (prioritaire : c'est ce qui fait qu'on regarde jusqu'au bout)
- La vidéo doit être claire, dynamique et agréable à regarder. L'histoire reste simple ; le dynamisme vient de la mise en scène : décors variés (jamais le même cadre deux scènes de suite), caméra qui bouge, gestes nets, répliques courtes qui s'enchaînent.
- Chaque scène ouvre une question nouvelle dans la tête du spectateur (qui ? pourquoi ? et lui ? et maintenant ?), jamais un rappel.
- Chaque clip SE TERMINE par un mouvement de caméra ou un geste qui appelle le plan suivant (whip-pan, push-in sur un objet, tilt vers le ciel, regard vers une porte, objet lancé). Ce mouvement final est écrit dans le prompt vidéo, comme dernier temps de l'action, et repris dans le bloc MONTAGE.
- La première image du clip suivant répond à ce mouvement (raccord de direction, de lumière, d'objet ou de regard). Au montage, une coupe franche pile sur le mouvement suffit presque partout ; les effets sont rares et très courts (0,1 à 0,2 s).
- La dernière scène coupe juste avant la réponse : le spectateur doit vouloir la partie suivante.

## 4 bis. Zéro texte à l'image
- Aucun texte lisible dans les images de scène ni dans les clips : pas de panneau, d'enseigne, de pancarte, d'affiche, d'écran, de lettre, d'étiquette ou de vêtement portant des mots, des lettres ou des chiffres. N'en demande jamais dans un prompt image ou vidéo, et ne nomme aucun lieu par un panneau.
- Si l'histoire a besoin d'un écrit (lettre, pancarte, message sur un téléphone, nom d'un lieu), on ne le lit pas : il est vu de dos, flou, hors champ, ou remplacé par un dessin ou un symbole, et c'est une réplique qui dit ce qu'il contient.
- Aucun sous-titre : les répliques s'entendent, elles ne s'écrivent jamais. Seule exception possible : la rubrique « mot fort à l'écran », si elle figure dans la demande.

## 4 ter. Qui parle (prioritaire : Grok fait parler le mauvais personnage dès que c'est flou)
- Chaque réplique est dite par UN seul personnage, et tient sur UNE ligne du prompt vidéo, à ce format exact : RÉPLIQUE n — NOM (sa place dans l'image : à gauche, à droite, au centre, au premier plan ou au fond ; son espèce ; un signe distinctif bien visible) : "texte". La place écrite est celle du personnage dans l'image de la scène.
- Jamais deux personnages qui parlent en même temps : les répliques se suivent, dans l'ordre écrit. Dans une scène à une seule réplique, un seul personnage ouvre la bouche.
- Deux personnages qui se ressemblent (même espèce, même couleur) ne sont jamais ensemble dans une scène où l'un d'eux parle, sauf si un signe distinctif net les sépare (vêtement, couleur, accessoire), repris dans la ligne de la réplique.
- Les personnages présents qui n'ont pas de réplique sont nommés dans le prompt vidéo comme silencieux : bouche fermée du début à la fin, ils réagissent avec le regard et le corps.
- Celui qui parle est bien visible, de face ou de trois quarts, pendant sa réplique ; un personnage de dos ou hors champ ne parle pas (sauf voix off voulue par l'histoire, alors écrite comme telle : RÉPLIQUE n — NARRATEUR (voix off) : "texte").

## 5. La miniature
Format vertical 9:16, même rendu 3D que les scènes. Le bloc MINIATURE décrit UNIQUEMENT l'image, jamais le texte :
- L'image la plus forte de l'épisode, sans la révéler entièrement : les deux personnages principaux au premier plan dans un moment d'émotion lisible en un quart de seconde, et le personnage rival ou témoin au second plan, plus petit, qui les regarde, visage net. Lumière et couleurs fortes, décor de l'histoire, cadrage d'affiche.
- Les visages et l'action tiennent dans les deux tiers inférieurs de l'image ; le tiers supérieur reste calme (ciel, mur, décor flou) pour recevoir le titre.
- N'écris AUCUNE consigne de texte, de titre, de lettrage, de badge ni de couleur de lettres : le programme ajoute lui-même le texte de la miniature (l'accroche et le numéro de partie) dans le style choisi par l'utilisateur.
- La matière des personnages (celle de leurs planches) partout, jamais de peau humaine, aucun visage coupé par le cadre.

## 6. La description TikTok
{{REGLE_DESCRIPTION}}
`;

/* ---------- Messages envoyés au rédacteur ---------- */
const fmtT = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(Math.round(s % 60)).padStart(2, '0')}`;

export function sourceBlock(prod) {
  const L = [];
  const s = prod.source || {};
  if (s.url) L.push(`Vidéo d'origine : ${s.url}`);
  if (s.author) L.push(`Compte : @${s.author}${s.stats ? ` — ${s.stats}` : ''}`);
  if (s.duration) L.push(`Durée : ${Math.round(s.duration)} s`);
  if (s.desc) L.push(`Description : « ${s.desc} »`);
  if (prod.sheets && prod.sheets.length) {
    L.push('', `LA VIDÉO : regarde-la en entier avant d'écrire quoi que ce soit. Les planches jointes « lecture-01.jpg » à « lecture-${String(prod.sheets.length).padStart(2, '0')}.jpg » sont toute la vidéo, dans l'ordre, ${String(prod.sheetsRate || 2).replace('.', ',')} images par seconde, 12 images par planche, à lire de gauche à droite puis de haut en bas ; le temps est écrit en jaune sur chaque image (${prod.sheets.map((x, i) => `lecture-${String(i + 1).padStart(2, '0')} = ${fmtT(x.from)} à ${fmtT(x.to)}`).join(', ')}).`,
      'Sers-t\'en pour comprendre exactement ce qui se passe : qui est qui, les actions, les gestes, les cadrages, les changements de plan, les décors, le rythme et le moment de chaque retournement. La transcription ci-dessous donne ce qui est dit (tu n\'as pas le son).');
    if (prod.videoSent) L.push('La vidéo d\'origine est aussi jointe (« video-source.mp4 ») : si tu peux l\'ouvrir avec ton outil d\'analyse, fais-le pour compléter les planches.');
    L.push('');
  }
  if (prod.frames && prod.frames.length) L.push(`Captures jointes, dans l'ordre : ${prod.frames.map((f, i) => `capture-${String(i + 1).padStart(2, '0')} = ${fmtT(f.t)}`).join(', ')}.`);
  const tr = prod.transcript || [];
  if (tr.length) {
    L.push('', `Transcription (${prod.transcriptFrom || 'source inconnue'}) :`);
    tr.forEach((c) => L.push(c.start !== null && c.start !== undefined ? `[${fmtT(c.start)}] ${c.text}` : c.text));
  } else L.push('', 'Pas de transcription disponible : appuie-toi sur les planches de lecture, les captures et la description.');
  return L.join('\n');
}

/* La règle de la description dépend de la chaîne : son nom est cité et repris en hashtag (s'il y en a un) */
export function descriptionRule(brand = '') {
  const b = String(brand || '').trim(), tag = b.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9]+/g, '');
  return `Courte, mystérieuse, sans emoji, une ou deux phrases qui donnent envie sans révéler la fin${b ? `, avec la mention ${b}` : ''}, puis exactement six hashtags, sur la même ligne : #partie[numéro]${tag ? ` #${tag}` : ''}, puis ${tag ? 'quatre' : 'cinq'} hashtags de RECHERCHE, ceux que les gens tapent vraiment dans la recherche TikTok pour trouver ce genre de vidéo. Choisis-les pour CETTE histoire : son thème (ex. #trahison, #mariage, #vengeance, #jalousie), son genre (ex. #histoire, #drama, #feuilleton) et l'univers (ex. #fruitsia, #fruitdrama, #animationia). En français, en minuscules, un ou deux mots collés, connus et souvent cherchés. Jamais de hashtag inventé, trop long ou trop général (#fyp, #pourtoi, #viral).`;
}
/* Métaprompt V7 : mêmes blocs balisés, mais les renvois de l'annexe aux gabarits de la V6 (directives de style, phrase d'ouverture,
   « RÉPLIQUE n — NOM : "texte" ») sont remplacés par ceux de la V7 (fiches de style, ligne Clean frame, répliques sans guillemets ni majuscules). */
const ANNEX_V7 = [
  [/Cette règle remplace la règle « texte brut, jamais de bloc code »\./, 'Cette règle remplace la LIVRAISON EN PAGE et la RÈGLE DE SORTIE du métaprompt (un bloc code par prompt) : ici, aucune page et aucun bloc code à l\'intérieur du bloc unique.'],
  [/- Le tableau de script, le test du petit cousin et la proposition finale de l'autre version sont faits mentalement et ne sont PAS écrits\./, '- Le décorticage de l\'original, le tableau de script, le test du petit cousin, les titres de série, la publication du métaprompt (miniature 3:4, story, sondage), les lignes de contrôle de chaque scène (planches à joindre, inventaire, image à joindre, durée) et le nombre de caractères sont faits mentalement et ne sont PAS écrits.\n- Le bloc « MA DEMANDE » du métaprompt est remplacé par la demande ci-dessous. Le style est celui indiqué dans ce message ; sans indication, c\'est le style 1 Classique. En option 3, l\'élément principal est gardé.'],
  [/\[prompt complet de la planche de référence, tel que le métaprompt le définit, Directive de Style Planche comprise\]/, '[prompt complet de la planche de référence, au format PLANCHE V4 du métaprompt, rempli avec la fiche du style]'],
  [/\[prompt image complet de la scène, VERROU DE CADRAGE et Directive de Style de Scène compris\]/, '[prompt image complet de la scène, au GABARIT SCÈNE V4 du métaprompt, rempli avec la fiche du style]'],
  [/\[prompt vidéo complet, version recommandée uniquement, commençant par la phrase d'ouverture commune\]/, '[prompt vidéo complet, une seule version (normale ou dynamique), au gabarit du métaprompt, commençant par la ligne Clean frame puis la ligne Langue, 4 000 caractères au maximum, soit 620 mots au plus (BUDGET DU PROMPT VIDÉO du métaprompt)]'],
  [/- Chaque réplique est dite par UN seul personnage, et tient sur UNE ligne du prompt vidéo, à ce format exact : [^\n]*/, '- Chaque réplique est dite par UN seul personnage, et tient sur UNE ligne du prompt vidéo, au format du métaprompt : Réplique n, étiquette du personnage, en français, intonation : texte (sans guillemets, sans mot entièrement en majuscules). La place du personnage dans l\'image (à gauche, à droite, au centre, au fond) est écrite avec son étiquette, et c\'est celle qu\'il a dans l\'image de la scène.'],
  [/RÉPLIQUE n — NARRATEUR \(voix off\) : "texte"/, 'Réplique n, narrateur en voix off : texte'],
  [/Format vertical 9:16, même rendu 3D que les scènes\. Le bloc MINIATURE/, 'Format vertical 9:16 (et non le 3:4 du métaprompt), même rendu que les scènes, avec le champ RENDU de la fiche du style. Le bloc MINIATURE']
];
export const annexFor = (brand, ver = 'v6') => {
  let a = ANNEX;
  if (ver === 'v7') for (const [re, to] of ANNEX_V7) a = a.replace(re, to);
  return a.replace('{{REGLE_DESCRIPTION}}', descriptionRule(brand));
};

export function firstMessage(prod, { extra = '', knownPlanches = [], prevBible = '', metaAttached = true, brand = '', audience = '', hook = false, prevVideo = false, prevScript = false, cast = [], castImages = false, metaVer = 'v6' } = {}) {
  const L = [], v7 = metaVer === 'v7';
  L.push(metaAttached
    ? 'Le fichier joint « metaprompt.txt » est ton métaprompt : applique-le en entier. L\'annexe ci-dessous fixe la forme de ta réponse.'
    : 'Applique le métaprompt de ce projet en entier. L\'annexe ci-dessous fixe la forme de ta réponse.');
  const sb = styleBlock(prod, openingFor(OPENING_DEFAULT, prod), metaVer);
  if (sb) L.push('', sb);
  L.push('', annexFor(brand, metaVer), '', '# LA DEMANDE', '', `Audience : ${String(audience || '').trim() || 'France (adultes de 24 à 35 ans)'}.`, `Partie : ${prod.part || 1}.`);
  if (prod.mode === 'remake' && v7) {
    L.push('', 'OPTION 3 — refaire cette vidéo virale, en REPRISE FIDÈLE comme le métaprompt la définit : même hook, mêmes rôles, mêmes étapes dans le même ordre, même retournement, même fin, même durée ; élément principal gardé ; nouveaux personnages, nouveaux décors du même type, répliques réécrites en français clair. Les planches de lecture et la transcription jointes sont les pièces de l\'ÉTAPE 0 : ne demande rien. Regarde d\'abord toute la vidéo, fais le décorticage mentalement, puis livre le package complet au format de l\'annexe.', '', sourceBlock(prod));
  } else if (prod.mode === 'remake') {
    L.push('', 'OPTION 3 — refaire cette vidéo virale. Même histoire avec MES fruits : garde les mêmes moments forts, le même rythme, les mêmes retournements et la même fin qui donne envie de la suite, mais avec mes personnages, mes dialogues en français et ma direction artistique. Ne copie pas plan pour plan. Regarde d\'abord toute la vidéo (planches de lecture), fais le déroulé scène par scène mentalement, puis livre le package complet au format de l\'annexe.', '', sourceBlock(prod));
  } else if (prod.mode === 'idee') {
    L.push('', 'OPTION 2 — voici mon idée. Choisis toi-même le meilleur angle, puis livre le package complet au format de l\'annexe.', '', `Mon idée : ${prod.idea || ''}`);
  } else if (prod.mode === 'idees') {
    L.push('', 'OPTION 1 — propose 10 scénarios. Pour CETTE réponse uniquement, le format est :', '', IDEA_FORMAT(1), '',
      'Les dix idées restent dans un même style qui marche (histoires humaines simples, gros enjeu, hook visuel fort), pas dix univers éparpillés.',
      'Écris pour quelqu\'un qui choisit en 5 secondes : des phrases courtes, claires, sans jargon, sans répéter le titre dans l\'histoire.',
      prod.idea ? `Ce que je veux : ${prod.idea}` : '');
  } else if (prod.mode === 'suite') {
    L.push('', `SUITE — écris la PARTIE ${prod.part} de cette histoire, cohérente avec les parties précédentes (mêmes personnages, mêmes voix, même règle du monde, aucune nouvelle magie). Elle démarre sur la réponse au cliffhanger précédent et se termine sur un nouveau cliffhanger.`,
      prod.idea ? `Ce que je veux dans cette partie : ${prod.idea}` : '', '', 'Mémoire de la série :', prevBible || '(aucune mémoire enregistrée : appuie-toi sur le titre et invente la suite la plus logique)');
    if (prevScript) L.push('', 'LA MÉMOIRE COMPLÈTE DE LA SÉRIE EST JOINTE (« histoire-precedente.txt ») : le résumé de chaque partie déjà publiée, puis le SCRIPT EXACT de la dernière, scène par scène, avec toutes ses répliques jusqu\'à la fin. Lis-la en entier AVANT d\'écrire. Elle fait foi pour les noms, les voix et les dialogues : une transcription peut mal entendre un nom, pas ce fichier. Ta partie démarre juste après sa dernière réplique.');
    if (prevVideo) L.push('', 'LA PARTIE PRÉCÉDENTE EST JOINTE EN IMAGES : ses planches de lecture « lecture-NN.jpg » montrent TOUTE la vidéo dans l\'ordre, avec le minutage incrusté ; ses captures « capture-NN.jpg » et sa transcription sont jointes quand elles existent (et le fichier « partie-precedente.mp4 » quand le site l\'accepte). Regarde-les en entier AVANT d\'écrire. Ce n\'est PAS une vidéo à refaire : c\'est l\'épisode d\'avant. Reprends exactement ses personnages (apparence, tenue, voix, façon de parler), son décor, son ton et son rythme, et pars de la question laissée ouverte à sa dernière scène.');
  }
  if (hook && prod.mode === 'remake') L.push('', 'UNE ANALYSE DE CETTE VIDÉO PAR GEMINI EST JOINTE (« analyse-hook.txt ») : le hook des 3 premières secondes, la question qui fait rester, ce qui retient les gens. Sers-t\'en pour écrire un hook au moins aussi fort et garder ce qui fait marcher la vidéo. Si elle contredit ce que tu vois dans la vidéo, c\'est la vidéo qui a raison.');
  if (cast.length && prod.mode !== 'suite') {
    L.push('', `PERSONNAGES IMPOSÉS (choisis par l'utilisateur dans sa bibliothèque) : l'histoire se joue avec eux. Ils existent déjà : garde leur nom exact, leur apparence et leur tenue. Leur rôle, leur caractère et leur voix dans CETTE histoire, c'est toi qui les fixes. Ajoute d'autres personnages seulement si l'histoire en a besoin.${castImages ? ' Leurs planches sont jointes (« planche-nom.jpg ») : regarde-les avant d\'écrire.' : ''}`,
      ...cast.map((c) => `- "${c.name}"${c.desc ? ` : ${c.desc}` : ''}`));
  }
  if (knownPlanches.length) {
    L.push('', `Planches déjà en stock (images existantes) : ${knownPlanches.map((n) => `"${n}"`).join(', ')}.`,
      'Pour un personnage de cette liste qui garde exactement la même apparence, n\'écris PAS de bloc PLANCHE : cite simplement son nom exact dans refs. Écris une PLANCHE seulement pour un personnage nouveau ou un nouvel état (avec un nouveau nom).');
  }
  if (prod.keyText) L.push('', '# MOT FORT À L\'ÉCRAN (option choisie par l\'utilisateur)', '',
    'But : un mot-choc qui fait PARTIE DE LA SCÈNE, comme s\'il existait vraiment dans le décor : écrit sur un objet ou une surface, en volume, éclairé comme le reste. Jamais un texte plat posé par-dessus la vidéo, jamais un grand titre qui surgit d\'un coup, jamais un sous-titre.',
    'OÙ DANS LA VIDÉO — 2 scènes AU MAXIMUM : la scène 1 (le hook) et, au plus, un autre moment vraiment décisif de l\'histoire (révélation, chiffre, retournement). Toutes les autres scènes restent sans aucun texte à l\'écran.',
    'QUEL MOT — le mot le plus fort de la réplique, celui qui résume le choc : un mot, deux au grand maximum, jamais une phrase. Pistes : un lien ou un prénom (« sœur »), une couleur dont on parle (« bleus »), un verdict (« trahie », « menteur »), un secret (« enceinte »). Ce mot est PRONONCÉ dans la scène. Si c\'est un chiffre, écris-le en chiffres avec son unité, exactement comme il doit se lire (« 50 000 € », « 3 ans »), jamais en toutes lettres. Écris le mot tel qu\'il doit apparaître (casse comprise), orthographe et accents vérifiés : il sera recopié caractère pour caractère.',
    'WHEN — au moment exact où le personnage dit ce mot, il se forme dans le décor en 1 à 2 secondes, puis il reste à sa place jusqu\'à la fin du plan, pendant la réaction. Dans la description de l\'action, cite le mot entre guillemets droits à l\'instant où il est dit (ex. : exactement pendant qu\'elle dit "bleus", elle serre la photo contre elle).',
    'PLACE — SUR ou CONTRE un élément réel de la scène, lié au mot ou à celui qui parle, et jamais au même endroit d\'une scène à l\'autre : la vitre d\'un cadre photo, la porte du frigo, le mur derrière lui, le bord de la table, une fenêtre embuée, le ciel au-dessus d\'eux… Le mot suit la perspective et l\'angle de cette surface. Taille modeste : un quart à un tiers de la largeur de l\'image, bien lisible. Jamais sur un visage, jamais dans le tiers bas de l\'image (zone des légendes TikTok), jamais en bandeau, pas au centre exact par défaut.',
    'LOOK — une vraie matière en 3D qui vit dans la lumière de la scène : reflets, ombre douce sur la surface, un personnage peut passer devant. Pistes selon le ton : écriture fine en néon de verre, lettres gravées ou brûlées dans le bois, givre, braise, encre qui coule, lettres découpées dans du papier, buée sur une vitre, fumée, chrome teinté, ballon gonflé.',
    'EFFECT — il n\'apparaît jamais d\'un coup : il s\'écrit lettre par lettre avec une traînée de lumière, se grave, se couvre de givre, s\'allume comme un néon qui grésille, se dessine en fumée… avec un petit effet autour s\'il va avec le ton (étincelles, poussière lumineuse, gouttes). Varie l\'effet d\'une vidéo à l\'autre.',
    'COLOR — c\'est toi qui la choisis, et elle vient de l\'histoire : la couleur d\'un élément visible lié au mot (la sœur a les cheveux bleus → ce bleu ; une robe rouge → ce rouge ; un citron → jaune citron ; de l\'argent → vert billet ; un secret → violet nuit ; un danger → rouge sombre). Nomme la teinte précisément (deep cobalt blue, pas seulement blue). Pas de couleur par défaut : pas de jaune ni de doré sauf si l\'histoire le demande ; deux mots de la même vidéo n\'ont pas la même couleur sauf si l\'histoire le justifie ; la teinte se détache du décor.',
    'COMMENT L\'ÉCRIRE — dans le prompt vidéo de ces scènes-là, ajoute une ligne à part, exactement sous cette forme, les cinq rubriques rédigées en anglais :',
    'MOT FORT À L\'ÉCRAN : « le mot » — COLOR: … ; LOOK: … ; PLACE: … ; EFFECT: … ; WHEN: …',
    'Exemple : MOT FORT À L\'ÉCRAN : « bleus » — COLOR: deep cobalt blue, the exact blue of her sister\'s hair ; LOOK: thin glass-neon handwriting with real depth, catching the warm kitchen light, a soft blue reflection on the frame ; PLACE: written across the glass of the photo frame she holds, following its angle ; EFFECT: writes itself letter by letter with a soft light trail, a few tiny blue sparkles fade around it ; WHEN: exactly as she says "bleus", then it stays on the frame until the end of the shot',
    'Les images de scène ne contiennent jamais de texte.');
  else L.push('', '# AUCUN TEXTE À L\'ÉCRAN', '',
    'L\'option « Mot fort à l\'écran » n\'est PAS cochée : aucun mot, titre, chiffre ni lettre ne s\'affiche dans les vidéos. N\'écris aucune ligne « MOT FORT À L\'ÉCRAN » et ne décris jamais un mot ou un texte qui apparaît à l\'écran, même si la vidéo d\'origine ou la partie précédente en montrait : cette vidéo-ci est entièrement sans texte. Les répliques s\'entendent, elles ne s\'écrivent jamais.');
  if (extra && extra.trim()) L.push('', 'Consignes en plus :', extra.trim());
  return L.filter((x) => x !== undefined).join('\n');
}

/* La phrase tapée dans Claude : tout le reste est dans les fichiers joints */
export function shortMessage(prod, metaAttached = true) {
  const what = { remake: 'OPTION 3, refaire une vidéo virale', idee: 'OPTION 2, mon idée', idees: 'OPTION 1, dix idées', suite: `SUITE, partie ${prod.part}` }[prod.mode];
  return `Demande FruitRadar (${what}). ${metaAttached ? 'Lis d\'abord metaprompt.txt en entier, puis demande.txt' : 'Applique le métaprompt de ce projet, puis lis demande.txt'} : ce fichier contient l'annexe de mise en forme et la demande. Réponds exactement au format que demande.txt impose, dans un seul bloc de code, sans artefact et sans autre texte.`;
}

/* Format d'une idée : des champs nommés, pour l'afficher proprement en carte */
const IDEA_FORMAT = (from) => [
  `@@IDEE n="${from}"@@`,
  'TITRE : [le titre de la vidéo, accrocheur, qui se comprend tout seul]',
  'ACCROCHE : [ce qu\'on voit ou entend dans les 2 premières secondes, qui scotche]',
  'HISTOIRE : [3 ou 4 phrases simples : qui sont les personnages, ce qui se passe, le retournement, la fin qui donne envie de la suite]',
  'PERSONNAGES : [Nom (fruit ou légume, rôle) ; Nom (…, rôle)]',
  'POURQUOI ÇA PEUT PERCER : [une phrase]',
  'PARTIES : [nombre de parties possibles, un chiffre]',
  '@@FIN@@', `(dix blocs IDEE numérotés de ${from} à ${from + 9}, puis la ligne @@CHOIX@@ et rien d'autre)`
].join('\n');
/* ---------- Une idée modifiée par l'utilisateur avant de la choisir : titre, accroche, histoire, personnages (nom + qui c'est, à quoi il ressemble) ---------- */
const oneLine = (x, max) => String(x ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
export const parseCast = (s) => String(s || '').split(/\s*[;•|]\s*/).map((c) => c.trim()).filter(Boolean)
  .map((c) => { const m = c.match(/^([^(]+)\(([^)]*)\)\s*$/); return m ? { name: m[1].trim(), role: m[2].trim() } : { name: c, role: '' }; });
export const castLine = (cast) => (cast || []).map((c) => (c.role ? `${c.name} (${c.role})` : c.name)).join(' ; ');
export function cleanIdeaEdit(e) {
  if (!e || typeof e !== 'object') return null;
  // les parenthèses et points-virgules servent de séparateurs dans « Nom (qui c'est) ; Nom (…) » : dans un nom ou une description, ils deviennent des virgules
  const role = (r) => oneLine(r, 200).replace(/\s*\(\s*/g, ', ').replace(/\s*\)\s*/g, ' ').replace(/\s*[|•;]\s*/g, ', ').replace(/\s*,(\s*,)+/g, ',').replace(/\s+,/g, ',').replace(/^[,\s]+|[,\s]+$/g, '');
  const cast = (Array.isArray(e.cast) ? e.cast : []).map((c) => ({ name: oneLine(c && c.name, 40).replace(/[();|•]/g, '').trim(), role: role(c && c.role) }))
    .filter((c) => c.name).slice(0, 10);
  const out = { titre: oneLine(e.titre, 140), accroche: oneLine(e.accroche, 300), histoire: oneLine(e.histoire, 1500), cast };
  return out.titre || out.histoire || cast.length ? out : null;
}
/* L'idée de Claude, avec les changements de l'utilisateur par-dessus */
export function applyIdeaEdit(idea, edit) {
  const e = cleanIdeaEdit(edit); if (!idea || !e) return idea;
  const histoire = e.histoire || idea.histoire || '';
  return { ...idea, titre: e.titre || idea.titre, accroche: e.accroche || idea.accroche || '', histoire, pitch: histoire, personnages: e.cast.length ? castLine(e.cast) : idea.personnages, edited: true };
}
/* Une idée en quelques lignes (reprise d'une idée déjà choisie, dans une nouvelle conversation) */
export function ideaBrief(idea) {
  const cast = parseCast(idea && idea.personnages);
  return [`${idea.titre}.`, idea.accroche ? `Les 2 premières secondes : ${idea.accroche}` : '', idea.histoire || idea.pitch || '',
    cast.length ? `Personnages : ${castLine(cast)}. Garde exactement ces noms et respecte ce qui est écrit de chacun.` : ''].filter(Boolean).join(' ');
}
export const chooseMessage = (n, note = '', edit = null) => {
  const e = cleanIdeaEdit(edit), extra = note && note.trim() ? `Précisions pour cette histoire : ${note.trim()}` : '';
  const end = 'Livre maintenant le package complet de cette histoire au format de l\'annexe (META, BIBLE, PLANCHE, SCENE, MINIATURE, DESCRIPTION, puis @@FINI@@).';
  if (!e) return `Je choisis l'idée ${n}.${extra ? ` ${extra}` : ''} ${end}`;
  return [`Je choisis l'idée ${n}, mais je l'ai modifiée : la version ci-dessous fait foi, elle remplace celle que tu as proposée.`,
    e.titre ? `TITRE : ${e.titre}` : '', e.accroche ? `ACCROCHE : ${e.accroche}` : '', e.histoire ? `HISTOIRE : ${e.histoire}` : '',
    e.cast.length ? `PERSONNAGES : ${castLine(e.cast)}` : '',
    e.cast.length ? 'Garde exactement ces noms, écrits de la même façon partout (planches, scènes, répliques, miniature, description), et respecte ce que j\'ai écrit de chacun (fruit ou légume, rôle, apparence). Ajoute un personnage seulement si l\'histoire en a vraiment besoin.' : '',
    extra, end].filter(Boolean).join('\n');
};
export const moreIdeasMessage = (from, note = '', titles = []) => [
  `Propose 10 NOUVELLES idées, numérotées de ${from} à ${from + 9}, toutes différentes de celles déjà proposées${titles.length ? ` (${titles.slice(-30).map((t) => `« ${t} »`).join(', ')})` : ''}.`,
  note && note.trim() ? `Ce que je veux cette fois : ${note.trim()}` : 'Garde le même style qui marche, avec des histoires et des retournements nouveaux.',
  'Même format exact qu\'avant :', '', IDEA_FORMAT(from)
].join('\n');
export const continueMessage = (missing) => (missing && missing.length
  ? `SUITE. Il manque encore : ${missing.join(' ; ')}. Livre uniquement ces blocs, au même format, dans un seul bloc de code, puis @@FINI@@.`
  : 'SUITE');

/* ---------- Lecture de la réponse ---------- */
const MARK = /^\s*@@\s*([A-ZÉÈ_]+)\b(.*?)@@\s*$/;
const ATTR = /([a-z_]+)\s*=\s*(?:"([^"]*)"|“([^”]*)”|([^\s"]+))/g;
export const normName = (s) => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const splitRefs = (s) => String(s || '').split('|').map((x) => x.trim()).filter(Boolean);

export function emptyPackage() {
  return { meta: {}, bible: '', planches: [], scenes: [], miniature: null, description: '', ideas: [], done: false, more: false, choice: false };
}

const IDEA_KEYS = [['titre', /^titre$/], ['accroche', /^(accroche|hook)$/], ['histoire', /^(histoire|resume|pitch|synopsis)$/], ['personnages', /^(personnages?|casting)$/], ['pourquoi', /^pourquoi/], ['parties', /^(parties|nombre de parties)$/]];
function parseIdea(n, attrs, lines) {
  const out = { n, titre: (attrs.titre || '').trim(), accroche: '', histoire: '', personnages: '', pourquoi: '', parties: '' };
  let key = null; const rest = [];
  for (const raw of lines) {
    const m = raw.match(/^\s*[-*•]?\s*\**([A-Za-zÀ-ÿ' ]{3,32}?)\**\s*:\s*(.*)$/);
    const k = m && IDEA_KEYS.find(([, re]) => re.test(normName(m[1])));
    if (k) { key = k[0]; out[key] = m[2].trim(); continue; }
    if (key && raw.trim()) out[key] += (out[key] ? ' ' : '') + raw.trim();
    else if (raw.trim()) rest.push(raw.trim());
  }
  if (!out.histoire && rest.length) out.histoire = rest.join(' ');
  out.titre = out.titre.replace(/^["«\s]+|["»\s]+$/g, '') || `Idée ${n}`;
  out.parties = (String(out.parties).match(/\d+/) || [''])[0];
  out.pitch = out.histoire; // ancien nom
  return out;
}
export function parsePackage(text) {
  const pkg = emptyPackage();
  const lines = String(text || '').replace(/\r/g, '').split('\n');
  let cur = null, field = null;
  const push = (line) => { if (cur && field) cur.buf[field].push(line); };
  const close = () => {
    if (!cur) return;
    const get = (k) => (cur.buf[k] || []).join('\n').trim();
    const a = cur.attrs;
    if (cur.type === 'META') {
      for (const l of cur.buf.body) { const m = l.match(/^\s*([a-zé_]+)\s*:\s*(.+)$/i); if (m) pkg.meta[normName(m[1]).replace(/ /g, '_')] = m[2].trim(); }
    } else if (cur.type === 'BIBLE') pkg.bible = get('body');
    else if (cur.type === 'PLANCHE') { if (a.nom && get('body')) pkg.planches.push({ name: a.nom.trim(), prompt: get('body') }); }
    else if (cur.type === 'SCENE') {
      const n = parseInt(a.n, 10), image = get('IMAGE'), video = get('VIDEO');
      if (Number.isFinite(n) && image && video) {
        const mt = {};
        for (const l of cur.buf.MONTAGE || []) { const m = l.match(/^\s*(fin|suivant|montage)\s*:\s*(.+)$/i); if (m) mt[m[1].toLowerCase()] = m[2].trim(); }
        pkg.scenes.push({ n, duree: parseInt(a.duree, 10) || 6, refs: splitRefs(a.refs), titre: a.titre || '', version: a.version || '', image, video, montage: mt });
      }
    } else if (cur.type === 'MINIATURE') { if (get('body')) pkg.miniature = { refs: splitRefs(a.refs), prompt: get('body') }; }
    else if (cur.type === 'DESCRIPTION') pkg.description = get('body');
    else if (cur.type === 'IDEE') { const n = parseInt(a.n, 10); if (Number.isFinite(n)) pkg.ideas.push(parseIdea(n, a, cur.buf.body)); }
    cur = null; field = null;
  };
  for (const raw of lines) {
    const m = raw.match(MARK);
    if (!m) { push(raw); continue; }
    const type = m[1];
    if (type === 'FIN') { close(); continue; }
    if (type === 'FINI') { cur = null; pkg.done = true; continue; }
    if (type === 'SUITE') { cur = null; pkg.more = true; continue; }
    if (type === 'CHOIX') { cur = null; pkg.choice = true; continue; }
    if (cur && cur.type === 'SCENE' && (type === 'IMAGE' || type === 'VIDEO' || type === 'MONTAGE')) { field = type; cur.buf[type] = []; continue; }
    if (['META', 'BIBLE', 'PLANCHE', 'SCENE', 'MINIATURE', 'DESCRIPTION', 'IDEE'].includes(type)) {
      // un bloc ouvert sans @@FIN@@ avant le suivant : coupé, on l'ignore (il sera redemandé)
      const attrs = {};
      for (const am of m[2].matchAll(ATTR)) attrs[am[1]] = am[2] ?? am[3] ?? am[4] ?? '';
      cur = { type, attrs, buf: { body: [] } };
      field = type === 'SCENE' ? null : 'body';
    }
  }
  return pkg;
}

/* Fusionne une réponse dans le package en cours (la version la plus récente d'un bloc gagne) */
export function mergePackage(base, add) {
  const out = base ? JSON.parse(JSON.stringify(base)) : emptyPackage();
  Object.assign(out.meta, add.meta);
  if (add.bible) out.bible = add.bible;
  for (const p of add.planches) { const i = out.planches.findIndex((x) => normName(x.name) === normName(p.name)); if (i >= 0) out.planches[i] = { ...out.planches[i], ...p }; else out.planches.push(p); }
  for (const s of add.scenes) { const i = out.scenes.findIndex((x) => x.n === s.n); if (i >= 0) out.scenes[i] = { ...out.scenes[i], ...s }; else out.scenes.push(s); }
  out.scenes.sort((a, b) => a.n - b.n);
  if (add.miniature) out.miniature = { ...(out.miniature || {}), ...add.miniature };
  if (add.description) out.description = add.description;
  if (add.ideas.length) out.ideas = add.ideas;
  out.done = out.done || add.done; out.more = add.more; out.choice = out.choice || add.choice;
  return out;
}

/* Ce qui manque pour lancer la production. known = noms des planches déjà en stock. */
export function missingParts(pkg, known = []) {
  const miss = [];
  if (!pkg.meta.titre) miss.push('le bloc META');
  if (!pkg.scenes.length) { miss.push('toutes les scènes'); return miss; }
  const max = Math.max(...pkg.scenes.map((s) => s.n));
  const holes = [];
  for (let i = 1; i <= max; i++) if (!pkg.scenes.some((s) => s.n === i)) holes.push(i);
  if (holes.length) miss.push(`les scènes ${holes.join(', ')}`);
  if (!pkg.done && !holes.length) miss.push(`les scènes après la ${max} s'il en reste`);
  const have = new Set([...pkg.planches.map((p) => normName(p.name)), ...known.map(normName)]);
  const lost = new Set();
  for (const s of pkg.scenes) for (const r of s.refs) if (!have.has(normName(r))) lost.add(r);
  if (pkg.miniature) for (const r of pkg.miniature.refs) if (!have.has(normName(r))) lost.add(r);
  if (lost.size) miss.push(`les planches ${[...lost].map((x) => `"${x}"`).join(', ')}`);
  const bad = pkg.scenes.filter((s) => !DURATIONS.includes(s.duree)).map((s) => s.n);
  if (bad.length) miss.push(`une durée de 6, 10 ou 15 s pour les scènes ${bad.join(', ')} (renvoie ces scènes en entier)`);
  if (!pkg.miniature) miss.push('le bloc MINIATURE');
  if (!pkg.description) miss.push('le bloc DESCRIPTION');
  if (!pkg.bible) miss.push('le bloc BIBLE');
  return miss;
}

export const totalDuration = (pkg) => pkg.scenes.reduce((a, s) => a + (s.duree || 0), 0);

export const slug = (s) => normName(s).replace(/ /g, '-').slice(0, 48) || 'video';

/* Texte lisible du package (export, copie) */
export function packageToText(pkg) {
  const L = [`# ${pkg.meta.titre || 'Sans titre'} — partie ${pkg.meta.partie || '?'}`, ''];
  for (const p of pkg.planches) L.push(`## PLANCHE — ${p.name}`, '', p.prompt, '');
  for (const s of pkg.scenes) {
    L.push(`## SCÈNE ${s.n} — ${s.titre} — ${s.duree} s`, `Références : ${s.refs.join(', ') || '—'}`, '', '### Prompt image', '', s.image, '', `### Prompt vidéo (${s.duree} s)`, '', s.video, '');
    if (s.montage && (s.montage.fin || s.montage.montage)) L.push(`Montage : ${[s.montage.fin, s.montage.suivant, s.montage.montage].filter(Boolean).join(' → ')}`, '');
  }
  if (pkg.miniature) L.push('## MINIATURE', '', pkg.miniature.prompt, '');
  if (pkg.description) L.push('## DESCRIPTION TIKTOK', '', pkg.description, '');
  return L.join('\n');
}

/* Refus de ChatGPT / Grok (modération) : on adoucit le prompt sans changer l'histoire.
   Niveau 1 : mots qui déclenchent les filtres remplacés + consigne « tout public ».
   Niveau 2 : en plus, les gestes brusques deviennent des émotions jouées par les expressions. */
const SOFT1 = [
  [/\b(sang|sanglant(e|s|es)?|ensanglant\w*)\b/gi, 'jus rouge'], [/\bsaign\w*/gi, 'coule du jus'],
  [/\b(poignard\w*|couteau\w*|lame\w*|machette\w*|hache\w*)\b/gi, 'ustensile'], [/\b(pistolet\w*|fusil\w*|revolver\w*|arme\w*)\b/gi, 'objet'],
  [/\b(tu(e|es|er|é|ée|ent)|assassin\w*|meurtr\w*)\b/gi, 'trahit'], [/\b(mort(e|s|es)?|cadavre\w*|décéd\w*)\b/gi, 'évanoui'],
  [/\b(bless(é|ée|és|ure|ures|er)|plaie\w*)\b/gi, 'égratigné'], [/\b(gifl\w*|frapp\w*|cogn\w*|tabass\w*|coup de poing|coups de poing)\b/gi, 'bouscule'],
  [/\b(étrangl\w*|égorg\w*|décapit\w*|écras\w*)\b/gi, 'menace'], [/\b(drogu\w*|cocaïne|héroïne)\b/gi, 'potion'], [/\b(alcool\w*|ivre|bourré\w*)\b/gi, 'jus pétillant'],
  [/\b(cigarette\w*|clope\w*)\b/gi, 'paille'], [/\b(nu|nue|nus|nues|déshabill\w*|sexy|sensuel\w*)\b/gi, 'élégant'], [/\b(viol|viols|viol(é|ée|és|ées|er)|abus\w*)\b/gi, 'trahison'],
  [/\b(suicid\w*)\b/gi, 'désespoir'], [/\b(enfant|bébé|petit(e)? fille|petit garçon)s?\b/gi, 'petit fruit']
];
const SOFT2 = [
  [/\b(hurl\w*|cri(e|ent|er|ant))\b/gi, 'parle fort'], [/\b(violent(e|s|es)?|violemment|brutal\w*)\b/gi, 'intense'], [/\b(pousse|poussé|bouscule)\b/gi, 'tire doucement'],
  [/\b(détrui\w*|cass\w*|explos\w*)\b/gi, 'renverse'], [/\b(peur panique|terroris\w*|horreur)\b/gi, 'inquiétude'], [/\b(larmes de sang)\b/gi, 'grosses larmes']
];
// \b ne connaît pas les accents : on refait les frontières de mots avec les lettres Unicode
const fix = (list) => list.map(([re, by]) => { const src = re.source; const parts = src.split('\\b'); return [new RegExp(parts.map((x, i) => i === 0 ? x : (i === parts.length - 1 && x === '' ? '(?![\\p{L}\\d])' : (i % 2 ? '(?<![\\p{L}\\d])' : '(?![\\p{L}\\d])') + x)).join(''), 'giu'), by]; });
const S1 = fix(SOFT1), S2 = fix(SOFT2);
export function soften(text, level = 1, kind = 'image') {
  let t = String(text || '');
  for (const [re, by] of S1) t = t.replace(re, by);
  if (level >= 2) for (const [re, by] of S2) t = t.replace(re, by);
  const head = kind === 'video'
    ? 'Animation 3D tout public, style film d\'animation familial. Aucune violence, aucun contact brutal : les émotions passent par les expressions du visage, les gestes et la voix.'
    : 'Illustration 3D tout public, style film d\'animation familial. Aucune violence ni blessure visible : les émotions passent par les expressions et les postures.';
  return `${head}${level >= 2 ? ' Scène sobre et bienveillante, sans rien de choquant.' : ''}\n\n${t}`;
}

/* ---------- Contrôle du métaprompt V6 sur les prompts vidéo ----------
   On ne se fie pas à Claude : chaque prompt vidéo est relu avec les règles VERROUILLÉES du métaprompt qu'on peut vérifier à coup sûr.
   Si une règle n'est pas respectée, on redemande ces scènes-là à Claude (puis on corrige à la main ce qui est mécanique). */
/* Styles de personnages proposés au lancement. « opening » remplace le type de personnages dans la phrase d'ouverture V6 des prompts vidéo. */
export const STYLES = {
  fruits: { label: 'Fruits', short: 'Fruits et légumes humanoïdes réalistes', opening: 'semi-realistic textured fruit-and-vegetable characters',
    brief: 'Fruits et légumes humanoïdes réalistes et texturés (le style habituel du métaprompt).' },
  porcelaine: { label: 'Fruits cristal', short: 'Cristal vivant très brillant, façon pierre précieuse', opening: 'luminous translucent living-crystal gemstone fruit-and-vegetable characters, glossy like blown glass with a soft inner glow',
    look: 'RENDU MATIÈRE OBLIGATOIRE (haut de gamme) : chaque personnage est fait d\'une matière de cristal vivant, translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours. Rendu très lumineux, net et premium, digne d\'une affiche de film d\'animation ; jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque ; matière parfaitement intacte. Les vêtements restent en vrais tissus opaques.',
    brief: 'Fruits et légumes humanoïdes en CRISTAL VIVANT, rendu haut de gamme : le corps entier de chaque personnage (visage, torse, bras, mains, jambes) est fait d\'une matière translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours. Le fruit ou le légume forme la chevelure, en fibres ou en facettes de cristal scintillantes. Chaque personnage a SA pierre précieuse, écrite dans sa planche et dans chaque prompt image (saphir, rubis, émeraude, améthyste, citrine, tourmaline rose, quartz rose, ambre, jade, topaze, aigue-marine…) ; deux personnages d\'une même scène n\'ont jamais la même. La matière reste souple, lisse et vivante sur le visage, parfaitement intacte, sans fissure. Grands yeux lumineux avec catchlights, visages très beaux qu\'on aime au premier regard, vêtements en vrais tissus opaques. Jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque. Écris cette matière en toutes lettres pour chaque personnage dans chaque planche et chaque prompt image.' },
  bubbletea: { label: 'Bubble tea', cast: 'des gobelets de bubble tea humanoïdes', short: 'Gobelets de bubble tea fruités, avec le liquide', opening: 'semi-realistic fruity bubble-tea cup characters with visible liquid and tapioca pearls inside',
    brief: 'Personnages BUBBLE TEA : chaque personnage est un gobelet de bubble tea humanoïde au parfum d\'un fruit (couleur, motifs et morceaux du fruit), corps transparent rempli de thé au lait ou de jus coloré qui bouge avec eux, perles de tapioca visibles à l\'intérieur, couvercle bombé et paille comme coiffure, bras et jambes, visage expressif sur le gobelet. Le nom de chaque personnage vient de son fruit.' },
  bubbletea_porcelaine: { label: 'Bubble tea cristal', cast: 'des gobelets de bubble tea humanoïdes', short: 'Bubble tea en cristal vivant très brillant', opening: 'luminous translucent living-crystal bubble-tea cup characters, glossy like blown glass, with visible liquid and tapioca pearls inside',
    look: 'RENDU MATIÈRE OBLIGATOIRE (haut de gamme) : chaque personnage est fait d\'une matière de cristal vivant, translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours. Rendu très lumineux, net et premium, digne d\'une affiche de film d\'animation ; jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque ; matière parfaitement intacte. Les vêtements restent en vrais tissus opaques.',
    brief: 'Personnages BUBBLE TEA en CRISTAL VIVANT, rendu haut de gamme : gobelets de bubble tea humanoïdes au parfum d\'un fruit, dont le gobelet, le couvercle et la paille sont faits d\'une matière translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours, avec le thé ou le jus coloré et les perles de tapioca visibles à l\'intérieur. Visage expressif, bras et jambes. Chaque personnage a SA pierre précieuse, écrite dans sa planche et dans chaque prompt image (saphir, rubis, émeraude, améthyste, citrine, tourmaline rose, quartz rose, ambre, jade, topaze, aigue-marine…) ; deux personnages d\'une même scène n\'ont jamais la même. La matière reste souple, lisse et vivante sur le visage, parfaitement intacte, sans fissure. Grands yeux lumineux avec catchlights, visages très beaux qu\'on aime au premier regard, vêtements en vrais tissus opaques. Jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque. Écris cette matière en toutes lettres pour chaque personnage dans chaque planche et chaque prompt image.' },
  oiseaux: { label: 'Oiseaux', cast: 'des oiseaux humanoïdes', short: 'Autruche, pigeon, oie… avec un bec et des dents', opening: 'semi-realistic textured humanoid bird characters with beaks full of human-like teeth',
    brief: 'OISEAUX humanoïdes réalistes à la place des fruits : autruche, pigeon, oie, canard, poule, dinde, mouette, flamant, perroquet… Plumes texturées, habillés comme des humains, BEC avec des DENTS humaines bien visibles quand ils parlent ou crient. Le nom de chaque personnage vient de son espèce. Toutes les autres règles du métaprompt s\'appliquent comme pour les fruits.' },
  oiseaux_porcelaine: { label: 'Oiseaux cristal', cast: 'des oiseaux humanoïdes', short: 'Oiseaux en cristal vivant, bec et dents', opening: 'luminous translucent living-crystal humanoid bird characters, glossy like blown glass, with beaks full of human-like teeth',
    look: 'RENDU MATIÈRE OBLIGATOIRE (haut de gamme) : chaque personnage est fait d\'une matière de cristal vivant, translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours. Rendu très lumineux, net et premium, digne d\'une affiche de film d\'animation ; jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque ; matière parfaitement intacte. Les vêtements restent en vrais tissus opaques.',
    brief: 'OISEAUX humanoïdes en CRISTAL VIVANT, rendu haut de gamme, à la place des fruits : autruche, pigeon, oie, canard, poule, flamant… Plumes sculptées dans une matière translucide et très brillante comme du verre soufflé ou une pierre précieuse polie, éclairée de l\'intérieur par une douce lueur de sa couleur, avec une forte diffusion sous-surfacique, des reflets spéculaires nets, de minuscules paillettes scintillantes prises dans la matière et des reflets prismatiques arc-en-ciel sur les contours, habillés comme des humains, BEC avec des DENTS humaines bien visibles quand ils parlent. Chaque personnage a SA pierre précieuse, écrite dans sa planche et dans chaque prompt image (saphir, rubis, émeraude, améthyste, citrine, tourmaline rose, quartz rose, ambre, jade, topaze, aigue-marine…) ; deux personnages d\'une même scène n\'ont jamais la même. La matière reste souple, lisse et vivante sur le visage, parfaitement intacte, sans fissure. Grands yeux lumineux avec catchlights, visages très beaux qu\'on aime au premier regard, vêtements en vrais tissus opaques. Jamais de porcelaine mate, jamais d\'aspect plastique, laiteux ou opaque. Écris cette matière en toutes lettres pour chaque personnage dans chaque planche et chaque prompt image. Toutes les autres règles du métaprompt s\'appliquent comme pour les fruits.' },
  fruits_humains: { label: 'Fruits très humains', short: 'Anatomie humaine marquée, zéro effet mascotte', opening: 'semi-realistic textured fruit-and-vegetable characters with strongly human anatomy, defined faces and proportions', v6: true,
    matiere: 'anatomie humaine renforcée : tête bien proportionnée, cou visible, nez, pommettes et mâchoire dessinés, membres humains, expressions nuancées ; les couleurs, textures et contours du fruit restent lisibles sur la tête et la peau ; jamais d\'aspect mascotte.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : anatomie humaine renforcée : tête bien proportionnée, cou visible, nez, pommettes et mâchoire dessinés, membres humains, expressions nuancées ; les couleurs, textures et contours du fruit restent lisibles sur la tête et la peau ; jamais d\'aspect mascotte.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : anatomie humaine renforcée : tête bien proportionnée, cou visible, nez, pommettes et mâchoire dessinés, membres humains, expressions nuancées ; les couleurs, textures et contours du fruit restent lisibles sur la tête et la peau ; jamais d\'aspect mascotte.' },
  diamant: { label: 'Fruits diamant', short: 'Peau en diamant coloré taillé, à facettes', opening: 'semi-realistic fruit-and-vegetable characters whose skin is faceted colored diamond with crisp edges and inner refraction', v6: true,
    matiere: 'toute la peau visible (visage, cou, mains, jambes) est un diamant coloré taillé : facettes géométriques translucides, arêtes nettes, profondeur cristalline, réfractions internes et éclats de lumière ; facettes plus fines autour des yeux et de la bouche pour garder toute l\'expressivité ; la couleur est celle du fruit de chaque personnage ; les vêtements restent en tissu.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : toute la peau visible (visage, cou, mains, jambes) est un diamant coloré taillé : facettes géométriques translucides, arêtes nettes, profondeur cristalline, réfractions internes et éclats de lumière ; facettes plus fines autour des yeux et de la bouche pour garder toute l\'expressivité ; la couleur est celle du fruit de chaque personnage ; les vêtements restent en tissu.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : toute la peau visible (visage, cou, mains, jambes) est un diamant coloré taillé : facettes géométriques translucides, arêtes nettes, profondeur cristalline, réfractions internes et éclats de lumière ; facettes plus fines autour des yeux et de la bouche pour garder toute l\'expressivité ; la couleur est celle du fruit de chaque personnage ; les vêtements restent en tissu.' },
  liquide: { label: 'Fruits à cœur liquide', short: 'Enveloppe transparente remplie de jus coloré', opening: 'semi-realistic fruit-and-vegetable characters made of a thin transparent shell filled with colored juice, bubbles and floating seeds', v6: true,
    matiere: 'la tête et toute la peau visible sont une fine enveloppe transparente remplie de jus à la couleur du fruit : niveau de liquide lisible, poche d\'air, petites bulles et quelques graines en suspension ; le visage est modelé dans la paroi ; réfractions crédibles, lumière qui traverse le liquide ; cou, mains et membres visibles sont dans la même matière.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la tête et toute la peau visible sont une fine enveloppe transparente remplie de jus à la couleur du fruit : niveau de liquide lisible, poche d\'air, petites bulles et quelques graines en suspension ; le visage est modelé dans la paroi ; réfractions crédibles, lumière qui traverse le liquide ; cou, mains et membres visibles sont dans la même matière.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la tête et toute la peau visible sont une fine enveloppe transparente remplie de jus à la couleur du fruit : niveau de liquide lisible, poche d\'air, petites bulles et quelques graines en suspension ; le visage est modelé dans la paroi ; réfractions crédibles, lumière qui traverse le liquide ; cou, mains et membres visibles sont dans la même matière.' },
  givres: { label: 'Fruits givrés', short: 'Voile de givre et petits cristaux de glace', opening: 'semi-realistic fruit-and-vegetable characters with a frosted skin, a thin veil of frost and tiny ice crystals', v6: true,
    matiere: 'la matière du fruit est givrée : surface fraîche légèrement translucide, fin voile de givre et petits cristaux de glace sur la peau, les contours et les feuilles ; reflets froids, couleur du fruit toujours reconnaissable ; le givre ne cache ni les yeux ni les expressions. C\'est une matière, pas un décor d\'hiver : l\'histoire et les tenues restent libres.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la matière du fruit est givrée : surface fraîche légèrement translucide, fin voile de givre et petits cristaux de glace sur la peau, les contours et les feuilles ; reflets froids, couleur du fruit toujours reconnaissable ; le givre ne cache ni les yeux ni les expressions. C\'est une matière, pas un décor d\'hiver : l\'histoire et les tenues restent libres.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la matière du fruit est givrée : surface fraîche légèrement translucide, fin voile de givre et petits cristaux de glace sur la peau, les contours et les feuilles ; reflets froids, couleur du fruit toujours reconnaissable ; le givre ne cache ni les yeux ni les expressions. C\'est une matière, pas un décor d\'hiver : l\'histoire et les tenues restent libres.' },
  nacres: { label: 'Fruits nacrés', short: 'Fini perlé, irisations douces', opening: 'semi-realistic fruit-and-vegetable characters with a smooth pearlescent mother-of-pearl skin and soft iridescence', v6: true,
    matiere: 'la peau du fruit a un fini de nacre, lisse et lumineux : couches perlées, irisations subtiles qui changent avec l\'angle, reflets doux ; la couleur de chaque fruit reste perceptible sous la nacre ; ni facettes de diamant, ni métal miroir.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la peau du fruit a un fini de nacre, lisse et lumineux : couches perlées, irisations subtiles qui changent avec l\'angle, reflets doux ; la couleur de chaque fruit reste perceptible sous la nacre ; ni facettes de diamant, ni métal miroir.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la peau du fruit a un fini de nacre, lisse et lumineux : couches perlées, irisations subtiles qui changent avec l\'angle, reflets doux ; la couleur de chaque fruit reste perceptible sous la nacre ; ni facettes de diamant, ni métal miroir.' },
  fruits_porcelaine: { label: 'Fruits en porcelaine', short: 'Porcelaine émaillée, motifs peints', opening: 'semi-realistic fruit-and-vegetable characters with glazed porcelain skin and delicate painted botanical patterns', v6: true,
    matiere: 'la peau du fruit est en porcelaine émaillée : reliefs du visage finement moulés, reflets de glaçure et délicats motifs botaniques peints, propres à l\'espèce de chaque personnage ; formes de fruits reconnaissables, couleurs harmonieuses, détails de céramique crédibles.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la peau du fruit est en porcelaine émaillée : reliefs du visage finement moulés, reflets de glaçure et délicats motifs botaniques peints, propres à l\'espèce de chaque personnage ; formes de fruits reconnaissables, couleurs harmonieuses, détails de céramique crédibles.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la peau du fruit est en porcelaine émaillée : reliefs du visage finement moulés, reflets de glaçure et délicats motifs botaniques peints, propres à l\'espèce de chaque personnage ; formes de fruits reconnaissables, couleurs harmonieuses, détails de céramique crédibles.' },
  metal: { label: 'Fruits métalliques', short: 'Métal coloré poli ou brossé', opening: 'semi-realistic fruit-and-vegetable characters with colored polished or brushed metal skin, never robotic', v6: true,
    matiere: 'la peau du fruit est en métal coloré, à la couleur de l\'espèce : surfaces polies ou brossées, reflets physiquement justes, nuances riches ; visage expressif sculpté dans le métal, tige et feuilles reconnaissables ; vêtements en vrais tissus ; le corps reste humanoïde et vivant, jamais un robot mécanique.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la peau du fruit est en métal coloré, à la couleur de l\'espèce : surfaces polies ou brossées, reflets physiquement justes, nuances riches ; visage expressif sculpté dans le métal, tige et feuilles reconnaissables ; vêtements en vrais tissus ; le corps reste humanoïde et vivant, jamais un robot mécanique.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la peau du fruit est en métal coloré, à la couleur de l\'espèce : surfaces polies ou brossées, reflets physiquement justes, nuances riches ; visage expressif sculpté dans le métal, tige et feuilles reconnaissables ; vêtements en vrais tissus ; le corps reste humanoïde et vivant, jamais un robot mécanique.' },
  lumineux: { label: 'Fruits lumineux', short: 'Graines et veines qui brillent doucement', opening: 'semi-realistic fruit-and-vegetable characters with softly glowing seeds and fine bioluminescent veins in their skin', v6: true,
    matiere: 'la peau du fruit porte des graines lumineuses et de très fines veines bioluminescentes : lueur douce, intégrée à la matière et accordée à la couleur de l\'espèce, qui ne cache pas la texture fraîche du fruit et ne surexpose jamais les expressions.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la peau du fruit porte des graines lumineuses et de très fines veines bioluminescentes : lueur douce, intégrée à la matière et accordée à la couleur de l\'espèce, qui ne cache pas la texture fraîche du fruit et ne surexpose jamais les expressions.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la peau du fruit porte des graines lumineuses et de très fines veines bioluminescentes : lueur douce, intégrée à la matière et accordée à la couleur de l\'espèce, qui ne cache pas la texture fraîche du fruit et ne surexpose jamais les expressions.' },
  marbre: { label: 'Fruits en marbre', short: 'Marbre poli coloré, fines veines', opening: 'semi-realistic fruit-and-vegetable characters with colored polished marble skin and fine mineral veins', v6: true,
    matiere: 'la peau du fruit est en marbre poli coloré : fines veines minérales, profondeur naturelle, reflets satinés ; silhouettes de fruits reconnaissables, visages expressifs finement sculptés ; les vêtements restent en tissu.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus, pour la matière seulement : la peau du fruit est en marbre poli coloré : fines veines minérales, profondeur naturelle, reflets satinés ; silhouettes de fruits reconnaissables, visages expressifs finement sculptés ; les vêtements restent en tissu.',
    brief: 'Les personnages restent les fruits et légumes humanoïdes du métaprompt, décrits et proportionnés exactement comme il le demande. Seule leur MATIÈRE change : la peau du fruit est en marbre poli coloré : fines veines minérales, profondeur naturelle, reflets satinés ; silhouettes de fruits reconnaissables, visages expressifs finement sculptés ; les vêtements restent en tissu.' },
  cafe: { label: 'Tasses de café', short: 'Tête en tasse de café, café visible', opening: 'semi-realistic humanoid characters with a ceramic coffee-cup head, visible coffee and foam on top', v6: true, espece: 'une tasse de café',
    matiere: 'céramique de tasse, avec son anse, et le café visible au sommet (mousse, crème, motif) ; visage expressif sculpté dans la céramique ; cou, mains et peau visible assortis à la tasse ; formes de tasses, cafés, mousses et couleurs différents d\'un personnage à l\'autre.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus : les personnages ne sont pas des fruits ni des légumes ; la tête de chacun est une tasse de café. Matière : céramique de tasse, avec son anse, et le café visible au sommet (mousse, crème, motif) ; visage expressif sculpté dans la céramique ; cou, mains et peau visible assortis à la tasse ; formes de tasses, cafés, mousses et couleurs différents d\'un personnage à l\'autre.',
    brief: 'ESPÈCE DU STYLE : à la place des fruits et légumes, chaque personnage est un humanoïde dont la tête est une tasse de café. Matière : céramique de tasse, avec son anse, et le café visible au sommet (mousse, crème, motif) ; visage expressif sculpté dans la céramique ; cou, mains et peau visible assortis à la tasse ; formes de tasses, cafés, mousses et couleurs différents d\'un personnage à l\'autre. Tout le reste est celui du métaprompt : rendu 3D semi-réaliste haut de gamme, corps humain habillé, proportions selon l\'âge, yeux et expressions réalistes.' },
  cafe_verre: { label: 'Cafés en verre', short: 'Tasse en verre, couches de café et de lait', opening: 'semi-realistic humanoid characters with a glass coffee-cup head showing layered coffee, milk and foam', v6: true, espece: 'une tasse en verre remplie de café',
    matiere: 'tasse en verre remplie de café : liquide, couches de lait, mousse ou glaçons visibles avec des réfractions crédibles ; visage expressif intégré au verre ; cou et mains translucides eux aussi ; tasses et boissons différentes d\'un personnage à l\'autre.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus : les personnages ne sont pas des fruits ni des légumes ; la tête de chacun est une tasse en verre remplie de café. Matière : tasse en verre remplie de café : liquide, couches de lait, mousse ou glaçons visibles avec des réfractions crédibles ; visage expressif intégré au verre ; cou et mains translucides eux aussi ; tasses et boissons différentes d\'un personnage à l\'autre.',
    brief: 'ESPÈCE DU STYLE : à la place des fruits et légumes, chaque personnage est un humanoïde dont la tête est une tasse en verre remplie de café. Matière : tasse en verre remplie de café : liquide, couches de lait, mousse ou glaçons visibles avec des réfractions crédibles ; visage expressif intégré au verre ; cou et mains translucides eux aussi ; tasses et boissons différentes d\'un personnage à l\'autre. Tout le reste est celui du métaprompt : rendu 3D semi-réaliste haut de gamme, corps humain habillé, proportions selon l\'âge, yeux et expressions réalistes.' },
  the: { label: 'Thés et matcha', short: 'Tête en tasse ou bol de thé, vapeur légère', opening: 'semi-realistic humanoid characters with a teacup or tea-bowl head, visible tea and light steam', v6: true, espece: 'une tasse ou un bol de thé',
    matiere: 'tasse ou bol de thé en céramique ou en verre détaillés, boisson visible, parfois une légère vapeur ; visage expressif intégré à la matière ; cou, mains et peau visible assortis ; variétés de thé, contenants, couleurs et détails botaniques différents d\'un personnage à l\'autre.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus : les personnages ne sont pas des fruits ni des légumes ; la tête de chacun est une tasse ou un bol de thé. Matière : tasse ou bol de thé en céramique ou en verre détaillés, boisson visible, parfois une légère vapeur ; visage expressif intégré à la matière ; cou, mains et peau visible assortis ; variétés de thé, contenants, couleurs et détails botaniques différents d\'un personnage à l\'autre.',
    brief: 'ESPÈCE DU STYLE : à la place des fruits et légumes, chaque personnage est un humanoïde dont la tête est une tasse ou un bol de thé. Matière : tasse ou bol de thé en céramique ou en verre détaillés, boisson visible, parfois une légère vapeur ; visage expressif intégré à la matière ; cou, mains et peau visible assortis ; variétés de thé, contenants, couleurs et détails botaniques différents d\'un personnage à l\'autre. Tout le reste est celui du métaprompt : rendu 3D semi-réaliste haut de gamme, corps humain habillé, proportions selon l\'âge, yeux et expressions réalistes.' },
  smartphone: { label: 'Smartphones premium', short: 'Tête en smartphone, visage sur l\'écran', opening: 'semi-realistic humanoid characters with a premium smartphone head and an expressive face on the screen', v6: true, espece: 'un smartphone',
    matiere: 'smartphone haut de gamme : cadre métallique, verre et boutons crédibles, visage expressif affiché sur l\'écran ; cou et mains assortis à l\'appareil ; formes, couleurs et finitions inventées, sans copier un modèle ni une marque existants.',
    look: 'PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus : les personnages ne sont pas des fruits ni des légumes ; la tête de chacun est un smartphone. Matière : smartphone haut de gamme : cadre métallique, verre et boutons crédibles, visage expressif affiché sur l\'écran ; cou et mains assortis à l\'appareil ; formes, couleurs et finitions inventées, sans copier un modèle ni une marque existants.',
    brief: 'ESPÈCE DU STYLE : à la place des fruits et légumes, chaque personnage est un humanoïde dont la tête est un smartphone. Matière : smartphone haut de gamme : cadre métallique, verre et boutons crédibles, visage expressif affiché sur l\'écran ; cou et mains assortis à l\'appareil ; formes, couleurs et finitions inventées, sans copier un modèle ni une marque existants. Tout le reste est celui du métaprompt : rendu 3D semi-réaliste haut de gamme, corps humain habillé, proportions selon l\'âge, yeux et expressions réalistes.' },
  // Style repris de la vidéo jointe (vidéo à reproduire, ou partie précédente donnée en fichier) : c'est Claude qui le lit dans les images
  video: { label: 'Style de la vidéo', short: 'Le même que les personnages de la vidéo', opening: 'semi-realistic textured stylized humanoid characters', brief: '', fromVideo: true },
  autre: { label: 'Nouveau style', short: 'Tu le décris, tu peux l\'enregistrer', opening: 'semi-realistic textured stylized humanoid characters', brief: '' }
};
const FRUIT_PHRASE = 'semi-realistic textured fruit-and-vegetable characters';
export const styleOf = (prod) => STYLES[(prod && prod.style) || 'fruits'] || STYLES.fruits;
/* Phrase d'ouverture V6 adaptée au style choisi (le reste de la phrase ne change pas) */
export function openingFor(opening, prod) {
  const st = styleOf(prod);
  return st === STYLES.fruits || !opening.includes(FRUIT_PHRASE) ? opening : opening.replace(FRUIT_PHRASE, st.opening);
}
/* Bloc ajouté à la demande quand le style n'est pas celui par défaut */
/* Métaprompt V7 : le style passe par ses FICHES (plus de directive de style ni de phrase d'ouverture commune). */
const V7_FICHE = { fruits: 1, fruits_humains: 2, liquide: 8, diamant: 10, oiseaux: 12, oiseaux_porcelaine: 12, porcelaine: 13, bubbletea: 17, bubbletea_porcelaine: 17, cafe: 18, cafe_verre: 18, the: 18 };
function styleBlockV7(prod) {
  const st = styleOf(prod), H = '# STYLE DES PERSONNAGES (choisi par l\'utilisateur, pour toute la série)';
  if (st === STYLES.fruits) return `${H}\n\nStyle 1 Classique du métaprompt (FICHE 1).`;
  const how = (base) => ['Comment l\'appliquer — le métaprompt reste la base :',
    `- ${base} Ses champs sont recopiés dans les gabarits PLANCHE V4 et SCÈNE V4, comme le métaprompt le demande.`,
    '- Juste après le champ RENDU de chaque planche, de chaque image de scène et de la miniature, ajoute cette phrase : « Précisions de style, qui priment sur la fiche : [le style, en une ou deux phrases précises, toujours les mêmes]. »',
    '- Si le style remplace les fruits et légumes par une autre espèce ou un autre objet, les mots [FRUIT] et « fruit ou légume » des fiches se lisent avec cette espèce ; l\'histoire reste 100 % humaine (LOI HUMAINE).',
    '- Même style partout : planches, images de scène, miniature, étiquettes des prompts vidéo. Toutes les autres règles du métaprompt s\'appliquent.'];
  if (st.fromVideo) return [`${H.replace('(choisi', ': CELUI DE LA VIDÉO JOINTE (choisi')}`, '',
    'Regarde les captures (« capture-NN.jpg ») et les planches de lecture (« lecture-NN.jpg ») de la vidéo. Avant d\'écrire, identifie le style d\'apparence de ses personnages : leur espèce ou leur nature, leur matière et sa finition, le niveau de réalisme, les proportions du corps, la façon dont ils sont habillés.',
    prod.mode === 'suite'
      ? 'Les personnages qui reviennent gardent EXACTEMENT leur apparence de la vidéo (espèce, couleurs, visage, tenue) ; les nouveaux personnages sont faits dans le même style.'
      : 'Tes personnages sont faits dans CE style-là. Tu reprends le style, pas les personnages : chacun reste nouveau (autre variété, autre nom, autre visage, autre tenue).', '',
    ...how('Choisis la FICHE du métaprompt la plus proche de ce style et adapte-la aux captures (règle 35 : la direction artistique de l\'utilisateur prime, dans les limites de la LOI HUMAINE et du GARDE-FOU MODÉRATION).')].join('\n');
  const brief = prod.style === 'autre' ? String(prod.styleText || '').trim() : st.brief;
  if (!brief) return `${H}\n\nStyle 1 Classique du métaprompt (FICHE 1).`;
  const n = V7_FICHE[prod.style];
  return [H, '', brief, '', ...how(n ? `Pars de la FICHE ${n} du métaprompt.` : 'Pars de la FICHE du métaprompt la plus proche de ce style (règle 35 : la direction artistique de l\'utilisateur prime, dans les limites de la LOI HUMAINE et du GARDE-FOU MODÉRATION).')].join('\n');
}
export function styleBlock(prod, opening, ver = 'v6') {
  if (ver === 'v7') return styleBlockV7(prod);
  const st = styleOf(prod);
  if (st === STYLES.fruits) return '';
  if (st.fromVideo) {
    return ['# STYLE DES PERSONNAGES : CELUI DE LA VIDÉO JOINTE (choisi par l\'utilisateur, prioritaire sur le métaprompt)', '',
      'Regarde les captures (« capture-NN.jpg ») et les planches de lecture (« lecture-NN.jpg ») de la vidéo. Avant d\'écrire, identifie le STYLE D\'APPARENCE de ses personnages : leur espèce ou leur nature (fruits, légumes, oiseaux, gobelets, objets…), leur matière et sa finition (texturée, brillante, cristal, verre, porcelaine, métal…), le niveau de réalisme, les proportions du corps, la façon dont ils sont habillés.',
      prod.mode === 'suite'
        ? 'Les personnages qui reviennent gardent EXACTEMENT leur apparence de la vidéo (espèce, couleurs, visage, tenue) ; les nouveaux personnages sont faits dans le même style.'
        : 'Tes personnages sont faits dans CE style-là : même espèce ou même famille, même matière, même rendu, mêmes proportions. Tu reprends le style, pas les personnages : chacun reste nouveau (autre variété, autre nom, autre visage, autre tenue).',
      'Écris ce style en une ou deux phrases précises, et reprends ces mêmes phrases, mot pour mot, dans chaque planche, chaque image de scène et la miniature.', '',
      'Comment l\'appliquer — le métaprompt reste la base, le style n\'y ajoute que son espèce et sa matière :',
      '- Planches : le FORMAT DE PLANCHE du métaprompt, point par point (ouverture, nom, proportions, description unique, quatre vues, trois gros plans, interdictions). La matière du style s\'écrit dans la « Description unique » (texture du matériau, couleur exacte).',
      '- Chaque planche se termine par la Directive de Style Planche, et chaque image de scène par la Directive de Style de Scène, recopiées intégralement. Juste AVANT la directive, ajoute cette phrase : « Précisions de style, qui priment sur la directive de style qui suit : [le style de la vidéo, en une ou deux phrases]. »',
      '- Si les personnages de la vidéo ne sont pas des fruits ou des légumes, recopie les directives en remplaçant seulement les mots « fruit ou légume » par leur espèce : le rendu, les proportions, les yeux et les expressions ne changent pas.',
      '- Même style partout : planches, images de scène, miniature, prompts vidéo. Toutes les autres règles du métaprompt s\'appliquent (structure, durées, répliques, voix, hook).',
      `Dans les prompts vidéo, la phrase d'ouverture commune devient, mot pour mot : « ${opening} »`].join('\n');
  }
  const custom = prod.style === 'autre';
  const brief = custom ? String(prod.styleText || '').trim() : st.brief;
  if (!brief) return '';
  const L = ['# STYLE DES PERSONNAGES (choisi par l\'utilisateur, prioritaire sur le métaprompt)', '', brief, ''];
  if (st.v6 || custom) L.push( // styles bâtis sur le métaprompt : il reste la base, le style n'ajoute que sa matière (ou son espèce)
    'Comment l\'appliquer — le métaprompt reste la base, le style n\'y ajoute que sa matière :',
    '- Planches : le FORMAT DE PLANCHE du métaprompt, point par point (ouverture, nom, proportions, description unique, quatre vues, trois gros plans, interdictions). La matière du style s\'écrit dans la « Description unique » (texture du matériau, couleur exacte).',
    '- Chaque planche se termine par la Directive de Style Planche, et chaque image de scène par la Directive de Style de Scène, recopiées intégralement. Juste AVANT la directive, ajoute cette phrase : « Précisions de style, qui priment sur la directive de style qui suit : [la matière du style, en une ou deux phrases]. »',
    '- Si le style remplace les fruits et légumes par une autre espèce (tasse, gobelet, smartphone, oiseau…), recopie les directives en remplaçant seulement les mots « fruit ou légume » par cette espèce : le rendu, les proportions, les yeux et les expressions ne changent pas.',
    '- Même matière partout : planches, images de scène, miniature, prompts vidéo. Toutes les autres règles du métaprompt s\'appliquent (structure, durées, répliques, voix, hook).');
  else L.push('Applique ce style à TOUT : personnages, planches de personnages, images de scène, miniature, prompts vidéo. Garde toutes les autres règles du métaprompt (structure, durées, répliques, voix, hook).');
  L.push(`Dans les prompts vidéo, la phrase d'ouverture commune devient, mot pour mot : « ${opening} »`);
  return L.join('\n');
}
/* ---------- Le métaprompt comme base des images de style ----------
   La Directive de Style Planche est lue dans le métaprompt lui-même (si tu l'as modifié, c'est ta version qui compte). */
export const PLANCHE_DIRECTIVE_DEFAULT = 'Style d\'animation 3D haut de gamme dans la lignée de Pixar et DreamWorks, poussé vers un rendu semi-réaliste mature et texturé, avec un niveau de détail matière élevé et une diffusion sous-surfacique sur la matière du fruit ou du légume. Éclairage de studio doux, neutre et uniforme sur un fond blanc pur, couleurs fidèles et saturées, légère ombre douce au sol. Le corps entier — visage, torse, bras, mains, jambes, pieds — est fait intégralement de la matière de son fruit ou légume, sans aucune peau chair humaine nulle part. Corps entièrement humanoïde, grand et élancé, environ cinq têtes et demie de haut pour un adulte, longues jambes, cou visible, jamais chibi. Yeux réalistes et expressifs, expressions réalistes et nuancées.';
export function plancheDirectiveOf(metaText) {
  const t = String(metaText || ''), at = t.search(/DIRECTIVE DE STYLE PLANCHE\*\*/);
  if (at < 0) return PLANCHE_DIRECTIVE_DEFAULT;
  const m = /```\s*\n([\s\S]*?)\n```/.exec(t.slice(at));
  return m && m[1].trim().length > 200 ? m[1].trim() : PLANCHE_DIRECTIVE_DEFAULT;
}
/* Image d'aperçu d'un style (bouton du lanceur) : cinq personnages côte à côte, dans le rendu exact des planches du métaprompt.
   Même logique que pour une vraie planche : la directive de style du métaprompt, précédée des précisions du style. */
export function stylePreviewPrompt(style, metaText) {
  const st = style || {}, dir = plancheDirectiveOf(metaText).replace(/,?\s*composition verticale 9:16/i, '').replace(/\s*Rendu net, propre et parfaitement identique dans chaque vue\.?/i, '').trim();
  const esp = st.cast || (st.espece ? `des humanoïdes dont la tête est ${st.espece}` : st.custom ? 'dans le style décrit plus bas' : 'des fruits et légumes humanoïdes');
  // précisions du style : son rendu matière s'il en a un, sinon sa description (styles d'origine et styles enregistrés)
  const precis = st.look || (st.matiere ? `PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessous : ${st.matiere}` : (st.brief && st.key !== 'fruits' ? `PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessous : ${String(st.brief).trim()}` : ''));
  return ['Une image de présentation de style, au format paysage 16:9, sur un fond blanc pur et uniforme, sans décor, sans cadre et sans aucun texte.',
    `Cinq personnages adultes différents, ${esp}, debout, en pied, côte à côte et bien espacés : hommes et femmes, chacun d'une espèce ou d'une variété différente, chacun dans une tenue élégante différente et complète, poses naturelles et variées, regards dirigés de côté, jamais vers la caméra, légère ombre douce au sol. Chaque corps est entier, du sommet de la tête jusqu'aux pieds, jamais coupé.`,
    'Chaque personnage a un CORPS D\'ADULTE COMPLET, GRAND ET ÉLANCÉ, d\'environ cinq têtes et demie de haut, avec de longues jambes, un cou visible et des épaules d\'adulte ; visage semi-réaliste aux expressions nuancées, jamais de peau humaine.',
    precis.replace('ci-dessus', 'ci-dessous'), dir].filter(Boolean).join('\n\n');
}
/* Style repris de la vidéo : des captures de la vidéo partent avec chaque planche */
export const VIDEO_REF_NOTE = 'Les images jointes sont des captures d\'une vidéo : ce sont des RÉFÉRENCES DE STYLE uniquement. Reprends leur rendu (espèce ou nature des personnages, matière, niveau de réalisme, finition, lumière, proportions des corps), mais ne reproduis aucun de leurs personnages, ni leurs visages, ni leurs tenues, ni le décor : le personnage à dessiner est celui décrit ci-dessous.\n\n';
export const VIDEO_REF_NOTE_SUITE = 'Les images jointes sont des captures de la partie précédente de cette histoire. Si le personnage décrit ci-dessous y apparaît, dessine-le IDENTIQUE (même espèce, mêmes couleurs, même visage, même tenue). Sinon, reprends seulement leur rendu (matière, niveau de réalisme, finition, proportions). N\'ajoute ni décor ni autre personnage.\n\n';
/* Résumé court d'un personnage de la bibliothèque, tiré du prompt de sa planche */
export function charBrief(prompt, max = 420) {
  const t = String(prompt || '').replace(/\s+/g, ' ').trim();
  if (t.length <= max) return t;
  const cut = t.slice(0, max), dot = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf(' ; '));
  return (dot > max * 0.5 ? cut.slice(0, dot + 1) : cut.replace(/\s+\S*$/, '')) + ' […]';
}
/* Note jointe à une planche quand l'image du style part avec elle : c'est une référence de rendu, pas un modèle de personnage */
export const STYLE_REF_NOTE = 'L\'image jointe est une RÉFÉRENCE DE STYLE uniquement : reprends son rendu (matière, niveau de réalisme, finition, lumière, proportions des corps), mais ne reproduis aucun de ses personnages, ni leurs visages, ni leurs tenues, ni leurs poses, et ne reprends pas sa mise en page. Génère la planche du personnage décrit ci-dessous. ';
/* ---------- Miniature : le texte et son style sont ajoutés ICI, au moment d'envoyer à ChatGPT ----------
   Claude décrit l'image ; l'utilisateur choisit le style du texte (au lancement, ou en refaisant la miniature).
   Le style peut donc changer sans réécrire le package, et chaque « Refaire » demande une version vraiment différente. */
export const MINI_STYLES = {
  libre: { label: 'Carte blanche', short: 'ChatGPT invente le lettrage et la mise en page, différents à chaque histoire',
    rule: 'carte blanche. Tu es le directeur artistique : invente un lettrage sur mesure pour CETTE histoire (forme, matière, couleurs et effets des lettres inspirés du décor, de l\'objet clé ou de l\'émotion de la scène), comme le titre d\'une affiche qu\'on n\'a encore jamais vue. Le gros titre est très grand, spectaculaire et parfaitement lisible ; le repère de partie est intégré dans le même esprit (étiquette, ruban, tampon, autocollant… à toi de choisir). Typographie, couleurs et disposition libres, tant que c\'est beau, net et lisible.' },
  cartoon: { label: 'Gros titre cartoon', short: 'Très grosses lettres rondes et rebondies, façon dessin animé',
    rule: 'gros titre de dessin animé. Très grosses lettres rondes, épaisses et rebondies, en 3D brillante, un peu penchées et de tailles inégales comme un logo de cartoon, avec un épais contour sombre, une ombre portée et des reflets ; couleurs vives et joyeuses tirées de la scène ; un ou deux mots clés encore plus gros que les autres. Le repère de partie tient dans une petite bulle ou un autocollant assorti.' },
  cinema: { label: 'Affiche de cinéma', short: 'Titre 3D sculpté, lumière dramatique, composition d\'affiche',
    rule: 'affiche de film d\'animation. Titre en grandes lettres 3D sculptées dans une matière liée à l\'histoire (or, glace, bois, verre, bonbon, pierre…), reliefs et reflets soignés, éclairage dramatique, composition d\'affiche de cinéma. Le repère de partie est écrit en petites capitales élégantes, comme le numéro d\'un épisode.' },
  bd: { label: 'Bande dessinée', short: 'Éclat de BD, lettres épaisses inclinées, trame de points',
    rule: 'bande dessinée. Le gros titre jaillit d\'un grand éclat ou d\'une bulle de BD : lettres épaisses et inclinées à contour noir, trame de points, traits de vitesse, deux ou trois couleurs franches. Le repère de partie est dans un petit cartouche de BD.' },
  neon: { label: 'Néon lumineux', short: 'Lettres lumineuses qui éclairent la scène',
    rule: 'néon lumineux. Titre en tubes de néon ou en lettres lumineuses qui éclairent vraiment la scène (reflets colorés sur les personnages et le décor), une ou deux couleurs de lumière accordées à l\'histoire, fond un peu plus sombre derrière les lettres pour qu\'elles ressortent. Le repère de partie est un petit néon assorti.' },
  classique: { label: 'Classique', short: 'Titre de la série, badge bleu « PARTIE », accroche jaune (l\'ancien style)',
    rule: 'trois niveaux bien séparés, de haut en bas : (1) le titre de la série en lettres cursives élégantes blanc crème avec un fin contour sombre ; (2) un badge arrondi bleu roi à bordure dorée contenant le repère de partie en capitales blanches épaisses ; (3) le gros titre en très grosses capitales jaune vif à épais contour rouge sombre, légèrement inclinées, sur une ou deux lignes.' }
};
export const MINI_DEFAULT = 'libre';
export const miniStyleKey = (prod, fallback) => (prod && MINI_STYLES[prod.miniStyle] ? prod.miniStyle : MINI_STYLES[fallback] ? fallback : MINI_DEFAULT);
/* pistes données à ChatGPT quand on refait une miniature « carte blanche » : une direction différente à chaque essai */
const MINI_TWISTS = ['lettres faites de la matière de l\'objet clé de l\'histoire', 'lettres gonflées et brillantes comme des ballons', 'titre peint à grands coups de pinceau, avec des éclaboussures de couleur',
  'lettres découpées façon autocollants, à gros contour blanc', 'lettres dorées en relief, façon écrin de luxe', 'lettres de lumière, qui éclairent les personnages'];
export function miniPrompt(pkg, prod, fallback) {
  const m = (pkg && pkg.miniature) || {}, meta = (pkg && pkg.meta) || {};
  const base = String(m.prompt || '').trim();
  const hook = String(meta.accroche || '').replace(/\s+/g, ' ').replace(/^["«“]\s*|\s*["»”]$/g, '').trim().toUpperCase();
  if (!base || !hook) return base; // pas d'accroche (package ancien ou collé à la main) : le prompt part tel quel
  const key = miniStyleKey(prod, fallback), st = MINI_STYLES[key], v = Number(m.variant) || 0;
  const part = `PARTIE ${String(meta.partie || (prod && prod.part) || 1).replace(/^partie\s*/i, '').trim()}`;
  const serie = String(meta.serie || '').replace(/\s+/g, ' ').trim();
  const L = ['', '', 'TEXTE DE LA MINIATURE — consigne prioritaire : elle remplace toute autre indication de texte, de titre, de police, de badge ou de couleur de lettres donnée ailleurs dans ce message.',
    'Texte à écrire, exactement ces mots, lettre pour lettre, sans guillemets, sans faute, et rien d\'autre :'];
  if (key === 'classique' && serie) L.push(`- Titre de la série : ${serie}`);
  L.push(`- Gros titre : ${hook}`, `- Repère de partie : ${part}`,
    `Style du texte : ${st.rule}`,
    'Placement : tout le texte tient dans la moitié haute de l\'image, à plus de 8 % des bords, sans jamais couvrir un visage ; il se lit d\'un coup d\'œil sur un écran de téléphone. Aucun autre texte, aucun logo, aucun filigrane.');
  if (v > 0) L.push(`NOUVELLE VERSION (n° ${v + 1}) : fais une miniature nettement différente de la précédente (autre disposition du texte, autres couleurs de lettres, autre cadrage des personnages), avec le même texte.${key === 'libre' ? ` Piste pour cette version : ${MINI_TWISTS[(v - 1) % MINI_TWISTS.length]}.` : ''}`);
  return base + L.join('\n');
}

/* Miniature type d'un style : une scène d'exemple avec le texte dans ce style, pour voir ce que ça donne avant de choisir.
   Même consigne de texte que pour une vraie miniature (miniPrompt) : c'est vraiment ce que le style produira. */
const MINI_SAMPLE = {
  serie: 'Les Secrets du Verger', accroche: 'Elle a tout vu',
  scene: 'Miniature TikTok au format portrait vertical 9:16, rendu 3D semi-réaliste de film d\'animation haut de gamme. Une cuisine moderne le soir, lumière chaude et dramatique qui découpe les visages, couleurs fortes. Au premier plan, deux personnages humanoïdes adultes dont la tête est un fruit : à gauche, une pêche (femme, robe rouge), les yeux brillants de larmes et de colère, qui serre un téléphone contre elle ; à droite, une poire (homme, chemise blanche), qui recule d\'un pas, la main levée, l\'air coupable. Au second plan, plus petite, une cerise (femme, veste noire) les observe depuis l\'embrasure de la porte, visage net, sourire en coin. Corps d\'adultes complets et élancés, visages semi-réalistes aux expressions nuancées, jamais de peau humaine : la matière des fruits partout. Les visages et l\'action tiennent dans les deux tiers inférieurs de l\'image ; le tiers supérieur reste calme (mur de la cuisine un peu flou) pour recevoir le titre. Aucun visage coupé par le cadre.'
};
export function miniTypePrompt(key) {
  const pkg = { miniature: { prompt: MINI_SAMPLE.scene }, meta: { accroche: MINI_SAMPLE.accroche, partie: '1', serie: MINI_SAMPLE.serie } };
  return `Génère cette miniature, au format portrait vertical 9:16, avec le texte demandé écrit sans faute. Ne réponds que par l'image.\n\n${miniPrompt(pkg, { miniStyle: MINI_STYLES[key] ? key : MINI_DEFAULT, part: 1 })}`;
}

/* Aucun texte à l'image : ajouté à chaque prompt vidéo envoyé à Grok et à chaque image de scène */
export const NO_TEXT_VIDEO = 'NO TEXT ON SCREEN: no subtitles, no captions, no titles, no speech bubbles, no letters, words or numbers anywhere in the video, no logos, no watermark.';
export const NO_TEXT_IMAGE = 'AUCUN TEXTE dans l\'image : pas de sous-titre, pas de bulle, pas de titre, pas de lettre, de mot ou de chiffre, pas de logo, pas de filigrane. Un panneau, une enseigne, une pancarte, une affiche ou un écran présent dans la scène reste vierge, flou ou vu de dos : rien n\'y est écrit.';
/* Rendu matière ajouté à chaque prompt image quand le style choisi est un style cristal */
export const lookOf = (prod) => {
  const st = styleOf(prod);
  if (prod && prod.style === 'autre') { const t = String(prod.styleText || '').replace(/\s+/g, ' ').trim(); return t && t.length <= 700 ? `PRÉCISIONS DE STYLE — elles priment sur la directive de style ci-dessus : ${t}` : ''; }
  return (st && st.look) || '';
};
/* Suite : on garde le TEXTE de la miniature précédente (mêmes mots, même lettrage, mêmes effets, même place) avec le nouveau numéro de partie.
   L'image, elle, est nouvelle : c'est la scène de cette partie, décrite par Claude. */
export function miniKeepTextPrompt(pkg, prod, prevPart) {
  const m = (pkg && pkg.miniature) || {}, base = String(m.prompt || '').trim(), v = Number(m.variant) || 0;
  const part = `PARTIE ${String((prod && prod.part) || 1).replace(/^partie\s*/i, '').trim()}`;
  const L = [
    'L\'image jointe nommée « miniature-precedente » est la miniature de la partie précédente de cette série. Elle sert de MODÈLE POUR LE TEXTE, et seulement pour le texte : ce n\'est pas une planche de personnage.',
    `TEXTE — consigne prioritaire, elle remplace toute autre indication de texte, de titre, de police, de badge ou de couleur de lettres donnée plus bas : recopie le titre de cette miniature mot pour mot, sans faute, avec exactement le même lettrage (même police, mêmes couleurs, mêmes contours, mêmes ombres, mêmes reflets et effets, même inclinaison, même taille) et au même endroit dans l'image. UN SEUL changement dans le texte : le repère de partie devient « ${part} »${prevPart ? ` (à la place de « PARTIE ${prevPart} »)` : ''}, écrit au même endroit et dans le même style que l'ancien. Aucun autre texte, aucun logo, aucun filigrane.`,
    'IMAGE — elle est NOUVELLE : ne reprends ni la scène, ni les poses, ni le décor, ni le cadrage de la miniature jointe. Dessine la scène décrite ci-dessous, celle de cette nouvelle partie, sans jamais couvrir un visage avec le texte.'
  ];
  if (v > 0) L.push(`NOUVELLE VERSION (n° ${v + 1}) : change nettement l'image (autre cadrage, autre moment de la scène), en gardant exactement le même texte et le même lettrage.`);
  L.push('Format portrait vertical 9:16. Ne réponds que par l\'image.');
  return `${L.join('\n')}\n\n${base}`;
}
/* Suite : la miniature de la partie précédente refaite à l'identique, seul le numéro de partie change (ancienne façon, gardée pour les productions déjà lancées) */
export function miniReusePrompt(part, prevPart) {
  return `L'image jointe est la miniature de la partie précédente. Refais EXACTEMENT cette image, à l'identique : mêmes personnages, mêmes poses, même décor, même cadrage, mêmes couleurs, même titre, mêmes lettres, même mise en page. UN SEUL changement : le repère de partie devient « PARTIE ${part} »${prevPart ? ` (à la place de « PARTIE ${prevPart} »)` : ''}, écrit au même endroit, dans le même style et la même couleur. Ne change rien d'autre, n'ajoute rien. Format portrait vertical 9:16. Ne réponds que par l'image.`;
}
/* Analyse Gemini (lib/analysis.js, format du Radar) → note en texte clair jointe à la demande de Claude */
export function hookNote(a) {
  a = a || {}; const h = a.hook || {}, q = a.question || {}, L = ['ANALYSE DE LA VIDÉO D\'ORIGINE PAR GEMINI (aide pour écrire le hook)', ''];
  const line = (k, v) => { if (v) L.push(`- ${k} : ${v}`); };
  L.push(`LE HOOK (${h.temps || '00:00-00:03'})`); line('Ce qu\'on voit', h.visuel); line('Ce qu\'on entend ou lit', h.texte_ou_voix); line('Type de hook', h.type); line('Pourquoi ça empêche de scroller', h.pourquoi);
  if (q.question) { L.push('', 'LA QUESTION QUI FAIT RESTER'); line('Question', q.question); line('Posée à', q.posee_a); line('Réponse', q.reponse); line('Donnée à', q.repondue_a); }
  if (a.resume) L.push('', 'EN BREF', a.resume);
  const list = (title, arr) => { if (arr && arr.length) { L.push('', title); arr.forEach((x) => L.push(`- ${x}`)); } };
  list('CE QUI RETIENT LES GENS', a.retention); list('POURQUOI ÇA MARCHE', a.pourquoi_ca_marche);
  if (a.retournement && a.retournement.description) L.push('', `LE RETOURNEMENT (${a.retournement.moment || '?'}) : ${a.retournement.description}`);
  if (a.fin) L.push('', `LA FIN : ${a.fin}`);
  return L.join('\n');
}
/* Catégorie proposée pour une planche, d'après sa description (modifiable ensuite dans Personnages) */
export function charCat(p) {
  const t = ` ${String((p && (p.prompt || '')) || '')} ${String((p && p.name) || '')} `.toLowerCase();
  const n = (words) => (t.match(new RegExp(`(?<![\\p{L}])(${words})(?![\\p{L}])`, 'gu')) || []).length;
  // L'espèce (oiseau, fruit…) est le STYLE ; la catégorie dit d'abord si c'est un enfant, une femme ou un homme, et « Animaux » seulement à défaut
  if (n('enfant|bébé|bebe|fillette|garçonnet|child|kid|baby|toddler|little girl|little boy')) return 'Enfants';
  const f = n('femme|woman|female|fille|girl|mère|mother|épouse|wife|madame|lady|she|her|feminine|féminine');
  const h = n('homme|man|male|garçon|boy|père|father|mari|husband|monsieur|gentleman|he|his|him|masculine|masculin');
  if (f !== h) return f > h ? 'Femmes' : 'Hommes';
  return n('chien|chat|cheval|animal|dog|cat|horse|puppy|kitten|pet') ? 'Animaux' : '';
}
/* Verrou des voix : Grok fait parfois dire la réplique d'un personnage par un autre, ou fait parler un personnage qui n'a pas de réplique.
   À partir des répliques du prompt lui-même (« RÉPLIQUE n — QUI (position, espèce, marqueur) : "texte" »), on ajoute :
   - EN TÊTE du prompt (ce que Grok lit en premier) : combien de personnages parlent, lesquels, où ils sont dans l'image, dans quel ordre,
     et que tous les autres personnages visibles n'ont AUCUNE réplique ;
   - À LA FIN : la liste « qui dit quoi », réplique par réplique, avec la place du personnage dans l'image. */
const SPEAKER_POS = [[/\b(gauche|left)\b/i, 'on the LEFT of the frame'], [/\b(droite|right)\b/i, 'on the RIGHT of the frame'], [/\b(centre|milieu|center|middle)\b/i, 'in the CENTER of the frame'],
  [/\b(premier plan|devant|foreground|front)\b/i, 'in the FOREGROUND'], [/\b(arrière-plan|arriere-plan|au fond|fond|background)\b/i, 'in the BACKGROUND']];
/* Prompt vidéo écrit avec le métaprompt V7 : il commence par la ligne « Clean frame » et ses répliques s'écrivent
   « Réplique n, étiquette, intonation : texte », sans guillemets ni majuscules (Grok affiche à l'écran ce qui est en majuscules ou entre guillemets). */
export const isV7Video = (video) => /^\s*Clean frame\s*:/i.test(String(video || ''));
function speakerLinesV7(video) {
  return String(video || '').split('\n').map((l) => l.trim().match(/^R[ée]plique\s*(\d+)\s*,\s*([^:]+?)\s*:\s*(.+)$/i)).filter(Boolean).map((m) => {
    const who = m[2].split(',')[0].trim();
    return { who, off: /narrat|voix[- ]?off|hors[- ]?champ/i.test(m[2]), label: who, pos: '', text: m[3].replace(/\s+/g, ' ').trim() };
  });
}
export function speakerLines(video) {
  if (isV7Video(video)) return speakerLinesV7(video);
  return String(video || '').split('\n').map((l) => l.trim().match(/^R[ÉE]PLIQUE\s*(\d+)\s*[—–-]\s*(.+?)\s*:\s*["«“]\s*(.+?)\s*["»”]?\s*$/i)).filter(Boolean).map((m) => {
    const who = m[2].trim(), inside = (who.match(/\(([^)]*)\)/) || [])[1] || '';
    return { who, off: /narrat|voix[- ]?off|voice[- ]?over|hors[- ]?champ|off[- ]?screen/i.test(who), label: who.replace(/\s*\([^)]*\)\s*/g, ' ').replace(/\s+/g, ' ').trim(), pos: SPEAKER_POS.filter(([re]) => re.test(inside)).map(([, en]) => en).join(' and '),
      text: m[3].replace(/\s*\([^)]*\)\s*/g, ' ').replace(/\s+/g, ' ').trim().replace(/["»”]+$/, '').trim() };
  });
}
export function withSpeakerLock(video) {
  const t = String(video || '').replace(/\s+$/, '');
  if (/SPEAKER LOCK/i.test(t) || isV7Video(t)) return t; // V7 : ses voix verrouillées et son ordre de parole suffisent, et nos ajouts en majuscules s'afficheraient à l'écran
  const lines = speakerLines(t);
  if (!lines.length) return t;
  const full = (x) => (x.off ? `${x.who} — an OFF-SCREEN voice, no mouth on screen moves for this line` : `${x.who}${x.pos ? ` — the character ${x.pos}` : ''}`);
  const anyOff = lines.some((x) => x.off);
  const speakers = [...new Map(lines.map((x) => [x.label.toLowerCase(), x])).values()];
  const one = speakers.length === 1;
  const head = `WHO SPEAKS — READ THIS FIRST: in this clip exactly ${speakers.length} ${anyOff ? 'voice' : 'character'}${one ? '' : 's'} speak${one ? 's' : ''}: ${speakers.map(full).join(' ; ')}. `
    + `Order of the ${lines.length} spoken line${lines.length > 1 ? 's' : ''}: ${lines.map((x, i) => `${i + 1}) ${x.label}`).join(', then ')}. `
    + 'Every OTHER character visible in the image has NO line at all: lips sealed and completely silent from the first frame to the last, reacting only with eyes, face and body. '
    + (anyOff ? 'A line is never spoken by a character other than its owner.' : 'A line is never spoken by a character other than its owner, and never by an off-screen voice or a narrator.');
  const list = lines.map((x, i) => `${i + 1}) ${full(x)} — and nobody else — says: "${x.text}"`).join('\n');
  const tail = `SPEAKER LOCK — NON NEGOTIABLE: this clip has exactly ${lines.length} spoken line${lines.length > 1 ? 's' : ''}, in this exact order, each one by ONE character only.\n${list}\n`
    + 'While a line is spoken, ONLY its owner\'s mouth moves (lip-sync on that character alone) and that character is clearly on screen; every other character keeps the mouth fully closed and stays silent. '
    + (anyOff ? 'During an off-screen line, NO mouth on screen moves at all. ' : '')
    + `A character never says a line assigned to another character. Voices are never swapped${one ? '' : `: the ${speakers.length} speakers have clearly different voices, and each keeps the same single voice for the whole clip`}. `
    + 'Characters without a line never speak, never whisper, never mouth words. No other words are spoken by anyone.';
  const nl = t.indexOf('\n');
  const body = nl < 0 ? `${t}\n\n${head}` : `${t.slice(0, nl)}\n\n${head}\n${t.slice(nl)}`;
  return `${body}\n\n${tail}`;
}
/* Mot fort : ligne écrite par Claude dans le prompt vidéo de 1 ou 2 scènes, quand l'option est cochée.
   Forme attendue : MOT FORT À L'ÉCRAN : « BLEUS » — COLOR: deep cobalt blue… ; LOOK: glossy 3D letters… ; PLACE: upper third… ; WHEN: silent beat…
   (anciens packages : un style libre après le tiret, sans rubriques — il sert alors de rendu). */
const KEYWORD_LINE = /^.*MOT FORT (?:À|A) L['’][ÉE]CRAN\s*:\s*(.+)$/im;
const KW_LABELS = { color: 'COLOU?R|COULEUR', look: 'LOOK|STYLE|RENDU', place: 'PLACE(?:MENT)?|ENDROIT', effect: 'EFFECTS?|EFFETS?|ANIMATION', when: 'WHEN|MOMENT|QUAND' };
export function keywordOf(video) {
  const m = String(video || '').match(KEYWORD_LINE); if (!m) return null;
  const rest = m[1].trim(), q = rest.match(/^[«"“]\s*(.+?)\s*[»"”]\s*(?:[—–\-:,;]\s*)?(.*)$/);
  let word = '', style = '';
  if (q) { word = q[1]; style = q[2]; } else { const parts = rest.split(/\s+[—–-]\s+/); word = parts[0]; style = parts.slice(1).join(', '); }
  word = word.replace(/[.«»"“”\s]+$/g, '').replace(/\s+/g, ' ').trim();
  if (!word || word.split(' ').length > 3) return null; // une phrase n'est pas un mot fort : la scène reste sans texte
  const all = Object.values(KW_LABELS).join('|'), out = { word: word.slice(0, 40) }; // le mot garde sa casse, ses chiffres et ses symboles : il s'affiche tel que Claude l'a écrit
  for (const [k, re] of Object.entries(KW_LABELS)) {
    const x = style.match(new RegExp(`(?:^|[;.,]\\s*|\\s)(?:${re})\\s*:\\s*([\\s\\S]*?)(?=\\s*[;.,]?\\s*(?:${all})\\s*:|$)`, 'i'));
    out[k] = x ? x[1].trim().replace(/[;.,\s]+$/, '').slice(0, 260) : '';
  }
  out.style = out.color || out.look || out.place || out.effect || out.when ? '' : style.trim().replace(/[.\s]+$/, '').slice(0, 260);
  return out;
}
const NO_TEXT_HEAD = 'NOTHING IS WRITTEN ON SCREEN in this video: no subtitles, no captions, no titles, no written dialogue, no sign, label or screen with readable letters, words or numbers. Every dialogue line below is SPOKEN AUDIO ONLY and is never displayed as text.';
/* Option décochée (ou scène sans mot fort) : en plus de la ligne « MOT FORT », on retire toute phrase qui fait apparaître un mot à l'écran,
   même écrite autrement (vu le 19 novembre 2026 : une suite avait repris les mots forts de la partie précédente, option décochée).
   Les lignes de dialogue (« RÉPLIQUE … : "…" », verrou des voix) ne sont jamais touchées. */
const SCREEN_LABEL = /^\s*(?:[-*•]\s*)?(?:MOTS? FORTS?|TEXTE (?:À|A) L['’][ÉE]CRAN|ON[- ]?SCREEN (?:WORD|TEXT|TITLE)|WRITTEN WORD|TITLE WORD|TEXT ON SCREEN)\b.*$/gim;
const SCREEN_NOUN = /(?:\bthe (?:single |only )?(?:written |title |key |strong )?word\b|\btitle word\b|\bwritten word\b|\bon[- ]?screen (?:text|word|title)\b|\btext overlay\b|\b3D (?:letters|title|text|word)\b|\b(?:glowing|neon|glossy|chrome|golden|giant|big|huge|bold|floating) (?:letters|title|text|word)\b|\bletters? spelling\b|\ble mot\b|\bmot fort\b|\blettres (?:3D|en volume|lumineuses|néon)|\btexte à l['’]écran)/i;
const SCREEN_VERB = /(?:\b(?:appears?|appearing|pops?(?: in| up)?|writes? itself|is written|spells?|spelled|forms?|materiali[sz]es?|floats?|fades? in|flashes|apparaît|apparait|surgit|se forme)\b|\bs['’](?:écrit|affiche|inscrit)\b)/i;
const isScreenWord = (x) => SCREEN_NOUN.test(x) && SCREEN_VERB.test(x);
export function stripScreenWords(video) {
  return String(video || '').replace(SCREEN_LABEL, '').split('\n').map((line) => {
    if (/^\s*R[ÉE]PLIQUE\b/i.test(line) || /(?::|says|dit)\s*["«“]/i.test(line) || !isScreenWord(line)) return line;
    return line.split(/(?<=[.!?])\s+/).map((sen) => {
      if (!isScreenWord(sen)) return sen;
      const parts = sen.split(/(?<=[,;])\s+/), kept = parts.filter((x) => !isScreenWord(x));
      return kept.length === parts.length ? '' : kept.join(' ').replace(/[,;]\s*$/, '.');
    }).filter((x) => x.trim()).join(' ');
  }).join('\n').replace(/\n{3,}/g, '\n\n').trim();
}
export function withNoText(video, allowKeyword = false) {
  let t = String(video || '').replace(/\s+$/, '');
  const kw = allowKeyword ? keywordOf(t) : null;
  t = t.replace(new RegExp(KEYWORD_LINE.source, 'gim'), '').replace(/\n{3,}/g, '\n\n').trim(); // la ligne « mot fort » ne part jamais telle quelle
  if (isV7Video(t)) { // V7 : la ligne Clean frame fait déjà ce travail, sans majuscules
    if (!kw) return t;
    t = t.replace(/^\s*Clean frame\s*:[^\n]*/i, `Clean frame: no subtitles, captions, speech bubbles, logos or watermark at any second; the only written element is the single word ${kw.word} described below.`);
  }
  if (kw) {
    // Le mot est annoncé juste après la phrase d'ouverture (ce que Grok lit d'abord), puis décrit en détail à la fin.
    // 4.8.3 : retour à l'esprit de la 4.3.2 (un mot qui fait partie du décor, écrit au moment où il est dit), avec la couleur tirée
    // de l'histoire (4.6.0), un placement qui change selon la scène et un effet d'apparition. Plus de gros titre qui surgit d'un coup.
    const head = `ONLY ONE WRITTEN WORD in this whole video: "${kw.word}". It is a physical part of the scene, not a subtitle and not a flat overlay. No sentence, no other word of the dialogue and no caption is ever written: every dialogue line below is SPOKEN AUDIO ONLY.`;
    t = t.replace(/\bno on-screen text\b/gi, `no on-screen text except the single written word "${kw.word}"`).replace(/\b(no\s+)?text overlays?\b/gi, `no text overlay except the single written word "${kw.word}"`);
    const nl = t.indexOf('\n');
    t = nl >= 40 ? `${t.slice(0, nl)}\n${head}${t.slice(nl)}` : `${head}\n\n${t}`;
    const look = kw.look || kw.style || 'letters with real depth, made of a material that fits the scene (glass, carved wood, frost, embers, ink)';
    return `${t}\n\nTHE WRITTEN WORD — "${kw.word}", and nothing else. It exists INSIDE the 3D scene as if it were really there: never flat text pasted over the video, never a big title card, never a subtitle.
- WHEN: ${kw.when || `exactly as the character says "${kw.word}"`}. It forms progressively over 1 to 2 seconds, never popping in all at once, then stays in place until the end of the shot.
- PLACE: ${kw.place || 'on a real surface of the set right next to the character or object this word is about (a wall, a window, a prop they hold, the edge of a table), not in the exact center of the frame'}. It follows the perspective and the angle of that surface. Never on a face, never in the lower third of the frame, never as a banner. Modest size: about a quarter to a third of the frame width, clearly readable.
- LOOK: ${look}. Lit by the scene's own light, with reflections and a soft shadow on the surface it sits on; characters or objects may pass in front of it; the slight camera movement shows parallax.
- EFFECT: ${kw.effect || 'it writes itself letter by letter with a soft light trail'}.
- COLOR: ${kw.color || 'the exact color of the element of the story this word is about, clearly standing out from the background'}. The letters are entirely this color: this color is mandatory.
Spelled exactly "${kw.word}", character for character${/\d/.test(kw.word) ? ' (digits, spaces and symbols exactly as written, thick and wide numerals)' : ''}. The rest of the dialogue is NEVER written. No subtitles, no captions, no other letters, words or numbers anywhere, no logos, no watermark.`;
  }
  t = stripScreenWords(t);
  // la consigne est dite deux fois : juste après la phrase d'ouverture (qui fixe le style et reste en tête), et à la fin
  if (!/NOTHING IS WRITTEN ON SCREEN/i.test(t)) {
    const nl = t.indexOf('\n');
    t = nl >= 40 ? `${t.slice(0, nl)}\n${NO_TEXT_HEAD}${t.slice(nl)}` : `${NO_TEXT_HEAD}\n\n${t}`;
  }
  return /NO TEXT ON SCREEN:/i.test(t) ? t : `${t}\n\n${NO_TEXT_VIDEO}`;
}

export const OPENING_DEFAULT = 'Vertical 9:16 cinematic 3D animation, semi-realistic textured fruit-and-vegetable characters, animate the attached image (@image1) while keeping its exact setting, lighting, characters, outfits and props unchanged.';
/* la phrase d'ouverture commune est lue dans le métaprompt lui-même (si tu l'as modifié, c'est ta version qui compte) */
export function openingOf(metaText) {
  const m = /^Vertical 9:16 cinematic 3D animation[^\n]*$/m.exec(metaText || '');
  return m ? m[0].trim() : OPENING_DEFAULT;
}
export function videoProblems(s, opening = OPENING_DEFAULT) {
  const t = String(s.video || '').replace(/\r/g, '');
  const out = [];
  if (!t.trim()) return ['prompt vidéo vide'];
  if (/```/.test(t)) out.push('le prompt est dans un bloc code (texte brut obligatoire)');
  const first = t.split('\n').find((l) => l.trim()) || '';
  if (first.trim() !== opening) out.push('la première ligne doit être la phrase d\'ouverture commune, mot pour mot');
  const dyn = /CHARACTERS AND VOICES/.test(t);
  if (/ANIMATION BRIEF/i.test(t)) out.push('en-tête interdit (« ANIMATION BRIEF »)');
  if (dyn) {
    for (const k of ['ACTION', 'CAMERA', 'DIALOGUE', 'CRITICAL RULE', 'AUDIO:', 'NEGATIVE:']) if (!t.includes(k)) out.push(`bloc « ${k.replace(':', '')} » absent de la version dynamique`);
  } else {
    if (!/Characters in shot:/.test(t)) out.push('« Characters in shot: » absent (gabarit version normale)');
    for (const k of ['Voices:', 'Dialogue:', 'ANIMATION RULES', 'EYELINE', 'AUDIO:', 'OUTPUT:']) if (!t.includes(k)) out.push(`« ${k.replace(':', '')} » absent de la version normale`);
  }
  if (/@image[2-9]/i.test(t)) out.push('seule @image1 existe (pas de @image2, @image3…)');
  if (!/RÉPLIQUE 1/.test(t)) out.push('répliques numérotées absentes (RÉPLIQUE 1 — …)');
  { const numbered = t.split('\n').filter((l) => /^\s*R[ÉE]PLIQUE\s*\d+/i.test(l)).length;
    if (numbered && speakerLines(t).length < numbered) out.push('chaque réplique tient sur UNE ligne, avec le personnage qui la dit puis le texte entre guillemets : RÉPLIQUE n — NOM (place dans l\'image, espèce, signe distinctif) : "texte"'); }
  if (s.duree && !new RegExp(`\\b${s.duree}\\s*(secondes|seconds|s)\\b`, 'i').test(t.slice(t.search(/Dialogue|DIALOGUE/) >= 0 ? t.search(/Dialogue|DIALOGUE/) : 0))) out.push(`le bloc Dialogue doit annoncer ${s.duree} secondes (durée de la scène)`);
  if (!/exactement la même voix que d'habitude/i.test(t)) out.push('verrou de voix incomplet (« exactement la même voix que d\'habitude, cette fois… » absent)');
  if (!dyn && /(bruitage|sound effects?)/i.test(t.replace(/NO (background music, NO soundtrack, NO )?sound effects/gi, ''))) out.push('pas de bruitages dans la version normale');
  return out;
}
/* Contrôle des prompts vidéo du métaprompt V7 : ce qui se vérifie à coup sûr. */
export function videoProblemsV7(s) {
  const raw = String(s.video || '').replace(/\r/g, '');
  if (!raw.trim()) return ['prompt vidéo vide'];
  const out = [], t = raw.replace(new RegExp(KEYWORD_LINE.source, 'gim'), '').trim(); // la ligne « mot fort » est retirée par le programme : elle n'est pas contrôlée
  if (/```/.test(t)) out.push('aucun bloc code dans le prompt (texte brut)');
  if (!isV7Video(t)) out.push('la première ligne doit être la ligne Clean frame du gabarit');
  if (!/^\s*Langue\s*:/im.test(t)) out.push('ligne Langue absente (deuxième ligne du gabarit : tous les personnages parlent uniquement en français…)');
  if (!/@image1\b/i.test(t)) out.push('@image1 absent de la ligne Langue');
  if (/@image[2-9]/i.test(t)) out.push('seule @image1 existe (pas de @image2, @image3…)');
  if (/["«»“”]/.test(t)) out.push('aucun guillemet dans le prompt vidéo, répliques comprises');
  { const caps = [...new Set(t.match(/(?<![A-Za-zÀ-ÿ])[A-ZÀ-Ý]{3,}(?![A-Za-zÀ-ÿ])/g) || [])]; if (caps.length) out.push(`aucun mot entièrement en majuscules (${caps.slice(0, 4).join(', ')})`); }
  if (/^\s*R[ée]plique\s*\d/im.test(t)) { if (!/Voix verrouillées/i.test(t)) out.push('bloc « Voix verrouillées » absent'); }
  else if (!/Aucun dialogue/i.test(t)) out.push('ni réplique numérotée (Réplique 1, … : …) ni mention « Aucun dialogue »');
  if (!/jusqu['’]à la dernière seconde/i.test(t)) out.push('l\'action doit se terminer par « jusqu\'à la dernière seconde : … »');
  if (!/Format vertical portrait 9:16\.?\s*$/i.test(t)) out.push('ligne de clôture absente à la fin');
  if (t.length > 4000) out.push(`prompt trop long : ${t.length} caractères, ${t.length - 4000} de trop (4 000 au maximum)`);
  return out;
}
export function v7Problems(pkg) {
  const res = [];
  for (const s of pkg.scenes) { const list = videoProblemsV7(s); if (list.length) res.push({ n: s.n, list }); }
  return res;
}
export const metaProblems = (pkg, opening, ver) => (ver === 'v7' ? v7Problems(pkg) : v6Problems(pkg, opening));
export function v6Problems(pkg, opening = OPENING_DEFAULT) {
  const res = [];
  for (const s of pkg.scenes) { const list = videoProblems(s, opening); if (s.n === 1 && s.duree > 10) list.push('la scène 1 dure 6 secondes par défaut, 10 au maximum'); if (list.length) res.push({ n: s.n, list }); }
  return res;
}
export function fixMessage(problems, ver = 'v6') {
  if (ver === 'v7') return `CONTRÔLE MÉTAPROMPT V7 : un programme a relu tes prompts vidéo et trouvé des règles VERROUILLÉES non respectées.\n\n${problems.map((p) => `Scène ${p.n} :\n${p.list.map((x) => `- ${x}`).join('\n')}`).join('\n\n')}\n\n${problems.some((p) => p.list.some((x) => /trop long/.test(x))) ? 'Pour un prompt trop long : vise 3 500 caractères (environ 580 mots). Garde les répliques et les verrous de voix mot pour mot, et raccourcis le reste : chaque personnage décrit une seule fois (ensuite, son étiquette seule), une seule phrase d\'action par personnage, l\'émotion de la voix écrite une seule fois sur la ligne de réplique, aucune consigne ajoutée à la partie fixe du gabarit. S\'il y a 3 personnages qui parlent ou plus, ou 5 répliques ou plus, prends le gabarit SCÈNE CHARGÉE du métaprompt (à défaut : un bloc Personnages, l\'action en deux phrases, puis les lignes de réplique).\n\n' : ''}Réécris UNIQUEMENT ces scènes ${problems.map((p) => p.n).join(', ')}, en entier (blocs @@SCENE …@@ avec @@IMAGE@@, @@VIDEO@@ et @@MONTAGE@@, chacun fermé par @@FIN@@), en suivant à la lettre le gabarit vidéo du métaprompt (ligne Clean frame en première ligne, ligne Langue juste dessous, prompt entièrement en français, @image1 comme seul tag, bloc Voix verrouillées, aucun guillemet, aucun mot entièrement en majuscules, ligne de clôture, 4 000 caractères au maximum). Garde l'histoire, les répliques et les planches. Même forme de sortie qu'avant, puis @@FINI@@.`;
  return `CONTRÔLE MÉTAPROMPT V6 : un programme a relu tes prompts vidéo et trouvé des règles VERROUILLÉES non respectées.\n\n${problems.map((p) => `Scène ${p.n} :\n${p.list.map((x) => `- ${x}`).join('\n')}`).join('\n\n')}\n\nRéécris UNIQUEMENT ces scènes ${problems.map((p) => p.n).join(', ')}, en entier (blocs @@SCENE …@@ avec @@IMAGE@@, @@VIDEO@@ et @@MONTAGE@@, chacun fermé par @@FIN@@), en suivant à la lettre le gabarit du métaprompt (phrase d'ouverture commune en première ligne, gabarit version normale ou dynamique complet, verrou de voix recopié, dialogue annonçant la bonne durée). Garde l'histoire, les répliques et les planches. Même forme de sortie qu'avant, puis @@FINI@@.`;
}
/* Corrections mécaniques, quand Claude n'a pas corrigé après relance : retire les accents graves, remet la phrase d'ouverture */
export function patchVideo(s, opening = OPENING_DEFAULT, ver = 'v6') {
  let t = String(s.video || '').replace(/\r/g, '').replace(/```[a-z]*\n?/gi, '').trim();
  if (ver === 'v7' || isV7Video(t)) return t; // V7 : pas de phrase d'ouverture commune à remettre
  const lines = t.split('\n'); const i = lines.findIndex((l) => l.trim());
  if (i >= 0 && lines[i].trim() !== opening) {
    if (/^Vertical 9:16 cinematic 3D animation/i.test(lines[i].trim())) lines[i] = opening; else lines.splice(i, 0, opening, '');
    t = lines.join('\n');
  }
  return t;
}

/* Description envoyée à TikTok : celle écrite pour la vidéo, ou (édition de l'auteur, mode « perso ») toujours la même,
   suivie si demandé des hashtags de la vidéo. */
export function finalDesc(desc, auto = {}, admin = false) {
  const d = String(desc || '').trim();
  const perso = String(auto.descPerso || '').trim();
  if (!admin || auto.descMode !== 'perso' || !perso) return d;
  const m = d.match(/((?:\s*#[\p{L}\p{N}_]+)+)$/u);
  return auto.descPersoTags !== false && m ? `${perso}\n${m[1].trim()}` : perso;
}
