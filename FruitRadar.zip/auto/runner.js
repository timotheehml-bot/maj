// FruitRadar — © 2026 Timothée Hamel. Tous droits réservés.
// FruitRadar — fenêtre pilote de l'automatisation.
// Elle enchaîne : source (vidéo, captures, transcription) → package (Claude) → images (ChatGPT) → clips (Grok) → CapCut.
// Chaque élément garde son état dans la base : après une pause ou un « Refaire », on reprend exactement où on en était.
import * as DB from '../lib/db.js';
import { getSettings } from '../lib/settings.js';
import { IS_ADMIN } from '../lib/build.js';
import { parseVtt, geminiAnalyze, buildPrompt } from '../lib/analysis.js';
import * as F from '../lib/frames.js';
import { wakeVideo, initWake } from './wake.js';
import { dupGuard } from './dupguard.js';
import * as P from './protocol.js';
import * as META from '../lib/meta.js';
import { STYLE_PREVIEWS } from './style-previews.js';
import { siteConfig, START_URL, SITES } from './sites.js';
import { railHtml, progressOf, STATUS } from './steps.js';

const chrome = globalThis.browser ?? globalThis.chrome;

/* Fonctions INJECTÉES dans la page d'un site (chrome.scripting.executeScript { func }).
   Chrome les sérialise en texte et les exécute DANS la page cible : elles ne doivent donc
   référencer aucune variable de ce module, seulement leurs arguments et les globals de la page. */
const FRA_CALL = (f, a) => window.__FRA[f](...a);
const KILL_BEFOREUNLOAD = () => {
  try { window.onbeforeunload = null; Object.defineProperty(window, 'onbeforeunload', { configurable: true, get() { return null; }, set() {} }); } catch (e) { /* rien */ }
  try { const pd = Event.prototype.preventDefault; Event.prototype.preventDefault = function () { if (this && this.type === 'beforeunload') return undefined; return pd.apply(this, arguments); }; } catch (e) { /* rien */ }
  try { Object.defineProperty(BeforeUnloadEvent.prototype, 'returnValue', { configurable: true, get() { return ''; }, set() {} }); } catch (e) { /* rien */ }
  window.addEventListener('beforeunload', (e) => { e.stopImmediatePropagation(); }, true);
};

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const TEST = new URLSearchParams(location.search).has('test'); // attentes raccourcies pour les essais
/* Chrome ne charge aucune vidéo dans une page cachée tant qu'elle n'en a jamais joué une. La fenêtre pilote lit des vidéos (captures de la vidéo
   d'origine, contrôle des clips) : on joue donc une vidéo muette d'une demi-seconde dès l'ouverture, pour que ces lectures marchent ensuite
   même quand la fenêtre est cachée. Ça ne suffit pas quand la page n'a JAMAIS été affichée (onglet ouvert en arrière-plan) : depuis la 4.4.0,
   les captures, les planches de lecture, la comparaison des clips (lib/frames.js) et la vidéo finale (mp4Info) lisent le fichier directement. */
initWake();
/* Chrome met en veille, voire décharge, un onglet resté longtemps en arrière-plan sans rien faire (par exemple pendant que la vidéo attend ton
   accord pour être publiée) : la fenêtre pilote ne répondait plus, puis repartait de zéro. On l'en exclut : jamais déchargée (le verrou
   « fruitradar-pilote », pris plus bas et tenu en permanence, empêche déjà sa mise en veille). */
try { chrome.tabs.getCurrent().then((me) => { if (me) chrome.tabs.update(me.id, { autoDiscardable: false }).catch(() => {}); }).catch(() => {}); } catch (e) { /* rien */ }
setInterval(() => { try { chrome.storage.session && chrome.storage.session.set({ piloteVivant: Date.now() }); } catch (e) { /* rien */ } }, 25000); // un peu d'activité régulière

let prod = null, auto = null, winId = null;
const tabs = {};
let stopFlag = false, running = false;
let waiters = [];
const hold = () => new Promise((res, rej) => { waiters.push({ res, rej }); });
const release = (ok = true) => { const w = waiters; waiters = []; w.forEach((x) => (ok ? x.res() : x.rej(new Stop('arrêt')))); return w.length; };
/* « Les mains » : une seule suite de gestes à la fois (joindre, taper, envoyer), dans l'onglet mis au premier plan.
   Chrome ralentit les onglets cachés : on n'y fait que regarder, jamais agir. */
/* Production en pause (une étape attend « Reprendre ») : aucun autre geste ne démarre entre-temps ; tout repart ensemble à la reprise. */
const gate = async () => {
  while (prod && prod.status === 'paused' && waiters.length) await hold();
  for (let i = 0; i < 60 && prod && prod.status === 'paused' && !waiters.length && !stopFlag; i++) await new Promise((r) => setTimeout(r, 50)); // le temps que la reprise relise les réglages
};
/* File à priorités : 2 = envoyer le prompt ChatGPT (c'est lui qui fixe le rythme de toute la vidéo), 1 = geste normal (lancer une scène chez Grok),
   0 = ce qui peut attendre (préparer le prompt suivant, remettre un onglet au premier plan). Un geste commencé n'est jamais coupé. */
const handQ = []; let handBusy = false, handSeq = 0, handsKey = null, warnedMin = false;
let homeKey = null; // onglet à remettre devant dès qu'aucun geste n'est en cours (ChatGPT tant qu'il dessine : une page cachée n'affiche pas toujours l'image finie)
async function goHome(from) {
  try {
    if (!homeKey || from === homeKey || handBusy || !(await tabAlive(homeKey))) return;
    const t = await chrome.tabs.get(tabs[homeKey]);
    if (!t.active && !handBusy) await chrome.tabs.update(t.id, { active: true });
  } catch (e) { /* onglet fermé entre-temps */ }
}
function withHands(key, fn, prio = 1) {
  return new Promise((res, rej) => { handQ.push({ key, fn, prio, res, rej, n: handSeq++ }); pumpHands(); });
}
async function front(key) { // l'onglet du geste doit être celui qu'on voit : un onglet caché ouvre mal ses menus
  try {
    const t = await chrome.tabs.get(tabs[key]);
    if (!t.active) { await chrome.tabs.update(t.id, { active: true }); await sleep(TEST ? 20 : 150); }
    if (!warnedMin) { const w = await chrome.windows.get(t.windowId); if (w.state === 'minimized') { warnedMin = true; log('La fenêtre Chrome où tournent les sites est réduite : ils y travaillent au ralenti et les menus s\'ouvrent mal. Laisse-la affichée (même derrière une autre).', 'warn'); } }
  } catch (e) { if (e instanceof Stop) throw e; }
}
async function pumpHands() {
  if (handBusy || !handQ.length) return;
  handQ.sort((a, b) => b.prio - a.prio || a.n - b.n);
  const j = handQ.shift(); handBusy = true;
  try { await gate(); handsKey = j.key; if (await tabAlive(j.key)) await front(j.key); j.res(await j.fn()); }
  catch (e) { j.rej(e); }
  finally { handsKey = null; handBusy = false; if (!handQ.length) goHome(j.key); pumpHands(); }
}
/* Pendant un geste, si un autre onglet de la fenêtre passe devant (clic ailleurs), on remet le bon : sinon le geste se fait à l'aveugle. */
chrome.tabs.onActivated.addListener((info) => {
  if (!handsKey || info.windowId !== winId) return;
  const id = tabs[handsKey];
  if (id && info.tabId !== id) chrome.tabs.update(id, { active: true }).catch(() => {});
});

/* ---------- temps : les minuteries d'un onglet caché sont ralenties par Chrome, pas celles d'un worker ---------- */
const ticker = new Worker(chrome.runtime.getURL('auto/tick.js'));
const ticks = new Map(); let tickN = 0;
ticker.onmessage = (e) => { const r = ticks.get(e.data); if (r) { ticks.delete(e.data); r(); } };
class Stop extends Error {}
class Blocked extends Error { constructor(reason, detail) { super(detail || reason); this.reason = reason; } } // pause immédiate : connexion, captcha
class Refused extends Error {} // le site refuse le contenu (modération) : on reformule
class Later extends Error {}
class Again extends Error {} // l'essai n'a rien envoyé (prompt resté dans la zone de saisie) : on recommence tout de suite, sans compter un échec // le site est occupé (trop de générations à la fois) : on réessaie plus tard, sans compter un échec
const REFUSAL = /(je ne peux pas|je ne suis pas en mesure|ne peux pas (générer|créer|produire)|i can.?t (help|create|generate|make)|i.?m (not able|unable)|unable to (generate|create)|content polic|politique de contenu|politiques? d.utilisation|usage polic|guidelines|lignes directrices|ne respecte pas|violat|modér|moderat|inappropri|not allowed|pas autoris|refus)/i;
/* Messages de consommation de Grok. « Vous avez utilisé 75 % de votre quota » (ou « atteint 75 % ») n'est qu'une information : la production continue.
   Seul un quota épuisé (100 %, « limite atteinte », « plus de générations », « réessaie dans 3 h ») l'arrête, avec un son et la raison.
   Un message « trop de générations à la fois » n'est pas un quota : il est traité à part (on réessaie un peu plus tard). */
function grokQuota(alerts) {
  for (const a of alerts || []) {
    const t = String(a || '');
    if (/(simultan|concurrent|à la fois|at (a|the same) time|en même temps)/i.test(t)) continue;
    if (/(plus (aucune|de) (génération|crédit|vidéo)s?|no (more )?(generations|credits|videos)( left| remaining)?\b|out of (generations|credits)|run out of|ran out of)/i.test(t)) return { full: true, text: t };
    // une barre de progression (« Génération… 100 % ») n'est pas un quota : il faut un mot de consommation
    if (!/(utilis|usage|quota|limit|consomm|crédit|credit|forfait|abonnement|subscription|upgrade|mettre à niveau|supergrok)/i.test(t)) continue;
    const pcts = [...t.matchAll(/(\d{1,3}(?:[.,]\d+)?)\s*%/g)].map((m) => Number(m[1].replace(',', '.')));
    if (pcts.some((p) => p >= 100)) return { full: true, text: t };
    if (pcts.some((p) => p > 0)) return { info: true, text: t };
    if (/(atteint|reached|hit (your|the)|[ée]puis[ée]|exhausted|d[ée]pass[ée]|exceeded|reviens (dans|plus tard|demain)|come back|réessa\w* (dans|plus tard|demain)|try again (in|later|tomorrow)|resets? (in|at|on)|réinitialis|renouvel)/i.test(t)) return { full: true, text: t };
  }
  return null;
}
// quota épuisé : pause avec son et notification (« alert ») ; la scène n'est jamais renvoyée toute seule à la reprise
const quotaPause = (s, text, sent) => new Blocked('quota Grok', `Grok : ton quota de générations est épuisé (« ${String(text).slice(0, 140)} »). ${sent ? `Le clip de la scène ${s.n} a peut-être été lancé juste avant : regarde l'onglet Grok. ` : `La scène ${s.n} n'est pas partie. `}Quand ton quota revient (Grok indique quand), clique sur Reprendre : je continue à partir de là, sans rien renvoyer en double`);
const sleep = (ms) => new Promise((res, rej) => {
  const id = ++tickN;
  ticks.set(id, () => (stopFlag ? rej(new Stop('arrêt demandé')) : res()));
  ticker.postMessage({ id, ms: TEST ? Math.min(ms, 400) : ms });
});
/* Rythme : les petites pauses entre deux gestes sont multipliées par ce facteur (Réglages → Création → Rythme). */
const pace = () => Math.min(1.5, Math.max(0.25, Number(auto && auto.pace) || 0.45));
const jitter = (a, b) => sleep((a + Math.random() * (b - a)) * pace());
/* timeout: Infinity = on attend tant qu'il faut (une génération peut être très longue). `nag` : au bout de ce délai,
   on prévient une fois (journal + notification) puis on continue d'attendre. */
async function until(fn, { timeout = 60000, every = 2500, what = 'la page', nag = 0, nagText = '' } = {}) {
  const t0 = Date.now(), limit = TEST ? Math.min(timeout, 25000) : timeout;
  let nagN = 0;
  for (;;) {
    const r = await fn();
    if (r) return r;
    const el = Date.now() - t0;
    if (el > limit) throw new Error(`délai dépassé : ${what}`);
    if (nag && !TEST && el > nag * (nagN + 1)) {
      nagN++;
      const min = Math.round(el / 60000);
      log(nagN === 1 && nagText ? nagText : `Toujours en attente depuis ${min} min (${what}). Je continue d'attendre.`, 'warn');
      if (nagN === 1 && auto.notifyErrors) notify('FruitRadar — ça prend du temps', `${nagText || `En attente depuis ${min} min : ${what}.`} L'automatisation continue d'attendre.`, 'info');
    }
    await sleep(every);
  }
}

/* ---------- journal et état ---------- */
let saveT = null;
async function save(now = false) {
  if (!prod) return;
  prod.updatedAt = Date.now();
  const write = async () => {
    saveT = null;
    if (!(await DB.getProd(prod.id))) return; // supprimée depuis le dashboard : on ne la recrée pas
    await DB.putProd(prod);
    const s = progress();
    await chrome.storage.local.set({ autoState: { id: prod.id, status: prod.status, step: prod.step, title: prod.title, msg: (prod.log[prod.log.length - 1] || {}).msg || '', done: s.done, total: s.total, pause: prod.pause || null, t: Date.now() } });
  };
  if (now) { clearTimeout(saveT); await write(); } else if (!saveT) saveT = setTimeout(write, 900);
}
const progress = () => progressOf(prod);
function log(msg, level = 'info') {
  if (!prod) return;
  prod.log.push({ t: Date.now(), level, msg });
  if (prod.log.length > 400) prod.log.splice(0, prod.log.length - 400);
  draw();
  save();
}
let startedAt = Date.now(), loadedId = null;
function draw() {
  if (!prod) return;
  $('#title').textContent = prod.title || 'Nouvelle vidéo';
  const s = progress(), last = prod.log[prod.log.length - 1];
  $('#meta').textContent = `Partie ${prod.part || 1}${prod.pkg ? `, ${prod.pkg.scenes.length} scènes, ${P.totalDuration(prod.pkg)} s` : ''}`;
  const stamp = $('#stamp'); stamp.textContent = STATUS[prod.status] || prod.status; stamp.className = 'stamp ' + prod.status;
  $('#steps').innerHTML = railHtml(prod);
  $('#now').textContent = prod.status === 'paused' ? ((prod.pause && prod.pause.reason) || 'En pause') : last ? last.msg : 'Démarrage…';
  $('#nowbox').className = 'now ' + prod.status;
  $('#count').textContent = s.total ? `${s.done}/${s.total}` : '';
  const m = $('#meter'); m.style.width = s.total ? `${Math.max(3, s.pct)}%` : '100%'; m.parentElement.className = 'meter' + (s.total || prod.status !== 'running' ? '' : ' wait');
  $('#pause').hidden = prod.status !== 'paused';
  if (prod.status === 'paused') $('#pauseWhy').textContent = (prod.pause && prod.pause.reason) || '';
  $('#btnStop').hidden = !(prod.status === 'running' || prod.status === 'paused' || prod.status === 'waiting');
  const box = $('#log');
  const atEnd = box.scrollHeight - box.scrollTop - box.clientHeight < 40, top = box.scrollTop; // on suit les nouvelles lignes seulement si on était déjà en bas
  box.innerHTML = prod.log.slice(-160).map((l) => `<p class="${l.level}"><span>${new Date(l.t).toLocaleTimeString('fr-FR')}</span>${esc(l.msg)}</p>`).join('');
  box.scrollTop = atEnd ? box.scrollHeight : top;
}
setInterval(() => { // temps écoulé depuis le lancement de cette fenêtre
  const el = $('#elapsed'); if (!el || !running) return;
  const sec = Math.floor((Date.now() - startedAt) / 1000), h = Math.floor(sec / 3600), mn = Math.floor((sec % 3600) / 60);
  el.textContent = `En route depuis ${h ? h + ' h ' : ''}${mn} min`;
}, 15000);
/* kind : 'done' (vidéo prête), 'alert' (besoin de toi), 'info' (essai raté, attente longue), null = sans son */
/* Son seul, même sans notification : « published » (fanfare) ou « error » (notes qui descendent, une fois par 20 s au plus).
   « error » : une erreur que FruitRadar rattrape seul (essai raté, prompt refusé, CapCut à finir à la main). Quand il a besoin de toi
   (pause, export bloqué, erreur inattendue), c'est la notification qui joue « alert » : jamais deux sons en même temps. */
let lastErrSound = 0;
function chime(kind) {
  if (!auto.sound) return;
  if (kind === 'error') { if (Date.now() - lastErrSound < 20000) return; lastErrSound = Date.now(); }
  chrome.runtime.sendMessage({ type: 'autoSound', kind }).catch(() => {});
}
async function notify(title, message, kind = 'alert') {
  try { chrome.notifications.create('fr-auto-' + Date.now(), { type: 'basic', iconUrl: chrome.runtime.getURL('icons/icon128.png'), title, message, priority: 2, requireInteraction: true }); } catch (e) {}
  // Son : seulement quand la vidéo est prête (« done ») ou quand ça bloque vraiment (« alert »). Jamais pour un essai raté, une attente ou une étape finie.
  if ((kind === 'done' || kind === 'alert') && auto.sound) chrome.runtime.sendMessage({ type: 'autoSound', kind }).catch(() => {});
}

/* ---------- onglets des sites ---------- */
/* Une clé d'onglet peut porter un numéro (« grok#3 » = l'onglet de la scène 3) : le site reste « grok ». */
const siteOf = (key) => String(key).split('#')[0];
const nameOf = (key) => SITES[siteOf(key)].name;
/* Lectures : sans effet sur la page, on peut les rejouer si la page changeait d'adresse à ce moment-là.
   Tout le reste (cliquer, joindre, envoyer) ne part qu'UNE fois : en cas de doute, c'est l'étape qui décide quoi faire, pas une relance aveugle. */
const READS = new Set(['grokUser', 'grokClips', 'capcutNewest', 'chatFind', 'chatProbe', 'state', 'answerText', 'attachedCount', 'diag', 'dump', 'pageText', 'visible', 'turboRow', 'turboRead', 'turboDialog', 'vtFind', 'vtCredits', 'vtText', 'capcutState', 'capcutTimes', 'capcutIssue', 'tiktokState', 'tiktokAccount', 'grokCheck', 'getChunk', 'ping']);
async function call(key, fn, ...args) {
  const tabId = tabs[key];
  const inject = async () => { for (let i = 0; ; i++) { try { await chrome.scripting.executeScript({ target: { tabId }, files: ['auto/page.js'] }); return; } catch (e) { if (i >= 3) throw new Error(`${nameOf(key)} ne répond pas (${e.message})`); await sleep(1200); } } };
  await inject();
  for (let i = 0; ; i++) {
    try {
      const res = await chrome.scripting.executeScript({ target: { tabId }, func: FRA_CALL, args: [fn, args] });
      return res && res[0] ? res[0].result : null;
    } catch (e) {
      if (!READS.has(fn) || i >= 3) { const err = new Error(`${nameOf(key)} ne répond pas (${e.message})`); err.unsure = !READS.has(fn); throw err; }
      await sleep(1200); await inject();
    }
  }
}
const cfgOf = (key) => siteConfig(siteOf(key), auto.selectors);
/* Tu as cet onglet sous les yeux : onglet devant, dans la fenêtre active, pas réduite. Sinon, c'est que tu fais autre chose (YouTube…). */
async function lookingAt(key) {
  try { const t = await chrome.tabs.get(tabs[key]); if (!t.active) return false; const w = await chrome.windows.get(t.windowId); return !!w.focused && w.state !== 'minimized'; } catch (e) { return false; }
}
async function tabAlive(key) { if (!tabs[key]) return false; try { await chrome.tabs.get(tabs[key]); return true; } catch (e) { delete tabs[key]; return false; } }
async function getMetaText() {
  const { autoMetaprompt } = await chrome.storage.local.get('autoMetaprompt');
  if (autoMetaprompt && autoMetaprompt.text) return autoMetaprompt.text;
  return (await META.provided()).text; // le Metaprompt fourni : le fichier du dossier, ou le serveur dans l'édition vendue
}
/* Les onglets des sites s'ouvrent dans la fenêtre où tourne l'automatisation (par défaut : ta fenêtre Chrome), rangés dans un groupe
   « FruitRadar » pour s'y retrouver. Chrome ne doit jamais les mettre en veille. */
let groupId = null;
async function groupTab(id) {
  try { await chrome.tabs.update(id, { autoDiscardable: false }); } catch (e) { /* onglet déjà fermé */ }
  if (auto.sameWindow !== true || !chrome.tabs.group) return;
  for (let i = 0; i < 2; i++) {
    try {
      groupId = await chrome.tabs.group(groupId != null ? { groupId, tabIds: [id] } : { tabIds: [id], createProperties: { windowId: winId } });
      if (chrome.tabGroups) await chrome.tabGroups.update(groupId, { title: 'FruitRadar', color: 'orange' });
      return;
    } catch (e) { groupId = null; } // groupe fermé entre-temps : on en refait un
  }
}
/* Fermer un onglet dont la page retient un travail non enregistré (TikTok Studio avec une vidéo prête) SANS la boîte « Quitter le site Web ? » de Chrome.
   Cette boîte bloquait tout tant qu'on ne cliquait pas « Quitter » (signalé le 18 novembre 2026) et une extension ne peut pas y cliquer.
   Moyen retenu, vérifié dans Chrome sur les trois façons qu'a une page de poser la question : un correctif posé dans le monde JavaScript de la page
   lui retire la possibilité de la poser, puis l'onglet est fermé. Un écouteur posé depuis le monde de l'extension ne suffit PAS (essayé).
   Ne pas décharger l'onglet (chrome.tabs.discard) avant de le fermer : ça évite aussi la boîte, mais ça a fait planter Chrome 5 fois sur 10 aux essais. */
async function shutTab(tabId) {
  const there = async () => { try { return await chrome.tabs.get(tabId); } catch (e) { return null; } };
  const soon = (pr, ms) => Promise.race([Promise.resolve(pr).catch(() => null), new Promise((r) => setTimeout(() => r(null), ms))]);
  if (!(await there())) return true;
  await soon(chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: KILL_BEFOREUNLOAD }), 2500);
  await soon(chrome.tabs.remove(tabId), 3000);
  for (let i = 0; i < 8; i++) { if (!(await there())) return true; await new Promise((r) => setTimeout(r, 250)); }
  return false;
}
/* Un onglet neuf s'ouvre d'abord en arrière-plan, puis passe devant DANS sa fenêtre.
   chrome.tabs.create(active) ramène toute la fenêtre Chrome au premier plan (par-dessus ce que tu fais) ; chrome.tabs.update(active), non.
   La fenêtre ne revient devant que quand c'est indispensable (showBriefly, ChatGPT qui ne dessine pas caché, validation). */
async function quietTab(url, active) {
  const t = await chrome.tabs.create({ windowId: winId, url, active: false });
  await groupTab(t.id);
  if (active) await chrome.tabs.update(t.id, { active: true }).catch(() => null);
  return t.id;
}
async function openSite(key, { url, needComposer = true, fresh = true, newTab = false, active = true } = {}) {
  url = url || START_URL(siteOf(key), auto);
  const name = nameOf(key);
  if (newTab && await tabAlive(key)) { // comme recliquer sur le lien : page entièrement neuve. La nouvelle s'ouvre d'abord, l'ancienne est fermée ensuite, sans « Quitter le site ? »
    const old = tabs[key]; delete tabs[key];
    tabs[key] = await quietTab(url, active);
    if (!(await shutTab(old))) log(`L'ancien onglet ${name} est resté ouvert : ferme-le toi-même (clique sur « Quitter » si Chrome le demande).`, 'warn');
  } else if (await tabAlive(key)) {
    if (fresh) await chrome.tabs.update(tabs[key], { url, active }); else if (active) await chrome.tabs.update(tabs[key], { active: true });
  } else tabs[key] = await quietTab(url, active);
  await sleep(250);
  await until(async () => { try { return (await chrome.tabs.get(tabs[key])).status === 'complete'; } catch (e) { return false; } }, { timeout: 60000, every: 250, what: `chargement de ${name}` });
  const cfg = cfgOf(key);
  let st = null;
  try {
    st = await until(async () => { const s = await call(key, 'state', cfg); return s && (s.block || !needComposer || s.composer) ? s : null; }, { timeout: 40000, every: 400, what: `${name} prêt` });
  } catch (e) {
    if (e instanceof Stop || e instanceof Blocked) throw e;
    throw new Error(/délai dépassé/.test(e.message) ? `${name} : la zone de saisie n'apparaît pas (interface changée ou page pas chargée)` : e.message);
  }
  if (st.block) throw new Blocked(st.block, st.block === 'connexion' ? `${name} demande de te connecter` : `${name} affiche une vérification (captcha)`);
  await jitter(250, 500);
  return cfg;
}
const blobToB64 = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = () => rej(r.error); r.readAsDataURL(blob); });
async function sendFiles(key, files) { // files : [{ blob, name }] → identifiants côté page
  const ids = [];
  for (const f of files) {
    const id = 'f' + Math.random().toString(36).slice(2, 9);
    const STEP = 3 * 1024 * 1024;
    for (let o = 0; o < f.blob.size || o === 0; o += STEP) { await call(key, 'putChunk', id, f.name, f.blob.type || 'application/octet-stream', await blobToB64(f.blob.slice(o, o + STEP))); if (!f.blob.size) break; }
    ids.push(id);
  }
  return ids;
}
/* Téléchargement par morceaux (requêtes « Range »), comme le fait un lecteur vidéo.
   Vu sur grok.com le 16 novembre 2026 : le serveur des clips (assets.grok.com) répond bien à un téléchargement entier, puis coupe la
   connexion au bout de 3 secondes (« Failed to fetch ») ; les mêmes 14 Mo passent sans problème en morceaux de 4 Mo. Un morceau qui
   échoue est redemandé, en plus petit. Rend null si l'adresse ne donne pas un fichier (page web, erreur). */
async function fetchRanged(src, fallbackType) {
  const ctl = new AbortController();
  const h = await fetch(src, { credentials: 'include', cache: 'no-store', signal: ctl.signal }); // on ne lit que l'en-tête : taille et type du fichier
  const total = Number(h.headers.get('content-length')) || 0, type = h.headers.get('content-type') || '';
  try { ctl.abort(); } catch (e) { /* déjà fini */ }
  if (!h.ok || /html/.test(type)) return null;
  let step = 4 * 1048576, off = 0; const parts = [];
  for (let n = 0; n < 4000 && (!total || off < total); n++) {
    let b = null, res = null, err = null, asked = step;
    for (let t = 0; t < 4 && !b; t++) {
      asked = step;
      try {
        res = await fetch(src, { credentials: 'include', cache: 'no-store', headers: { Range: `bytes=${off}-${off + asked - 1}` } });
        if (res.status === 416) break;
        if (res.status !== 206 && res.status !== 200) throw new Error(`réponse ${res.status}`);
        b = await res.blob();
      } catch (e) { err = e; b = null; step = Math.max(262144, Math.floor(step / 2)); await sleep(400 * (t + 1)); }
    }
    if (res && res.status === 416) break;
    if (!b) throw err || new Error('morceau illisible');
    parts.push(b); off += b.size;
    if (res.status === 200 || (!total && b.size < asked)) break; // 200 : le serveur a ignoré « Range », tout le fichier est là
  }
  if (total && off < total) throw new Error(`fichier incomplet (${off} octets sur ${total})`);
  return new Blob(parts, { type: /^(video|image|audio)\//.test(type) ? type : fallbackType });
}
async function pull(key, src, fallbackType, minSize = 2000) { // récupère un fichier affiché par la page (minSize : petit fichier texte accepté)
  const big = (b) => (b && b.size >= Math.max(1, minSize) ? (b.type ? b : new Blob([b], { type: fallbackType })) : null);
  const direct = async () => {
    const res = await fetch(src, { credentials: 'include' });
    if (!res.ok || /html/.test(res.headers.get('content-type') || '')) return null;
    return big(await res.blob());
  };
  const ranged = async () => big(await fetchRanged(src, fallbackType));
  // une vidéo : par morceaux d'abord (plus sûr, et obligatoire chez Grok) ; le reste : d'un coup d'abord
  const video = /^video\//.test(fallbackType || '');
  if (/^https?:/.test(src)) {
    for (const how of video ? [ranged, direct] : [direct, ranged]) { try { const b = await how(); if (b) return b; } catch (e) { if (e instanceof Stop) throw e; /* on essaie autrement, puis par la page */ } }
  }
  let r = null;
  for (const byRange of /^https?:/.test(src) ? (video ? [true, false] : [false, true]) : [false]) {
    const id = 'o' + Math.random().toString(36).slice(2, 9);
    r = await call(key, 'fetchOut', src, id, minSize, byRange);
    if (r && r.ok) {
      const parts = [];
      for (let i = 0; i < r.n; i++) { const b64 = await call(key, 'getChunk', id, i); const bin = atob(b64 || ''); const u = new Uint8Array(bin.length); for (let j = 0; j < bin.length; j++) u[j] = bin.charCodeAt(j); parts.push(u); }
      return new Blob(parts, { type: r.type || fallbackType });
    }
  }
  throw new Error('fichier généré impossible à récupérer' + (r && r.error ? ` (${r.error})` : ''));
}
async function submit(key, cfg, text, fileIds = []) {
  if (fileIds.length) {
    const a = await call(key, 'attach', fileIds, cfg);
    if (!a || !a.ok) throw new Error(`${nameOf(key)} : pièce jointe refusée (${(a && a.error) || 'inconnu'})`);
    await jitter(2000, 3200); // le site téléverse (l'envoi attend de toute façon que le bouton soit actif)
  }
  const before = await call(key, 'state', cfg);
  const t = await call(key, 'setText', text, cfg);
  if (!t || !t.ok) throw new Error(`${nameOf(key)} : ${(t && t.error) || 'saisie impossible'}`);
  await jitter(900, 1800);
  let s;
  try { s = await call(key, 'send', cfg, TEST ? 8000 : 90000); } catch (e) {
    if (!e.unsure) throw e;
    await sleep(2500); // la page a changé pendant le clic : le message est-il parti ? On ne reclique pas sans savoir.
    const now = await call(key, 'state', cfg).catch(() => null);
    if (now && (now.busy || now.users > before.users)) s = { ok: true, how: 'vérifié après coup' }; else throw e;
  }
  if (!s || !s.ok) throw new Error(`${nameOf(key)} : ${(s && s.error) || 'envoi impossible'}`);
  await call(key, 'dropFiles', fileIds);
  return before;
}

/* ---------- disque ---------- */
async function toDisk(blob, path) {
  if (!auto.saveToDisk) return; // par défaut tout reste dans l'extension (Mes productions)
  try {
    const url = URL.createObjectURL(blob);
    await chrome.downloads.download({ url, filename: `FruitRadar/Productions/${prod.folder}/${path}`, conflictAction: 'overwrite', saveAs: false });
    setTimeout(() => URL.revokeObjectURL(url), 120000);
  } catch (e) { log(`Enregistrement sur le disque impossible pour ${path} : ${e.message}`, 'warn'); }
}
const keep = async (name, blob) => { await DB.putMedia({ key: `${prod.id}/${name}`, prodId: prod.id, name, blob }); return `${prod.id}/${name}`; };
const media = async (key) => { const m = key && await DB.getMedia(key); return m ? m.blob : null; };
/* Un fichier du disque (la vidéo arrivée dans tes Téléchargements), quand Chrome autorise FruitRadar à lire les fichiers.
   Par XMLHttpRequest : fetch() refuse toujours les adresses file://, même avec cette autorisation (c'est ce qui faisait échouer la lecture de l'export CapCut). */
const readLocal = (url) => new Promise((ok, ko) => {
  const x = new XMLHttpRequest();
  try { x.open('GET', url); } catch (e) { ko(e); return; }
  x.responseType = 'blob'; x.timeout = 180000;
  x.onload = () => ((x.status === 200 || x.status === 0) && x.response && x.response.size ? ok(x.response) : ko(new Error(x.status ? `réponse ${x.status}` : 'fichier vide ou illisible')));
  x.onerror = () => ko(new Error('lecture refusée par Chrome'));
  x.ontimeout = () => ko(new Error('lecture trop longue'));
  x.send();
});
const fileUrl = (path) => { const parts = String(path).replace(/\\/g, '/').replace(/^\/+/, '').split('/'); return 'file:///' + parts.map((x, n) => (n === 0 && /^[A-Za-z]:$/.test(x) ? x : encodeURIComponent(x))).join('/'); };
/* La vidéo exportée, lue dans tes Téléchargements. Plusieurs essais espacés : juste après le téléchargement, l'antivirus
   (ou la vérification de Chrome) garde souvent le fichier quelques secondes, et une seule lecture immédiate échouait. */
async function readExport(path, n = 6) {
  const allowed = await new Promise((r) => { try { chrome.extension.isAllowedFileSchemeAccess(r); } catch (e) { r(false); } });
  prod.fileAccess = !!allowed;
  if (!allowed) return { error: 'Chrome n\'autorise pas FruitRadar à lire les fichiers du disque' };
  let last = '';
  for (let i = 0; i < n; i++) {
    if (i) await sleep(TEST ? 200 : [0, 3000, 5000, 8000, 12000, 20000][Math.min(i, 5)]);
    try { const b = await readLocal(fileUrl(path)); if (b.size > 2000) return { blob: /^video\//.test(b.type || '') ? b : new Blob([b], { type: 'video/mp4' }) }; last = 'fichier vide'; } catch (e) { last = e.message; }
  }
  return { error: `${last}${n > 1 ? ` (${n} essais)` : ''}` };
}
const pad = (n) => String(n).padStart(2, '0');

/* ---------- étapes : essais puis pause ---------- */
async function snapPage(key, why, detail = null) {
  if (!key || !(await tabAlive(key))) return;
  try { prod.lastDump = { site: nameOf(key), why, at: Date.now(), ...(detail ? { detail } : {}), page: await call(key, 'dump', cfgOf(key)) }; } catch (e) {}
}
async function attempt(label, fn, key = null) {
  const max = Math.max(1, auto.retries || 2);
  let soft = 0, later = 0, again = 0; // soft : niveau de reformulation après un refus (modération) ; later : attentes « site occupé » ; again : envois qui n'étaient pas partis
  let failed = false;
  for (let i = 1; ; i++) {
    try {
      await gate(); const out = await fn(i, soft);
      if (failed && prod.lastDump && String(prod.lastDump.why || '').startsWith(label)) { prod.lastDump.fixed = Date.now(); save(); } // l'essai suivant a réussi : ce relevé n'est plus un problème
      return out;
    } catch (e) {
      if (e instanceof Stop) throw e;
      failed = true;
      if (e instanceof Again && (again = again + 1) <= 3) { i--; log(`${label} : ${e.message}`, 'warn'); await sleep(TEST ? 200 : 1000); continue; }
            if (e instanceof Later && (later = (later || 0) + 1) <= 30) { i--; log(`${label} : ${e.message} Nouvel essai dans un instant.`, 'warn'); await sleep(TEST ? 800 : 30000); continue; }
      await snapPage(key, `${label} : ${e.message}`);
      if (e instanceof Refused && soft < 2) {
        soft++; i--;
        log(`${label} : refusé par le site (${e.message.slice(0, 120)}). Je reformule le prompt en plus doux et je relance (${soft}/2).`, 'warn');
        chime('error');
        if (auto.notifyErrors) notify('FruitRadar — prompt refusé', `${label} : je reformule et je relance (${soft}/2).`, 'info');
        await jitter(3000, 6000); continue;
      }
      if (e instanceof Refused) { await pause(`${label} : encore refusé après 2 reformulations. Corrige le prompt (bouton « Refaire » ou dans le site) puis Reprendre`); soft = 0; i = 0; continue; }
      if (e instanceof Blocked) await pause(e.message);
      else if (i >= max) await pause(`${label} : ${e.message}`);
      else {
        log(`${label} : ${e.message}. Nouvel essai (${i + 1}/${max}).`, 'warn');
        chime('error');
        if (auto.notifyErrors) notify('FruitRadar — un essai a échoué', `${label} : ${e.message}. Nouvel essai en cours.`, 'info');
        await jitter(3000, 6000); continue;
      }
      i = 0; // après « Reprendre », on repart sur une série d'essais
    }
  }
}
async function pause(reason) {
  prod.status = 'paused'; prod.pause = { reason, at: Date.now() };
  log(`Pause : ${reason}`, 'err');
  await save(true);
  const quota = /^Grok : ton quota/.test(reason); // quota Grok épuisé : la notification (avec le son) dit pourquoi, sans le « corrige » habituel
  await notify(quota ? 'FruitRadar — quota Grok épuisé' : 'FruitRadar — automatisation en pause', quota ? `${reason}.` : `${reason}. Corrige dans la fenêtre du site puis clique sur Reprendre.`);
  await hold();
  if (stopFlag) throw new Stop('arrêt demandé');
  auto = (await getSettings()).auto; // un réglage ou un sélecteur corrigé pendant la pause est pris en compte
  prod.status = 'running'; prod.pause = null;
  log('Reprise.');
  await save(true);
}

/* 1 — Source : vidéo d'origine, captures, transcription */
/* Captures, planches de lecture et comparaison des clips : d'abord par décodage direct du fichier (lib/frames.js), qui marche même quand la
   fenêtre pilote est cachée ; la balise <video> ne sert plus que de secours (codec que ce Chrome ne décode pas tout seul, fichier non MP4). */
let framesBy = '', framesWhy = '', softOnly = false;
const viewOf = (tr) => (tr.rot % 180 ? [tr.height, tr.width] : [tr.width, tr.height]);
// image entièrement noire ? (décodeur qui rend des images vides) : on regarde un point sur cent
const blackCanvas = (sh) => { const d = sh.ctx.getImageData(0, 0, sh.c.width, sh.c.height).data; for (let k = 0; k < d.length; k += 400) if (d[k] > 14 || d[k + 1] > 14 || d[k + 2] > 14) return false; return true; };
async function captureFramesCodec(blob, n, soft) {
  const tr = await F.mp4Video(blob), dur = tr.duration > 0 ? tr.duration : 60, [vw, vh] = viewOf(tr);
  const W = 540, H = Math.round(W * (vh || 16) / (vw || 9));
  const times = [0.4, ...Array.from({ length: n - 1 }, (_, i) => (dur * (i + 1)) / n)].map((t) => Math.max(0, Math.min(t, dur - 0.1)));
  const cans = times.map(() => null);
  const r = await F.grabFrames(blob, times, (i, frame) => { const sh = F.sheet(W, H); F.drawFrame(sh.ctx, frame, 0, 0, W, H, tr.rot); cans[i] = sh; }, tr, { soft });
  const made = cans.filter(Boolean);
  if (!made.length) throw new Error('aucune capture');
  if (made.every(blackCanvas)) throw new Error('images toutes noires');
  const out = [];
  for (let i = 0; i < times.length; i++) if (cans[i]) out.push({ t: times[i], blob: await cans[i].blob('image/jpeg', 0.82) });
  if (!out.filter((f) => f.blob).length) throw new Error('aucune capture');
  return { frames: out.filter((f) => f.blob), duration: dur, by: r.by };
}
async function captureFrames(blob, n = 8) {
  const why = []; framesWhy = '';
  for (const soft of [false, true]) {
    try { const r = await captureFramesCodec(blob, n, soft); softOnly = soft; framesBy = `fichier, ${r.by}`; framesWhy = why.join(' ; '); return r; }
    catch (e) { why.push(e.message); if (!/noires/.test(e.message)) break; } // le décodeur logiciel a déjà été essayé, sauf si les images sortent noires
  }
  framesWhy = why.join(' ; ');
  const woke = await wakeVideo(); // le lecteur de la page ne marche que si l'onglet a déjà été affiché
  try { const r = await captureFramesVideo(blob, n); framesBy = 'lecteur de la page'; return r; }
  catch (e) { throw new Error(`lecture directe : ${framesWhy} ; lecteur de la page : ${e.message}${woke ? '' : ', onglet jamais affiché'}`); }
}
async function captureFramesVideo(blob, n = 8) {
  const url = URL.createObjectURL(blob), v = document.createElement('video');
  v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = url;
  try {
    await new Promise((res, rej) => { const t = setTimeout(() => rej(new Error('vidéo illisible')), 20000); v.onloadeddata = () => { clearTimeout(t); res(); }; v.onerror = () => { clearTimeout(t); rej(new Error('format vidéo non lisible')); }; });
    const dur = Number.isFinite(v.duration) && v.duration > 0 ? v.duration : 60;
    const W = 540, H = Math.round(W * (v.videoHeight || 16) / (v.videoWidth || 9));
    const c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d');
    const times = [0.4, ...Array.from({ length: n - 1 }, (_, i) => (dur * (i + 1)) / n)].map((t) => Math.min(t, dur - 0.1));
    const out = [];
    for (const t of times) {
      await new Promise((res) => { let d = false; const fin = () => { if (!d) { d = true; v.removeEventListener('seeked', fin); res(); } }; v.addEventListener('seeked', fin); v.currentTime = t; setTimeout(fin, 2500); });
      ctx.drawImage(v, 0, 0, W, H);
      out.push({ t, blob: await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.82)) });
    }
    return { frames: out.filter((f) => f.blob), duration: dur };
  } finally { URL.revokeObjectURL(url); v.removeAttribute('src'); try { v.load(); } catch (e) {} }
}
/* Pour que Claude « regarde » la vidéo : toute la vidéo en planches de 12 images (3 × 4), dans l'ordre,
   2 images par seconde (moins si la vidéo est longue, pour rester sous 8 planches), le temps écrit sur chaque image. */
const stamp = (ctx, t, x, y) => {
  const lab = `${String(Math.floor(t / 60)).padStart(2, '0')}:${(t % 60).toFixed(1).padStart(4, '0')}`;
  ctx.font = 'bold 26px sans-serif'; const w = ctx.measureText(lab).width;
  ctx.fillStyle = 'rgba(0,0,0,.75)'; ctx.fillRect(x + 6, y + 6, w + 16, 36); ctx.fillStyle = '#FFD24A'; ctx.fillText(lab, x + 14, y + 33);
};
async function readingSheetsCodec(blob, { perSec = 2, perSheet = 12, maxSheets = 8 } = {}) {
  const tr = await F.mp4Video(blob), dur = tr.duration > 0 ? tr.duration : 60, [vw, vh] = viewOf(tr);
  const n = Math.min(Math.ceil(dur * perSec), perSheet * maxSheets), step = dur / n;
  const COLS = 3, TW = 360, TH = Math.round(TW * (vh || 16) / (vw || 9)), GAP = 6;
  const pages = [];
  for (let s0 = 0; s0 < n; s0 += perSheet) {
    const k = Math.min(perSheet, n - s0), rows = Math.ceil(k / COLS), sh = F.sheet(COLS * TW + (COLS + 1) * GAP, rows * TH + (rows + 1) * GAP);
    sh.ctx.fillStyle = '#000'; sh.ctx.fillRect(0, 0, sh.c.width, sh.c.height); pages.push({ s0, k, sh });
  }
  const times = Array.from({ length: n }, (_, i) => Math.max(0, Math.min(i * step + step / 2, dur - 0.05)));
  await F.grabFrames(blob, times, (i, frame) => {
    const pg = pages[Math.floor(i / perSheet)], j = i - pg.s0;
    const x = GAP + (j % COLS) * (TW + GAP), y = GAP + Math.floor(j / COLS) * (TH + GAP);
    F.drawFrame(pg.sh.ctx, frame, x, y, TW, TH, tr.rot); stamp(pg.sh.ctx, times[i], x, y);
  }, tr, { soft: softOnly });
  const sheets = [];
  for (const pg of pages) sheets.push({ from: pg.s0 * step, to: Math.min((pg.s0 + pg.k) * step, dur), blob: await pg.sh.blob('image/jpeg', 0.8) });
  return { sheets: sheets.filter((x) => x.blob), duration: dur, perSec: n / dur };
}
async function readingSheets(blob, opts = {}) {
  let why = '';
  try { return await readingSheetsCodec(blob, opts); } catch (e) { why = e.message; }
  await wakeVideo();
  try { return await readingSheetsVideo(blob, opts); } catch (e) { throw new Error(`lecture directe : ${why} ; lecteur de la page : ${e.message}`); }
}
async function readingSheetsVideo(blob, { perSec = 2, perSheet = 12, maxSheets = 8 } = {}) {
  const url = URL.createObjectURL(blob), v = document.createElement('video');
  v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = url;
  try {
    await new Promise((res, rej) => { const t = setTimeout(() => rej(new Error('vidéo illisible')), 20000); v.onloadeddata = () => { clearTimeout(t); res(); }; v.onerror = () => { clearTimeout(t); rej(new Error('vidéo illisible')); }; });
    const dur = Number.isFinite(v.duration) && v.duration > 0 ? v.duration : 60;
    const n = Math.min(Math.ceil(dur * perSec), perSheet * maxSheets), step = dur / n;
    const COLS = 3, ROWS = Math.ceil(perSheet / COLS), TW = 360, TH = Math.round(TW * (v.videoHeight || 16) / (v.videoWidth || 9)), GAP = 6;
    const sheets = [];
    for (let s0 = 0; s0 < n; s0 += perSheet) {
      const k = Math.min(perSheet, n - s0), rows = Math.ceil(k / COLS);
      const c = document.createElement('canvas'); c.width = COLS * TW + (COLS + 1) * GAP; c.height = rows * TH + (rows + 1) * GAP;
      const ctx = c.getContext('2d'); ctx.fillStyle = '#000'; ctx.fillRect(0, 0, c.width, c.height);
      for (let i = 0; i < k; i++) {
        const t = Math.min((s0 + i) * step + step / 2, dur - 0.05);
        await new Promise((res) => { let d = false; const fin = () => { if (!d) { d = true; v.removeEventListener('seeked', fin); res(); } }; v.addEventListener('seeked', fin); v.currentTime = t; setTimeout(fin, 2500); });
        const x = GAP + (i % COLS) * (TW + GAP), y = GAP + Math.floor(i / COLS) * (TH + GAP);
        ctx.drawImage(v, x, y, TW, TH);
        const lab = `${String(Math.floor(t / 60)).padStart(2, '0')}:${(t % 60).toFixed(1).padStart(4, '0')}`;
        ctx.font = 'bold 26px sans-serif'; const w = ctx.measureText(lab).width;
        ctx.fillStyle = 'rgba(0,0,0,.75)'; ctx.fillRect(x + 6, y + 6, w + 16, 36); ctx.fillStyle = '#FFD24A'; ctx.fillText(lab, x + 14, y + 33);
      }
      sheets.push({ from: s0 * step, to: Math.min((s0 + k) * step, dur), blob: await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.8)) });
    }
    return { sheets: sheets.filter((x) => x.blob), duration: dur, perSec: n / dur };
  } finally { URL.revokeObjectURL(url); v.removeAttribute('src'); try { v.load(); } catch (e) {} }
}
async function makeSheets(blob) {
  try {
    const r = await readingSheets(blob);
    prod.sheets = [];
    for (let i = 0; i < r.sheets.length; i++) prod.sheets.push({ from: r.sheets[i].from, to: r.sheets[i].to, key: await keep(`lecture-${pad(i + 1)}.jpg`, r.sheets[i].blob) });
    prod.sheetsRate = Math.round(r.perSec * 10) / 10;
    log(`Vidéo découpée pour Claude : ${prod.sheets.length} planches de lecture (${String(prod.sheetsRate).replace('.', ',')} image/s, toute la vidéo).`);
  } catch (e) { prod.sheets = []; log(`Planches de lecture impossibles (${e.message}) : Claude aura les captures et la transcription.`, 'warn'); }
}
/* Texte exporté par TurboScribe → lignes minutées. Le vrai fichier ressemble à :
     (Transcrit par TurboScribe. Passez à Illimité pour supprimer ce message.)

     (0:00 - 0:11)
     Le texte dit pendant ce passage…
   On accepte aussi « (0:05) texte » ou « [0:05] texte » sur une seule ligne. */
const secOf = (a, b, c) => (c !== undefined ? Number(a) * 3600 + Number(b) * 60 + Number(c) : Number(a) * 60 + Number(b));
function parseTranscript(text) {
  const out = []; let cur = null;
  for (const raw of String(text || '').replace(/^﻿/, '').split(/\r?\n/)) {
    const l = raw.trim();
    if (!l) { cur = null; continue; }
    if (/^\(?\s*(transcrit par|transcribed by)\s+turboscribe/i.test(l)) continue; // bandeau de l'offre gratuite
    let m = l.match(/^[([]?\s*(\d{1,2}):(\d{2})(?::(\d{2}))?\s*[-–—]\s*\d{1,2}:\d{2}(?::\d{2})?\s*[)\]]?\s*(.*)$/);
    if (m) { cur = { start: secOf(m[1], m[2], m[3]), text: (m[4] || '').trim() }; out.push(cur); continue; }
    m = l.match(/^[([]\s*(\d{1,2}):(\d{2})(?::(\d{2}))?\s*[)\]]\s*[-–:]?\s*(.+)$/) || l.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?\s+[-–:]?\s*(.+)$/);
    if (m) { cur = null; out.push({ start: secOf(m[1], m[2], m[3]), text: m[4].trim() }); continue; }
    if (cur) cur.text = cur.text ? `${cur.text} ${l}` : l; else out.push({ start: null, text: l });
  }
  return out.filter((x) => x.text);
}
const fmtClock = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
async function keepTranscript(text, how, site = 'TurboScribe') {
  const lines = parseTranscript(text);
  if (lines.map((x) => x.text).join(' ').length < 20) return null;
  const clean = lines.map((x) => (x.start !== null ? `[${fmtClock(x.start)}] ${x.text}` : x.text)).join('\n');
  const b = new Blob([clean], { type: 'text/plain' });
  prod.transcriptKey = await keep('transcription.txt', b);
  await toDisk(b, 'transcription.txt').catch(() => {});
  log(`${site} : transcription récupérée (${how}, ${lines.length} passages).`);
  return lines;
}
/* VideoTranscriber (videotranscriber.ai) : on dépose la vidéo, « Transcribe », on attend la file d'attente du site (souvent quelques minutes),
   puis on lit le texte minuté dans les données du site. Compte gratuit : 10 transcriptions par jour. */
/* Affiche vraiment un onglet piloté le temps d'une action que Chrome refuse dans une page cachée (charger une vidéo…),
   puis rend la main à la fenêtre où tu étais. */
async function showBriefly(key, fn) {
  let back = null;
  try { const w = await chrome.windows.getLastFocused(); back = w ? w.id : null; } catch (e) { /* aucune fenêtre au premier plan */ }
  const t = await chrome.tabs.update(tabs[key], { active: true });
  let st = ''; try { st = (await chrome.windows.get(t.windowId)).state; } catch (e) { /* fenêtre fermée */ }
  await chrome.windows.update(t.windowId, st === 'minimized' ? { focused: true, state: 'normal' } : { focused: true }).catch(() => null);
  try {
    for (let i = 0; i < 20; i++) { if (await call(key, 'visible').catch(() => false)) break; await sleep(250); } // le temps que Chrome affiche la page
    return await fn();
  } finally { if (back !== null && back !== t.windowId) await chrome.windows.update(back, { focused: true }).catch(() => null); }
}
async function vtTranscript(blob, name) {
  let cfg = await openSite('vt', { needComposer: false });
  const maxWait = Math.max(5, Number(auto.turboWaitMin) || 30) * 60000;
  const bad = []; // essais ratés (le site les garde dans sa liste, sous le même nom)
  const find = (since) => call('vt', 'vtFind', name, since || 0, bad).catch(() => null);
  // raté côté site : « failed », « timeout » (file d'attente abandonnée, relevé le 17/11/2026), ou file fermée sans succès
  const dead = (r) => !!r && r.found && r.status !== 'success' && (/fail|error|cancel|timeout|expire|reject/i.test(r.status) || r.queue === 'closed' || (!!r.error && r.status !== 'processing'));
  const why = (r) => `le site annonce un échec (${[r.status, r.error].filter(Boolean).join(' : ').slice(0, 120) || 'sans détail'})`;
  const waitDone = (r0) => until(async () => {
    const r = await find(0);
    if (!r || !r.found) return null;
    if (dead(r)) { bad.push(r.id); throw Object.assign(new Error(why(r)), { vtDead: true }); }
    return r.status === 'success' ? r : null;
  }, { timeout: maxWait, every: TEST ? 300 : 4000, what: 'transcription VideoTranscriber', nag: 5 * 60000 });
  /* Un envoi : dépôt, modèle, UN clic sur « Transcribe », puis la vidéo doit apparaître dans les données du site */
  const send = async (model, left) => {
    const t0 = Date.now();
    const ids = await sendFiles('vt', [{ blob, name }]);
    let up = await call('vt', 'vtUpload', ids, cfg, model, false);
    if (up && (up.hidden || up.grey)) { // page cachée : Chrome n'y charge pas la vidéo, le site ne lit pas sa durée et garde « Transcribe » grisé
      log('VideoTranscriber : la fenêtre d\'automatisation est cachée, et le site a besoin que sa page soit affichée pour lire la vidéo. Je l\'affiche quelques secondes, puis je te rends la main.', 'warn');
      if (up.grey) cfg = await openSite('vt', { needComposer: false }); // dépôt déjà tenté dans la page cachée : on repart d'une page neuve
      up = await showBriefly('vt', () => call('vt', 'vtUpload', ids, cfg, model, true));
    }
    await call('vt', 'dropFiles', ids).catch(() => null);
    if (!up || !up.ok) { await snapPage('vt', 'dépôt du fichier'); throw new Error((up && up.error) || 'envoi du fichier impossible'); }
    log(`VideoTranscriber : vidéo déposée, clic sur « Transcribe » (modèle ${model}${left !== null ? `, il te restait ${left} transcription${left > 1 ? 's' : ''}` : ''}).`);
    // l'envoi du fichier se fait après le clic : la vidéo apparaît dans les données du site quand il est fini (compter large pour un gros fichier)
    const upWait = TEST ? 15000 : Math.max(180000, Math.round(blob.size / 60000) * 1000);
    try { await until(async () => { const r = await find(t0); return r && r.found ? r : null; }, { timeout: upWait, every: TEST ? 300 : 2500, what: 'envoi de la vidéo à VideoTranscriber' }); } catch (e) {
      if (e instanceof Stop || e instanceof Blocked) throw e;
      await snapPage('vt', 'vidéo absente de la liste après l\'envoi'); throw new Error('la vidéo n\'apparaît pas dans la liste du site après l\'envoi');
    }
    log('VideoTranscriber : vidéo reçue par le site.');
  };
  let rec = null;
  for (let i = 0; i < 3 && !(rec && rec.found); i++) { rec = await find(0); if (!(rec && rec.found)) await sleep(400); }
  if (rec && rec.found && dead(rec)) { bad.push(rec.id); rec = null; } // un ancien essai raté de ce fichier : on renvoie
  if (rec && rec.found) {
    log('VideoTranscriber a déjà ce fichier : je ne le renvoie pas.'); // ne pas dépenser une deuxième transcription du jour
    log(`VideoTranscriber transcrit la vidéo… (j'attends jusqu'à ${Math.round(maxWait / 60000)} min)`);
    rec = await waitDone();
  } else {
    const cr = await call('vt', 'vtCredits').catch(() => null);
    if (cr && cr.ok && cr.basic <= 0 && cr.premium <= 0) throw new Error(`plus de transcription gratuite aujourd'hui${cr.resetAt ? ` (retour ${new Date(cr.resetAt).toLocaleString('fr-FR', { weekday: 'long', hour: '2-digit', minute: '2-digit' })})` : ''}`);
    // modèle simple d'abord (10 par jour) ; s'il échoue côté site, un second essai avec l'autre modèle, tant qu'il en reste
    const models = cr && cr.ok ? [cr.basic > 0 ? 'Basic' : '', cr.premium > 0 ? 'Advanced' : ''].filter(Boolean) : ['Basic'];
    rec = null;
    for (let k = 0; k < models.length && !rec; k++) {
      const model = models[k], left = cr && cr.ok ? (model === 'Basic' ? cr.basic : cr.premium) : null;
      try {
        await send(model, left);
        log(`VideoTranscriber transcrit la vidéo… (file d'attente du site : de une à quelques minutes, j'attends jusqu'à ${Math.round(maxWait / 60000)} min)`);
        rec = await waitDone();
      } catch (e) {
        if (e instanceof Stop || e instanceof Blocked || !e.vtDead || k + 1 >= models.length) throw e;
        log(`VideoTranscriber : ${e.message} avec le modèle ${model}. Je renvoie la vidéo avec le modèle ${models[k + 1]}.`, 'warn');
        cfg = await openSite('vt', { needComposer: false }); // page neuve pour le second envoi
      }
    }
  }
  let tx = null;
  for (let i = 0; i < 3; i++) { tx = await call('vt', 'vtText', rec.id).catch((e) => ({ ok: false, error: e.message })); if (tx && tx.ok && tx.text) break; await sleep(TEST ? 300 : 2000); }
  if (!tx || !tx.ok || !tx.text) { await snapPage('vt', `lecture du texte : ${(tx && tx.error) || 'vide'}`); throw new Error(`transcription faite mais texte illisible (${(tx && tx.error) || 'vide'})`); }
  if (tx.locked || (tx.mode && tx.mode !== 'full')) log('VideoTranscriber : le site ne donne qu\'une partie du texte avec le compte gratuit.', 'warn');
  const lines = await keepTranscript(tx.text, `${tx.n} passages lus dans les données du site`, 'VideoTranscriber');
  if (!lines || !lines.length) throw new Error('texte vide');
  return lines;
}
const TRANSCRIBERS = { vt: ['VideoTranscriber', vtTranscript], turbo: ['TurboScribe', (blob, name) => turboTranscript(blob, name)] };
/* Transcrit avec le site choisi dans les réglages ; s'il échoue (quota, panne, interface changée), l'autre site prend le relais */
async function transcribe(blob, name) {
  const order = auto.transcriber === 'turbo' ? ['turbo', 'vt'] : ['vt', 'turbo'];
  let last = null;
  for (let i = 0; i < order.length; i++) {
    const [label, fn] = TRANSCRIBERS[order[i]];
    try { return { lines: await fn(blob, name), from: label }; } catch (e) {
      if (e instanceof Stop) throw e;
      last = e;
      log(`${label} : ${String(e.message).replace(new RegExp(`^${label}\\s*:\\s*`), '')}.${i + 1 < order.length ? ` J'essaie ${TRANSCRIBERS[order[i + 1]][0]}.` : ''}`, 'warn');
    }
  }
  throw last || new Error('aucun site de transcription');
}
/* Script exact d'une production faite dans FruitRadar : chaque scène, son minutage et ses répliques, dans l'ordre */
function scriptOf(pv) {
  const k = pv && pv.pkg;
  if (!k || !(k.scenes || []).length) return { text: '', lines: [] };
  const out = [], lines = []; let t = 0;
  for (const sc of [...k.scenes].sort((a, b) => a.n - b.n)) {
    const said = P.speakerLines(sc.video);
    out.push(`Scène ${sc.n} [${fmtClock(t)}, ${sc.duree || 0} s]${sc.titre ? ` — ${sc.titre}` : ''}`);
    if (!said.length) out.push('  (aucune réplique dans cette scène)');
    for (const l of said) { out.push(`  ${l.who} : « ${l.text} »`); lines.push({ start: t, text: `${l.label || l.who} : ${l.text}` }); }
    t += sc.duree || 0;
  }
  return { text: out.join('\n'), lines };
}
/* Mémoire complète de la série pour une suite : la bible de chaque partie déjà faite, puis le script exact de la dernière */
async function seriesMemory() {
  const chain = []; let id = prod.prevId;
  for (let i = 0; i < 6 && id; i++) { const p = await DB.getProd(id).catch(() => null); if (!p || chain.some((x) => x.id === p.id)) break; chain.unshift(p); id = p.prevId; }
  if (!chain.length) return null;
  const last = chain[chain.length - 1], sc = scriptOf(last), L = [];
  L.push('MÉMOIRE DE LA SÉRIE — tout ce qui a déjà été publié, dans l\'ordre. Les noms, les voix et les répliques écrits ici sont exacts : ils priment sur toute transcription.', '');
  for (const p of chain) {
    const m = (p.pkg && p.pkg.meta) || {};
    L.push(`===== PARTIE ${p.part || 1} — ${m.titre || p.title || 'sans titre'} =====`);
    if (p.pkg && p.pkg.bible) L.push(p.pkg.bible.trim());
    else L.push('(pas de résumé enregistré pour cette partie)');
    L.push('');
  }
  if (sc.text) L.push(`===== SCRIPT EXACT DE LA PARTIE ${last.part || 1} (la dernière publiée) : toutes les scènes et toutes les répliques, jusqu'à la fin =====`, sc.text, '', 'La nouvelle partie démarre juste après la dernière réplique ci-dessus.');
  return { text: L.join('\n'), parts: chain.length, script: sc, last };
}
/* TurboScribe, comme à la main : « Transcrire des fichiers » → la vidéo → « Transcrire » → attendre la coche verte →
   « … » → « Exporter la transcription » (lue directement, rien n'est téléchargé sur le PC). */
async function turboTranscript(blob, name) {
  const cfg = await openSite('turbo', { needComposer: false });
  const maxWait = Math.max(5, Number(auto.turboWaitMin) || 30) * 60000;
  const rowNow = () => call('turbo', 'turboRow', name).catch(() => null);
  let had = null;
  for (let i = 0; i < 4 && !(had && had.found); i++) { had = await rowNow(); if (!(had && had.found)) await sleep(500); } // la liste arrive un instant après la page
  if (had && had.found) log('TurboScribe a déjà ce fichier dans sa liste : je ne le renvoie pas.'); // le compte gratuit n'a que quelques transcriptions par jour
  else {
    const ids = await sendFiles('turbo', [{ blob, name }]);
    const up = await call('turbo', 'turboUpload', ids, cfg);
    await call('turbo', 'dropFiles', ids).catch(() => null);
    if (!up || !up.ok) { await snapPage('turbo', 'fenêtre d\'envoi'); throw new Error(`TurboScribe : ${(up && up.error) || 'envoi du fichier impossible'}`); }
    log('TurboScribe : vidéo déposée, téléversement…');
    // téléversement fini = le nom du fichier est affiché sans pourcentage ; alors UN clic sur « Transcrire »
    let clicked = false, sent = false, lastPct = -1, since = Date.now(), clickedAt = 0, reclicked = false;
    for (let i = 0; i < (TEST ? 40 : 600) && !sent; i++) {
      await sleep(TEST ? 250 : 700);
      const d = await call('turbo', 'turboDialog', name);
      if (d.open && new RegExp(cfg.limitText, 'i').test(d.text) && /(atteint|reached|exceeded|dépassé)/i.test(d.text)) throw new Error('quota gratuit TurboScribe atteint');
      if (d.open && !clicked) {
        if (d.pct !== lastPct) { lastPct = d.pct; since = Date.now(); }
        const ready = d.submit && !d.disabled && ((d.hasFile && !d.uploading) || Date.now() - since > 20000);
        if (ready) { const c = await call('turbo', 'turboSubmit'); clicked = !!(c && c.ok); clickedAt = Date.now(); if (clicked) log('TurboScribe : clic sur « Transcrire ».'); else log(`TurboScribe : ${(c && c.error) || 'clic impossible'}.`, 'warn'); }
        else if (!d.submit && i % 12 === 11) log('TurboScribe : je ne trouve pas le bouton « Transcrire » dans la fenêtre.', 'warn');
      }
      const r = await rowNow();
      sent = !!(r && r.found);
      // la fenêtre est restée ouverte 25 s après le clic, fichier prêt, rien dans la liste : le clic n'a pas pris, on le refait une seule fois
      if (!sent && clicked && !reclicked && d.open && d.submit && !d.uploading && Date.now() - clickedAt > (TEST ? 4000 : 25000)) { reclicked = true; await call('turbo', 'turboSubmit'); log('TurboScribe : la fenêtre est restée ouverte, je reclique une fois sur « Transcrire ».', 'warn'); }
      if (!sent && clicked && !d.open && i % 8 === 7) { await chrome.tabs.reload(tabs.turbo).catch(() => {}); await sleep(2500); } // fenêtre fermée mais liste pas rafraîchie
      if (!sent && !d.open && !clicked && Date.now() - since > 15000) break;
    }
    if (!sent) { await snapPage('turbo', 'fichier absent de la liste après l\'envoi'); throw new Error('TurboScribe : la vidéo n\'est pas apparue dans « Fichiers récents » (envoi non pris en compte)'); }
    log('TurboScribe : vidéo envoyée, elle est dans la liste.');
  }
  log(`TurboScribe transcrit la vidéo… (j'attends jusqu'à ${Math.round(maxWait / 60000)} min)`);
  let calm = 0, lastSeen = '';
  const doneRow = await until(async () => {
    const r = await rowNow();
    if (!r || !r.found) return null;
    if (r.failed) throw new Error('TurboScribe annonce un échec pour ce fichier');
    if (r.done) return r;
    if (r.pct !== null && String(r.pct) !== lastSeen) { lastSeen = String(r.pct); }
    calm = r.busy ? 0 : calm + 1;
    return calm >= 6 ? r : null; // pas de coche reconnue mais plus aucun signe de travail : on tente l'export
  }, { timeout: maxWait, every: TEST ? 300 : 2000, what: 'transcription TurboScribe', nag: 5 * 60000 });
  await sleep(TEST ? 200 : 800);
  // 1) Lecture directe : on ouvre la page du fichier et on y lit les phrases minutées (ou son lien « Télécharger le TXT »). Aucun menu à ouvrir.
  const page = doneRow && /\/transcript\//.test(doneRow.href || '') ? doneRow.href : '';
  if (page) {
    try {
      await chrome.tabs.update(tabs.turbo, { url: page }); await sleep(TEST ? 300 : 800);
      await until(async () => { try { return (await chrome.tabs.get(tabs.turbo)).status === 'complete'; } catch (e) { return false; } }, { timeout: 45000, every: 300, what: 'page du fichier TurboScribe' });
      let rd = null;
      for (let i = 0; i < 2 && !(rd && rd.ok); i++) { rd = await call('turbo', 'turboRead').catch((e) => ({ ok: false, error: e.message })); if (!(rd && rd.ok)) await sleep(TEST ? 300 : 1500); }
      if (rd && rd.ok && String(rd.text || '').trim().length >= 20) {
        const got = await keepTranscript(rd.text, rd.how === 'page' ? `${rd.n} phrases lues sur la page du fichier` : 'fichier TXT du site, sans minutage');
        if (got && got.length) return got;
      }
      log(`TurboScribe : lecture sur la page du fichier impossible (${(rd && rd.error) || 'texte vide'}). J'essaie l'export par le menu.`, 'warn');
    } catch (e) {
      if (e instanceof Stop || e instanceof Blocked) throw e;
      log(`TurboScribe : page du fichier illisible (${e.message}). J'essaie l'export par le menu.`, 'warn');
    }
    await openSite('turbo', { needComposer: false }); // retour à la liste pour l'export
    for (let i = 0; i < 12; i++) { const r = await rowNow(); if (r && r.found) break; await sleep(TEST ? 200 : 500); }
  }
  // 2) Export par le menu « … » de la ligne (ancienne voie)
  let ex = null;
  for (let i = 0; i < 3; i++) {
    ex = await call('turbo', 'turboExport', name).catch((e) => ({ ok: false, error: e.message }));
    if (ex && ex.ok) break;
    log(`TurboScribe : export (${i + 1}/3) : ${(ex && ex.error) || 'sans résultat'}.`, 'warn');
    await sleep(TEST ? 300 : 2000);
  }
  if (!ex || !ex.ok) { await snapPage('turbo', `export : ${(ex && ex.error) || 'échec'}`); throw new Error(`TurboScribe : transcription faite mais export impossible (${(ex && ex.error) || 'échec'})`); }
  let text = ex.text || '';
  if (text.trim().length < 20 && ex.href) text = await (await pull('turbo', ex.href, 'text/plain', 10)).text();
  const lines = await keepTranscript(text, 'export TXT');
  if (!lines || !lines.length) { await snapPage('turbo', 'fichier exporté vide'); throw new Error('TurboScribe : le fichier exporté est vide'); }
  return lines;
}
/* Relit sur le disque la vidéo finale d'une production (Téléchargements/FruitRadar/Productions/<dossier>/video-finale.mp4, ou le fichier exporté de CapCut).
   Chrome ne le permet que si « Autoriser l'accès aux URL de fichier » est activé pour FruitRadar. */
async function diskVideo(pv) {
  const allowed = await new Promise((r) => { try { chrome.extension.isAllowedFileSchemeAccess(r); } catch (e) { r(false); } });
  if (!allowed) return null;
  const rx = (x) => String(x).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wanted = [];
  if (pv.folder) wanted.push(`FruitRadar[\\\\/]Productions[\\\\/]${rx(pv.folder)}[\\\\/]video-finale\\.mp4$`);
  if (pv.exportFile) wanted.push(`[\\\\/]${rx(pv.exportFile)}$`);
  for (const filenameRegex of wanted) {
    let items = [];
    try { items = await chrome.downloads.search({ filenameRegex, exists: true, state: 'complete', orderBy: ['-startTime'], limit: 3 }); } catch (e) { items = []; }
    for (const it of items) {
      try {
        const parts = String(it.filename).replace(/\\/g, '/').replace(/^\/+/, '').split('/');
        const res = await fetch('file:///' + parts.map((x, n) => (n === 0 && /^[A-Za-z]:$/.test(x) ? x : encodeURIComponent(x))).join('/'));
        const b = await res.blob();
        if (b.size > 20000) return b.type ? b : new Blob([b], { type: 'video/mp4' });
      } catch (e) { /* fichier déplacé ou illisible : on essaie le suivant */ }
    }
  }
  return null;
}
/* « Suite d'une histoire » : la vidéo de la partie précédente. Dans l'ordre : le fichier donné au lancement,
   la vidéo finale que FruitRadar a gardée pour la production choisie, puis son fichier resté dans Téléchargements. */
async function prevPartVideo() {
  const ok = (b) => b && b.size > 20000;
  if (prod.prevVideoKey) { const b = await media(prod.prevVideoKey); if (ok(b)) return { blob: b, from: prod.prevVideoFrom || 'fichier que tu as donné' }; }
  if (!prod.prevId) return null;
  const pv = await DB.getProd(prod.prevId).catch(() => null);
  if (!pv) return null;
  const own = pv.finalKey ? await media(pv.finalKey) : null;
  if (ok(own)) { prod.prevVideoKey = pv.finalKey; prod.prevVideoFrom = 'gardée dans FruitRadar'; return { blob: own, from: prod.prevVideoFrom }; }
  const disk = await diskVideo(pv);
  if (ok(disk)) { prod.prevVideoKey = await keep('previous.mp4', disk); prod.prevVideoFrom = 'relue dans tes Téléchargements'; return { blob: disk, from: prod.prevVideoFrom }; }
  return null;
}
async function stepSource() {
  // « Suite d'une histoire » : la vidéo de la partie précédente est préparée pour Claude comme une vidéo d'origine
  // (captures, planches de lecture, transcription), mais Claude la reçoit comme « partie précédente », pas comme vidéo à refaire.
  if (prod.sourceDone) return;
  let pvid = null;
  if (prod.mode === 'suite') {
    if (prod.pkg || prod.claudeAsked) return; // suite déjà écrite (ou demande déjà partie) avant cette version : on ne prépare pas la vidéo après coup
    pvid = await prevPartVideo();
    if (!pvid) {
      if (prod.prevId || prod.prevVideoKey) {
        log('Vidéo de la partie précédente introuvable (ni dans FruitRadar, ni dans tes Téléchargements) : Claude travaillera avec le package de cette partie. Pour la joindre, relance la suite en donnant le fichier de la vidéo.', 'warn');
        prod.prevVideoKey = null; prod.sourceDone = true; await save(true);
      }
      return;
    }
  }
  const prevVid = !!pvid;
  if (prod.mode !== 'remake' && !prevVid) return;
  const s = prod.source || {};
  // fichier de la vidéo donné à la main (bouton « Donner le fichier de la vidéo », quand TikTok refuse le téléchargement) : il passe devant
  const given = (!prevVid && prod.mode === 'remake') ? await media(`${prod.id}/source.mp4`).catch(() => null) : null;
  const hand = !!(given && given.size > 20000);
  if (hand) log('Vidéo d\'origine : je prends le fichier que tu as donné.');
  const r = prevVid ? { blob: pvid.blob, subs: [], duration: 0 } : hand ? { blob: given.type ? given : new Blob([given], { type: 'video/mp4' }), subs: [], duration: 0 } : await attempt('Récupération de la vidéo TikTok', async () => {
    const x = await chrome.runtime.sendMessage({ type: 'resolvePlay', id: s.videoId, url: s.url });
    if (!x || !x.ok || !x.playUrl) throw new Error((x && x.error) || 'lien de la vidéo introuvable');
    let host = ''; try { host = new URL(x.playUrl).hostname; } catch (e) {}
    let res;
    try { res = await fetch(x.playUrl, { credentials: 'include' }); }
    catch (e1) { // refus réseau (souvent : TikTok sert la vidéo depuis une adresse que l'extension ne connaît pas) : second essai sans les cookies, que ces serveurs acceptent de partout
      try { res = await fetch(x.playUrl, { credentials: 'omit' }); log(`Vidéo TikTok récupérée par la seconde voie (${host}).`); }
      catch (e2) { throw new Error(`téléchargement bloqué (${host || 'adresse inconnue'}) : ${e2.message}`); }
    }
    if (!res.ok || /html/.test(res.headers.get('content-type') || '')) throw new Error('TikTok a refusé le téléchargement');
    const b = await res.blob();
    if (b.size < 20000) throw new Error('fichier vidéo vide');
    return { blob: b.type ? b : new Blob([b], { type: 'video/mp4' }), subs: x.subtitles || [], duration: x.duration };
  });
  if (prevVid) log(`Vidéo de la partie précédente (${pvid.from}) : je la prépare pour Claude (captures, transcription).`);
  else if (hand) await toDisk(r.blob, 'source/original.mp4');
  else { await keep('source.mp4', r.blob); await toDisk(r.blob, 'source/original.mp4'); log('Vidéo d\'origine récupérée.'); }
  try {
    const cap = await captureFrames(r.blob, 8);
    prod.frames = [];
    for (let i = 0; i < cap.frames.length; i++) prod.frames.push({ t: cap.frames[i].t, key: await keep(`capture-${pad(i + 1)}.jpg`, cap.frames[i].blob) });
    s.duration = s.duration || cap.duration || r.duration;
    prod.framesBy = framesBy + (framesWhy ? ` — ${framesWhy}` : '');
    log(`${prod.frames.length} captures prises.`);
    if (framesWhy) log(`Captures : la lecture directe du fichier n'a pas marché du premier coup (${framesWhy.slice(0, 220)}) ; prises par ${framesBy}.`, 'warn');
  } catch (e) { prod.frames = []; log(`Captures impossibles (${e.message}) : on continue avec la transcription.`, 'warn'); }
  await makeSheets(r.blob);
  prod.transcript = []; prod.transcriptFrom = '';
  // suite d'une production faite dans FruitRadar : ses répliques exactes sont dans son package, aucun site de transcription à attendre
  const own = prevVid && prod.prevId ? scriptOf(await DB.getProd(prod.prevId).catch(() => null)) : null;
  if (own && own.lines.length) {
    prod.transcript = own.lines; prod.transcriptFrom = 'script exact du package';
    log(`Répliques de la partie précédente : ${own.lines.length}, prises telles quelles dans son package (exactes, sans site de transcription et sans dépenser ton quota du jour).`);
  } else if (auto.useTurbo) {
    try { const tr = await transcribe(r.blob, `fr-${s.videoId || prod.id}.mp4`); prod.transcript = tr.lines; prod.transcriptFrom = tr.from; log(`Transcription ${tr.from} : ${prod.transcript.length} lignes.`); } catch (e) {
      if (e instanceof Stop) throw e;
      log(`Transcription par un site impossible.${prevVid ? '' : ' Je prends les sous-titres TikTok à la place.'}`, 'warn');
    }
  }
  if (!prod.transcript.length && r.subs.length) {
    try {
      const sub = r.subs.find((x) => /^fr|fra/i.test(x.lang)) || r.subs.find((x) => /^(en|eng|es|spa|pt|por)/i.test(x.lang)) || r.subs[0];
      const res = await fetch(sub.url, { credentials: 'omit' });
      if (res.ok) { prod.transcript = parseVtt(await res.text()); prod.transcriptFrom = `sous-titres TikTok (${sub.lang || '?'})`; log(`Sous-titres TikTok : ${prod.transcript.length} lignes.`); }
    } catch (e) { /* pas de sous-titres */ }
  }
  if (!prod.transcript.length) log(prevVid ? 'Aucune transcription : Claude travaillera avec les planches de lecture et la mémoire de la série.' : 'Aucune transcription : Claude travaillera avec les captures et la description.', 'warn');
  // Option « Analyser le hook avec Gemini » (clé gratuite des Réglages → Analyse IA) : une analyse déjà faite dans le Radar est reprise telle quelle
  if (!prevVid && prod.hookGemini && !prod.hookKey) {
    try {
      const st = await getSettings();
      const old = s.videoId ? await DB.getAnalysis(s.videoId).catch(() => null) : null;
      let ai = old && old.ai;
      if (ai) log('Analyse Gemini de cette vidéo déjà faite dans le Radar : je la reprends pour Claude.');
      else if (!st.geminiKey) log('Analyse du hook par Gemini demandée, mais aucune clé Gemini dans Réglages → Analyse IA : je continue sans.', 'warn');
      else {
        log('Gemini analyse le hook de la vidéo (30 s à 2 min)…');
        // 5 minutes au plus : si Gemini ne répond pas, la production continue sans son analyse
        const res = await Promise.race([geminiAnalyze({ key: st.geminiKey, model: st.geminiModel, blob: r.blob,
          prompt: buildPrompt({ v: { author: { uniqueId: s.author || '' }, stats: s.stats || {}, duration: s.duration, desc: s.desc || '' }, m: null, local: {}, brief: st.accountBrief }) }),
        new Promise((_, no) => setTimeout(() => no(new Error('pas de réponse après 5 minutes')), 300000))]);
        ai = res.data;
        if (s.videoId) await DB.putAnalysis({ id: s.videoId, at: Date.now(), local: (old && old.local) || { duration: s.duration || null, scenes: [], transcript: [] }, ai, model: res.model }).catch(() => null);
      }
      if (ai) { prod.hookKey = await keep('analyse-hook.txt', new Blob([P.hookNote(ai)], { type: 'text/plain' })); log('Analyse du hook par Gemini prête : elle part avec la demande à Claude.'); }
    } catch (e) { if (e instanceof Stop) throw e; log(`Analyse Gemini impossible (${e.message}) : je continue sans.`, 'warn'); }
  }
  prod.sourceDone = true;
  await save(true);
}

/* 2 — Package : Claude écrit tout, on relit */
/* `before` : état de la page avant l'envoi (null quand on reprend une conversation déjà lancée).
   Fin de réponse = la dernière ligne attendue (@@FINI@@, @@SUITE@@ ou @@CHOIX@@) est là et le texte ne bouge plus.
   Aucune limite de temps : Claude peut réfléchir puis écrire pendant très longtemps. */
async function waitAnswer(key, cfg, before) {
  const name = nameOf(key);
  if (before) await until(async () => { const s = await call(key, 'state', cfg); if (s.block) throw new Blocked(s.block, `${name} : ${s.block}`); return s.busy || s.users > before.users || s.answerLen !== before.answerLen; },
    { timeout: Infinity, every: 1500, what: `début de la réponse de ${name}`, nag: 3 * 60000, nagText: `${name} n'a pas commencé à répondre : vérifie dans son onglet que le message est bien parti.` });
  let last = -1, calm = 0, still = Date.now();
  await until(async () => {
    const s = await call(key, 'state', cfg);
    if (s.block) throw new Blocked(s.block, `${name} : ${s.block}`);
    if (s.answerLen !== last) { last = s.answerLen; calm = 0; still = Date.now(); } else calm++;
    if (s.answerLen <= 0) return false;
    if (s.answerEnd && ((!s.busy && calm >= 2) || calm >= 20)) return true;       // dernière ligne reçue
    if (s.busy) { if (!s.answerEnd) still = Date.now(); return false; }            // il écrit ou réfléchit encore
    return Date.now() - still > (TEST ? 6000 : 5 * 60000);                         // réponse arrêtée sans sa dernière ligne (coupée, refus…)
  }, { timeout: Infinity, every: 1500, what: `fin de la réponse de ${name}`, nag: 25 * 60000 });
  return (await call(key, 'answerText', cfg)).text;
}
async function castChars() { // personnages de la bibliothèque choisis au lancement (toutes les façons de démarrer)
  if (!(prod.charIds || []).length) return [];
  const all = await DB.allChars();
  return prod.charIds.map((id) => all.find((c) => c.id === id)).filter(Boolean);
}
async function knownPlanches() { return (await castChars()).map((c) => c.name); }
/* Les idées s'ajoutent lot après lot (1 à 10, 11 à 20…) : numéros uniques, pas de doublon de titre */
function mergeIdeas(old = [], add = [], from = 0) {
  const out = [...(old || [])], used = new Set(out.map((x) => x.n)), titles = new Set(out.map((x) => P.normName(x.titre)));
  const batch = Math.max(0, ...out.map((x) => x.batch || 1)) + (out.length ? 1 : 0) || 1;
  let next = Math.max(from - 1, 0, ...used) + 1;
  for (const i of add || []) {
    if (titles.has(P.normName(i.titre))) continue;
    const n = used.has(i.n) || i.n < from ? next++ : i.n;
    used.add(n); titles.add(P.normName(i.titre)); next = Math.max(next, n + 1);
    out.push({ ...i, n, batch });
  }
  return out;
}
async function stepPackage() {
  if (prod.pkgReady) return;
  const known = await knownPlanches();
  await attempt('Package (Claude)', async () => {
    const phase = prod.mode === 'idees' && !prod.choice ? 'ideas' : 'pkg';
    const tabUrl = (await tabAlive('claude')) ? (await chrome.tabs.get(tabs.claude)).url : '';
    const canResume = prod.claudeAsked === phase && !!prod.claudeUrl && (tabUrl === prod.claudeUrl || /\/chat\/[\w-]{8,}/.test(prod.claudeUrl));
    const noteUrl = async () => { try { prod.claudeUrl = (await chrome.tabs.get(tabs.claude)).url; } catch (e) {} };
    let cfg, before, pkg = null, text;
    if (canResume) {
      // la demande est déjà partie : on ne la renvoie pas, on retourne lire la réponse
      cfg = await openSite('claude', { url: prod.claudeUrl, fresh: tabUrl !== prod.claudeUrl });
      log('Je reprends la conversation Claude déjà lancée, sans renvoyer la demande.');
      if (phase === 'pkg' && prod.pkgDraft) pkg = prod.pkgDraft;
      text = await waitAnswer('claude', cfg, null);
    } else {
      let meta = '';
      if (auto.attachMetaprompt) { // récupéré AVANT d'ouvrir Claude : sans lui, la demande ne part pas (une pause explique pourquoi)
        const { autoMetaprompt } = await chrome.storage.local.get('autoMetaprompt');
        meta = autoMetaprompt && autoMetaprompt.text ? autoMetaprompt.text : '';
        if (!meta) { const m = await META.provided(); if (!m.text) throw new Blocked('metaprompt', m.error || META.MSG.missing); meta = m.text; }
      }
      cfg = await openSite('claude');
      const files = [];
      if (meta) files.push({ blob: new Blob([meta], { type: 'text/plain' }), name: 'metaprompt.txt' });
      let src = null;
      const prevVid = prod.mode === 'suite' && !!prod.prevVideoKey;
      if (prod.mode === 'remake' || prevVid) {
        src = await media(prevVid ? prod.prevVideoKey : `${prod.id}/source.mp4`);
        if (src && prod.sheets === undefined) await makeSheets(src); // production lancée avant cette version
        for (const [i, f] of (prod.sheets || []).entries()) { const b = await media(f.key); if (b) files.push({ blob: b, name: `lecture-${pad(i + 1)}.jpg` }); }
      }
      for (const [i, f] of (prod.frames || []).entries()) { const b = await media(f.key); if (b) files.push({ blob: b, name: `capture-${pad(i + 1)}.jpg` }); }
      // personnages choisis dans la bibliothèque : leurs planches partent chez Claude (8 au plus, et jamais plus de 19 fichiers en tout)
      const cast = await castChars(); let castImgs = 0;
      for (const c of cast.slice(0, 8)) {
        if (!c.blob || files.length >= 16) break;
        try { const light = await lightRef(c.blob); files.push({ blob: light, name: `planche-${P.slug(c.name)}.${ext(light)}` }); castImgs++; } catch (e) { /* planche illisible : Claude aura sa description */ }
      }
      let prevBible = prod.prevBible || '', memo = null;
      if (prod.mode === 'suite' && prod.prevId) {
        const pv = await DB.getProd(prod.prevId); if (pv && pv.pkg) prevBible = `Titre : ${pv.title}\n${pv.pkg.bible || ''}`;
        memo = await seriesMemory().catch(() => null);
        if (memo) { files.push({ blob: new Blob([memo.text], { type: 'text/plain' }), name: 'histoire-precedente.txt' }); log(`Mémoire de la série jointe pour Claude : ${memo.parts} partie${memo.parts > 1 ? 's' : ''} déjà faite${memo.parts > 1 ? 's' : ''}${memo.script.lines.length ? `, avec le script exact de la partie ${memo.last.part || 1} (${memo.script.lines.length} répliques, jusqu'à la fin)` : ''}.`); }
      }
      log(`Envoi de la demande à Claude (${files.length + 1} fichiers joints)…`);
      // idée déjà choisie avant une pause : on repart directement sur cette idée
      const picked0 = prod.mode === 'idees' && prod.choice && (prod.ideas || []).find((x) => x.n === prod.choice);
      const pk0 = picked0 && prod.choiceEdit ? P.applyIdeaEdit(picked0, prod.choiceEdit) : picked0; // idée modifiée par toi : c'est elle qui repart
      const ask = pk0 ? { ...prod, mode: 'idee', idea: pk0.edited ? P.ideaBrief(pk0) : `${pk0.titre}. ${pk0.pitch}` } : prod;
      // La demande complète part en fichier (un long texte collé serait transformé ou tronqué selon le site) ; on ne tape qu'une phrase.
      let demand = P.firstMessage(ask, { extra: [auto.extra, prod.extra].filter(Boolean).join('\n'), knownPlanches: known, prevBible, metaAttached: auto.attachMetaprompt, brand: auto.brand, audience: auto.audience, hook: !!prod.hookKey, prevVideo: prevVid && !!src, prevScript: !!memo, cast: cast.map((c) => ({ name: c.name, desc: P.charBrief(c.prompt) })), castImages: castImgs > 0 });
      if (cast.length && prod.mode !== 'suite') log(`Personnages imposés à Claude : ${cast.map((c) => c.name).join(', ')}${castImgs ? ` (${castImgs} planche${castImgs > 1 ? 's' : ''} jointe${castImgs > 1 ? 's' : ''})` : ''}.`);
      files.push({ blob: new Blob([demand], { type: 'text/plain' }), name: 'demande.txt' });
      if (prod.hookKey) { const hb = await media(prod.hookKey); if (hb) files.push({ blob: hb, name: 'analyse-hook.txt' }); }
      if (prod.transcriptKey) { const tb = await media(prod.transcriptKey); if (tb) files.push({ blob: tb, name: 'transcription.txt' }); }
      const ids = await sendFiles('claude', files);
      // la vidéo elle-même, à part : si claude.ai la refuse, le reste part quand même
      prod.videoSent = false;
      if (src && auto.sendVideoToClaude !== false) {
        if (src.size > 30 * 1024 * 1024) log(`Claude.ai n'accepte pas un fichier vidéo de ${Math.round(src.size / 1048576)} Mo : Claude voit toute la vidéo par les ${(prod.sheets || []).length} planches de lecture (une image toutes les ${prod.sheetsRate ? String(Math.round(10 / prod.sheetsRate) / 10).replace('.', ',') : '1'} s).`);
        else {
          const v0 = await call('claude', 'state', cfg);
          const vid = await sendFiles('claude', [{ blob: src, name: prevVid ? 'partie-precedente.mp4' : 'video-source.mp4' }]);
          const va = await call('claude', 'attach', vid, cfg);
          await sleep(4000);
          const v1 = await call('claude', 'state', cfg);
          const refused = v1.alerts.find((a) => /(non pris en charge|pas pris en charge|unsupported|not supported|format|type de fichier|file type|impossible)/i.test(a) && !v0.alerts.includes(a));
          if (va && va.ok && !refused) { prod.videoSent = true; log(prevVid ? 'Vidéo de la partie précédente jointe pour Claude.' : 'Vidéo d\'origine jointe pour Claude.'); }
          else log(`claude.ai n'accepte pas la vidéo${refused ? ` (« ${refused.slice(0, 90)} »)` : ''} : Claude la verra par les planches de lecture.`, 'warn');
          await call('claude', 'dropFiles', vid);
        }
      }
      before = await submit('claude', cfg, P.shortMessage(ask, auto.attachMetaprompt), ids);
      prod.claudeAsked = phase; prod.pkgDraft = null;
      await sleep(3000); await noteUrl(); await save(true);
      log('Demande envoyée. Claude écrit le package : ça peut être long, j\'attends le temps qu\'il faut.');
      text = await waitAnswer('claude', cfg, before);
    }
    await noteUrl();
    pkg = P.mergePackage(pkg, P.parsePackage(text));

    if (phase === 'ideas') {
      if (!pkg.ideas.length) { prod.claudeAsked = null; throw new Error('Claude n\'a pas renvoyé la liste d\'idées au bon format'); }
      const had = (prod.ideas || []).length;
      prod.ideas = mergeIdeas(prod.ideas, pkg.ideas);
      let fresh = (prod.ideas.length - had) || prod.ideas.length;
      // tu choisis une idée, ou tu redemandes 10 nouvelles idées (avec ta précision), autant de fois que tu veux
      for (;;) {
        prod.status = 'waiting'; prod.ideasBusy = false;
        if (fresh) {
          log(`${fresh} ${prod.ideas.length > fresh ? 'nouvelles ' : ''}idées reçues : choisis-en une dans FruitRadar (page Automatisation), ou redemande 10 idées.`);
          await notify('FruitRadar — choisis ton histoire', `${fresh} ${prod.ideas.length > fresh ? 'nouvelles ' : ''}idées sont prêtes dans la page Automatisation.`, null);
        }
        await save(true);
        await hold();
        if (stopFlag) throw new Stop('arrêt demandé');
        if (!prod.moreAsk && !prod.ideas.some((x) => x.n === prod.choice)) { fresh = 0; continue; } // « Reprendre » sans choix : on attend toujours
        if (!prod.moreAsk) break;
        const ask = prod.moreAsk; prod.moreAsk = null;
        prod.status = 'running'; prod.ideasBusy = true; await save(true);
        const from = Math.max(0, ...prod.ideas.map((x) => x.n)) + 1;
        log(`Je demande 10 nouvelles idées à Claude${ask.text ? ` (« ${ask.text.slice(0, 90)} »)` : ''}…`);
        await jitter(1200, 2400);
        before = await submit('claude', cfg, P.moreIdeasMessage(from, ask.text, prod.ideas.map((x) => x.titre)));
        const add = P.parsePackage(await waitAnswer('claude', cfg, before)).ideas;
        const n0 = prod.ideas.length;
        prod.ideas = mergeIdeas(prod.ideas, add, from);
        fresh = prod.ideas.length - n0;
        if (!fresh) log('Claude n\'a pas renvoyé de nouvelles idées lisibles : redemande, ou choisis parmi celles-ci.', 'warn');
      }
      prod.status = 'running'; prod.ideasBusy = false;
      const picked = prod.ideas.find((x) => x.n === prod.choice);
      if (picked && prod.choiceEdit) Object.assign(picked, P.applyIdeaEdit(picked, prod.choiceEdit)); // modifiée par toi : c'est cette version qui part
      if (picked) prod.title = picked.titre;
      log(`Idée ${prod.choice} choisie${picked ? ` : « ${picked.titre} »` : ''}${prod.choiceEdit ? ' (modifiée par toi)' : ''}${prod.choiceNote ? `, avec ta précision « ${prod.choiceNote.slice(0, 90)} »` : ''}.`);
      before = await submit('claude', cfg, P.chooseMessage(prod.choice, prod.choiceNote, prod.choiceEdit));
      prod.claudeAsked = 'pkg'; prod.pkgDraft = null; await save(true);
      pkg = P.mergePackage(null, P.parsePackage(await waitAnswer('claude', cfg, before)));
    }
    prod.pkgDraft = pkg; await save(true);
    for (let round = 0; round < 8; round++) {
      const miss = P.missingParts(pkg, known);
      if (!miss.length) break;
      if (round === 7) { prod.claudeAsked = null; prod.pkgDraft = null; throw new Error(`package incomplet après plusieurs relances (manque : ${miss.join(' ; ')})`); }
      log(`Package partiel (${pkg.scenes.length} scènes, ${pkg.planches.length} planches) : je demande la suite.`);
      await jitter(2000, 4000);
      before = await submit('claude', cfg, P.continueMessage(pkg.more && !pkg.done ? null : miss));
      pkg = P.mergePackage(pkg, P.parsePackage(await waitAnswer('claude', cfg, before)));
      prod.pkgDraft = pkg; await save(true);
    }
    // Contrôle du métaprompt V6 : les règles verrouillées des prompts vidéo sont vérifiées par le programme, pas laissées à la confiance.
    {
      const opening = P.openingFor(P.openingOf(await getMetaText()), prod);
      const patchAll = () => { for (const sc of pkg.scenes) sc.video = P.patchVideo(sc, opening); };
      patchAll(); // phrase d'ouverture, blocs code : corrigés par le programme, sans attendre Claude
      const probs = P.v6Problems(pkg, opening);
      if (probs.length) {
        log(`Contrôle du métaprompt V6 : ${probs.length} scène(s) à corriger (${probs.map((x) => `${x.n} : ${x.list[0]}`).join(' ; ').slice(0, 240)}). Je les redemande à Claude.`, 'warn');
        await jitter(1500, 3000);
        before = await submit('claude', cfg, P.fixMessage(probs));
        pkg = P.mergePackage(pkg, P.parsePackage(await waitAnswer('claude', cfg, before)));
        prod.pkgDraft = pkg; await save(true);
        patchAll();
      }
      const left = P.v6Problems(pkg, opening);
      if (left.length) log(`Contrôle du métaprompt V6 : encore à vérifier à la main — ${left.map((x) => `scène ${x.n} (${x.list.join(', ')})`).join(' ; ').slice(0, 400)}.`, 'warn');
      else log('Contrôle du métaprompt V6 : tous les prompts vidéo respectent les règles verrouillées.');
      pkg.v6 = left.map((x) => ({ n: x.n, list: x.list }));
    }
    pkg.planches.forEach((p) => { p.status = 'todo'; });
    pkg.scenes.forEach((s) => { s.imgStatus = 'todo'; s.vidStatus = 'todo'; });
    pkg.miniature.status = 'todo';
    prod.pkg = pkg; prod.pkgDraft = null;
    prod.title = pkg.meta.titre || prod.title;
    if (pkg.meta.partie && !prod.partLocked) prod.part = parseInt(pkg.meta.partie, 10) || prod.part;
    prod.pkgReady = true;
  }, 'claude');
  await toDisk(new Blob([P.packageToText(prod.pkg)], { type: 'text/plain' }), 'package.txt');
  if (prod.pkg.description) await toDisk(new Blob([P.finalDesc(prod.pkg.description, auto, IS_ADMIN)], { type: 'text/plain' }), 'description-tiktok.txt');
  log(`Package prêt : « ${prod.title} », ${prod.pkg.scenes.length} scènes, ${P.totalDuration(prod.pkg)} s, ${prod.pkg.planches.length} planche(s).`);
  if (auto.notifySteps) notify('FruitRadar — package prêt', `« ${prod.title} » : ${prod.pkg.scenes.length} scènes.`, null);
  await save(true);
}

/* 3 — Images : ChatGPT, une conversation par vidéo */
/* Les planches sont jointes à chaque image de scène : en JPEG de haute qualité (mêmes dimensions), elles pèsent 6 à 8 fois moins
   qu'en PNG, donc partent et se téléversent bien plus vite. Une planche déjà légère est envoyée telle quelle. */
const lightRefs = new Map();
async function lightRef(blob) {
  if (auto.refLight === false || blob.size < 600000 || /jpe?g/.test(blob.type)) return blob;
  const k = `${blob.size}:${blob.type}:${await hashOf(blob)}`;
  if (lightRefs.has(k)) return lightRefs.get(k);
  let out = blob;
  try {
    const bmp = await createImageBitmap(blob), c = document.createElement('canvas');
    c.width = bmp.width; c.height = bmp.height;
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(bmp, 0, 0); bmp.close && bmp.close();
    const j = await new Promise((res) => c.toBlob(res, 'image/jpeg', 0.93));
    if (j && j.size > 20000 && j.size < blob.size * 0.8) out = j;
  } catch (e) { /* image illisible ici : on envoie l'originale */ }
  lightRefs.set(k, out);
  return out;
}
async function refBlobs(names) {
  const out = [], chars = await DB.allChars();
  for (const n of names) {
    const key = P.normName(n);
    const pl = prod.pkg.planches.find((p) => P.normName(p.name) === key);
    let blob = pl && pl.key ? await media(pl.key) : null;
    if (!blob) { const c = chars.filter((x) => P.normName(x.name) === key).sort((a, b) => ((prod.charIds || []).includes(b.id) ? 1 : 0) - ((prod.charIds || []).includes(a.id) ? 1 : 0))[0]; blob = c ? c.blob : null; }
    if (blob) { const light = await lightRef(blob); out.push({ blob: light, name: `planche-${P.slug(n)}.${ext(light)}` }); } else log(`Planche « ${n} » introuvable : l'image sera générée sans elle.`, 'warn');
  }
  return out;
}
/* Image de style jointe à chaque planche : le rendu des personnages colle alors à l'aperçu du style.
   Le style de base « Fruits » (le métaprompt tel quel) n'en reçoit pas : ses planches restent celles que tu connais. */
let styleRefCache;
async function styleRef() {
  if (styleRefCache !== undefined) return styleRefCache;
  styleRefCache = null;
  const key = prod.styleKey || prod.style || 'fruits';
  if (auto.styleRef === false || key === 'fruits') return null;
  if (key === 'video') { // style repris de la vidéo : deux captures de la vidéo servent de référence
    const refs = [];
    for (const i of [1, 4]) { const f = (prod.frames || [])[i]; const b = f ? await media(f.key) : null; if (b) refs.push({ blob: b, name: `video-${pad(i + 1)}.jpg` }); }
    if (refs.length) { styleRefCache = { refs, note: prod.mode === 'suite' ? P.VIDEO_REF_NOTE_SUITE : P.VIDEO_REF_NOTE }; log(`Style repris de la vidéo : ${refs.length} capture${refs.length > 1 ? 's' : ''} jointe${refs.length > 1 ? 's' : ''} aux planches.`); }
    return styleRefCache;
  }
  try {
    let blob = null;
    const { styleImgs } = await chrome.storage.local.get('styleImgs');
    if (styleImgs && styleImgs[key]) blob = await (await fetch(styleImgs[key])).blob();
    else if (STYLE_PREVIEWS.includes(key)) blob = await (await fetch(chrome.runtime.getURL(`auto/styles/${key}.jpg`))).blob();
    if (blob && blob.size > 2000) styleRefCache = { refs: [{ blob, name: `style-${P.slug(key.replace(/^c:/, 'perso-'))}.${ext(blob)}` }], note: P.STYLE_REF_NOTE };
  } catch (e) { /* pas d'image pour ce style : les planches partent avec le texte seul */ }
  if (styleRefCache) log('Image du style jointe aux planches : même rendu que l\'aperçu du style, personnages inventés.');
  return styleRefCache;
}
const grokPending = new Map(); // scènes dont l'image vient d'être prête et qui attendent leur tour pour être lancées chez Grok (n° → heure)
let clipsOpen = false; // l'étape des clips tourne : « Refaire le clip » peut y remettre une scène sans rien arrêter
const grokLive = new Set(); let grokMax = 3; // scènes en cours chez Grok (lancement ou génération) et nombre de clips autorisés en même temps
// Une scène « attend son tour » seulement si elle peut partir maintenant : déjà en lancement, ou une place libre chez Grok.
// (Sans ça, quand Grok est plein, ChatGPT n'osait plus préparer son prompt suivant et perdait du temps à chaque image.)
const grokWaitingNow = () => [...grokPending].some(([n, t]) => Date.now() - t < 90000 && (grokLive.has(n) || grokLive.size < grokMax));
let chatReady = false, chatPre = null; // chatPre : élément dont le prompt (et les planches) attend déjà dans la zone de saisie
/* ChatGPT : UNE conversation par vidéo. On n'en ouvre une neuve qu'à la toute première image de la vidéo ;
   ensuite on revient toujours dans celle-là (même après une erreur, un refus ou une relance). */
let chatOwner = null; // production à qui appartient l'onglet ChatGPT ouvert
const convRe = () => new RegExp(cfgOf('chatgpt').convPattern || '/c/[\\w-]{8,}');
async function chatTabUrl() { try { return (await chrome.tabs.get(tabs.chatgpt)).url || ''; } catch (e) { return ''; } }
async function rememberChat() {
  if (chatOwner !== prod.id) return prod.chatUrl || '';
  const u = (await chatTabUrl()).split('#')[0];
  if (u && convRe().test(u) && u !== prod.chatUrl) { prod.chatUrl = u; await save(); }
  return prod.chatUrl || '';
}
let chatWatch = 0;
function watchChat() { // l'adresse de la conversation n'apparaît qu'un moment après le premier envoi : on la guette en fond
  const my = ++chatWatch, owner = prod.id;
  (async () => { for (let i = 0; i < 240 && my === chatWatch && owner === prod.id && chatOwner === owner; i++) { await sleep(1000); if (convRe().test(await chatTabUrl())) { await rememberChat(); return; } } })();
}
async function chatEnsure(job) {
  const alive = await tabAlive('chatgpt');
  const mine = alive && chatOwner === prod.id;
  if (mine) await rememberChat();
  if (!prod.chatStarted && !prod.chatUrl) {
    if (!mine) { log('Nouvelle conversation ChatGPT pour cette vidéo.'); await openSite('chatgpt'); chatOwner = prod.id; chatPre = null; }
    else if (!chatReady) await openSite('chatgpt', { fresh: false });
  } else if (!mine || !chatReady) {
    if (prod.chatUrl) { await openSite('chatgpt', { url: prod.chatUrl, fresh: !mine || convRe().test(await chatTabUrl()) }); chatOwner = prod.id; chatPre = chatPre ? '?' : null; if (!mine) log('Je reviens dans la conversation ChatGPT de cette vidéo.'); } // page rechargée : ce qui était préparé est à refaire
    else if (mine) await openSite('chatgpt', { fresh: false }); // adresse pas encore connue : on reste sur la page, c'est bien cette conversation
    else {
      log('La conversation ChatGPT de cette vidéo est introuvable (onglet fermé avant que son adresse soit connue) : j\'en ouvre une nouvelle, les planches seront jointes à nouveau.', 'warn');
      await openSite('chatgpt'); chatOwner = prod.id; chatPre = null; prod.chatStarted = false;
    }
  }
  chatReady = true;
  // la zone de saisie contient autre chose (élément préparé en avance, ou état inconnu) : on la vide sur place, sans changer de conversation
  if (chatPre && chatPre !== job.id) {
    const c = await call('chatgpt', 'clearComposer', cfgOf('chatgpt'));
    if (!(c && c.ok)) {
      if (prod.chatUrl) await openSite('chatgpt', { url: prod.chatUrl }); // recharger la même conversation vide la zone de saisie
      else log(`Zone de saisie ChatGPT pas entièrement vidée (${(c && (c.error || `${c.left} pièce(s) jointe(s) restante(s)`)) || 'inconnu'}).`, 'warn');
    }
    chatPre = null;
  }
}
const knownImg = new Set(); // empreintes de toutes les images déjà connues de cette vidéo (planches, scènes, pièces jointes)
const hashOf = async (blob) => [...new Uint8Array(await crypto.subtle.digest('SHA-1', await blob.arrayBuffer()))].map((b) => b.toString(16).padStart(2, '0')).join('');
async function chatPrepare(job) {
  const cfg = cfgOf('chatgpt'), made = await job.make();
  if (job.soft) made.text = P.soften(made.text, job.soft, 'image');
  job.text = made.text; job.refsN = made.refs.length;
  job.refHashes = await Promise.all(made.refs.map((r) => hashOf(r.blob)));
  job.refHashes.forEach((h) => knownImg.add(h));
  chatPre = '?'; // tant que ce n'est pas fini, la zone de saisie est dans un état inconnu
  // on part toujours d'une zone de saisie vide (un brouillon ou des planches peuvent y rester après un rechargement ou un essai raté)
  { const pr = await call('chatgpt', 'chatProbe', cfg, made.text).catch(() => null); if (pr && (pr.compLen > 0 || pr.attach > 0)) await call('chatgpt', 'clearComposer', cfg).catch(() => null); }
  const ids = await sendFiles('chatgpt', made.refs);
  if (ids.length) { const a = await call('chatgpt', 'attach', ids, cfg); if (!a || !a.ok) throw new Error(`ChatGPT : pièce jointe refusée (${(a && a.error) || 'inconnu'})`); await jitter(600, 1000); } // les planches se téléversent ; l'envoi attend de toute façon que le bouton soit actif
  const t = await call('chatgpt', 'setText', made.text, cfg);
  if (!t || !t.ok) throw new Error(`ChatGPT : ${(t && t.error) || 'saisie impossible'}`);
  await call('chatgpt', 'dropFiles', ids);
  chatPre = job.id;
}
async function chatImage(job) { // un prompt à la fois : collé et envoyé quand l'image d'avant est finie
  return attempt(job.label, async (_i, soft) => {
    if ((job.soft || 0) !== soft) { job.soft = soft; job.text = null; job.preUsers = null; if (chatPre === job.id) chatPre = '?'; } // prompt adouci : on le retape
    try {
      let cfg, before = null, base = new Set();
      /* Règle de base : chaque image est rattachée à SON prompt. On retrouve dans la conversation le message de ce prompt (chatFind) et on prend
         l'image rangée juste après lui — jamais « la dernière image arrivée ». Un prompt déjà présent dans la conversation n'est jamais renvoyé ;
         un prompt absent (resté dans la zone de saisie, clic non pris) est renvoyé tout de suite. */
      prod.chatSent = prod.chatSent || {};
      const markSent = (v) => { if (v) prod.chatSent[job.id] = v; else delete prod.chatSent[job.id]; job.sent = v; }; // { t: heure, from: rang du message dans la conversation }
      const was = job.sent || prod.chatSent[job.id] || null;
      let anchor = was && typeof was === 'object' && Number.isFinite(was.from) ? was.from : null, strict = anchor !== null;
      let resume = !!was;
      const prepNext = !resume;
      if (!job.text) { const m = await job.make(); job.text = job.soft ? P.soften(m.text, job.soft, 'image') : m.text; job.refsN = m.refs.length; } // le texte exact du prompt, pour le reconnaître sur la page
      const wantLen = job.text.replace(/\s+/g, '').length;
      // rang connu (relevé à l'envoi) : on ne regarde jamais plus haut dans la conversation — un ancien message au même texte (image refaite) n'est pas le nôtre
      let sure = false; // envoi prouvé pendant cet essai : le message est forcément dans la conversation, on ne le renvoie plus
      const find = (h = {}) => call('chatgpt', 'chatFind', cfg, job.text, { from: anchor === null ? 0 : anchor, strict, only: strict, sure: sure && strict, ...h });
      const asked = Date.now();
      await withHands('chatgpt', async () => {
        await chatEnsure(job);
        cfg = cfgOf('chatgpt');
        // 1. Ce prompt est-il déjà dans la conversation ?
        if (resume) { // noté « parti » lors d'un essai précédent
          sure = anchor !== null; // noté parti = envoi prouvé : il est dans la conversation, à ce rang
          const f = await find().catch(() => null);
          if (!f) return; // page illisible pour l'instant : on attend son image, sans rien renvoyer
          if (f.found) { anchor = f.index; strict = true; log(`${job.label} : le prompt est déjà dans la conversation, j'attends son image sans le renvoyer.`, 'warn'); return; }
          if (f.comp >= 0.9) { log(`${job.label} : le prompt était resté dans la zone de saisie (le clic d'envoi n'avait pas pris), je l'envoie.`, 'warn'); chatPre = job.id; }
          else log(`${job.label} : noté comme parti, mais il n'est pas dans la conversation : je l'envoie.`, 'warn');
          markSent(null); resume = false; anchor = null; strict = false; sure = false;
        } else if (job.preUsers != null) { // posé d'avance : est-il parti avant son tour (clic sur Envoyer à la main, par exemple) ?
          const f = await call('chatgpt', 'chatFind', cfg, job.text, { from: job.preUsers, only: true }).catch(() => null);
          if (f && f.found) {
            anchor = f.index; strict = true; resume = true; markSent({ t: Date.now(), from: anchor }); job.sentAt = Date.now(); await save(true);
            log(`${job.label} : ce prompt est déjà parti (envoyé depuis la zone de saisie avant son tour). Je ne le renvoie pas, je prends son image.`, 'warn');
            if (chatPre === job.id) chatPre = f.comp >= 0.9 ? '?' : null; // une copie restée dans la zone de saisie sera vidée avant le prompt suivant
            return;
          }
        }
        // 2. Envoi. Un prompt posé d'avance a pu être abîmé entre-temps (zone de saisie remontée par ChatGPT, clic dans la page…) : on le relit d'abord.
        job.wasReady = chatPre === job.id;
        if (chatPre === job.id) {
          const pr = await call('chatgpt', 'chatProbe', cfg, job.text).catch(() => null);
          const gone = pr && (pr.compLen < wantLen * 0.8 || pr.compLen > wantLen * 1.25); // texte disparu, coupé ou doublé (la zone de saisie peut reformater quelques signes : on juge sur la longueur)
          if (pr && (gone || (job.refsN > 0 && pr.attach < job.refsN))) {
            log(`${job.label} : le prompt posé d'avance n'est plus entier dans la zone de saisie (${gone ? 'texte changé' : `${pr.attach} planche(s) sur ${job.refsN}`}), je le repose.`, 'warn');
            await call('chatgpt', 'clearComposer', cfg).catch(() => null); chatPre = null; job.wasReady = false;
          }
        }
        if (chatPre !== job.id) {
          await chatPrepare(job); await jitter(400, 800);
          const pr = await call('chatgpt', 'chatProbe', cfg, job.text).catch(() => null);
          if (pr && pr.compLen < wantLen * 0.8) throw new Error('ChatGPT : le prompt n\'est pas entré en entier dans la zone de saisie');
        }
        before = await call('chatgpt', 'state', cfg); base = new Set(before.imgs.map((i) => i.src));
        const f0 = await call('chatgpt', 'chatFind', cfg, job.text, { from: 1e9, only: true }).catch(() => null); // combien de messages avant le nôtre : le nôtre sera le suivant
        const sent = await call('chatgpt', 'send', cfg, TEST ? 8000 : 60000);
        if (!sent || !sent.ok) throw new Error(`ChatGPT : ${(sent && sent.error) || 'envoi impossible'}`);
        // Preuve d'envoi : ChatGPT vide sa zone de saisie quand le message part. Si le prompt y est encore au bout de 4 s, le clic n'a pas pris :
        // on reclique (aucun risque de doublon, le prompt n'est pas parti). On ne note « envoyé » qu'une fois la zone vidée.
        { let seen = false, still = false, clicks = 1;
          for (let i = 0; i < (TEST ? 16 : 44); i++) {
            await sleep(TEST ? 100 : 500);
            const pr = await call('chatgpt', 'chatProbe', cfg, job.text).catch(() => null);
            if (!pr) continue;
            seen = true; still = pr.comp >= 0.9 || (wantLen > 80 && pr.compLen >= wantLen * 0.8);
            if (!still) break;
            if (i >= 7 && !pr.busy && clicks < 3 && (i - 7) % 12 === 0) { clicks++; log(`${job.label} : le clic d'envoi n'a pas pris, je reclique (${clicks}/3).`, 'warn'); await call('chatgpt', 'send', cfg, 15000).catch(() => null); }
          }
          if (seen && still) throw new Error('ChatGPT : le prompt reste dans la zone de saisie, l\'envoi ne part pas'); }
        if (f0 && Number.isFinite(f0.users)) { anchor = f0.users; strict = true; } sure = strict;
        chatPre = null; markSent({ t: Date.now(), from: anchor }); job.sentAt = Date.now(); job.waited = job.sentAt - asked;
        if (!prod.chatStarted) prod.chatStarted = true;
        await save(true);
        watchChat();
      }, 2);
      // Pendant que cette image se génère, on pose déjà le prompt suivant dans la zone de saisie : il partira dès qu'elle sera finie.
      // Grok passe d'abord (une scène prête doit partir tout de suite), et un raté ici n'est pas grave : le prompt sera reposé au moment d'envoyer.
      if (prepNext && job.next && auto.chatChain !== false) (async () => {
        const nx = job.next;
        try {
          await sleep(TEST ? 300 : 900);
          for (let w = 0; w < 240 && grokWaitingNow(); w++) await sleep(250); // une scène qui peut partir chez Grok passe d'abord
          if (!nx.canPrepare || !nx.canPrepare() || job.gotImage || chatPre) return;
          await withHands('chatgpt', async () => {
            if (job.gotImage || chatPre || chatOwner !== prod.id) return;
            await chatPrepare(nx);
            const fz = await call('chatgpt', 'chatFind', cfgOf('chatgpt'), nx.text, { from: 1e9, only: true }).catch(() => null);
            nx.preUsers = fz && Number.isFinite(fz.users) ? fz.users : null; // s'il part avant son tour, il sera retrouvé à partir de ce rang
            log(`${nx.label} : prompt déjà prêt dans ChatGPT, il partira dès que l'image en cours sera finie.`);
          }, 0);
        } catch (e) { if (!(e instanceof Stop)) chatPre = chatPre ? '?' : null; }
      })();
      await rememberChat();
      /* Attente de l'image de CE prompt. Elle est prise dès que ses boutons de fin sont là. Si la réponse est finie et que rien ne s'affiche,
         on ne reste pas à attendre : onglet remis devant, puis conversation rechargée ; s'il n'y a vraiment pas d'image, on le sait en 3 minutes, pas en 20. */
      const T = TEST ? { poke: 1200, pokeGap: 1500, hid: 4000, lost: 2500, cut: 1500, reload: 3200, reloadGap: 6000, long: 30000, longGap: 15000, front: 9000, refuse: 2400, noImg: 5000, giveUp: 14000 }
        : { poke: 6000, pokeGap: 12000, hid: 45000, lost: 15000, cut: 30000, reload: 90000, reloadGap: 180000, long: 5 * 60000, longGap: 4 * 60000, front: 150000, refuse: 60000, noImg: 240000, giveUp: Math.max(5, Number(auto.imageWaitMin) || 20) * 60000 };
      const MAKING = /(cr[ée]ation de l.image|g[ée]n[ée]ration|en cours|d[ée]marrage|ajout de d[ée]tails|finalisation|touches finales|quelques instants|creating|generating|getting started|adding details|finishing|rendering|presque|almost)/i;
      const t0 = Date.now();
      let blob = null, pullFails = 0, wrongTurn = 0, idleSince = 0, lostSince = 0, cutSince = 0, blindSince = 0, lastPoke = Date.now(), lastReload = 0, reloads = 0, fronted = false, lastSrc = '', calm = 0;
      const taken = new Set(); // adresses déjà lues et écartées
      const poke = async () => { lastPoke = Date.now(); await withHands('chatgpt', () => sleep(TEST ? 60 : 1200), 0); };
      const reload = async (why) => {
        let url = prod.chatUrl || ''; if (!url) { const u = await chatTabUrl(); if (convRe().test(u)) url = u; }
        if (!url) return false;
        reloads++; lastReload = Date.now();
        log(`${job.label} : ${why}. Je recharge la conversation pour relire ce que ChatGPT a vraiment produit (rien n'est renvoyé).`, 'warn');
        await withHands('chatgpt', async () => { await openSite('chatgpt', { url, fresh: true }); chatPre = null; }, 1);
        base = new Set(); idleSince = lostSince = cutSince = blindSince = 0; lastSrc = ''; calm = 0;
        return true;
      };
      const noReady = () => { if (!prod.noReadyNoted) { prod.noReadyNoted = true; log(`${job.label} : image prise sans avoir vu ses boutons de fin (ChatGPT a peut-être changé d'interface) : vérifie-la.`, 'warn'); } };
      while (!blob) {
        const got = await until(async () => {
          const f = await find().catch(() => null);
          if (!f) return null;
          if (f.block) throw new Blocked(f.block, `ChatGPT : ${f.block}`);
          const now = Date.now();
          // A. notre message est là, avec une image
          if (f.found && f.img && !taken.has(f.img.src)) {
            idleSince = lostSince = cutSince = blindSince = 0;
            if (f.img.ready) { // ses boutons de fin sont là : elle est finie. On confirme un instant plus tard ; son adresse peut changer entre deux relevés, peu importe.
              await sleep(TEST ? 50 : 350);
              const f2 = await find().catch(() => null);
              return f2 && f2.found && f2.img && f2.img.ready ? f2.img : null;
            }
            if (f.img.src === lastSrc) calm++; else { calm = 0; lastSrc = f.img.src; }
            // sans ses boutons de fin (Modifier, Partager, Copier l'image), on ne la prend qu'après un vrai calme : une image encore en cours de rendu ne doit jamais partir
            if ((!f.busy && calm >= 6) || calm >= 45) { noReady(); return f.img; }
            return null;
          }
          // B. notre message est là, sans image (pour l'instant)
          if (f.found) {
            lostSince = blindSince = 0;
            // Un autre message est parti après le nôtre. Tant que ChatGPT travaille, notre image peut encore arriver sous notre message : on attend.
            // Une fois ChatGPT au repos, si notre message n'a toujours pas d'image, sa génération a été coupée → on le renvoie.
            if (!f.isLast) {
              if (f.pageBusy && now - t0 < T.long) cutSince = 0; else if (!cutSince) cutSince = now;
              if (cutSince && now - cutSince > T.cut) { markSent(null); chatPre = '?'; throw new Again('un autre message est parti dans ChatGPT et ce prompt est resté sans image : je le renvoie.'); }
              if (f.hidden && now - lastPoke > T.hid) await poke();
              return null;
            }
            cutSince = 0;
            const idle = !f.busy && !MAKING.test((f.tail || '').slice(-200));
            if (!idle) idleSince = 0; else if (!idleSince) idleSince = now;
            const idleMs = idleSince ? now - idleSince : 0;
            if (idleMs >= T.refuse && REFUSAL.test(f.tail || '')) { markSent(null); throw new Refused(`ChatGPT : « ${f.tail.slice(-140)} »`); }
            // réponse finie sans image, ou page cachée : ChatGPT repasse devant (une page cachée n'affiche pas toujours l'image finie)
            if ((idleMs >= T.poke && now - lastPoke > T.pokeGap) || (f.hidden && now - lastPoke > T.hid)) { await poke(); return null; }
            // toujours rien : on recharge la conversation (l'image, si elle existe, y sera rangée sous notre message)
            if (idleMs >= T.reload && now - lastReload > T.reloadGap && reloads < 5 && await reload('la réponse semble finie mais aucune image ne s\'affiche')) return null;
            // « en cours » depuis très longtemps : l'affichage est peut-être figé, on recharge aussi
            if (!idle && now - t0 > T.long && now - Math.max(lastReload, t0) > T.longGap && reloads < 5 && await reload('ChatGPT affiche « en cours » depuis très longtemps')) return null;
            // conversation rechargée, réponse finie, et toujours aucune image sous notre message : il n'y en aura pas. On n'attend pas 20 minutes.
            if (reloads > 0 && idleMs >= T.noImg && (f.tail || '').replace(/\s+/g, '').length >= 40 && !f.pending) { markSent(null); throw new Error(`ChatGPT a répondu sans donner d'image (« ${(f.tail || '').slice(-160) || (f.alerts[0] || 'réponse vide')} »)`); }
            // dernier recours : la fenêtre elle-même est cachée (réduite, ou derrière une autre) : on la remet devant une fois
            if (f.hidden && idleMs >= T.front && !fronted && auto.bringFront !== false) {
              fronted = true;
              log(`${job.label} : la fenêtre Chrome des sites est cachée (réduite ou derrière une autre), ChatGPT n'y affiche pas l'image. Je la remets devant.`, 'warn');
              try { const w = await chrome.windows.get(winId); await chrome.windows.update(winId, w.state === 'minimized' ? { state: 'normal', focused: true } : { focused: true }); } catch (e) { /* fenêtre fermée */ }
              await poke(); return null;
            }
            if (idleMs >= T.giveUp || now - t0 > T.giveUp + 15 * 60000) { markSent(null); throw new Error(`ChatGPT n'a donné aucune image après ${TEST ? 'le délai de test' : Math.round((now - t0) / 60000) + ' min'} (« ${(f.tail || '').slice(-160) || (f.alerts[0] || 'rien')} »)`); }
            return null;
          }
          // C. la page ne montre aucun de tes messages (interface changée ?) : ancienne méthode, la première image nouvelle de la page
          if (!f.users) {
            if (!blindSince) blindSince = now;
            if (now - blindSince > (TEST ? 1500 : 6000)) {
              const s = await call('chatgpt', 'state', cfg).catch(() => null), top = s && s.imgs.filter((i) => !base.has(i.src) && !taken.has(i.src))[0];
              if (top) { if (top.src === lastSrc) calm++; else { calm = 0; lastSrc = top.src; } if ((top.ready && calm >= 1) || (!s.busy && calm >= 6) || calm >= 45) { if (!top.ready) noReady(); return { ...top, blind: true }; } }
              if (now - blindSince > T.giveUp) { markSent(null); throw new Error('ChatGPT : conversation illisible et aucune image nouvelle'); }
            }
            return null;
          }
          blindSince = 0;
          // D. notre message n'est pas dans la conversation
          idleSince = cutSince = 0;
          if (!lostSince) lostSince = now;
          const lost = now - lostSince;
          if (f.comp >= 0.9) { markSent(null); chatPre = '?'; throw new Again('le prompt était resté dans la zone de saisie de ChatGPT (envoi non pris) : je l\'envoie.'); }
          if (lost > T.poke && now - lastPoke > T.pokeGap) { await poke(); return null; }
          if (lost > T.lost && !reloads && await reload('ce prompt n\'apparaît pas dans la conversation')) return null;
          if (lost > T.lost && !sure && (reloads > 0 || lost > T.lost * 4)) { markSent(null); chatPre = '?'; throw new Again('ce prompt n\'est pas dans la conversation ChatGPT : je le renvoie.'); }
          return null;
        }, { timeout: Infinity, every: 1000, what: 'génération de l\'image par ChatGPT', nag: 10 * 60000 });
        let b = null;
        try { b = await pull('chatgpt', got.src, 'image/png'); const bmp = await createImageBitmap(b); const okSize = bmp.width >= 400 && bmp.height >= 400; bmp.close && bmp.close(); if (!okSize) throw new Error('image trop petite'); }
        catch (e) { // adresse déjà remplacée par la page, ou image pas encore lisible : on la relit au relevé suivant
          if (e instanceof Stop) throw e;
          if (++pullFails > 8) { markSent(null); throw new Error(`image de ChatGPT impossible à récupérer (${e.message})`); }
          await sleep(TEST ? 150 : 800); continue;
        }
        const h = await hashOf(b);
        if (knownImg.has(h)) { // l'image rangée sous ce message est déjà celle d'un autre élément : ce n'était pas notre message
          taken.add(got.src);
          if (!got.blind && ++wrongTurn >= 2) { markSent(null); chatPre = '?'; throw new Again('l\'image trouvée sous ce prompt appartient déjà à un autre élément : je renvoie ce prompt.'); }
          await sleep(TEST ? 150 : 1000); continue;
        }
        knownImg.add(h); blob = b;
      }
      job.gotImage = true; job.doneAt = Date.now();
      markSent(null);
      return blob;
    } catch (e) { if (!(e instanceof Stop)) { chatReady = false; chatPre = chatPre ? '?' : null; } throw e; } // on reviendra dans la même conversation
  }, 'chatgpt');
}
const ext = (blob) => (/jpe?g/.test(blob.type) ? 'jpg' : /webp/.test(blob.type) ? 'webp' : 'png');
const REFS_NOTE = 'Les images jointes sont les planches de référence des personnages : respecte-les à l\'identique (visage, matière, tenue, marqueur). Ce sont des références, pas le résultat : génère une NOUVELLE image. ';
let lastImgAt = 0; // heure de la dernière image reçue de ChatGPT (chrono de l'enchaînement)
async function stepImages() {
  const k = prod.pkg, jobs = [];
  lastImgAt = 0;
  const look = P.lookOf(prod) ? `\n\n${P.lookOf(prod)}` : '';
  for (const key of [...k.planches.map((p) => p.status === 'done' && p.key), ...k.scenes.map((s) => s.imgStatus === 'done' && s.imgKey), k.miniature.status === 'done' && k.miniature.key].filter(Boolean)) {
    const b = await media(key); if (b) knownImg.add(await hashOf(b));
  }
  for (const p of k.planches) if (p.status !== 'done') jobs.push({ id: `pl:${p.name}`, kind: 'planche', label: `Planche « ${p.name} »`, make: async () => { const sr = await styleRef(); return { refs: sr ? sr.refs : [], text: `${sr ? sr.note : ''}Génère cette image, au format portrait vertical 9:16. ${P.NO_TEXT_IMAGE} Ne réponds que par l'image.\n\n${p.prompt}${look}` }; },
    done: async (blob) => {
      p.key = await keep(`planche-${P.slug(p.name)}.${ext(blob)}`, blob); p.status = 'done';
      await toDisk(blob, `images/planche-${P.slug(p.name)}.${ext(blob)}`);
      { // une planche refaite garde la catégorie et le style que tu lui as donnés à la main
        const cid = `${prod.series}/${P.normName(p.name)}`, had = (await DB.allChars().catch(() => [])).find((x) => x.id === cid) || {};
        await DB.putChar({ id: cid, name: p.name, blob, prompt: p.prompt, series: prod.series, seriesTitle: k.meta.serie || prod.title, from: prod.id,
          style: had.style || ((prod.styleKey || prod.style) === 'video' ? '' : (prod.styleKey || prod.style || '')), styleLabel: had.style ? (had.styleLabel || '') : ((prod.styleKey || prod.style) === 'video' ? '' : (prod.styleLabel || '')) }); }
    } });
  for (const s of k.scenes) if (s.imgStatus !== 'done') jobs.push({ id: `sc:${s.n}`, n: s.n, kind: 'scene', label: `Image de la scène ${s.n}`, log: `Image de la scène ${s.n}/${k.scenes.length}…`,
    make: async () => { const refs = await refBlobs(s.refs); return { refs, text: `${refs.length ? REFS_NOTE : ''}Génère cette image de scène, au format portrait vertical 9:16 (le plus haut format vertical possible). Garde les personnages et l'action dans la bande centrale : rien d'important à moins de 8 % des bords gauche et droit, l'image sera recadrée en 9:16 exact. ${P.NO_TEXT_IMAGE} Ne réponds que par l'image.\n\n${s.image}${look}` }; },
    done: async (blob) => { s.imgKey = await keep(`scene-${pad(s.n)}.${ext(blob)}`, blob); s.imgAt = Date.now(); s.imgStatus = 'done'; grokPending.set(s.n, Date.now()); toDisk(blob, `images/scene-${pad(s.n)}.${ext(blob)}`); } });
  if (k.miniature.status !== 'done') jobs.push({ id: 'mini', kind: 'mini', label: 'Miniature', log: prod.miniFromKey && !k.miniature.variant ? `Miniature (même titre que la partie précédente, PARTIE ${prod.part})…` : `Miniature (texte : ${P.MINI_STYLES[P.miniStyleKey(prod, auto.miniStyle)].label.toLowerCase()}${k.miniature.variant ? `, version ${k.miniature.variant + 1}` : ''})…`,
    make: async () => {
      if (prod.miniFromKey && !k.miniature.variant) { // suite : même TITRE que la miniature d'avant (mots, lettrage, effets, place), nouveau numéro, NOUVELLE image
        const old = await media(prod.miniFromKey);
        if (old) {
          const chars = await refBlobs(k.miniature.refs);
          log(`Miniature : je garde le titre de la partie précédente (mêmes mots, même lettrage, mêmes effets) avec « PARTIE ${prod.part} », sur une nouvelle image.`);
          return { refs: [{ blob: old, name: `miniature-precedente.${ext(old)}` }, ...chars], text: `${chars.length ? 'Les autres images jointes sont les planches de référence des personnages : respecte-les à l\'identique (visage, matière, tenue, marqueur). ' : ''}${P.miniKeepTextPrompt(k, prod, prod.miniPrevPart)}${look}` };
        }
        log('Miniature de la partie précédente introuvable : j\'en fais une nouvelle.', 'warn');
      }
      const refs = await refBlobs(k.miniature.refs); return { refs, text: `${refs.length ? REFS_NOTE : ''}Génère cette miniature, au format portrait vertical 9:16, avec le texte demandé écrit sans faute. Ne réponds que par l'image.\n\n${P.miniPrompt(k, prod, auto.miniStyle)}${look}` }; },
    done: async (blob) => { const nm = `miniature${k.miniature.variant ? `-v${k.miniature.variant + 1}` : ''}.${ext(blob)}`; // une version refaite ne remplace pas la précédente sur le disque
      k.miniature.key = await keep(nm, blob); k.miniature.status = 'done'; k.miniature.style = P.miniStyleKey(prod, auto.miniStyle); await toDisk(blob, nm); } });
  const planchesReady = () => k.planches.every((p) => p.status === 'done');
  for (let i = 0; i < jobs.length; i++) {
    jobs[i].next = jobs[i + 1] || null;
    jobs[i].canPrepare = () => jobs[i].kind === 'planche' || planchesReady(); // une scène a besoin de toutes les planches pour ses références
  }
  homeKey = jobs.length ? 'chatgpt' : null;
  try {
  for (let i = 0; i < jobs.length; i++) {
    const job = jobs[i];
    log(job.log || `${job.label}…`);
    const blob = await chatImage(job);
    await job.done(blob); // (une scène est aussitôt signalée à Grok : elle doit partir avant toute préparation d'avance dans ChatGPT)
    // chrono : temps de génération, et délai entre l'image d'avant et l'envoi de ce prompt (c'est ce délai qu'il faut garder près de zéro)
    if (job.sentAt && job.doneAt) {
      const gen = Math.round((job.doneAt - job.sentAt) / 1000), gap = lastImgAt ? Math.max(0, (job.sentAt - lastImgAt) / 1000) : null;
      log(`${job.label} : reçue en ${gen} s${gap === null ? '' : `, prompt parti ${gap < 10 ? gap.toFixed(1).replace('.', ',') : Math.round(gap)} s après l'image d'avant${job.wasReady ? '' : ' (pas prêt d\'avance)'}`}.`, gap !== null && gap > 20 ? 'warn' : 'info');
      prod.chrono = prod.chrono || { img: 0, gap: 0, n: 0 }; prod.chrono.img += gen; prod.chrono.gap += gap || 0; prod.chrono.n++;
    }
    lastImgAt = job.doneAt || Date.now();
    await save(true);
  }
  } finally { homeKey = null; }
  if (jobs.length && prod.chrono && prod.chrono.n) log(`Images : ${prod.chrono.n} générées, ${Math.round(prod.chrono.img / 60)} min d'attente ChatGPT et ${Math.round(prod.chrono.gap)} s perdues entre deux images.`);
  if (auto.notifySteps && !prod.imagesNotified) { prod.imagesNotified = true; notify('FruitRadar — images prêtes', `« ${prod.title} » : toutes les images sont générées.`, null); }
}

/* 4 — Clips : Grok, une génération par scène. Trois choses comptent pour TikTok :
   la durée (6, 10 ou 15 s), le format vertical 9:16 et la qualité 1080p.
   En image → vidéo, c'est l'image de départ qui fixe le format : on l'envoie donc en 9:16 exact. */
async function fit916(blob) {
  const bmp = await createImageBitmap(blob);
  const W = 1080, H = 1920, bw = bmp.width, bh = bmp.height, r = bw / bh, target = W / H;
  if (Math.abs(r - target) < 0.004 && bw >= 1000) { bmp.close(); return { blob, note: '' };}
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const ctx = c.getContext('2d'); ctx.imageSmoothingQuality = 'high';
  let sw = bw, sh = bh, sx = 0, sy = 0;
  if (r > target) { sw = bh * target; sx = (bw - sw) / 2; } else { sh = bw / target; sy = (bh - sh) / 2; }
  ctx.drawImage(bmp, sx, sy, sw, sh, 0, 0, W, H); bmp.close();
  return { blob: await new Promise((res) => c.toBlob(res, 'image/png')), note: `${bw}×${bh} recadrée en 1080×1920` };
}
/* Durée et dimensions lues dans le fichier MP4 lui-même (boîtes moov → mvhd et trak → tkhd), sans lecteur vidéo.
   Vérifié dans Chrome le 16 novembre 2026 : une page CACHÉE qui n'a encore joué aucune vidéo ne charge pas une balise <video>
   (Chrome attend que la page redevienne visible). La fenêtre pilote est souvent cachée derrière l'onglet piloté : l'export CapCut,
   pourtant bien téléchargé, était alors déclaré « illisible » au bout de 15 s. */
async function mp4Info(blob) {
  const rd = async (o, n) => new DataView(await blob.slice(Math.max(0, o), Math.max(0, o) + n).arrayBuffer());
  const boxes = async (start, end) => {
    const out = []; let o = start;
    while (o + 8 <= end && out.length < 400) {
      const h = await rd(o, 16); if (h.byteLength < 8) break;
      let size = h.getUint32(0), head = 8;
      const type = String.fromCharCode(h.getUint8(4), h.getUint8(5), h.getUint8(6), h.getUint8(7));
      if (size === 1) { if (h.byteLength < 16) break; size = h.getUint32(8) * 4294967296 + h.getUint32(12); head = 16; } else if (size === 0) size = end - o;
      if (size < head) break;
      out.push({ type, start: o + head, end: Math.min(end, o + size) }); o += size;
    }
    return out;
  };
  const top = await boxes(0, blob.size);
  const moov = top.find((x) => x.type === 'moov');
  if (!moov || !top.some((x) => x.type === 'ftyp')) return null;
  const inMoov = await boxes(moov.start, moov.end);
  let dur = 0, w = 0, h = 0;
  const mvhd = inMoov.find((x) => x.type === 'mvhd');
  if (mvhd && mvhd.end - mvhd.start >= 32) {
    const d = await rd(mvhd.start, 32), v1 = d.getUint8(0) === 1;
    const scale = v1 ? d.getUint32(20) : d.getUint32(12), ticks = v1 ? d.getUint32(24) * 4294967296 + d.getUint32(28) : d.getUint32(16);
    if (scale && ticks && ticks !== 0xFFFFFFFF) dur = ticks / scale;
  }
  for (const trak of inMoov.filter((x) => x.type === 'trak')) {
    const tk = (await boxes(trak.start, trak.end)).find((x) => x.type === 'tkhd');
    if (!tk || tk.end - tk.start < 44) continue;
    const d = await rd(tk.end - 44, 44); // matrice (36 octets) puis largeur et hauteur en 16.16 : la piste image est celle qui a une taille
    let tw = d.getUint32(36) / 65536, th = d.getUint32(40) / 65536;
    if (d.getInt32(0) === 0 && d.getInt32(4) !== 0) [tw, th] = [th, tw]; // vidéo tournée d'un quart de tour
    if (tw * th > w * h) { w = Math.round(tw); h = Math.round(th); }
  }
  return dur > 0 && w > 0 && h > 0 ? { dur, w, h } : null;
}
async function probeVideo(blob) { // durée et dimensions réelles du fichier téléchargé
  const fast = await mp4Info(blob).catch(() => null);
  if (fast) return fast;
  // MP4 fragmenté (durée absente de l'en-tête) : on la calcule à partir de la liste des images
  const tr = await F.mp4Video(blob).catch(() => null);
  if (tr && tr.duration > 0 && tr.width && tr.height) { const [w, h] = viewOf(tr); return { dur: tr.duration, w, h }; }
  const url = URL.createObjectURL(blob), v = document.createElement('video');
  v.muted = true; v.preload = 'metadata'; v.src = url;
  try {
    await new Promise((res, rej) => { const t = setTimeout(() => rej(new Error('illisible')), 15000); v.onloadedmetadata = () => { clearTimeout(t); res(); }; v.onerror = () => { clearTimeout(t); rej(new Error('illisible')); }; });
    return { dur: Number.isFinite(v.duration) ? v.duration : 0, w: v.videoWidth, h: v.videoHeight };
  } finally { URL.revokeObjectURL(url); v.removeAttribute('src'); try { v.load(); } catch (e) {} }
}
/* Le fichier du clip : on lit directement la vidéo affichée sur la page du clip. AUCUN bouton n'y est cliqué : sur cette page,
   « Étendre la vidéo », « Créer une vidéo », « Régénérer » et la boîte pré-remplie relancent tous une génération. */
/* Le clip existe-t-il déjà chez Grok ? On lit 32 octets à son adresse, depuis l'extension : la page n'a pas besoin de l'afficher.
   true : c'est une vidéo ; false : pas encore (Grok répond « introuvable ») ; null : adresse illisible d'ici (on garde la méthode par la page). */
async function clipThere(u) {
  try {
    const r = await fetch(u, { credentials: 'include', cache: 'no-store', headers: { Range: 'bytes=0-31' } });
    if (!r.ok || /(html|xml|json)/i.test(r.headers.get('content-type') || '')) return r.status >= 400 && r.status < 500 ? false : null;
    const b = new Uint8Array(await r.arrayBuffer());
    return String.fromCharCode(...b.slice(4, 8)) === 'ftyp';
  } catch (e) { return null; }
}
let grokUid = '';
async function grokFetch(key, got) {
  const raw = await pull(key, got.src, 'video/mp4');
  const blob = raw.type ? raw : new Blob([raw], { type: 'video/mp4' });
  const info = await probeVideo(blob).catch(() => null);
  return { blob, info: info || { dur: got.dur, w: got.w || 0, h: got.h || 0 } };
}
/* Le clip part-il de l'image de la scène ? On compare, en tout petit, l'image envoyée aux premières images du clip.
   0 = identique ; une autre vidéo donne en général plus de 0,2. */
const MATCH_MAX = 0.18;
async function thumbOf(src) { const c = document.createElement('canvas'); c.width = 18; c.height = 32; const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(src, 0, 0, 18, 32); return x.getImageData(0, 0, 18, 32).data; }
const diffOf = (a, b) => { let t = 0, n = 0; for (let i = 0; i < a.length; i += 4) { t += Math.abs(a[i] - b[i]) + Math.abs(a[i + 1] - b[i + 1]) + Math.abs(a[i + 2] - b[i + 2]); n += 3; } return t / n / 255; };
async function startMatch(imgBlob, vidBlob) {
  const bm = await createImageBitmap(imgBlob); const ref = await thumbOf(bm); try { bm.close(); } catch (e) {}
  try { // décodage direct : marche fenêtre cachée
    let best = 1; const tr = await F.mp4Video(vidBlob);
    await F.grabFrames(vidBlob, [0.04, 0.4, 0.9].map((t) => Math.max(0, Math.min(t, (tr.duration || 1) - 0.05))), (i, frame) => {
      const sh = F.sheet(18, 32); F.drawFrame(sh.ctx, frame, 0, 0, 18, 32, tr.rot); best = Math.min(best, diffOf(ref, sh.ctx.getImageData(0, 0, 18, 32).data));
    }, tr, { timeout: 30000 });
    return Math.round(best * 1000) / 1000;
  } catch (e) { /* secours : balise <video> */ }
  const url = URL.createObjectURL(vidBlob), v = document.createElement('video'); v.muted = true; v.preload = 'auto'; v.src = url;
  try {
    await new Promise((res, rej) => { const t = setTimeout(() => rej(new Error('clip illisible')), 15000); v.onloadeddata = () => { clearTimeout(t); res(); }; v.onerror = () => { clearTimeout(t); rej(new Error('clip illisible')); }; });
    let bestD = 1;
    for (const t of [0.04, 0.4, 0.9]) {
      await new Promise((res) => { let d = false; const fin = () => { if (!d) { d = true; v.removeEventListener('seeked', fin); res(); } }; v.addEventListener('seeked', fin); v.currentTime = Math.max(0, Math.min(t, (v.duration || 1) - 0.05)); setTimeout(fin, 2500); });
      bestD = Math.min(bestD, diffOf(ref, await thumbOf(v)));
    }
    return Math.round(bestD * 1000) / 1000;
  } finally { URL.revokeObjectURL(url); v.removeAttribute('src'); try { v.load(); } catch (e) {} }
}
/* Chaque scène a SON onglet Grok (« grok#3 ») : on ouvre Imagine, on y met l'image de la scène et son prompt vidéo, on envoie UNE fois,
   puis on passe à la scène suivante pendant que Grok génère. Les clips sont récupérés ensuite, chacun sur sa page. */
const grokKey = (s) => `grok#${s.n}`;
const tabUrl = async (key) => { try { return (await chrome.tabs.get(tabs[key])).url || ''; } catch (e) { return ''; } };
const pathOf = (u) => { try { return new URL(u).pathname; } catch (e) { return ''; } };
async function closeTab(key) { if (await tabAlive(key)) { try { await chrome.tabs.remove(tabs[key]); } catch (e) { /* déjà fermé */ } } delete tabs[key]; }
const GROK_POST = /\/imagine\/post\/(?!tmp_)[\w-]{8,}/;
/* Onglet Imagine d'avance : une page neuve, jamais utilisée, chargée en arrière-plan pendant que ChatGPT dessine. */
const GROK_NEXT = 'grok#suivant';
let warming = false;
async function grokWarm() {
  if (auto.grokWarm === false || warming || await tabAlive(GROK_NEXT)) return;
  warming = true;
  try { tabs[GROK_NEXT] = (await chrome.tabs.create({ windowId: winId, url: START_URL('grok', auto), active: false })).id; await groupTab(tabs[GROK_NEXT]); }
  catch (e) { delete tabs[GROK_NEXT]; }
  finally { warming = false; }
}
async function grokLaunch(s, key, img, vtext) {
  let cfg = null, prep = null;
  const t0 = Date.now();
  for (let tryN = 1; ; tryN++) {
    cfg = null;
    if (tryN === 1 && !(await tabAlive(key)) && await tabAlive(GROK_NEXT)) { // la page ouverte d'avance, si elle est bien vierge
      tabs[key] = tabs[GROK_NEXT]; delete tabs[GROK_NEXT];
      try { const c = await openSite(key, { fresh: false }); const pre = await call(key, 'grokCheck', c); if (pre && pre.imagine && !pre.images && !(pre.textLen > 0)) cfg = c; } catch (e) { if (e instanceof Stop) throw e; } // page d'avance périmée (ouverte avant une connexion, par exemple) : on en rouvre une neuve juste après
    }
    if (!cfg) cfg = await openSite(key, { newTab: true }); // page Imagine entièrement neuve : rien de la scène d'avant
    const chk = await call(key, 'grokCheck', cfg);
    if (!chk || !chk.imagine) throw new Error(`Grok : la page Imagine ne s'ouvre pas (${(chk && chk.path) || 'adresse inconnue'}) — vérifie l'adresse Grok dans Réglages → Création`);
    const ids = await sendFiles(key, [{ blob: img, name: `scene-${pad(s.n)}.${ext(img)}` }]);
    prep = await call(key, 'grokPrepare', cfg, { fileId: ids[0], text: vtext, duree: s.duree, duration: cfg.durationOption[s.duree], quality: auto.grokQuality === 'any' ? '' : (cfg.qualityOption[auto.grokQuality] || cfg.qualityOption['1080p']) });
    await call(key, 'dropFiles', ids).catch(() => null);
    if (prep && prep.ok) break;
    if (prep && prep.started) { s.grokAuto = Date.now(); await save(true); throw new Blocked('Grok', `Grok a lancé une vidéo tout seul dès l'ajout de l'image de la scène ${s.n}, avant mon prompt. Pour éviter un clip en double, je m'arrête : regarde l'onglet Grok, puis clique sur Reprendre`); }
    if (tryN >= 2 || !(prep && prep.dirty)) throw new Error(`Grok : ${(prep && prep.error) || 'préparation de la scène impossible'}`);
  }
  log(`Scène ${s.n} dans Grok Imagine : ${[prep.quality, prep.duration, prep.ratio].filter(Boolean).join(' · ') || 'réglages non lus'}, image jointe, prompt collé${prep.miss && prep.miss.length ? ` — à vérifier : ${prep.miss.join(', ')}` : ''}.`, prep.miss && prep.miss.length ? 'warn' : 'info');
  // À partir d'ici cette scène est considérée comme envoyée : elle ne sera plus jamais renvoyée toute seule.
  s.grokSent = Date.now(); s.grokPost = null; await save(true);
  let fired = null;
  try { fired = await call(key, 'grokFire', cfg, { textLen: prep.textLen, duration: cfg.durationOption[s.duree], duree: s.duree }); } catch (e) { fired = { unsure: true, error: e.message }; }
  if (fired && fired.ok === false && !fired.unsure) { s.grokSent = null; await save(true); throw new Error(`Grok : envoi annulé, ${fired.error}`); } // la page a refusé avant de cliquer : rien n'est parti
  // Grok ouvre alors la page du clip (/imagine/post/…). Une conversation de texte serait une erreur.
  let moved = false;
  for (let i = 0; i < (TEST ? 30 : 120) && !s.grokPost; i++) {
    const u = await tabUrl(key), path = pathOf(u);
    if (GROK_POST.test(u)) s.grokPost = u;
    else if (/^\/(c|chat)\/[\w-]{6,}/.test(path)) throw new Blocked('Grok', `Le prompt de la scène ${s.n} est parti dans une conversation de texte au lieu d'Imagine. Regarde l'onglet Grok ; pour relancer la scène, clique sur « Refaire la scène »`);
    else if (/\/imagine\/post\//.test(path)) { if (moved) break; moved = true; } // adresse provisoire : la génération est lancée, on libère l'écran (l'adresse finale sera relevée pendant l'attente du clip)
    if (!s.grokPost) { if (i >= (TEST ? 14 : 40) && !moved) break; await sleep(TEST ? 150 : 300); }
  }
  if (!s.grokPost && !moved) {
    const chk = await call(key, 'grokCheck', cfg).catch(() => null);
    if (chk && chk.imagine && chk.images === 1 && chk.textLen > 20) {
      s.grokSent = null; await save(true);
      const st = await call(key, 'state', cfg).catch(() => null), quota = st && grokQuota(st.alerts);
      if (quota && quota.full) throw quotaPause(s, quota.text, false); // quota épuisé : on s'arrête, son et raison à l'appui
      const why = st && st.alerts.find((x) => !grokQuota([x]) && /(limit|trop de|too many|patiente|wait|plus tard|later|réessa|try again|simultan|concurrent)/i.test(x)); // « 75 % utilisés » n'est pas une raison
      if (why) throw new Later(`Grok n'a pas pris la scène ${s.n} (« ${why.slice(0, 120)} ») : il génère sans doute déjà le maximum de clips à la fois.`);
      throw new Error('Grok : le clic d\'envoi n\'a pas été pris en compte (image et prompt toujours dans la boîte), je recommence sur une page neuve');
    }
    throw new Blocked('Grok', `La scène ${s.n} a été envoyée mais Grok n'a pas ouvert la page de son clip. Regarde dans Grok si le clip se génère ; sinon clique sur « Refaire la scène »`);
  }
  { const lag = s.imgAt && Date.now() - s.imgAt < 30 * 60000 ? Math.round((Date.now() - s.imgAt) / 1000) : null;
    log(`Scène ${s.n} lancée chez Grok en ${Math.round((Date.now() - t0) / 1000)} s${lag === null ? '' : `, ${lag} s après son image`}.`, lag !== null && lag > 60 ? 'warn' : 'info'); }
  await save(true);
  return cfg;
}
async function grokClip(s) {
  const key = grokKey(s);
  return attempt(`Clip de la scène ${s.n}`, async (_i, soft) => {
    const vtext = P.withNoText(P.withSpeakerLock(soft ? P.soften(s.video, soft, 'video') : s.video), !!prod.keyText && prod.pkg.scenes.filter((x) => P.keywordOf(x.video)).slice(0, 2).some((x) => x.n === s.n)); // mot fort : 2 scènes au plus (le hook et un moment fort), même si le package en propose davantage // qui dit quoi, répété à la fin ; jamais de texte incrusté
    let img = await media(s.imgKey), cfg;
    if (!img) throw new Error('image de départ absente');
    if (auto.grokCrop) { try { const f = await fit916(img); img = f.blob; if (f.note && !s.cropNoted) { s.cropNoted = true; log(`Scène ${s.n} : image de départ ${f.note} pour un clip vertical 9:16.`); } } catch (e) { log(`Scène ${s.n} : recadrage 9:16 impossible (${e.message}), image envoyée telle quelle.`, 'warn'); } }
    // UNE SEULE génération par scène. Si un essai échoue après l'envoi, on retourne sur la page du clip et on l'attend
    // (seuls « Refaire la scène » ou un refus de Grok relancent une génération).
    const forget = () => { s.grokSent = null; s.grokPost = null; };
    if (s.grokSent) {
      if (!(await tabAlive(key))) {
        if (!s.grokPost) throw new Blocked('Grok', `La scène ${s.n} a déjà été envoyée à Grok, mais je n'ai pas retrouvé la page de son clip. Regarde dans Grok si le clip existe ; sinon clique sur « Refaire la scène » dans FruitRadar`);
        log(`Scène ${s.n} : déjà envoyée à Grok, je ne la renvoie pas. Je retourne sur la page de son clip.`);
        await withHands(key, () => openSite(key, { url: s.grokPost, needComposer: false }));
      }
      cfg = cfgOf(key);
    } else { try { cfg = await withHands(key, () => grokLaunch(s, key, img, vtext)); } finally { grokPending.delete(s.n); } }
    // Attente du clip, sans monopoliser l'écran : les autres scènes se lancent pendant ce temps.
    const sentAt = s.grokSent || Date.now();
    let lastSrc = '', calm = 0, poke = Date.now(), clip = null, got = null, offSince = 0, back = 0, lastReload = 0, reloads = 0;
    let directAt = 0, directFails = 0, direct = true; // téléchargement à l'adresse du clip : direct = false si l'adresse est illisible d'ici
    let convAt = 0, convFails = 0, convId = ''; // conversation Imagine de la scène (nouvelle version de Grok) : elle donne l'adresse exacte du clip
    const postOf = (u) => (/\/imagine\/post\/([\w-]{8,})/.exec(u || '') || [])[1] || '';
    const convOf = (u) => { try { return new URL(u).searchParams.get('conversation') || ''; } catch (e) { return ''; } };
    const waitFrom = Math.max(sentAt, Date.now()); // une scène envoyée avant une reprise : les délais de secours partent de maintenant
    const rejected = new Set();
    const clipUrl = async () => {
      const m = /\/imagine\/post\/([\w-]{8,})/.exec(s.grokPost || '');
      if (!m || /^tmp_/.test(m[1])) return null;
      if (!grokUid) grokUid = prod.grokUid || '';
      if (!grokUid) { const u = await call(key, 'grokUser').catch(() => ''); if (u) { grokUid = u; prod.grokUid = u; save(); } }
      return grokUid ? `https://assets.grok.com/users/${grokUid}/generated/${m[1]}/generated_video.mp4?cache=1` : null;
    };
    // Vidéos qui ne sont jamais un clip généré : les exemples et modèles de l'accueil d'Imagine (vu le 16 novembre 2026 : « Modifier le texte », un café en 960×960 de 6 s)
    const foreign = (v) => /(\/\/media\.x\.ai\/|\/website\/|grok-web|template)/i.test(v.src || '');
    const MP4_URL = /^https?:\/\/[^\s]+\.mp4(\?|#|$)/i; let blindFails = 0; let showAt = 0, shows = 0;
    for (;;) {
      got = await until(async () => {
        if (!(await tabAlive(key))) { if (!s.grokPost) throw new Blocked('Grok', `L'onglet Grok de la scène ${s.n} a été fermé avant la fin. Regarde dans Grok si le clip existe ; sinon clique sur « Refaire la scène »`); await openSite(key, { url: s.grokPost, needComposer: false, active: false }); }
        if (!s.grokPost) { const u = await tabUrl(key); if (GROK_POST.test(u)) { s.grokPost = u; save(); } }
        const st = await call(key, 'state', cfg);
        if (st.block) throw new Blocked(st.block, `Grok : ${st.block}`);
        // L'onglet doit rester sur la page du clip (/imagine/post/…). S'il se retrouve ailleurs (Grok revient parfois à l'accueil d'Imagine),
        // on y retourne : l'accueil affiche des vidéos d'exemple, et l'ancienne version finissait par en prendre une à la place du clip.
        if (!/\/imagine\/post\//.test(await tabUrl(key))) {
          if (!offSince) offSince = Date.now();
          if (Date.now() - offSince > (TEST ? 4000 : 20000)) {
            if (s.grokPost && back < 3) { back++; offSince = 0; log(`Scène ${s.n} : l'onglet Grok n'est plus sur la page du clip, j'y retourne.`, 'warn'); await openSite(key, { url: s.grokPost, needComposer: false, active: false }); return null; }
            throw new Blocked('Grok', `L'onglet Grok de la scène ${s.n} n'est plus sur la page de son clip (Grok est revenu à l'accueil d'Imagine). Regarde dans Grok si le clip existe ; sinon clique sur « Refaire le clip »`);
          }
          return null;
        }
        offSince = 0;
        // Le plus sûr (nouvelle version de Grok, vu le 23 novembre 2026) : la page reste souvent sur l'IMAGE de départ, le clip n'étant qu'une
        // vignette (en haut ou en bas de la bande) avec son propre numéro. On demande à Grok la conversation Imagine de la scène : elle donne
        // l'adresse exacte du clip dès qu'il est prêt. Rien à afficher ni à cliquer : onglet caché, fenêtre réduite, ça marche. Toutes les 10 s.
        if (Date.now() - sentAt > (TEST ? 500 : 15000) && Date.now() - convAt > (TEST ? 800 : 10000)) {
          convAt = Date.now();
          const cl = await call(key, 'grokClips', postOf(s.grokPost), convId || convOf(s.grokPost)).catch((e) => { if (e instanceof Stop) throw e; return { ok: false, error: e.message }; });
          if (cl && cl.ok) {
            convFails = 0; if (cl.cid) convId = cl.cid; // retrouvée une fois : plus besoin de la redemander
            const vs = (cl.vids || []).filter((v) => v && v.url && !rejected.has(v.url)).sort((a, b) => (a.at || 0) - (b.at || 0)); // le 1er clip de la conversation : celui que j'ai lancé
            if (vs.length && vs.every((v) => v.moderated)) { forget(); throw new Refused(`Grok : le clip de la scène ${s.n} a été bloqué par la modération de Grok`); }
            const v = vs.find((x) => !x.moderated);
            if (v && (await clipThere(v.url)) !== false) return { src: v.url, dur: 0, w: 0, h: 0, main: true, area: 1e6, direct: true };
          } else if (++convFails === 6) log(`Scène ${s.n} : je n'arrive pas à lire chez Grok la conversation du clip (${String((cl && cl.error) || 'pas de réponse').slice(0, 100)}). J'essaie les autres méthodes.`, 'warn');
        }
        // Ancienne méthode : le clip à l'adresse déduite de sa page, quand c'est la page de la vidéo (Grok d'avant le 23 novembre 2026).
        // Pas besoin que la page l'affiche (fenêtre réduite, Firefox ou un jeu devant : Grok n'y met plus rien à jour, vu le 22 novembre 2026).
        if (direct &&Date.now() - sentAt > (TEST ? 500 : 20000) && Date.now() - directAt > (TEST ? 800 : 10000)) {
          directAt = Date.now();
          const u = await clipUrl();
          if (u && !rejected.has(u)) {
            const there = await clipThere(u);
            if (there === true) return { src: u, dur: 0, w: 0, h: 0, main: true, area: 1e6, direct: true };
            if (there === null && ++directFails >= 6) { direct = false; log(`Scène ${s.n} : je n'arrive pas à interroger l'adresse du clip chez Grok, j'attends qu'il s'affiche dans la page.`, 'warn'); }
          } else if (!u && Date.now() - sentAt > (TEST ? 4000 : 60000)) direct = false; // pas d'adresse (page du clip inconnue) : méthode par la page
        }
        // Onglet Grok caché : Chrome n'y charge pas la vidéo, donc ni durée ni taille dans la page (le clip, pourtant prêt, n'était vu que lorsque
        // tu affichais l'onglet). La vidéo principale de la page du clip qui pointe vers un fichier .mp4 est donc candidate même « à l'aveugle » :
        // sa durée et sa taille sont lues ensuite dans le fichier téléchargé.
        // Jamais les petites vidéos de la page : vignettes de la bande du clip, « créations récentes » du menu de gauche (les clips des AUTRES
        // scènes, 33 px de côté, ajoutées par Grok le 23 novembre 2026 : elles faisaient croire qu'une vidéo était affichée).
        const fresh = st.vids.filter((v) => (v.dur > 0 || ((v.main || (v.area || 0) > 60000) && MP4_URL.test(v.src) && !foreign(v))) && !rejected.has(v.src) && !(!v.main && v.area > 0 && v.area < 20000));
        // Aucune grande vidéo dans la page du clip : Grok affiche l'image de départ, le clip étant dans la bande de vignettes (« 0:06 », en haut ou en bas). On clique dessus.
        if (!fresh.some((v) => v.main || (v.area || 0) > 40000) && !st.busy && Date.now() - showAt > (TEST ? 1500 : 8000)) {
          showAt = Date.now();
          const sv = await call(key, 'grokShowVideo', shows % 3 === 2 ? 1 : 0).catch(() => null);
          if (sv && sv.clicked) { shows++; if (shows === 1 || shows % 10 === 0) log(`Scène ${s.n} : Grok affichait l'image, pas le clip. Je clique sur la vignette du clip${sv.ok ? '' : ' (la vidéo ne s\'est pas encore affichée, je réessaie)'}.`); return null; }
        }
        const mains = fresh.filter((v) => v.main);
        // interface changée (plus de vidéo principale reconnue) : au bout de 3 minutes, on accepte la plus grande vidéo VERTICALE de la page du clip,
        // jamais un exemple du site ni une vidéo carrée ou horizontale
        const pool = mains.length ? mains : (shows > 0 || Date.now() - sentAt > (TEST ? 3000 : 180000) ? fresh.filter((v) => (v.area || 0) > 40000 && !foreign(v) && !(v.w && v.h && v.h < v.w * 1.2)) : []);
        const top = pool.sort((a, b) => (b.w || 0) - (a.w || 0) || (b.area || 0) - (a.area || 0))[0];
        if (top) { if (top.src === lastSrc) calm++; else { calm = 0; lastSrc = top.src; } if ((!st.busy && calm >= 1) || calm >= 8) return top; return null; }
        // consommation d'abord : un message de quota n'est jamais pris pour un refus de contenu (on ne reformulerait pas pour rien)
        const quota = grokQuota(st.alerts);
        if (quota && quota.full) throw quotaPause(s, quota.text, true);
        // simple information de consommation (« vous avez utilisé 75 % de votre quota ») : la génération continue, on ne s'arrête pas
        if (quota && quota.info && !prod.grokUseNoted) { prod.grokUseNoted = true; log(`Grok indique ta consommation (« ${quota.text.slice(0, 90)} ») : simple information, je continue.`); }
        const bad = st.alerts.find((x) => !grokQuota([x]) && REFUSAL.test(x));
        if (bad) { forget(); throw new Refused(`Grok : ${bad.slice(0, 140)}`); }
        const hard = st.alerts.filter((x) => !grokQuota([x]) && /(limit|limite|try again|réessa)/i.test(x));
        if (hard.length) throw new Blocked('Grok', `Grok signale : « ${hard[0].slice(0, 140)} ». Regarde l'onglet Grok : si le clip de la scène ${s.n} se génère quand même, clique sur Reprendre (je ne renverrai pas la scène) ; sinon clique sur « Refaire la scène »`);
        // Grok ne met pas à jour une page qu'on ne voit pas (fenêtre recouverte par une autre ou réduite, autre onglet devant) : le clip, pourtant
        // prêt, n'y apparaît qu'après un rafraîchissement de la page — ce que tu devais faire à la main (vu le 22 novembre 2026, clips récupérés 13 min
        // après leur génération). Pas de clip au bout de 1 min 40 s : je rafraîchis moi-même la page du clip, puis toutes les 1 min 30 s tant qu'il
        // n'est pas là. Jamais quand tu as cet onglet sous les yeux. Rafraîchir ne relance rien : la génération continue chez Grok.
        // Secours seulement (adresse du clip impossible à interroger, ou toujours rien au bout de 8 min) : rafraîchir la page, toutes les 3 min au plus.
        const stale = Date.now() - (direct ? waitFrom : sentAt) > (direct ? (TEST ? 8000 : 8 * 60000) : st.hidden ? (TEST ? 3000 : 100000) : (TEST ? 6000 : 300000));
        if (s.grokPost && stale && Date.now() - lastReload > (TEST ? 3000 : 180000) && !(await lookingAt(key))) {
          lastReload = Date.now(); reloads++;
          if (reloads === 1 || reloads % 5 === 0) log(`Scène ${s.n} : clip pas encore visible dans Grok (page en arrière-plan), je rafraîchis sa page${reloads > 1 ? ` (${reloads}e fois)` : ''}.`);
          await chrome.tabs.reload(tabs[key]).catch(() => {});
          await sleep(TEST ? 300 : 4000);
          lastSrc = ''; calm = 0; showAt = 0;
          return null;
        }
        // Chrome ralentit les onglets cachés : de temps en temps on remet celui-ci une seconde au premier plan
        if (Date.now() - poke > 40000) { poke = Date.now(); await withHands(key, () => sleep(700), 0); }
        return null;
      }, { timeout: Infinity, every: 2500, what: `génération du clip ${s.n} par Grok`, nag: 15 * 60000 });
      const blind = !(got.dur > 0); // candidate sans durée lue dans la page (onglet caché)
      let cand = null;
      try { cand = await grokFetch(key, got); } catch (e) { if (e instanceof Stop || !blind) throw e; }
      if (blind && !(cand && cand.info && cand.info.dur > 0)) { // fichier pas encore prêt ou illisible : on continue d'attendre, sans rien relancer
        if (++blindFails > 12) throw new Error(`Grok : le fichier du clip de la scène ${s.n} reste illisible`);
        lastSrc = ''; calm = 0; await sleep(TEST ? 400 : 6000); continue;
      }
      if (got.direct && !prod.grokDirectNoted) { prod.grokDirectNoted = true; log('Grok : clips téléchargés directement à leur adresse, dès qu\'ils sont prêts (pas besoin que la page Grok soit affichée).'); }
      else if (blind && !got.direct && !prod.grokBlindNoted) { prod.grokBlindNoted = true; log('Grok : onglet caché, la page ne donne pas la durée du clip ; je la lis dans le fichier téléchargé.'); }
      { const need = { '1080p': 1000, '720p': 700 }[auto.grokQuality] || 0, short = (c) => Math.min(c.info.w || 0, c.info.h || 0);
        if (need && short(cand) && short(cand) < need) { // la page affiche parfois d'abord une version légère, puis la version HD
          for (let i = 0; i < (TEST ? 10 : 8); i++) {
            await sleep(TEST ? 500 : 2500);
            const st = await call(key, 'state', cfg).catch(() => null);
            const hd = st && st.vids.filter((v) => v.main && v.src && v.src !== got.src && !rejected.has(v.src) && (v.dur > 0 ? Math.min(v.w || 0, v.h || 0) > short(cand) : MP4_URL.test(v.src)))[0];
            if (hd) { const better = await grokFetch(key, hd).catch(() => null); if (better && short(better) > short(cand)) { cand = better; got = hd; } break; }
          }
        } }
      const dur = cand.info.dur || got.dur;
      if (!got.main) { // vidéo prise faute de repère : elle doit partir de l'image de la scène, sinon ce n'est pas notre clip
        const d0 = await startMatch(img, cand.blob).catch(() => null);
        if (d0 !== null && d0 > MATCH_MAX * 1.6) {
          rejected.add(got.src); lastSrc = ''; calm = 0;
          log(`Scène ${s.n} : une vidéo de la page ne part pas de l'image de la scène (écart ${d0}) : ce n'est pas le clip, j'attends le bon.`, 'warn');
          await sleep(TEST ? 300 : 5000); continue;
        }
      }
      if (Math.abs(dur - s.duree) <= 1.6 || rejected.size >= 2) { clip = cand; break; }
      rejected.add(got.src); lastSrc = ''; calm = 0; // aperçu pas fini ? On regarde encore un peu avant de conclure
      log(`Scène ${s.n} : la vidéo affichée fait ${dur.toFixed(1)} s au lieu de ${s.duree} s, je vérifie encore.`, 'warn');
      await sleep(TEST ? 300 : 5000);
    }
    const blob = clip.blob, info = clip.info;
    const dur = info.dur || got.dur;
    // Un mauvais réglage ne se corrige pas en réessayant : pause tout de suite, pour ne pas gaspiller de générations.
    if (Math.abs(dur - s.duree) > 1.6) { forget(); await closeTab(key); throw new Blocked('réglage', `Grok a rendu un clip de ${dur.toFixed(1)} s au lieu de ${s.duree} s (scène ${s.n}). Vérifie la durée dans Grok Imagine, puis Reprendre (la scène sera relancée une fois)`); }
    const diff = await startMatch(img, blob).catch(() => null);
    if (diff !== null && diff > MATCH_MAX) log(`Scène ${s.n} : le début du clip ne ressemble pas à l'image de la scène (écart ${diff}). Vérifie ce clip.`, 'warn');
    if (info.w && info.h) {
      if (Math.abs(info.w / info.h - 9 / 16) > 0.035) log(`Scène ${s.n} : clip en ${info.w}×${info.h}, pas en 9:16 vertical. Je le garde ; vérifie-le dans CapCut.`, 'warn');
      const need = { '1080p': 1000, '720p': 700 }[auto.grokQuality] || 0, short = Math.min(info.w, info.h);
      if (short < need && !prod.grokLowNoted) { prod.grokLowNoted = true; log(`Grok : clip en ${short}p au lieu de ${auto.grokQuality} (${info.w}×${info.h}). Je le garde (relancer ferait une scène en double) : vérifie « Résolution vidéo » dans Grok Imagine.`, 'warn'); }
    }
    s.vidInfo = { w: info.w, h: info.h, dur: Math.round(dur * 10) / 10 };
    await closeTab(key);
    return blob;
  }, key);
}
const clipName = (s) => `${pad(s.n)}_scene.mp4`;
/* Les scènes partent chez Grok dès que leur image est prête, plusieurs à la fois (Réglages → Création → clips en même temps) :
   on lance la scène, on rouvre Imagine pour la suivante, et les clips se génèrent en parallèle. Toujours un seul envoi par scène. */
async function stepVideos(imagesDone) {
  const k = prod.pkg, live = new Map();
  const max = Math.max(1, Math.min(6, Math.round(Number(auto.grokParallel) || 3)));
  let failure = null;
  grokMax = max; grokLive.clear(); clipsOpen = true;
  const start = (s) => {
    log(`Clip de la scène ${s.n}/${k.scenes.length} (${s.duree} s)…`);
    const job = (async () => {
      const blob = await grokClip(s);
      s.vidKey = await keep(clipName(s), blob); s.vidStatus = 'done'; s.grokSent = null; s.grokPost = null;
      await toDisk(blob, `clips/${clipName(s)}`);
      prod.capcut = null; // un clip a changé : le projet CapCut est à refaire
      log(`Clip de la scène ${s.n} récupéré (${s.vidInfo ? `${s.vidInfo.w}×${s.vidInfo.h}, ${s.vidInfo.dur} s` : 'ok'}).`);
      await save(true);
    })().catch((e) => { if (!failure || e instanceof Stop) failure = e; }).finally(() => { live.delete(s.n); grokLive.delete(s.n); });
    live.set(s.n, job); grokLive.add(s.n);
  };
  for (;;) {
    if (failure) { clipsOpen = false; await Promise.allSettled([...live.values()]); await closeTab(GROK_NEXT); throw failure; }
    const next = k.scenes.find((x) => x.imgStatus === 'done' && x.vidStatus !== 'done' && !live.has(x.n));
    if (next && live.size < max) { start(next); await sleep(150); continue; }
    if (!live.size && !next && (imagesDone() || k.scenes.every((x) => x.vidStatus === 'done'))) { clipsOpen = false; break; }
    // la page Imagine de la prochaine scène se charge d'avance, en arrière-plan : au moment de lancer, il n'y a plus qu'à régler, joindre et envoyer
    if (prod.status !== 'paused' && k.scenes.some((x) => x.vidStatus !== 'done' && !x.grokSent && !live.has(x.n))) await grokWarm();
    await sleep(300);
  }
  await closeTab(GROK_NEXT);
  if (auto.notifySteps && !prod.videosNotified) { prod.videosNotified = true; notify('FruitRadar — clips prêts', `« ${prod.title} » : tous les clips sont générés.`, null); }
}
/* 3 + 4 ensemble : ChatGPT dessine pendant que Grok tourne les scènes déjà dessinées */
async function stepMake() {
  let imgs = false, firstErr = null;
  const fail = (e) => { if (!firstErr || e instanceof Stop) firstErr = e; imgs = true; if (!(e instanceof Stop)) { stopFlag = true; release(false); } };
  const a = stepImages().then(() => { imgs = true; prod.step = 'videos'; return save(true); }).catch(fail);
  const b = stepVideos(() => imgs).catch(fail);
  await Promise.all([a, b]);
  if (firstErr) { if (!(firstErr instanceof Stop)) stopFlag = false; throw firstErr; }
}

/* Bibliothèque CapCut vidée au début de chaque montage : sinon les clips des vidéos précédentes y restent et remplissent
   le stockage du compte CapCut. FruitRadar garde ses propres copies des clips (et la vidéo finale) : il ne se sert jamais de ceux de CapCut. */
/* Durée totale de la timeline, lue seulement quand elle ne bouge plus : un projet qui se charge affiche d'abord 00:00:00. */
async function stableTimes() {
  let last = null, same = 0, t = null;
  for (let i = 0; i < (TEST ? 5 : 14); i++) {
    t = await call('capcut', 'capcutTimes').catch(() => null);
    const v = t && t.ok ? t.total : '?';
    if (v === last) { if (++same >= 2) return t; } else same = 0; // la même durée lue 3 fois de suite, à 1,5 s d'écart
    last = v;
    await sleep(TEST ? 60 : 1500);
  }
  return t;
}
async function cleanCapcut() {
  const r = await call('capcut', 'capcutClean', 80).catch((e) => ({ ok: false, deleted: 0, error: e.message }));
  if (!r) return;
  const s = r.deleted > 1 ? 's' : '';
  if (r.deleted) log(`CapCut : ${r.deleted} ancien${s} fichier${s} supprimé${s} de ta bibliothèque avant le montage (place libérée sur ton stockage CapCut).`);
  if (!r.ok) log(`CapCut : bibliothèque pas entièrement vidée (${r.error || 'raison inconnue'}). Je continue le montage.`, 'warn');
}
/* 5 — CapCut : import des clips dans l'ordre, puis pose sur la timeline */
async function stepCapcut() {
  if (prod.capcut && prod.capcut.done) return;
  if (prod.finalKey && prod.validated) return; // vidéo finale déjà là (déposée par toi) : pas de nouveau montage
  const k = prod.pkg, names = k.scenes.map(clipName);
  const res = { done: false, imported: 0, placed: 0, note: '', fadeWanted: !!auto.capcutTransitions }; // fadeWanted : les fondus au noir étaient-ils demandés pour ce montage ?
  try {
    // Toujours un onglet CapCut neuf : un projet vide, jamais la timeline de la vidéo d'avant.
    // (Recharger l'ancien onglet ne suffisait pas : CapCut peut bloquer le changement de page par « Quitter le site ? », et l'ancien montage restait.)
    const cfg = await openSite('capcut', { needComposer: false, newTab: true });
    await sleep(TEST ? 300 : 4000); await call('capcut', 'dismiss', cfg).catch(() => null); // pub d'accueil de CapCut
    let st = await until(async () => { const s = await call('capcut', 'capcutState', names, cfg); if (s.block) throw new Blocked(s.block, `CapCut : ${s.block}`); return s.input ? s : null; }, { timeout: 60000, every: 2500, what: 'éditeur CapCut' }).catch(async (e) => {
      if (e instanceof Blocked || e instanceof Stop) throw e;
      await call('capcut', 'clickText', cfg.uploadText); await sleep(2000);
      return call('capcut', 'capcutState', names, cfg);
    });
    if (!st.input) throw new Error('zone d\'import introuvable dans CapCut');
    if (auto.capcutClean !== false) await cleanCapcut(); // les clips des vidéos précédentes, encore dans la bibliothèque de CapCut
    const files = [];
    for (const s of k.scenes) files.push({ blob: await media(s.vidKey), name: clipName(s) });
    log(`Import de ${files.length} clips dans CapCut…`);
    // Vrai CapCut : un clip importé se pose à l'endroit du curseur de lecture. On met donc le curseur à la fin avant CHAQUE import :
    // les clips se suivent dans l'ordre. (Importés tous ensemble, ils se superposent à 0:00.)
    let t0 = await stableTimes();
    // Relance sur un projet qui contient déjà des clips : on repart d'un projet neuf, sinon les scènes se retrouvent en double ou en triple.
    if (auto.capcutPlace && t0 && t0.ok && !/^0?0:00:00$/.test(t0.total || '')) {
      log(`CapCut : ce projet contient déjà des clips (« ${t0.total} »). J'en ouvre un neuf pour ne pas doubler les scènes.`, 'warn');
      await openSite('capcut', { needComposer: false, newTab: true });
      await sleep(TEST ? 300 : 5000); await call('capcut', 'dismiss', cfg).catch(() => null);
      await until(async () => { const s = await call('capcut', 'capcutState', names, cfg).catch(() => null); return s && s.input ? s : null; }, { timeout: 60000, every: 2500, what: 'éditeur CapCut' }).catch((e) => { if (e instanceof Stop) throw e; });
      t0 = await stableTimes();
      if (t0 && t0.ok && !/^0?0:00:00$/.test(t0.total || '')) throw new Error(`le nouveau projet CapCut n'est pas vide (« ${t0.total} ») : ouvre CapCut, crée un projet vide, puis clique sur « Refaire le montage »`);
    }
    if (auto.capcutPlace && t0 && t0.ok) {
      let placed = 0, oneTrackOff = false, offTrack = 0, undoFails = 0;
      const secsOf = (t) => { const m = /^(\d\d):(\d\d):(\d\d)$/.exec(t || ''); return m ? +m[1] * 60 + +m[2] + +m[3] / 30 : -1; };
      const issue = (base) => call('capcut', 'capcutIssue', base).catch(() => ({}));
      let failBase = ((await issue()) || {}).n || 0; // vignettes « transcodage impossible » déjà présentes dans la bibliothèque (anciens projets)
      if (failBase) log(`CapCut : ${failBase} ancien(s) clip(s) en « transcodage impossible » dans ta bibliothèque, je n'en tiens pas compte.`);
      { const t0c = await call('capcut', 'capcutTimes').catch(() => null); if (t0c && t0c.ok && !/^0?0:00:00$/.test(t0c.total || '')) log(`CapCut : la timeline du projet n'est pas vide au départ (« ${t0c.total} »). Si le montage est faux, clique sur « Refaire le montage ».`, 'warn'); else if (!t0c || !t0c.ok) log(`CapCut : durée de la timeline illisible au départ (${JSON.stringify(t0c).slice(0, 120)}).`, 'warn'); }
      for (let i = 0; i < files.length; i++) {
        // Un clip n'est validé que quand la durée de la timeline a changé. Si CapCut annonce « transcodage impossible » (ou ne pose rien),
        // on remet EXACTEMENT le même fichier, curseur à la fin : il reste donc à sa place dans l'histoire, avant le clip suivant.
        let ok = false, why = '', skipOne = false;
        for (let tryN = 1; tryN <= 4 && !ok; tryN++) {
          for (let w = 0; w < 6 && (await issue(1e9)).transcode; w++) { await call('capcut', 'dismiss', cfg).catch(() => null); await sleep(800); } // message d'erreur (hors bibliothèque) encore affiché
          failBase = ((await issue()) || {}).n || 0;
          const seek = await call('capcut', 'capcutSeekEnd');
          if (!seek || !seek.ok) throw new Error(`curseur de la timeline : ${(seek && seek.error) || 'échec'}`);
          const before = (await call('capcut', 'capcutTimes')).total;
          // vignettes déjà bloquées sur un pourcentage avant cet envoi (restes d'un ancien essai) : elles ne comptent pas
          const bz0 = (await call('capcut', 'capcutBusy').catch(() => null)) || { n: 0, sig: '' };
          const working = (bz) => !!bz && bz.n > 0 && (bz.n > bz0.n || bz.sig !== bz0.sig);
          const one = await sendFiles('capcut', [files[i]]);
          const at = await call('capcut', 'attach', one, cfg);
          if (!at || !at.ok) throw new Error('CapCut a refusé le clip ' + (i + 1));
          const ts = Date.now();
          // Tant que la bibliothèque montre un pourcentage (téléversement, transcodage), CapCut travaille : on attend, sans renvoyer le fichier.
          let busyAt = 0, sig = '', sigAt = Date.now(), toldSlow = false;
          const r = await until(async () => {
            const t = await call('capcut', 'capcutTimes');
            if (t.ok && t.total !== before) return 'ok';
            const is = await issue(failBase);
            if (is.transcode) return 'transcode';
            const bz = await call('capcut', 'capcutBusy').catch(() => null);
            if (working(bz)) {
              busyAt = Date.now(); if (bz.sig !== sig) { sig = bz.sig; sigAt = Date.now(); }
              if (!toldSlow && Date.now() - ts > 60000) { toldSlow = true; log(`CapCut : le clip ${i + 1} est encore en cours de chargement (${bz.sig}). J'attends qu'il soit fini, sans le renvoyer.`); }
              if (Date.now() - sigAt > (TEST ? 8000 : 8 * 60000)) return 'stuck'; // pourcentage figé depuis 8 minutes
              return null;
            }
            if (Date.now() - ts > 90000 && Date.now() - busyAt > 30000) { const s2 = await call('capcut', 'capcutState', names, cfg); if (!s2.uploading) return 'stuck'; }
            return null;
          }, { timeout: Infinity, every: TEST ? 200 : 700, what: `clip ${i + 1} dans CapCut`, nag: 15 * 60000 });
          // Clip posé : on laisse la bibliothèque finir complètement (plus aucun pourcentage) avant d'y toucher, puis une courte pause
          if (r === 'ok') {
            for (let w = 0; w < (TEST ? 10 : 400); w++) { const bz = await call('capcut', 'capcutBusy').catch(() => null); if (!working(bz)) break; await sleep(TEST ? 100 : 750); }
            await sleep(TEST ? 60 : 1500);
          }
          await call('capcut', 'dropFiles', one);
          if (r === 'ok') {
            ok = true;
            // À partir du 2e clip, CapCut pose le fichier téléversé sur une nouvelle piste (en escalier). On le remet sur la piste principale,
            // à la suite : annuler la pose (le clip reste dans la bibliothèque), curseur à la fin, clic sur sa vignette.
            if (i > 0 && !/^0?0:00:00$/.test(before) && auto.capcutOneTrack !== false && !oneTrackOff && !skipOne) {
              const total = async () => ((await call('capcut', 'capcutTimes').catch(() => null)) || {}).total || '';
              const waitTotal = async (test, ms) => { for (let w = 0; w < ms / 200; w++) { if (test(await total())) return true; await sleep(200); } return false; };
              const B = secsOf(before), d = Math.max(0.5, secsOf(await total()) - B); // durée du clip, telle que CapCut la compte
              // Annule la dernière pose. Si un Ctrl+Z de trop a aussi retiré le clip d'avant (durée plus courte qu'avant), on le rétablit aussitôt.
              const undoTo = async () => {
                await call('capcut', 'capcutUndo');
                if (await waitTotal((t) => t === before, TEST ? 1200 : 5000)) return true;
                if (secsOf(await total()) < B - 0.2) { await call('capcut', 'capcutRedo').catch(() => null); return waitTotal((t) => t === before, TEST ? 600 : 4000); }
                return false;
              };
              let back = false, undone = await undoTo();
              if (!undone) { await sleep(TEST ? 100 : 800); undone = await undoTo(); } // Ctrl+Z pas pris : une deuxième fois
              if (undone) {
                undoFails = 0;
                for (let k = 0; k < 4 && !back; k++) {
                  // Jamais de pose tant que le curseur n'est pas à la fin : sinon le clip part sur une autre piste, au milieu du montage.
                  const sk = await call('capcut', 'capcutSeekEnd').catch(() => null);
                  if (!(sk && sk.ok)) { await sleep(TEST ? 150 : 900); continue; }
                  const add = await call('capcut', 'capcutAddNewest').catch(() => null);
                  if (add && add.ok) {
                    back = await waitTotal((t) => secsOf(t) >= B + d - 0.35, TEST ? 1500 : 8000);
                    // vignette cliquée mais durée attendue pas atteinte : si la durée a quand même bougé, le clip est posé ailleurs → on retire cette pose avant de recommencer
                    if (!back && (await total()) !== before) await undoTo();
                  } else await sleep(TEST ? 150 : 1200);
                }
                if (!back) { // on repose ce clip par téléversement (piste à part, à la suite) ; les clips suivants reviendront sur la piste principale
                  ok = false; why = 'clip non reposé sur la piste principale'; skipOne = true; offTrack++;
                  tryN = Math.min(tryN, 3); // il reste au moins un essai pour le poser par téléversement
                  log(`CapCut (détail) : clip ${i + 1}, durée avant « ${before} », après annulation « ${await total()} », vignette ${JSON.stringify(await call('capcut', 'capcutNewest').catch(() => null)).slice(0, 160)}.`);
                  log(`CapCut : je n'arrive pas à poser le clip ${i + 1} sur la piste principale. Je le pose à la suite sur une piste à part (les suivants reviennent sur la piste principale).`, 'warn');
                  continue;
                }
              } else { // l'annulation ne répond pas : le clip reste où CapCut l'a posé (à la suite, sur une piste à part)
                offTrack++; undoFails++;
                if (undoFails >= 2) { oneTrackOff = true; if (!TEST) log('CapCut : l\'annulation (Ctrl+Z) ne répond pas, les clips restent posés là où CapCut les met (en escalier).', 'warn'); }
              }
            } else if (i > 0 && !/^0?0:00:00$/.test(before) && auto.capcutOneTrack !== false) offTrack++;
            break;
          }
          why = r === 'transcode' ? 'transcodage impossible' : 'clip non posé sur la timeline';
          log(`CapCut : ${why} pour le clip ${i + 1} (essai ${tryN}/4), je remets le même fichier au même endroit.`, 'warn');
          await sleep(1500);
        }
        if (!ok) { await snapPage('capcut', `clip ${i + 1} : ${why}`); throw new Error(`clip ${i + 1} refusé 4 fois par CapCut (${why}) ; les clips 1 à ${i} sont posés, ajoute les suivants à la main`); }
        placed++; log(`CapCut : clip ${i + 1}/${files.length} posé à la suite.`);
        await sleep(TEST ? 50 : 1200); // un clip à la fois, sans presser CapCut
      }
      res.imported = res.placed = placed;
      res.sequential = true;
      res.oneTrack = auto.capcutOneTrack !== false && !oneTrackOff && offTrack === 0; res.offTrack = offTrack;
      // Les clips se suivent dans le temps mais CapCut les range sur des pistes différentes : un fondu ne s'applique qu'entre deux clips
      // de la MÊME piste. On tente quand même ; sinon la note dit quoi faire (3 clics).
      if (auto.capcutTransitions && files.length > 1) {
        await chrome.tabs.update(tabs.capcut, { active: true }).catch(() => null); await sleep(TEST ? 100 : 800);
        await call('capcut', 'dismiss', cfg).catch(() => null); // une fenêtre de CapCut par-dessus l'éditeur bloquerait les clics du fondu
        const tr = await call('capcut', 'capcutTransitions', cfg, k.scenes.map((sc) => Number((sc.vidInfo && sc.vidInfo.dur) || sc.duree) || 0)).catch((e) => ({ ok: false, error: e.message, done: [] }));
        res.transitions = !!(tr && tr.ok);
        if (tr && tr.ok) log(`Fondu au noir posé entre toutes les scènes (${(tr.done || []).join(', ')}).`);
        if (!(tr && tr.ok)) { log(`Transitions : ${(tr && tr.error) || 'échec'}${tr && tr.done && tr.done.length ? ` (fait : ${tr.done.join(', ')})` : ''}.`, 'warn'); await snapPage('capcut', `transitions : ${(tr && tr.error) || 'échec'}${tr && tr.done && tr.done.length ? ` (fait : ${tr.done.join(', ')})` : ''}`); }
      }
      { const s1 = await call('capcut', 'capcutState', names, cfg).catch(() => null); if (s1 && s1.uploading) log('CapCut finit de téléverser les clips (1 min 30 au plus), puis je passe à la suite.'); }
      // Après les fondus : téléversements terminés (nécessaire pour l'export, 1 min 30 au plus), et surveillance d'un transcodage raté tardif.
      await until(async () => { const s2 = await call('capcut', 'capcutState', names, cfg); if ((await issue(failBase)).transcode) throw new Error('late'); return !s2.uploading; }, { timeout: TEST ? 20000 : 90000, every: 1500, what: 'fin des téléversements CapCut' })
        .catch(async (e) => { if (e instanceof Stop) throw e; if (e.message === 'late') { log('CapCut affiche « transcodage impossible » après la pose des clips : vérifie la timeline, et utilise « Refaire le montage » à l\'étape Validation si un clip manque.', 'warn'); await snapPage('capcut', 'transcodage tardif'); } });
      res.note = `${placed} clips posés à la suite, dans l'ordre, sur la timeline CapCut.` + (res.transitions ? ' Fondu au noir ajouté.' : auto.capcutTransitions ? ' Fondu au noir à ajouter : mets les clips sur la même piste, onglet Transitions → Black Fade → « Appliquer à tout ».' : '');
    } else {
    const ids = await sendFiles('capcut', files);
    const a = await call('capcut', 'attach', ids, cfg);
    if (!a || !a.ok) throw new Error('CapCut a refusé les fichiers');
    st = await until(async () => { const s = await call('capcut', 'capcutState', names, cfg); return s.present.every(Boolean) && !s.uploading ? s : null; }, { timeout: Infinity, every: 4000, what: 'import des clips dans CapCut', nag: 15 * 60000 });
    res.imported = names.length;
    await call('capcut', 'dropFiles', ids);
    if (auto.capcutPlace) {
      for (const n of names) {
        const b = await call('capcut', 'capcutState', names, cfg);
        const r = await call('capcut', 'capcutAdd', n, cfg);
        await jitter(1500, 2500);
        const af = await call('capcut', 'capcutState', names, cfg);
        if (r && r.ok && (b.segments === null || af.segments > b.segments)) res.placed++; else break;
      }
      if (res.placed === names.length && auto.capcutTransitions && names.length > 1) {
        await jitter(1500, 2500);
        const tr = await call('capcut', 'capcutTransitions', cfg, k.scenes.map((sc) => Number((sc.vidInfo && sc.vidInfo.dur) || sc.duree) || 0)).catch((e) => ({ ok: false, error: e.message, done: [] }));
        res.transitions = !!(tr && tr.ok);
        log(tr && tr.ok ? 'Fondu au noir ajouté entre les clips.' : `Transitions : ${(tr && tr.error) || 'échec'}${tr && tr.done && tr.done.length ? ` (fait : ${tr.done.join(', ')})` : ''}. Ajoute-les à la main dans CapCut.`, tr && tr.ok ? 'info' : 'warn');
        if (!(tr && tr.ok)) await snapPage('capcut', 'transitions');
      }
      res.note = res.placed === names.length ? `Clips posés dans l'ordre sur la timeline${res.transitions ? ', avec un fondu au noir entre chaque' : ''}.` : `Clips importés et numérotés ; ${res.placed}/${names.length} posés automatiquement : sélectionne-les dans l'ordre et ajoute-les à la timeline.`;
    } else res.note = 'Clips importés et numérotés dans les médias du projet.';
    }
    res.done = true;
  } catch (e) {
    if (e instanceof Stop) throw e;
    if (e instanceof Blocked) { await pause(e.message); return stepCapcut(); }
    res.note = `CapCut : ${e.message}. Les clips sont dans Téléchargements/FruitRadar/Productions/${prod.folder}/clips, numérotés dans l'ordre.`;
    res.done = true; res.failed = true;
    chime('error');
    if (auto.notifyErrors) notify('FruitRadar — CapCut à finir à la main', res.note, 'info');
  }
  prod.capcut = res; prod.montageOk = false; // nouveau montage : à revoir avant l'export
  log(res.note, res.failed || res.placed < names.length && auto.capcutPlace ? 'warn' : 'info');
  await save(true);
}


/* 6 — Export CapCut → validation par toi → TikTok Studio (jamais de publication sans ton accord) */
let lateGuard = null; // garde contre un deuxième téléchargement de la vidéo exportée, encore actif quelques minutes après l'export
async function stepExport() {
  if (prod.finalKey || !auto.capcutExport) return;
  let item = null, guard = null;
  if (lateGuard) { chrome.downloads.onCreated.removeListener(lateGuard); lateGuard = null; } // le garde de l'export précédent n'a plus lieu d'être
  // le premier téléchargement est celui qu'on garde ; un deuxième de la même vidéo (export relancé, téléchargement automatique en double) est arrêté dès qu'il démarre
  const onC = (d) => { if (d.byExtensionId === chrome.runtime.id) return; if (!item) item = d; if (guard) guard.on(d); }; // le garde ne retient que ce qui vient de CapCut : un autre téléchargement fait au même moment ne compte pas
  chrome.downloads.onCreated.addListener(onC);
  try {
    if (!(await tabAlive('capcut'))) throw new Error('l\'onglet CapCut est fermé');
    { let host = ''; try { host = new URL((await chrome.tabs.get(tabs.capcut)).url).host; } catch (e) { /* adresse illisible */ }
      guard = dupGuard(host, () => log('CapCut a lancé un deuxième téléchargement de la même vidéo : je l\'ai arrêté, un seul fichier reste dans tes Téléchargements.')); if (item) guard.on(item); }
    await chrome.tabs.update(tabs.capcut, { active: true }); await sleep(1500);
    await call('capcut', 'dismiss', cfgOf('capcut')).catch(() => null); // « Installer une application », « Mettre à jour le projet ? » : elles couvrent le bouton Exporter
    prod.exportFile = null; prod.exportPath = null; // nouvel export : on ne relira jamais le fichier d'un export précédent
    const o = await call('capcut', 'capcutExport', 'open');
    if (!o || !o.ok) throw new Error((o && o.error) || 'bouton Exporter introuvable');
    log('Export CapCut lancé (Exporter → Télécharger → Exporter), j\'attends la vidéo…');
    const t0 = Date.now(); let href = '', lastPct = -1, lastMove = Date.now(), relaunch = 0, lastStep = '';
    const stallMs = (TEST ? 0.2 : Math.max(2, Number(auto.exportStallMin) || 8)) * 60000;
    while (!href && !item) {
      if (stopFlag) throw new Stop('arrêt demandé');
      if (prod.finalKey) { log('Vidéo finale déposée par toi pendant l\'export : je n\'attends plus CapCut.'); return; }
      if (Date.now() - t0 > 60 * 60000) throw new Error('aucune vidéo après 1 h');
      await sleep(TEST ? 400 : 2000);
      const r = await call('capcut', 'capcutExport', 'confirm').catch((e) => ({ ok: true, waiting: true, err: e.message }));
      if (r && r.ok === false) throw new Error(r.error || 'export refusé par CapCut');
      if (r && r.done && r.href) { href = r.href; break; }
      const mark = r && r.busy ? `p${r.pct}` : `s${(r && r.step) || ''}`;
      if (mark !== lastStep) { lastStep = mark; lastMove = Date.now(); }
      if (r && r.busy && r.pct !== null && Math.floor(r.pct / 25) !== Math.floor(lastPct / 25)) log(`Export CapCut : ${Math.round(r.pct)} %…`);
      if (r && r.busy && r.pct !== null) lastPct = r.pct;
      // CapCut reste parfois bloqué sur un pourcentage : au bout de 8 minutes sans bouger (réglage exportStallMin), on prévient et on relance l'export
      if (Date.now() - lastMove > stallMs) {
        const where = lastPct >= 0 ? `à ${lastPct} %` : 'avant de démarrer';
        if (relaunch >= 2) throw new Error(`l'export reste bloqué ${where} malgré 2 relances`);
        relaunch++;
        log(`Export CapCut bloqué ${where} depuis ${Math.round(stallMs / 60000)} min : je l'annule et je le relance (${relaunch}/2).`, 'warn');
        await notify('FruitRadar — export CapCut bloqué', `L'export est resté ${where} pendant ${Math.round(stallMs / 60000)} min. Je le relance (${relaunch}/2). Si ça recommence, relance-le à la main dans CapCut.`);
        await call('capcut', 'capcutExport', 'cancel').catch(() => null);
        await sleep(TEST ? 300 : 3000);
        const again = await call('capcut', 'capcutExport', 'open').catch(() => null);
        if (!again || !again.ok) throw new Error('impossible de relancer l\'export (bouton Exporter introuvable)');
        lastPct = -1; lastStep = ''; lastMove = Date.now();
      }
    }
    if (href) log('Export terminé dans CapCut. Je récupère maintenant le fichier vidéo (le téléchargement peut prendre une ou deux minutes)…');
    /* Le fichier : par le lien de la page s'il y en a un, sinon par l'adresse du téléchargement que CapCut vient de lancer.
       Ce téléchargement n'est plus annulé : la vidéo arrive dans tes Téléchargements quoi qu'il arrive, et si FruitRadar
       n'arrive pas à la lire lui-même, tu n'as plus qu'à déposer ce fichier. */
    let blob = null; const tries = [];
    const kind = (u) => (/^blob:/.test(u) ? 'adresse blob' : (() => { try { return new URL(u).host; } catch (e) { return 'adresse'; } })());
    const tryPull = async (u, label) => { if (blob || !/^(https?|blob):/.test(u || '')) return; try { blob = await pull('capcut', u, 'video/mp4'); } catch (e) { tries.push(`${label} (${kind(u)}) : ${e.message}`); } };
    const dlSince = Date.now() - 10 * 60000;
    await tryPull(href, 'lien de la page');
    for (let w = 0; !blob && !item && w < (TEST ? 5 : 40); w++) await sleep(1000); // le téléchargement de CapCut démarre quelques secondes après le clic
    if (!item) { // téléchargement lancé sans qu'on l'ait vu passer : on le retrouve dans la liste de Chrome
      const recent = await chrome.downloads.search({ orderBy: ['-startTime'], limit: 6 }).catch(() => []);
      item = recent.find((d) => d.byExtensionId !== chrome.runtime.id && /\.(mp4|mov|webm)$/i.test(d.filename || '') && new Date(d.startTime).getTime() > dlSince && d.state !== 'interrupted') || null;
    }
    if (item) await tryPull(item.finalUrl || item.url, 'adresse du téléchargement');
    if (item) { // on suit le téléchargement de CapCut jusqu'au bout (8 min au plus) : le fichier est alors dans tes Téléchargements
      // jusqu'au bout du téléchargement : 30 min au plus, ou 10 min sans qu'il avance (avant : 8 min, puis abandon même s'il allait finir)
      let lastBytes = -1, still = Date.now();
      for (let w = 0; w < (TEST ? 5 : 1800); w++) {
        const [d] = await chrome.downloads.search({ id: item.id }).catch(() => []);
        if (d) item = d;
        if (!d || d.state !== 'in_progress') break;
        if (blob && w > 3) break; // on a déjà le fichier : inutile d'attendre la fin de la copie sur le disque
        if (prod.finalKey) return; // déposée par toi entre-temps
        if (d.bytesReceived !== lastBytes) { lastBytes = d.bytesReceived; still = Date.now(); } else if (Date.now() - still > 10 * 60000) break;
        if (w && w % 60 === 0) log(`Téléchargement de la vidéo exportée : ${d.totalBytes > 0 ? `${Math.round((d.bytesReceived / d.totalBytes) * 100)} %` : `${Math.round(d.bytesReceived / 1048576)} Mo`}…`);
        await sleep(1000);
      }
      if (item.state === 'complete' || item.state === 'in_progress') { prod.finalSaved = true; prod.exportFile = String(item.filename || '').split(/[\\/]/).pop() || ''; } // déjà dans tes Téléchargements : pas de deuxième copie
      if (item.state === 'complete' && item.filename) prod.exportPath = String(item.filename); // pour la relire plus tard si la première lecture échoue
      // Le plus sûr : lire le fichier téléchargé lui-même (si Chrome autorise FruitRadar à lire les fichiers), en plusieurs essais espacés.
      if (!blob && item.state === 'complete' && item.filename) {
        const r = await readExport(item.filename, TEST ? 2 : 6);
        if (r.blob) blob = r.blob; else tries.push(`fichier téléchargé : ${r.error}`);
      } else if (!blob && item.state === 'in_progress') tries.push('fichier téléchargé : téléchargement toujours en cours');
      else if (!blob && item.state === 'interrupted') tries.push(`fichier téléchargé : téléchargement interrompu${item.error ? ` (${item.error})` : ''}`);
    } else if (!blob) tries.push('aucun téléchargement vu dans Chrome');
    if (blob && tries.length) log(`Export : fichier récupéré (essais sans résultat avant : ${tries.join(' ; ')}).`);
    if (!blob && prod.finalKey) return; // déposée par toi pendant les essais
    if (!blob) throw new Error(prod.exportFile ? `la vidéo est bien exportée, dans tes Téléchargements (« ${prod.exportFile} »), mais je n'ai pas pu la lire moi-même — ${tries.join(' ; ')}` : `vidéo exportée introuvable — ${tries.join(' ; ') || 'aucune adresse'}`);
    // Le serveur de CapCut annonce « application/octet-stream » : TikTok Studio n'accepte qu'un fichier vidéo, on remet le bon type.
    if (!/^video\//.test(blob.type || '')) blob = new Blob([blob], { type: 'video/mp4' });
    const info = await probeVideo(blob).catch(() => null);
    const head = [...new Uint8Array(await blob.slice(0, 12).arrayBuffer())].map((x) => (x >= 32 && x < 127 ? String.fromCharCode(x) : '.')).join('');
    const mo = `${(blob.size / 1048576).toFixed(1).replace('.', ',')} Mo`;
    // Un vrai MP4 (« ftyp » en tête) de bonne taille est gardé même si sa durée n'a pas pu être lue : tu le vois de toute façon à l'étape Validation.
    if ((!info || !info.dur) && !(/ftyp/.test(head) && blob.size > 300000)) throw new Error(`le fichier récupéré n'est pas une vidéo lisible (${mo}, début « ${head} »)`);
    prod.finalKey = await keep('final.mp4', blob); prod.finalInfo = info && info.dur ? { w: info.w, h: info.h, dur: Math.round(info.dur * 10) / 10, size: blob.size } : null;
    await toDisk(blob, 'video-finale.mp4');
    log(info && info.dur ? `Vidéo finale récupérée : ${info.w}×${info.h}, ${info.dur.toFixed(1)} s, ${mo}.` : `Vidéo finale récupérée (${mo}) ; durée non lue, regarde-la à l'étape Validation.`, info && info.dur ? 'info' : 'warn');
  } catch (e) {
    if (e instanceof Stop) throw e;
    log(prod.exportFile ? `Export : ${e.message}. Dépose ce fichier dans FruitRadar, page Automatisation, pour continuer.${prod.fileAccess === false ? ' Pour que FruitRadar le lise tout seul la prochaine fois : chrome://extensions → FruitRadar → Détails → active « Autoriser l\'accès aux URL de fichier ».' : ''}` : `Export automatique impossible (${e.message}). Exporte la vidéo depuis CapCut (Exporter → Télécharger) puis dépose le fichier dans FruitRadar, à l'étape Validation.`, 'warn');
    await snapPage('capcut', 'export', e.message); // la raison exacte part dans « Copier le diagnostic »
  } finally {
    chrome.downloads.onCreated.removeListener(onC);
    // un doublon peut encore arriver après coup (le premier export, resté bloqué, finit plus tard) : on le guette encore 5 minutes
    if (guard && prod && prod.finalKey) { const g = guard; if (item) g.on(item); lateGuard = (d) => { g.on(d); }; chrome.downloads.onCreated.addListener(lateGuard); const mine = lateGuard; setTimeout(() => { chrome.downloads.onCreated.removeListener(mine); if (lateGuard === mine) lateGuard = null; }, 5 * 60000); }
  }
  await save(true);
}
/* Étape « À valider » : tu regardes la vidéo entière dans FruitRadar. Rien ne part vers TikTok avant ton clic. Retourne 'redo' si tu demandes de refaire le montage. */
/* 5 bis — Contrôle du montage dans CapCut AVANT l'export (option « capcutCheck ») : on ne lance pas 3 à 4 minutes d'export sur un montage faux. */
async function stepMontage() {
  const mode = auto.capcutCheck === false || auto.capcutCheck === 'never' ? 'never' : auto.capcutCheck === true || auto.capcutCheck === 'always' ? 'always' : 'auto';
  if (prod.montageOk || prod.finalKey || !prod.capcut) return 'ok';
  const c = prod.capcut, n = prod.pkg.scenes.length, todo = [];
  // Montage interrompu ou incomplet : on n'exporte JAMAIS tout seul une vidéo à laquelle il manque des scènes, même si la vérification est coupée.
  const incomplete = !!c.failed || (auto.capcutPlace !== false && (c.placed || 0) < n);
  if (mode === 'never' && !incomplete) return 'ok';
  if (c.failed) todo.push('montage interrompu');
  if ((c.placed || 0) < n) todo.push(`${c.placed || 0} clips posés sur ${n}`);
  if (!c.oneTrack) todo.push('une seule piste à vérifier');
  const wantFade = n > 1 && (c.fadeWanted !== undefined ? !!c.fadeWanted : !!auto.capcutTransitions); // fondus décochés dans les réglages : ce n'est pas un point à vérifier
  if (wantFade && !c.transitions) todo.push('fondus au noir à vérifier');
  // mode « auto » : si les points sont confirmés (clips posés, une seule piste, fondus au noir s'ils sont demandés), on exporte sans t'attendre
  if (mode === 'auto' && !todo.length) { prod.montageOk = true; log(`Montage contrôlé (clips dans l'ordre, une seule piste${wantFade ? ', fondus au noir' : ''}) : export sans attendre.`); await save(true); return 'ok'; }
  prod.gate = 'montage'; prod.status = 'waiting'; prod.pause = null; prod.montageCmd = null;
  log(incomplete ? `Montage incomplet dans CapCut (${todo.join(', ')}) : je n'exporte pas tout seul. Refais le montage, ou complète-le à la main puis lance l'export.` : `Montage prêt dans CapCut${todo.length ? ` (${todo.join(', ')})` : ''} : vérifie-le, puis lance l'export depuis FruitRadar.`, todo.length ? 'warn' : 'info');
  await save(true);
  if (await tabAlive('capcut')) {
    await chrome.tabs.update(tabs.capcut, { active: true }).catch(() => null);
    // la même carte, posée dans la page CapCut : on voit tout de suite que FruitRadar attend, et on répond sur place
    await call('capcut', 'frGate', { id: prod.id, title: incomplete ? 'Montage incomplet : FruitRadar n\'exporte pas tout seul' : 'FruitRadar attend ton feu vert avant d\'exporter',
      text: incomplete ? `Il manque des scènes sur la timeline${c.failed && c.note ? ` (${String(c.note).slice(0, 140)})` : ''}. Refais le montage, ou complète-le ici à la main avant d'exporter.` : 'Regarde le montage ci-dessous, corrige-le ici si besoin, puis lance l\'export.',
      points: [
        { ok: (c.placed || 0) >= n, title: 'Les scènes se suivent dans l\'ordre', note: `${c.placed || 0} clips posés sur ${n}.` },
        { ok: !!c.oneTrack, title: 'Tout est sur une seule piste', note: c.oneTrack ? 'Les clips sont à la suite sur la piste du bas.' : 'Si des clips sont en escalier, glisse-les sur la piste du bas, à la suite.' },
        ...(wantFade ? [{ ok: !!c.transitions, title: 'Un fondu au noir entre chaque scène', note: c.transitions ? `${n - 1} transitions posées.` : 'Survole la jonction de deux clips, clique sur l\'icône de transition (Black Fade), clique sur la transition posée, puis « Appliquer à tout ».' }] : [])],
      buttons: incomplete ? [{ label: 'Refaire le montage', value: 'redo', primary: true }, { label: 'Je l\'ai complété, exporter', value: 'ok', confirm: 'Exporter le montage tel qu\'il est dans CapCut ?' }]
        : [{ label: 'Le montage est bon, exporter', value: 'ok', primary: true }, { label: 'Refaire le montage', value: 'redo', confirm: 'Refaire le montage ? Un nouveau projet CapCut est créé, avec les mêmes clips.' }] }).catch(() => null);
  }
  await notify('FruitRadar — montage à vérifier', `« ${prod.title} » : ${todo.length ? todo.join(', ') + '. ' : ''}Regarde le montage dans CapCut, puis lance l'export depuis FruitRadar.`, null);
  for (;;) {
    await hold();
    if (stopFlag) throw new Stop('arrêt demandé');
    if (prod.montageCmd === 'redo') { prod.montageCmd = null; prod.capcut = null; prod.gate = null; prod.status = 'running'; log('Je refais le montage CapCut.', 'warn'); await save(true); return 'redo'; }
    if (prod.montageCmd === 'ok') break;
    prod.montageCmd = null;
  }
  prod.montageOk = true; prod.gate = null; prod.status = 'running'; prod.montageCmd = null;
  if (await tabAlive('capcut')) await call('capcut', 'frGate', null).catch(() => null);
  log('Montage validé par toi : je lance l\'export.');
  await save(true);
  return 'ok';
}
async function finalToDownloads() { // la vidéo finale dans ton dossier Téléchargements, une seule fois
  if (auto.finalDownload === false || !prod.finalKey || prod.finalSaved) return;
  try {
    const blob = await media(prod.finalKey); if (!blob) return;
    const clean = (t) => String(t || '').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 70);
    const name = `${clean(prod.title) || 'video'}${prod.pkg && prod.pkg.part ? ` - partie ${prod.pkg.part}` : ''}.mp4`;
    const url = URL.createObjectURL(blob);
    await chrome.downloads.download({ url, filename: name, conflictAction: 'uniquify', saveAs: false });
    setTimeout(() => URL.revokeObjectURL(url), 180000);
    prod.finalSaved = true; log(`Vidéo finale enregistrée dans tes Téléchargements : « ${name} ».`); await save(true);
  } catch (e) { log(`Enregistrement dans les Téléchargements impossible (${e.message}).`, 'warn'); }
}
async function stepValidate() {
  if (prod.validated) return 'ok';
  await finalToDownloads();
  // option « valider la vidéo finale » coupée : on continue tout seul (TikTok te demandera toujours ton accord avant de publier)
  if (auto.finalCheck === false && prod.finalKey) { prod.validated = true; log('Vidéo finale prête : validation automatique (réglage), je continue.'); await save(true); return 'ok'; }
  prod.gate = 'validate'; prod.status = 'waiting'; prod.pause = null; prod.validateCmd = null;
  log(prod.finalKey ? 'Vidéo finale prête : regarde-la en entier dans FruitRadar, puis valide.' : 'Je n\'ai pas pu récupérer la vidéo exportée : exporte-la depuis CapCut et dépose le fichier dans FruitRadar.', 'info');
  await save(true);
  const showCard = async (front = true) => {
  if (await tabAlive('capcut')) { // la même demande, posée dans l'onglet CapCut : on répond sur place
    if (front) await chrome.tabs.update(tabs.capcut, { active: true }).catch(() => null);
    await call('capcut', 'frGate', { id: prod.id, title: prod.finalKey ? 'La vidéo est exportée : FruitRadar attend ta validation' : 'FruitRadar n\'a pas pu récupérer la vidéo',
      text: prod.finalKey ? 'Regarde-la (elle est dans tes Téléchargements et dans FruitRadar, page Automatisation), puis valide pour passer à TikTok.' : prod.exportFile ? `Elle est exportée, dans tes Téléchargements : « ${prod.exportFile} ». Dépose ce fichier dans FruitRadar, page Automatisation (« Déposer la vidéo exportée »).` : 'Clique sur « Télécharger » dans CapCut, puis dépose le fichier dans FruitRadar, page Automatisation (« Déposer la vidéo exportée »).',
      points: [],
      buttons: prod.finalKey ? [{ label: 'La vidéo est bonne, continuer', value: 'ok', primary: true }, { label: 'Refaire le montage', value: 'redo', confirm: 'Refaire le montage ? Un nouveau projet CapCut est créé, avec les mêmes clips.' }] : [{ label: 'Refaire le montage', value: 'redo' }] }).catch(() => null);
  }
  };
  await showCard();
  await notify('FruitRadar — vidéo à valider', `« ${prod.title} » : regarde la vidéo dans FruitRadar (page Automatisation), puis valide.`, null);
  // Vidéo exportée pas encore lue (gardée un moment par l'antivirus, par exemple) : je la relis toute seule, toutes les 20 s pendant 10 min.
  // Dès qu'elle est lue, elle s'affiche ici comme d'habitude (et si la validation est coupée dans les réglages, je continue tout seul).
  let poll = null, autoGo = false;
  if (!prod.finalKey && prod.exportPath && prod.fileAccess !== false) {
    const t0 = Date.now(); let reading = false;
    poll = setInterval(async () => {
      if (prod.finalKey || stopFlag || Date.now() - t0 > (TEST ? 20000 : 10 * 60000)) { clearInterval(poll); return; }
      if (reading) return; reading = true;
      try {
        const r = await readExport(prod.exportPath, 1);
        if (!r.blob || prod.finalKey) return;
        const info = await probeVideo(r.blob).catch(() => null);
        const head = [...new Uint8Array(await r.blob.slice(0, 12).arrayBuffer())].map((x) => (x >= 32 && x < 127 ? String.fromCharCode(x) : '.')).join('');
        if (!(info && info.dur) && !(/ftyp/.test(head) && r.blob.size > 300000)) return;
        prod.finalKey = await keep('final.mp4', r.blob);
        prod.finalInfo = info && info.dur ? { w: info.w, h: info.h, dur: Math.round(info.dur * 10) / 10, size: r.blob.size } : null;
        log(`Vidéo exportée enfin lue dans tes Téléchargements${prod.exportFile ? ` (« ${prod.exportFile} »)` : ''}${info && info.dur ? ` : ${info.w}×${info.h}, ${info.dur.toFixed(1).replace('.', ',')} s` : ''}. ${auto.finalCheck === false ? 'Je continue.' : 'Regarde-la, puis valide.'}`);
        if (auto.finalCheck === false) autoGo = true;
        await save(true); await showCard(false).catch(() => null);
        release();
      } catch (e) { /* toujours gardée : nouvel essai dans 20 s */ } finally { reading = false; }
    }, TEST ? 600 : 20000);
  }
  try {
  for (;;) {
    await hold();
    if (stopFlag) throw new Stop('arrêt demandé');
    if (prod.validateCmd === 'redo') { if (await tabAlive('capcut')) await call('capcut', 'frGate', null).catch(() => null); prod.finalSaved = false; prod.exportFile = null; prod.exportPath = null; prod.validateCmd = null; prod.capcut = null; prod.finalKey = null; prod.finalInfo = null; prod.gate = null; prod.status = 'running'; log('Je refais le montage CapCut.', 'warn'); await save(true); return 'redo'; }
    if (typeof prod.validateCmd === 'string' && prod.validateCmd.startsWith('mini')) { // « Refaire la miniature » depuis la carte de validation
      const st = prod.validateCmd.slice(5), k = prod.pkg; prod.validateCmd = null;
      if (k && k.miniature && k.miniature.prompt) {
        if (P.MINI_STYLES[st]) prod.miniStyle = st;
        const oldStatus = k.miniature.status;
        k.miniature.variant = (k.miniature.variant || 0) + 1; k.miniature.status = 'todo';
        prod.gate = null; prod.status = 'running';
        if (await tabAlive('capcut')) await call('capcut', 'frGate', null).catch(() => null);
        await save(true);
        try { await stepImages(); log('Nouvelle miniature prête : regarde-la, puis valide.'); }
        catch (e) { if (e instanceof Stop) throw e; k.miniature.variant -= 1; k.miniature.status = k.miniature.key ? oldStatus : 'todo'; log(`Miniature non refaite (${e.message}) : l'ancienne est gardée.`, 'warn'); }
        prod.gate = 'validate'; prod.status = 'waiting'; prod.pause = null;
        await save(true); await showCard(false);
        // la demande venait de la page FruitRadar : on y revient, la nouvelle miniature y est affichée à côté de la vidéo
        try { const [d] = await chrome.tabs.query({ url: chrome.runtime.getURL('dashboard/dashboard.html') + '*' }); if (d) { await chrome.tabs.update(d.id, { active: true }); await chrome.windows.update(d.windowId, { focused: true }).catch(() => null); } } catch (e) { /* page fermée */ }
      }
      continue;
    }
    if ((prod.validateCmd === 'ok' || prod.validateCmd === 'depot' || autoGo) && prod.finalKey) break;
    prod.validateCmd = null;
  }
  } finally { if (poll) clearInterval(poll); }
  const how = autoGo ? 'auto' : prod.validateCmd;
  prod.validated = true; prod.gate = null; prod.status = 'running'; prod.validateCmd = null;
  if (await tabAlive('capcut')) await call('capcut', 'frGate', null).catch(() => null);
  if (how === 'ok') log('Vidéo validée par toi.'); else if (how === 'auto') log('Validation de la vidéo finale coupée dans les réglages : je continue vers TikTok Studio.'); // déposée par toi : déjà dit
  await save(true);
  return 'ok';
}
const tkText = async (cfg) => (await call('tiktok', 'tiktokState', cfg)) || {};
async function stepTiktok() {
  if (prod.published || prod.publishSkipped) return;
  const want = String(auto.tiktokAccount || '').replace(/^@/, '').trim().toLowerCase();
  const blob = await media(prod.finalKey);
  if (!blob) throw new Error('vidéo finale absente');
  let cfg, notes = [], rc = {}; // rc : bilan de la préparation (description, couverture, légendes, son)
  prep: {
  // Tout était déjà prêt dans TikTok Studio (la vidéo n'attendait que ton accord) et la fenêtre pilote a été rechargée : si l'onglet TikTok
  // est toujours là avec son bouton Publier, on le reprend tel quel au lieu de tout refaire (et de fermer cet onglet).
  if (!(await tabAlive('tiktok')) && prod.tiktokTab != null) { // fenêtre pilote rechargée : on retrouve l'onglet TikTok Studio de cette production
    try { const t = await chrome.tabs.get(prod.tiktokTab); if (t && (TEST || /tiktok\.com\/tiktokstudio/.test(t.url || ''))) tabs.tiktok = t.id; } catch (e) { /* onglet fermé */ }
  }
  if (prod.tiktokReady) {
    if (await tabAlive('tiktok')) {
      cfg = cfgOf('tiktok');
      const st = await tkText(cfg).catch(() => null);
      if (st && st.publish) { notes = prod.tiktokNotes || []; rc = prod.tiktokRecap || {}; log('TikTok Studio : l\'onglet déjà prêt est toujours là, je le reprends tel quel.'); break prep; }
    }
    prod.tiktokReady = null;
  }
  // 0. Le son de la vidéo virale n'est pas dans la recherche de TikTok Studio. Méthode donnée par l'auteur (16 novembre 2026) : ouvrir la vidéo
  //    d'origine sur TikTok ; son son se range alors dans l'onglet « Récent » des Sons, où on le prend plus bas.
  const srcUrl = auto.tiktokSound !== 'manual' && prod.source && /^https:\/\/(www\.)?tiktok\.com\//.test(prod.source.url || '') ? prod.source.url : '';
  if (srcUrl && !TEST) {
    try {
      log('J\'ouvre la vidéo d\'origine quelques secondes : son son se range dans l\'onglet « Récent » de TikTok Studio.');
      const t = { id: await quietTab(srcUrl, true) };
      await sleep(9000);
      await chrome.tabs.remove(t.id).catch(() => null);
      prod.srcOpened = Date.now();
    } catch (e) { if (e instanceof Stop) throw e; log(`Vidéo d'origine non ouverte (${e.message}) : je prendrai un son de tes Favoris.`, 'warn'); }
  }
  // 1. ouverture, envoi de la vidéo, contrôle du compte : si c'est le mauvais compte, pause ; après « Reprendre », on recommence l'envoi
  for (;;) {
    cfg = await openSite('tiktok', { needComposer: false, newTab: true });
    await until(async () => { const s = await tkText(cfg); if (s.block) throw new Blocked(s.block, `TikTok : ${s.block}`); return s.input ? s : null; }, { timeout: Infinity, every: 2500, what: 'page d\'envoi de TikTok Studio', nag: 10 * 60000 });
    // le bon compte AVANT d'envoyer quoi que ce soit : TikTok Studio n'affiche pas le pseudo, on le demande à TikTok
    const me = want ? await call('tiktok', 'tiktokAccount').catch(() => null) : null;
    const meName = me && me.ok ? String(me.username).replace(/^@/, '').toLowerCase() : '';
    if (want && meName && meName !== want) {
      await pause(`TikTok est connecté sur @${meName}, pas sur @${want}. Change de compte dans TikTok (avatar en haut à droite), puis clique sur Reprendre. Rien n'a été envoyé ni publié`);
      continue;
    }
    log('Envoi de la vidéo finale dans TikTok Studio…');
    const ids = await sendFiles('tiktok', [{ blob, name: 'fruitradar-video.mp4' }]);
    const a = await call('tiktok', 'attach', ids, cfg);
    if (!a || !a.ok) throw new Error('TikTok Studio a refusé le fichier');
    await call('tiktok', 'dropFiles', ids);
    const st = await until(async () => { const s = await tkText(cfg); if (s.block) throw new Blocked(s.block, `TikTok : ${s.block}`); return s.desc && s.preview && !s.uploading ? s : null; }, { timeout: Infinity, every: 3000, what: 'téléversement de la vidéo dans TikTok', nag: 15 * 60000 });
    await sleep(1200);
    const now = await tkText(cfg);
    if (want && !meName && !String(now.text || st.text || '').toLowerCase().includes(want)) {
      await snapPage('tiktok', `compte : @${want} non visible`);
      await pause(`TikTok Studio n'affiche pas le compte @${want} (vérifie le compte connecté, via ton avatar en haut à droite). Passe sur @${want}, puis clique sur Reprendre : j'enverrai la vidéo de nouveau. Rien n'est publié`);
      continue;
    }
    log(want ? `Compte TikTok vérifié : @${want}.` : 'Vidéo envoyée dans TikTok Studio (aucun compte à vérifier dans les réglages).');
    break;
  }
  // 2. description (la mention de la chaîne et les hashtags viennent du package)
  if (prod.pkg && prod.pkg.description) {
    const fullDesc = P.finalDesc(prod.pkg.description, auto, IS_ADMIN);
    // les hashtags de fin s'écrivent un par un (collés d'un bloc, ils restent du texte non cliquable)
    const dm = fullDesc.match(/^([\s\S]*?)((?:\s*#[\p{L}\p{N}_]+)+)$/u);
    const tags = dm ? dm[2].match(/#[\p{L}\p{N}_]+/gu) : [];
    const r = await call('tiktok', 'setText', tags.length ? dm[1].trim() + ' ' : fullDesc, cfg).catch(() => null);
    rc.desc = r && r.ok ? { ok: true } : { ok: false, why: 'collage impossible' };
    if (r && r.ok && tags.length) {
      await sleep(600);
      const h = await call('tiktok', 'tiktokHashtags', tags, cfg).catch((e) => ({ ok: false, plain: tags, error: e.message }));
      if (h && h.ok) log(`Description collée, ${tags.length} hashtags cliquables.`);
      else { notes.push(`hashtags à revalider (${((h && h.plain) || tags).join(' ')})`); log(`Description collée, mais ${((h && h.plain) || tags).length} hashtag(s) sont restés en texte simple : ${((h && h.plain) || tags).join(' ')}. Dans TikTok, clique à la fin du hashtag et choisis-le dans la liste.`, 'warn'); }
    } else if (r && r.ok) log('Description collée.'); else { notes.push('description à coller à la main'); log('Description : je n\'ai pas réussi à la coller, elle est dans le package.', 'warn'); await snapPage('tiktok', 'description'); }
  } else { rc.desc = { ok: false, why: 'pas de description dans le package' }; notes.push('description à écrire à la main (le package n\'en a pas)'); log('Description : le package n\'en contient pas, je n\'ai rien collé.', 'warn'); }
  // 3. miniature (couverture) : « Modifier la couverture » → import de l'image → on la fait glisser pour voir le titre → « Enregistrer »
  let cover = prod.pkg && prod.pkg.miniature && prod.pkg.miniature.key ? await media(prod.pkg.miniature.key) : null;
  if (cover) {
    try {
      if (!/^image\/(png|jpe?g)$/.test(cover.type || '')) { // TikTok n'accepte que PNG et JPEG
        const bm = await createImageBitmap(cover), c = new OffscreenCanvas(bm.width, bm.height); c.getContext('2d').drawImage(bm, 0, 0); try { bm.close(); } catch (e) {}
        cover = await c.convertToBlob({ type: 'image/png' });
      }
      const o = await call('tiktok', 'tiktokCoverOpen');
      if (!o || !o.ok) throw new Error((o && o.error) || 'fenêtre de la couverture introuvable');
      const ids = await sendFiles('tiktok', [{ blob: cover, name: cover.type === 'image/png' ? 'miniature.png' : 'miniature.jpg' }]);
      const a = await call('tiktok', 'attach', ids, { ...cfg, changeOnly: false, fileInput: ['[class*="Dialog__content"] input[type="file"][accept*="image"]', 'input[type="file"][accept*="image"]'] });
      await call('tiktok', 'dropFiles', ids);
      if (!a || !a.ok || a.how !== 'sélecteur de fichiers') throw new Error('champ d\'import de la couverture introuvable');
      // l'aperçu du profil ne montre que le milieu de l'image : on la fait glisser pour garder le titre (en haut de la miniature) visible
      const al = await call('tiktok', 'tiktokCoverAlign', auto.tiktokCoverAlign || 'haut').catch(() => null);
      if (!(al && al.ok)) { notes.push('couverture à recadrer (fais glisser l\'image pour voir le titre)'); log(`Couverture : cadrage non confirmé (${(al && al.error) || 'échec'}). Dans « Modifier la couverture », fais glisser l'image pour que le titre soit visible.`, 'warn'); }
      const ok = await call('tiktok', 'tiktokCoverSave');
      if (!ok || !ok.ok) throw new Error((ok && ok.error) || 'bouton d\'enregistrement de la couverture introuvable');
      log('Miniature mise en couverture.'); rc.cover = { ok: true };
    } catch (e) { if (e instanceof Stop) throw e; rc.cover = { ok: false, why: e.message }; notes.push('couverture à choisir à la main'); log(`Couverture : ${e.message}. La miniature est dans FruitRadar, à choisir à la main dans TikTok Studio.`, 'warn'); await snapPage('tiktok', 'couverture'); }
  } else { // avant : rien n'était dit quand la production n'avait pas de miniature
    rc.cover = { ok: false, why: 'cette production n\'a pas de miniature' }; notes.push('couverture à choisir à la main (pas de miniature dans cette production)');
    log('Couverture NON mise : cette production n\'a pas de miniature (elle n\'a pas été générée, ou son image manque). Choisis la couverture à la main dans TikTok Studio.', 'warn');
  }
  // 4. éditeur TikTok : légendes (si parole), modèle Life in Motion remonté, son
  const wantSound = auto.tiktokSound !== 'manual';
  const capY = !auto.tiktokCaptionY || auto.tiktokCaptionY === 0.62 ? 0.68 : auto.tiktokCaptionY; // 0.62 = ancien réglage par défaut, trop haut (au niveau des yeux)
  if (!auto.tiktokCaptions) rc.caps = { skip: true, why: 'option décochée dans les réglages' };
  if (!wantSound) rc.sound = { skip: true, why: 'réglage « Je le choisis moi-même en publiant »' };
  if (auto.tiktokCaptions || wantSound) {
    try {
      const e = await call('tiktok', 'tiktokClick', '^(monter|edit)$');
      if (!e || !e.ok) throw new Error('bouton « Monter » introuvable');
      await until(async () => { const s = await tkText(cfg); return s.save ? s : null; }, { timeout: 120000, every: 500, what: 'éditeur TikTok' });
      await sleep(1200);
      for (let i = 0; i < 3; i++) { const ok = await call('tiktok', 'tiktokClick', '^(j\'ai compris|got it|ok)$'); if (!(ok && ok.ok)) break; await sleep(800); }
      const ph = await call('tiktok', 'tiktokPhoneMode').catch(() => null);
      if (ph && ph.ok) log('Aperçu TikTok en mode téléphone.'); else { notes.push('aperçu à passer en « Mode téléphone »'); log(`Mode téléphone : ${(ph && ph.error) || 'échec'}.`, 'warn'); }
      if (auto.tiktokCaptions) {
        // « Légendes » est dans la barre de gauche de l'éditeur ; « Générer » demande 10 à 20 s
        const rail = await call('tiktok', 'tiktokRail', 'captions').catch((e) => ({ ok: false, error: e.message }));
        if (!(rail && rail.ok)) { rc.caps = { ok: false, why: (rail && rail.error) || 'panneau introuvable' }; notes.push('légendes à générer à la main'); log(`Légendes : ${(rail && rail.error) || 'panneau introuvable'}.`, 'warn'); await snapPage('tiktok', 'panneau des légendes'); }
        else {
          const gen = await call('tiktok', 'tiktokCaptions').catch((e) => ({ ok: false, error: e.message }));
          if (gen && gen.none) { rc.caps = { ok: false, why: 'TikTok n\'a trouvé aucune parole' }; notes.push('pas de légendes (aucune parole détectée)'); log(`Légendes : TikTok n'a trouvé aucune parole${gen.tries === 2 ? ' (2 tentatives)' : ''}, je passe.`, 'warn'); }
          else if (!(gen && gen.ok)) { rc.caps = { ok: false, why: (gen && gen.error) || 'génération non lancée' }; notes.push('légendes à générer à la main'); log(`Légendes : ${(gen && gen.error) || 'génération non lancée'}.`, 'warn'); await snapPage('tiktok', 'génération des légendes'); }
          if (gen && gen.ok) {
            log(gen.tries === 2 ? 'Légendes générées à la 2e tentative (la 1re n\'avait rien donné).' : 'Légendes générées.'); rc.caps = { ok: true };
            const pr = await call('tiktok', 'tiktokPreset', 1).catch((e) => ({ ok: false, error: e.message }));
            if (pr && pr.ok && pr.applied !== false) log(`Légendes : modèle « Life in Motion » choisi (${(pr.notes || []).join(', ')}).`);
            else if (pr && pr.ok) { notes.push('modèle de légende à vérifier (le 1er, « Life in Motion »)'); log(`Légendes : modèle cliqué mais non confirmé (${(pr.notes || []).join(', ')}). Vérifie dans l'onglet TikTok ; sinon clique le 1er modèle.`, 'warn'); }
            else { notes.push('modèle de légende à choisir'); log(`Légendes : ${(pr && pr.error) || 'modèle non choisi'}.`, 'warn'); await snapPage('tiktok', 'modèle de légende'); }
            let up = await call('tiktok', 'tiktokRaiseCaption', capY).catch((e) => ({ ok: false, error: e.message }));
            if (!(up && up.ok) && !(await call('tiktok', 'visible').catch(() => true))) { // page TikTok cachée : le glissé n'y est pas toujours pris. On l'affiche le temps du geste, puis tu retrouves ta fenêtre.
              log('Légendes : la page TikTok était cachée, je l\'affiche quelques secondes pour remonter la légende.');
              up = await showBriefly('tiktok', () => call('tiktok', 'tiktokRaiseCaption', capY)).catch((e) => ({ ok: false, error: e.message }));
            }
            if (up && up.ok) log(`Légendes placées entre les commentaires et les enregistrements${up.tries > 1 ? ` (au ${up.tries}e essai)` : ''}.`); else { notes.push('légendes à remonter à la main'); log(`Légendes : ${(up && up.error) || 'remontée impossible'}. Fais glisser le cadre bleu vers le haut.`, 'warn'); await snapPage('tiktok', 'remontée des légendes'); }
          }
        }
      }
      if (wantSound) {
        const music = prod.source && prod.source.music && prod.source.music.title;
        const tries = [];
        // 1) le son de la vidéo d'origine, dans « Récent » (elle vient d'être ouverte) ; 2) ton son habituel, dans « Favoris » ; 3) le 1er favori
        if (prod.srcOpened) tries.push({ how: 'son de la vidéo d\'origine, onglet Récent', tab: 'recent', pick: music || '', orFirst: true });
        if (auto.tiktokSoundName) tries.push({ how: 'favori', tab: 'favorites', pick: auto.tiktokSoundName });
        tries.push({ how: '1er favori', tab: 'favorites' });
        let done = null; const why = [];
        for (const t of tries) { const r = await call('tiktok', 'tiktokSound', { tab: t.tab, pick: t.pick || '', orFirst: !!t.orFirst }).catch((e) => ({ ok: false, error: e.message })); if (r && r.ok) { done = { ...r, how: t.how }; break; } why.push(`${t.how} : ${(r && r.error) || 'échec'}`); if (r && r.noPanel) break; }
        if (done && Number.isFinite(Number(auto.tiktokVolume))) {
          const v = await call('tiktok', 'tiktokVolume', Number(auto.tiktokVolume)).catch((e) => ({ ok: false, error: e.message }));
          if (v && v.ok) log(`Volume du son réglé à ${auto.tiktokVolume} dB${v.already ? ' (il y était déjà)' : ''}.`);
          else { notes.push(`volume du son à mettre à ${auto.tiktokVolume} dB`); log(`Volume : ${(v && v.error) || 'échec'}.${v && v.see ? ` Vu dans le panneau : ${JSON.stringify(v.see).slice(0, 420)}` : ''}`, 'warn'); await snapPage('tiktok', 'volume', { erreur: (v && v.error) || 'échec', vu: (v && v.see) || null }); }
        }
        rc.sound = done ? { ok: true, why: `« ${done.name || '?'} »` } : { ok: false, why: why.join(' ; ') || 'échec' };
        if (done) { log(`Son : « ${done.name || '?'} » ajouté (${done.how}).${why.length ? ` Avant : ${why.join(' ; ')}.` : ''}`); if (done.how.includes('Récent') && music && done.picked === false) notes.push(`son à vérifier : j'ai pris le 1er de « Récent » (« ${done.name} »), le nom « ${music} » n'y était pas`); }
        else { notes.push('le son n\'a PAS été ajouté : choisis-le dans TikTok Studio, bouton « Sons »'); log(`Son NON ajouté (${why.join(' ; ')}). Choisis-le toi-même dans TikTok Studio, bouton « Sons », avant de publier.`, 'warn'); await snapPage('tiktok', 'son', { erreur: why }); }
      }
      const sv = await call('tiktok', 'tiktokClick', '^(enregistrer|save)$');
      if (!sv || !sv.ok) throw new Error('bouton « Enregistrer » de l\'éditeur introuvable');
      // retour à la page d'envoi en moins d'une seconde sur le vrai site ; une éventuelle confirmation est validée
      for (let i = 0; i < 12; i++) { await sleep(500); const st = await tkText(cfg).catch(() => null); if (st && !st.save) break; if (i === 5) await call('tiktok', 'tiktokClick', '^(enregistrer|save|confirmer|confirm)$').catch(() => null); }
    } catch (e) { for (const k of ['caps', 'sound']) if (!rc[k]) rc[k] = { ok: false, why: `éditeur TikTok interrompu (${e.message})` }; notes.push('édition TikTok à finir à la main'); log(`Éditeur TikTok : ${e.message}.`, 'warn'); await snapPage('tiktok', `éditeur : ${e.message}`); }
  }
  { // bilan de la préparation, en une ligne : ce qui est fait, ce qui ne l'est pas, et pourquoi
    const names = { desc: 'description', cover: 'couverture', caps: 'légendes', sound: 'son' };
    const parts = Object.keys(names).map((k) => { const x = rc[k]; return !x ? `${names[k]} : non tenté` : x.skip ? `${names[k]} : pas demandé (${x.why})` : x.ok ? `${names[k]} : fait${k === 'sound' && x.why ? ` (${x.why})` : ''}` : `${names[k]} : NON FAIT (${x.why})`; });
    const bad = Object.keys(names).some((k) => !rc[k] || (!rc[k].ok && !rc[k].skip));
    log(`Bilan TikTok Studio — ${parts.join(' · ')}.`, bad ? 'warn' : 'info');
  }
  prod.tiktokRecap = rc;
  prod.tiktokNotes = notes;
  } // prep
  prod.tiktokReady = Date.now(); prod.tiktokTab = tabs.tiktok;
  // 5. publication. Automatique (réglage, décoché par défaut) : seulement avec un compte de publication renseigné — il vient d'être vérifié dans
  //    TikTok Studio — et si tout a été préparé sans alerte. Au moindre point à vérifier (son manquant, légendes, couverture), on demande comme d'habitude.
  //    Une version de cette vidéo est déjà partie sur TikTok (montage ou préparation refaits ensuite) : jamais de 2e publication sans ton clic.
  let autoGo = !!auto.tiktokAutoPublish && !!want && !notes.length && !prod.publishedBefore;
  prod.pause = null; prod.publishCmd = autoGo ? 'publish' : null;
  if (autoGo) { // pas de carte « donne ton accord » pendant qu'il publie tout seul
    prod.gate = null; prod.status = 'running';
    log(`Tout est prêt dans TikTok Studio, sans alerte. Publication automatique (réglage) sur @${want} : j'appuie sur « Publier ».`);
    await save(true);
  } else {
    prod.gate = 'publish'; prod.status = 'waiting';
    log(`Tout est prêt dans TikTok Studio${notes.length ? ` (à vérifier : ${notes.join(' ; ')})` : ''}. Regarde l'onglet TikTok, puis autorise la publication dans FruitRadar.`);
    if (auto.tiktokAutoPublish) log(`Publication automatique non faite : ${prod.publishedBefore ? 'une version de cette vidéo a déjà été publiée' : !want ? 'aucun compte de publication renseigné (Réglages, « Mon compte »)' : `il reste à vérifier (${notes.join(' ; ')})`}. J'attends ton accord.`, 'warn');
    await save(true);
    if (notes.length) await notify('FruitRadar — vidéo prête, à vérifier avant de publier', `« ${prod.title} » : ${notes.join(' ; ')}.`, 'alert');
    else await notify('FruitRadar — la vidéo est prête à être publiée', `« ${prod.title} » est prête dans TikTok Studio. Il ne manque que ton accord pour publier.`, 'done');
  }
  for (;;) {
    if (autoGo) autoGo = false; // publication automatique : pas d'attente au premier passage
    else { if (prod.gate !== 'publish' || prod.status !== 'waiting') { prod.gate = 'publish'; prod.status = 'waiting'; prod.pause = null; await save(true); } await hold(); } // (re)demande ton accord : la carte « Prête à publier » est là
    if (stopFlag) throw new Stop('arrêt demandé');
    if (prod.publishCmd === 'skip' || prod.publishCmd === 'mine') { prod.publishSkipped = true; if (prod.publishCmd === 'mine') { prod.publishedByUser = Date.now(); log('Tu l\'as déjà publiée toi-même : je ne touche plus à TikTok.'); } break; } // « mine » : déjà publiée à la main
    if (prod.publishCmd !== 'publish') continue;
    const s = await tkText(cfg);
    if (!(await tabAlive('tiktok')) || !s.publish) { log('L\'onglet TikTok Studio n\'est plus sur la page d\'envoi : publie-la toi-même, ou relance cette étape.', 'warn'); prod.publishCmd = null; continue; }
    // Sécurité « bon compte » : on relit le compte connecté via l'API de TikTok (fiable, comme à la vérification du début), pas via le texte
    // de la page. On ne bloque QUE si l'API renvoie un compte réellement différent ; si elle ne répond pas, on publie (la vidéo, la description
    // et la couverture de CETTE production sont déjà en place dans cet onglet). Lire le handle dans le texte de la page donnait des faux positifs
    // (le compte est un avatar : le @handle est dans l'attribut alt, pas dans le texte, et il passe au-delà des 8000 premiers caractères).
    if (want) {
      const acc = await call('tiktok', 'tiktokAccount').catch(() => null);
      const got = acc && acc.ok ? String(acc.username || '').replace(/^@/, '').trim().toLowerCase() : '';
      if (got && got !== want) { await pause(`Le compte connecté dans TikTok Studio est @${got}, pas @${want} : rien n'est publié. Vérifie le compte, puis Reprendre`); continue; }
    }
    await chrome.tabs.update(tabs.tiktok, { active: true });
    // Le bouton Publier reste grisé tant que TikTok téléverse ou vérifie la vidéo : on attend qu'il se libère (3 minutes au plus)
    let p = null, told = false;
    for (let w = 0; w < (TEST ? 10 : 90); w++) {
      p = await call('tiktok', 'tiktokPublish').catch(() => null);
      if (!p || !p.off) break;
      if (!told) { told = true; log('TikTok : le bouton Publier est encore grisé (téléversement ou vérification en cours), j\'attends qu\'il se libère.'); }
      await sleep(TEST ? 200 : 2000);
    }
    if (!p || !p.ok) { log(p && p.off ? 'TikTok garde le bouton Publier grisé : regarde l\'onglet TikTok (un champ à compléter, une vérification en cours), puis reclique sur Publier ici.' : 'Bouton Publier introuvable : publie-la toi-même dans TikTok Studio.', 'warn'); await snapPage('tiktok', 'publier'); prod.publishCmd = null; continue; }
    // Publié pour de bon = TikTok quitte la page d'envoi, ou l'écrit. « En cours de publication » = il travaille encore : on attend, onglet ouvert.
    const look = async () => {
      if (!(await tabAlive('tiktok'))) return 'closed';
      const n = await tkText(cfg).catch(() => null); if (!n || !n.path) return 'unknown';
      if (!/\/upload/.test(n.path) || /(vidéo publiée|video published|a été publiée|has been published|publication réussie|successfully (posted|published))/i.test(n.text || '')) return 'done';
      if (/(en cours de publication|being (uploaded|posted|published)|publication en cours|posting|your video is being|ta vidéo est en cours)/i.test(n.text || '')) return 'posting';
      return n.publish ? 'no' : 'posting'; // plus de bouton Publier sur la page d'envoi : TikTok est en train de publier
    };
    let done = false, closed = false, again = false, postingAt = 0; const t0 = Date.now();
    for (;;) {
      await sleep(TEST ? 300 : 2000);
      const c = await call('tiktok', 'tiktokConfirm').catch(() => null);
      if (c && c.ok) { log(`TikTok demande une confirmation (« ${String(c.box || '').slice(0, 80)} ») : je clique sur « ${c.text} ».`); await sleep(TEST ? 200 : 2500); }
      const v = await look();
      if (v === 'done') { done = true; break; }
      if (v === 'closed') { closed = true; break; }
      if (v === 'posting') { // TikTok travaille : on attend la fin, 5 minutes au plus
        if (!postingAt) { postingAt = Date.now(); log('TikTok publie la vidéo : je garde l\'onglet ouvert jusqu\'à la fin.'); }
        if (Date.now() - postingAt > (TEST ? 6000 : 300000)) break;
        continue;
      }
      const waited = Date.now() - t0;
      if (!again && !postingAt && waited > (TEST ? 2500 : 40000)) { again = true; log('TikTok n\'a pas réagi au premier appui sur Publier, j\'appuie une deuxième fois.', 'warn'); await call('tiktok', 'tiktokPublish', true).catch(() => null); continue; }
      if (waited > (TEST ? 5000 : 80000)) break;
    }
    const posting = !!postingAt;
    if (closed) { log('L\'onglet TikTok Studio a été fermé pendant la publication : vérifie dans TikTok Studio, onglet Contenu, si la vidéo est partie.', 'warn'); prod.publishCmd = null; prod.tiktokReady = null; await save(true); await pause('L\'onglet TikTok Studio s\'est fermé pendant la publication. Vérifie dans TikTok Studio (Contenu) si la vidéo est publiée. Si oui, clique sur « Je publie moi-même » ; sinon clique sur Reprendre : je renvoie la vidéo'); return stepTiktok(); }
    if (!done && !posting) {
      await snapPage('tiktok', 'publication non confirmée');
      log('TikTok n\'a pas confirmé la publication : la vidéo est toujours sur la page d\'envoi. Tout est prêt dans l\'onglet TikTok : clique sur Publier là-bas, ou reclique sur Publier ici.', 'warn');
      await notify('FruitRadar — publication non confirmée', `« ${prod.title} » n'est pas partie : clique sur Publier dans l'onglet TikTok.`, 'alert').catch(() => {});
      prod.publishCmd = null; await save(true); continue;
    }
    if (!done) log('TikTok publie encore la vidéo : je laisse son onglet ouvert, ne le ferme pas avant la fin.', 'warn');
    prod.published = Date.now(); log('Publication lancée sur TikTok. Vérifie dans TikTok Studio, onglet Contenu.');
    chime('published'); // la petite fanfare : c'est bien parti
    break;
  }
  prod.gate = null; await save(true);
}

/* L'onglet TikTok Studio de l'ancienne version (montage ou préparation à refaire) : fermé tout de suite, pour qu'elle ne soit pas publiée par erreur */
async function dropTiktok() {
  let id = (await tabAlive('tiktok')) ? tabs.tiktok : null;
  if (id == null && prod.tiktokTab != null) { try { const t = await chrome.tabs.get(prod.tiktokTab); if (t && (TEST || /tiktok\.com\/tiktokstudio/.test(t.url || ''))) id = t.id; } catch (e) { /* déjà fermé */ } }
  delete tabs.tiktok; prod.tiktokTab = null;
  if (id == null) return;
  if (await shutTab(id)) log('Onglet TikTok Studio fermé : il contenait l\'ancienne version.');
  else log('L\'onglet TikTok Studio de l\'ancienne version est resté ouvert : ferme-le toi-même, et ne publie pas depuis celui-là.', 'warn');
}
/* ---------- déroulé ---------- */
async function run() {
  if (running) return; running = true; stopFlag = false; startedAt = Date.now();
  styleRefCache = undefined; // l'image du style est relue à chaque lancement (style ou réglage changé entre-temps)
  if (prod.id !== loadedId) { loadedId = prod.id; chatReady = false; chatPre = null; knownImg.clear(); } // nouvelle vidéo : nouvelle conversation ChatGPT
  auto = (await getSettings()).auto;
  winId = (await chrome.windows.getCurrent()).id;
  try { const me = await chrome.tabs.getCurrent(); if (me) await groupTab(me.id); } catch (e) { /* pas d'onglet courant */ }
  prod.status = 'running'; prod.pause = null; prod.stopping = null;
  log(prod.log.length ? 'Reprise de la production.' : 'Démarrage.');
  if (prod.dropTiktok) { prod.dropTiktok = null; await dropTiktok().catch(() => null); await save(true); }
  // Chien de garde : si rien n'avance depuis longtemps (aucune étape réussie), un vrai signal d'alerte, une seule fois par blocage.
  const wd = setInterval(() => {
    if (!prod || prod.status !== 'running') return;
    const lastOk = Math.max(startedAt, ...prod.log.filter((l) => l.level === 'info').map((l) => l.t));
    if (Date.now() - lastOk > (auto.watchdogMin || 60) * 60000 && prod.watchdogFor !== lastOk) {
      prod.watchdogFor = lastOk;
      log(`Rien n'a avancé depuis ${Math.round((Date.now() - lastOk) / 60000)} min : ça bloque sans doute. Regarde les onglets des sites.`, 'err');
      notify('FruitRadar — ça bloque ?', `« ${prod.title || 'La vidéo'} » n'avance plus depuis ${Math.round((Date.now() - lastOk) / 60000)} min. Regarde la fenêtre de l'automatisation.`, 'alert');
    }
  }, 60000);
  try {
    prod.tiktokFlow = auto.tiktokFlow !== false;
    const plan = [['source', stepSource], ['package', stepPackage], ['images', stepMake], ['capcut', stepCapcut]];
    if (prod.tiktokFlow) plan.push(['valider', async () => { if ((await stepMontage()) === 'redo') return 'redo'; await stepExport(); return stepValidate(); }], ['tiktok', stepTiktok]);
    for (let i = 0; i < plan.length; i++) {
      const [step, fn] = plan[i];
      prod.step = step; await save(true); draw();
      if ((await fn()) === 'redo') i = plan.findIndex((x) => x[0] === 'capcut') - 1; // « Refaire le montage » : retour à CapCut
    }
    prod.step = 'done'; prod.status = 'done'; prod.doneAt = Date.now();
    if (prod.tiktokFlow) {
      log(prod.published ? `Terminé : « ${prod.title} » a été envoyée à la publication sur TikTok.` : `Terminé : « ${prod.title} » est prête (publication faite par toi dans TikTok Studio).`);
      await save(true);
    } else {
      log(`Terminé : « ${prod.title} » est prête pour le montage.`);
      await save(true);
      await notify('FruitRadar — la vidéo est prête', `« ${prod.title} » : ${prod.pkg.scenes.length} clips ${prod.capcut && !prod.capcut.failed ? 'dans CapCut' : 'téléchargés'}, miniature et description prêtes.`, 'done');
      if (await tabAlive('capcut')) chrome.tabs.update(tabs.capcut, { active: true });
    }
  } catch (e) {
    if (e instanceof Stop) { prod.status = 'stopped'; prod.stopping = null; log('Mise de côté. Tu peux la continuer quand tu veux : elle reprendra où elle en était.', 'warn'); } else { prod.status = 'paused'; prod.pause = { reason: `Erreur inattendue : ${e.message}`, at: Date.now() }; log(`Erreur inattendue : ${e.message}`, 'err'); notify('FruitRadar — automatisation arrêtée', e.message); }
    await save(true);
  } finally { clearInterval(wd); running = false; draw(); }
  // Vidéo finie, ou mise de côté : la file d'attente avance toute seule.
  if (prod.status === 'done' || prod.status === 'stopped') await nextInQueue(prod.status === 'stopped');
}
/* File d'attente : les vidéos lancées pendant qu'une autre tourne s'enchaînent, la plus ancienne d'abord */
const queue = async () => (await DB.allProds()).filter((p) => p.status === 'queued' && (!running || p.id !== prod.id)).sort((a, b) => (a.queuedAt || a.createdAt || 0) - (b.queuedAt || b.createdAt || 0));
async function nextInQueue(quiet = false) {
  const q = await queue(); if (!q.length) return;
  if (!quiet) { log(`File d'attente : je passe à « ${q[0].title || 'la vidéo suivante'} » (${q.length - 1} autre${q.length > 2 ? 's' : ''} derrière).`); await save(true); }
  await new Promise((r) => setTimeout(r, TEST ? 1500 : 8000)); // attente simple : sleep() refuserait après un arrêt demandé
  if (running) return;
  prod = await DB.getProd(q[0].id); if (!prod || prod.status !== 'queued') return nextInQueue();
  draw(); run();
}

chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
  if (!msg || msg.type !== 'autoCmd') return false;
  (async () => {
    if (msg.cmd === 'ping') return { ok: true, id: prod && prod.id, running, status: prod && prod.status };
    if (msg.cmd === 'stop') { // « Mettre de côté » : visible tout de suite dans FruitRadar, l'arrêt réel suit dès la fin du geste en cours
      stopFlag = true; release(false);
      if (prod && running && !prod.stopping) { prod.stopping = Date.now(); log('Mise de côté demandée : j\'arrête dès que le geste en cours est fini.'); await save(true); }
      return { ok: true };
    }
    if (msg.cmd === 'import') { // « Importer » un clip pendant que la production tourne : ton fichier prend la place du clip, Grok ne le fabrique pas
      if (!prod || !running || (msg.id && prod.id !== msg.id)) return { ok: false, error: 'Cette production ne tourne pas en ce moment.' };
      const s = msg.kind === 'vid' && prod.pkg ? prod.pkg.scenes.find((x) => x.n === Number(msg.n)) : null;
      if (!s) return { ok: false, error: 'Pendant que la production tourne, seul un clip peut être importé. Pour une image ou une planche, mets-la d\'abord de côté.' };
      if (!clipsOpen && prod.step !== 'package' && prod.step !== 'source') return { ok: false, error: 'Les clips sont terminés pour cette production : mets-la d\'abord de côté, puis importe ton clip.' };
      if (grokLive.has(s.n)) return { ok: false, error: `Grok fabrique le clip de la scène ${s.n} en ce moment : attends qu'il ait fini, ou mets la production de côté.` };
      const blob = await media(msg.key); if (!blob) return { ok: false, error: 'Fichier importé introuvable.' };
      const info = await probeVideo(blob).catch(() => null);
      await closeTab(grokKey(s));
      s.vidKey = await keep(clipName(s), blob); s.vidStatus = 'done'; s.vidImported = true; s.grokSent = null; s.grokPost = null; prod.capcut = null;
      s.vidInfo = info ? { w: info.w, h: info.h, dur: Math.round(info.dur * 10) / 10 } : null;
      await DB.delMedia(msg.key).catch(() => {});
      log(`Scène ${s.n} : clip importé par toi${info ? ` (${info.w}×${info.h}, ${info.dur.toFixed(1)} s)` : ''}. Grok ne le fabriquera pas.`);
      await save(true); draw();
      return { ok: true };
    }
    if (msg.cmd === 'redo') { // « Refaire le clip » pendant que la production tourne : la scène repart chez Grok, tout le reste continue
      if (!prod || !running || (msg.id && prod.id !== msg.id)) return { ok: false, error: 'Cette production ne tourne pas en ce moment.' };
      const s = msg.kind === 'vid' && prod.pkg ? prod.pkg.scenes.find((x) => x.n === Number(msg.n)) : null;
      if (!s) return { ok: false, error: 'Pendant que la production tourne, seul un clip peut être refait. Pour le reste, mets-la d\'abord de côté.' };
      if (!clipsOpen) return { ok: false, error: 'Les clips sont terminés pour cette production : mets-la d\'abord de côté, puis clique sur « Refaire le clip ».' };
      if (grokLive.has(s.n)) return { ok: false, error: `Le clip de la scène ${s.n} est déjà en cours chez Grok.` };
      if (s.imgStatus !== 'done') return { ok: false, error: `L'image de la scène ${s.n} n'est pas encore prête.` };
      await closeTab(grokKey(s));
      s.vidStatus = 'todo'; s.vidInfo = null; s.grokSent = null; s.grokPost = null; prod.capcut = null;
      log(`Scène ${s.n} : clip à refaire (demandé dans FruitRadar). Je la relance chez Grok, le reste continue.`);
      await save(true); draw();
      return { ok: true };
    }
    if (msg.cmd === 'resume') {
      if (waiters.length && prod.status === 'paused') { release(); return { ok: true }; }
      if (!running && prod) { prod = await DB.getProd(prod.id); run(); return { ok: true }; }
      return { ok: false };
    }
    if (msg.cmd === 'choose') { if (waiters.length && prod.status === 'waiting') { prod.choice = Number(msg.n); prod.choiceNote = String(msg.text || '').trim(); prod.choiceEdit = P.cleanIdeaEdit(msg.edit); release(); return { ok: true }; } return { ok: false }; }
    if (msg.cmd === 'final') { // la vidéo finale déposée par toi (bouton ou glisser-déposer) : elle remplace l'export de CapCut, et vaut validation
      if (!prod || !running || (msg.id && prod.id !== msg.id)) return { ok: false, idle: true, error: 'Cette production ne tourne pas en ce moment.' };
      if (prod.step !== 'valider') return { ok: false, error: 'La vidéo finale se dépose une fois le montage CapCut fait.' };
      const key = `${prod.id}/final.mp4`, blob = await media(key);
      if (!blob) return { ok: false, error: 'Fichier déposé introuvable : dépose-le encore une fois.' };
      const info = await probeVideo(blob).catch(() => null);
      const head = [...new Uint8Array(await blob.slice(0, 12).arrayBuffer())].map((x) => (x >= 32 && x < 127 ? String.fromCharCode(x) : '.')).join('');
      if (!(info && info.dur) && !(/ftyp/.test(head) && blob.size > 300000)) return { ok: false, error: 'Ce fichier n\'est pas une vidéo lisible : dépose le .mp4 exporté de CapCut.' };
      const name = String(msg.text || '').replace(/[\u0000-\u001f]/g, '').slice(0, 120);
      prod.finalKey = key; prod.finalSaved = true; prod.validated = true; prod.finalDeposit = Date.now(); if (name) prod.exportFile = name;
      prod.finalInfo = info && info.dur ? { w: info.w, h: info.h, dur: Math.round(info.dur * 10) / 10, size: blob.size } : null;
      const mo = `${(blob.size / 1048576).toFixed(1).replace('.', ',')} Mo`;
      log(`Vidéo finale déposée par toi${name ? ` (« ${name} »)` : ''} : ${info && info.dur ? `${info.w}×${info.h}, ${info.dur.toFixed(1).replace('.', ',')} s, ` : ''}${mo}. Je continue vers TikTok Studio.`);
      if (prod.status === 'waiting' && prod.gate === 'validate') { prod.validateCmd = 'depot'; release(); }
      else if (prod.status === 'waiting' && prod.gate === 'montage') { prod.montageCmd = 'ok'; release(); } // exportée à la main : plus besoin de l'export automatique
      else if (prod.status === 'paused') release(); // une pause pendant l'export : la vidéo est là, on repart
      await save(true); draw();
      return { ok: true, info: prod.finalInfo };
    }
    if (msg.cmd === 'gate') { // validation de la vidéo / autorisation de publier, depuis le dashboard
      if (!prod || prod.status !== 'waiting' || !prod.gate) return { ok: false, error: 'Rien n\'attend ton accord pour le moment.' };
      if (msg.n === 'show') { if (!(await tabAlive('capcut'))) return { ok: false, error: 'L\'onglet CapCut est fermé : utilise « Refaire le montage ».' }; const t = await chrome.tabs.update(tabs.capcut, { active: true }); await chrome.windows.update(t.windowId, { focused: true }).catch(() => null); return { ok: true }; }
      if (prod.gate === 'montage') prod.montageCmd = msg.text;
      else if (prod.gate === 'validate') { prod.validateCmd = msg.text; if (msg.text === 'ok' && !prod.finalKey) return { ok: false, error: 'Dépose d\'abord la vidéo exportée.' }; }
      else if (prod.gate === 'publish') prod.publishCmd = msg.text;
      release(); return { ok: true };
    }
    if (msg.cmd === 'more') { if (waiters.length && prod.status === 'waiting') { prod.moreAsk = { text: String(msg.text || '').trim() }; release(); return { ok: true }; } return { ok: false, error: prod && prod.ideasBusy ? 'Claude écrit déjà de nouvelles idées.' : 'Rien à relancer pour l\'instant.' }; }
    if (msg.cmd === 'load') { // nouvelle production ou relance, quand la fenêtre est libre
      if (running) { const q = await queue(); const pos = q.findIndex((p) => p.id === msg.id) + 1; return pos ? { ok: true, queued: true, pos } : { ok: false, error: 'Une automatisation est déjà en cours.' }; }
      prod = await DB.getProd(msg.id); if (!prod) return { ok: false, error: 'Production introuvable.' };
      run(); return { ok: true };
    }
    return { ok: false };
  })().then(sendResponse).catch((e) => sendResponse({ ok: false, error: e.message }));
  return true;
});

(async function init() {
  // Une seule fenêtre pilote à la fois : une 2e fenêtre sur la même production refaisait les mêmes planches et les mêmes clips.
  if (navigator.locks) {
    const got = await new Promise((res) => {
      navigator.locks.request('fruitradar-pilote', { ifAvailable: true }, (lock) => {
        res(!!lock);
        return lock ? new Promise(() => {}) : null; // le verrou reste pris tant que cette fenêtre est ouverte
      }).catch(() => res(true));
    });
    if (got === false) { document.title = 'FruitRadar — déjà ouvert'; $('#title').textContent = 'Une fenêtre d\'automatisation est déjà ouverte : celle-ci ne fait rien.'; setTimeout(() => window.close(), 4000); return; }
  }
  $('#btnResume').onclick = () => { release(); };
  { // « Arrêter » se confirme par un second clic sur le même bouton. Jamais de boîte native (confirm) : tant qu'elle est ouverte, Chrome fige toutes les pages de FruitRadar, le tableau de bord compris.
    const b = $('#btnStop'); let armed = 0, t = null;
    const idle = () => { armed = 0; clearTimeout(t); b.textContent = 'Arrêter'; b.classList.remove('armed'); };
    b.onclick = () => {
      if (armed && Date.now() < armed) { idle(); stopFlag = true; release(false); return; }
      armed = Date.now() + 6000; b.textContent = 'Confirmer l\'arrêt (tout est gardé)'; b.classList.add('armed'); clearTimeout(t); t = setTimeout(idle, 6000);
    };
  }
  $('#btnDash').onclick = () => chrome.runtime.sendMessage({ type: 'openDashboard', hash: 'auto' });
  // pas de boîte « Quitter le site ? » à la fermeture : elle aussi figeait tout FruitRadar. Fermer cette fenêtre met la vidéo de côté ; « Continuer » la reprend où elle en était.
  const id = new URLSearchParams(location.search).get('id');
  prod = id ? await DB.getProd(id) : null;
  if (!prod) { $('#title').textContent = 'Aucune production à lancer'; return; }
  draw();
  if (prod.status !== 'done') run(); else nextInQueue();
})();
